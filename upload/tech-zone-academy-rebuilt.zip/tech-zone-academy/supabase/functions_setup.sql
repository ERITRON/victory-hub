-- supabase/functions_setup.sql
--
-- Run this AFTER deploying the Edge Functions:
--   supabase functions deploy on-document-change
--   supabase functions deploy process-scheduled-notifications
--   supabase functions deploy cleanup-expired-notifications
--
-- Replace YOUR_PROJECT_REF below with your Supabase project ref
-- (the "qsofrmhvohjlkyubghbr" part of your project URL), and set
-- app.settings.service_role_key first (Dashboard -> Project Settings ->
-- Database -> Custom Config, or via `alter database postgres set ...`)
-- so these triggers/cron jobs can authenticate to your functions.

create extension if not exists pg_net;
create extension if not exists pg_cron;

-- ============================================
-- 1) Database Webhook: documents table -> on-document-change
--    (equivalent to Firestore's onDocumentCreated/onDocumentUpdated)
-- ============================================
-- Easiest path: Dashboard -> Database -> Webhooks -> Create a new hook
--   Table: documents | Events: Insert, Update
--   Type: Supabase Edge Functions | Function: on-document-change
-- That's it — skip the SQL below if you use the Dashboard UI.
--
-- Equivalent raw SQL (if you'd rather not use the Dashboard UI):
create or replace function public.notify_document_change()
returns trigger as $$
declare
  payload jsonb;
begin
  payload := jsonb_build_object(
    'type', tg_op,
    'table', tg_table_name,
    'record', case when tg_op in ('INSERT', 'UPDATE') then to_jsonb(new) else null end,
    'old_record', case when tg_op in ('UPDATE', 'DELETE') then to_jsonb(old) else null end
  );
  perform net.http_post(
    url := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/on-document-change',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || current_setting('app.settings.service_role_key', true)
    ),
    body := payload
  );
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists documents_notify_trigger on documents;
create trigger documents_notify_trigger
  after insert or update on documents
  for each row execute function public.notify_document_change();

-- ============================================
-- 2) Cron: process-scheduled-notifications every 15 minutes
--    (equivalent to onSchedule("every 15 minutes"))
-- ============================================
select cron.schedule(
  'process-scheduled-notifications',
  '*/15 * * * *',
  $$
  select net.http_post(
    url := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/process-scheduled-notifications',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || current_setting('app.settings.service_role_key', true)
    )
  );
  $$
);

-- ============================================
-- 3) Cron: cleanup-expired-notifications daily at 03:00
--    (equivalent to onSchedule("every day 03:00"))
-- ============================================
select cron.schedule(
  'cleanup-expired-notifications',
  '0 3 * * *',
  $$
  select net.http_post(
    url := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/cleanup-expired-notifications',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || current_setting('app.settings.service_role_key', true)
    )
  );
  $$
);

-- To remove a scheduled job later: select cron.unschedule('job-name');
