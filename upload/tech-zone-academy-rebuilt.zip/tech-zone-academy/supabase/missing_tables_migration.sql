-- supabase/missing_tables_migration.sql
--
-- The frontend references a few collections that either had no table
-- mapping at all, or resolved to a mixed-case table name that Postgres/
-- PostgREST cannot match (e.g. "vicePrincipals"). This migration creates
-- those tables if they don't already exist. It is safe to run even if
-- some of them are already present — everything is IF NOT EXISTS.
--
-- Run this in the Supabase SQL editor.

create extension if not exists pgcrypto;

-- ============================================
-- gallery_videos  (src/pages/public/Gallery.jsx)
-- ============================================
create table if not exists gallery_videos (
  id          text primary key default gen_random_uuid()::text,
  title       text,
  video_url   text,
  thumbnail_url text,
  album_id    text,
  date        date default now(),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- ============================================
-- assignment_submissions
-- (src/pages/parents/ParentDashboard.jsx, src/pages/students/StudentAssignments.jsx)
-- ============================================
create table if not exists assignment_submissions (
  id            text primary key default gen_random_uuid()::text,
  assignment_id text,
  student_id    text,
  student_name  text,
  file_url      text,
  status        text default 'submitted',
  grade         text,
  remark        text,
  submitted_at  timestamptz default now(),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- ============================================
-- librarians  (role profile created by AuthContext.createRoleProfile)
-- ============================================
create table if not exists librarians (
  id            text primary key,          -- matches auth.users uid
  "userId"      text,
  email         text,
  "firstName"   text,
  "lastName"    text,
  phone         text,
  address       text,
  "librarianId" text,
  "createdBy"   text,
  "createdByRole" text,
  "createdAt"   timestamptz,
  status        text default 'active',
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- ============================================
-- vice_principals  (role profile created by AuthContext.createRoleProfile)
-- ============================================
create table if not exists vice_principals (
  id            text primary key,          -- matches auth.users uid
  "userId"      text,
  email         text,
  "firstName"   text,
  "lastName"    text,
  phone         text,
  address       text,
  "employeeId"  text,
  department    text,
  "createdBy"   text,
  "createdByRole" text,
  "createdAt"   timestamptz,
  status        text default 'active',
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- ============================================
-- Row Level Security (mirrors the permissive policy pattern already
-- used elsewhere in schema.sql — tighten later for production)
-- ============================================
alter table gallery_videos enable row level security;
alter table assignment_submissions enable row level security;
alter table librarians enable row level security;
alter table vice_principals enable row level security;

do $$
begin
  if not exists (select 1 from pg_policies where tablename = 'gallery_videos' and policyname = 'authenticated_all_gallery_videos') then
    create policy "authenticated_all_gallery_videos" on gallery_videos for all to authenticated using (true) with check (true);
  end if;
  if not exists (select 1 from pg_policies where tablename = 'gallery_videos' and policyname = 'public_read_gallery_videos') then
    create policy "public_read_gallery_videos" on gallery_videos for select to anon using (true);
  end if;

  if not exists (select 1 from pg_policies where tablename = 'assignment_submissions' and policyname = 'authenticated_all_assignment_submissions') then
    create policy "authenticated_all_assignment_submissions" on assignment_submissions for all to authenticated using (true) with check (true);
  end if;

  if not exists (select 1 from pg_policies where tablename = 'librarians' and policyname = 'authenticated_all_librarians') then
    create policy "authenticated_all_librarians" on librarians for all to authenticated using (true) with check (true);
  end if;

  if not exists (select 1 from pg_policies where tablename = 'vice_principals' and policyname = 'authenticated_all_vice_principals') then
    create policy "authenticated_all_vice_principals" on vice_principals for all to authenticated using (true) with check (true);
  end if;
end $$;
