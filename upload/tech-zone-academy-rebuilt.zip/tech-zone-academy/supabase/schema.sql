-- supabase/schema.sql
--
-- Run this in your Supabase project's SQL Editor (or via `supabase db push`)
-- before running the app. It creates the document-store table that
-- src/supabase/supabase.js uses to emulate Firestore's collection/doc API
-- on top of real Postgres.

create extension if not exists pgcrypto;

create table if not exists documents (
  collection  text        not null,
  id          text        not null,
  data        jsonb       not null default '{}'::jsonb,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  primary key (collection, id)
);

create index if not exists documents_collection_idx on documents (collection);
create index if not exists documents_data_gin_idx on documents using gin (data);

-- ============================================
-- Row Level Security
-- ============================================
-- Starting point: logged-in (authenticated) users can read/write everything,
-- and a few collections that power the public marketing site (news,
-- gallery, events, website settings, admissions info, statistics) are
-- readable by anyone, even signed out.
--
-- This is intentionally permissive so the app works immediately. Before
-- going to production, tighten these per-collection to match who should
-- actually be able to read/write each one (e.g. a student shouldn't be
-- able to edit other students' grades).

alter table documents enable row level security;

create policy "Authenticated users can read all documents"
  on documents for select
  to authenticated
  using (true);

create policy "Authenticated users can write all documents"
  on documents for insert
  to authenticated
  with check (true);

create policy "Authenticated users can update all documents"
  on documents for update
  to authenticated
  using (true)
  with check (true);

create policy "Authenticated users can delete all documents"
  on documents for delete
  to authenticated
  using (true);

create policy "Public can read public-facing content"
  on documents for select
  to anon
  using (
    collection in (
      'news',
      'galleryAlbums',
      'galleryImages',
      'events',
      'announcements',
      'websiteSettings',
      'schoolSettings',
      'admissions'
    )
  );

-- ============================================
-- Storage bucket (mirrors the old Firebase Storage bucket)
-- ============================================
-- Create this once, either here or in the Supabase Dashboard
-- (Storage -> New bucket -> name it "uploads"):
--
-- insert into storage.buckets (id, name, public)
-- values ('uploads', 'uploads', false)
-- on conflict (id) do nothing;
--
-- Then add storage policies for the "uploads" bucket allowing
-- authenticated users to upload/read/delete, e.g.:
--
-- create policy "Authenticated users can upload"
--   on storage.objects for insert to authenticated
--   with check (bucket_id = 'uploads');
--
-- create policy "Authenticated users can read"
--   on storage.objects for select to authenticated
--   using (bucket_id = 'uploads');
--
-- create policy "Authenticated users can delete"
--   on storage.objects for delete to authenticated
--   using (bucket_id = 'uploads');
