// supabase/functions/on-document-change/index.ts
//
// Ported from the Firestore-trigger functions in functions/src/index.js
// (onUserCreated, onUserApproved, onResultPublished, onResultUpdated,
// onAssignmentUploaded, onAttendanceMarked, onAnnouncementPublished,
// onNotificationEvent). Payment/finance triggers were dropped along
// with the finance module.
//
// Wire this up as a Supabase Database Webhook (Dashboard -> Database ->
// Webhooks) on the `documents` table, for INSERT and UPDATE, pointing
// at this function. See supabase/webhooks.sql for the equivalent SQL
// if you'd rather set it up that way.

import { deliver, deliverToRoles, resolveStudent, resolveParents, usersByIds, usersByRole, clean, fullName } from "../_shared/notify.ts";
import { NOTIFICATION_CATALOG } from "../_shared/notificationCatalog.ts";
import { supabaseAdmin, TABLE } from "../_shared/supabaseAdmin.ts";

interface WebhookPayload {
  type: "INSERT" | "UPDATE" | "DELETE";
  table: string;
  record?: { collection: string; id: string; data: Record<string, any> };
  old_record?: { collection: string; id: string; data: Record<string, any> };
}

async function notifyResult(result: Record<string, any>, resultId: string, eventKey: string) {
  const student = await resolveStudent(result.studentId);
  if (!student) {
    console.warn("Result recipient not found", resultId);
    return;
  }
  const score = result.score != null && result.outOf != null ? ` Score: ${result.score}/${result.outOf}.` : "";
  const payload = {
    title: "New result published",
    message: `Your ${result.subject || "subject"} result for ${result.assessment || "an assessment"} has been published.${score}`,
    link: "/student-results",
    relatedId: resultId,
    relatedType: "result",
    sender: result.teacherName,
    senderId: result.teacherId,
  };
  const parents = await resolveParents(student);
  await Promise.all([
    deliver("result_published", [{ id: student.id, ...student }], payload, eventKey),
    deliver(
      "child_result",
      parents,
      { ...payload, title: `${fullName(student) || result.studentName || "Your child"}'s result published`, link: "/parent-results" },
      `parent-${eventKey}`
    ),
  ]);
}

async function handleUsersInsert(user: { id: string; data: Record<string, any> }) {
  const u = { id: user.id, ...user.data };
  await Promise.all([
    deliver("account_created", [u], {
      title: "Account created",
      message: "Your Tech Zone Academy account has been created.",
      link: "/profile",
      relatedId: u.id,
      relatedType: "user",
    }, `user-created:${u.id}`),
    deliverToRoles("new_user_registration", ["admin"], {
      title: "New user registration",
      message: `${u.email || fullName(u) || "A new user"} registered as ${u.role || "a user"}.`,
      link: "/admin-approval",
      relatedId: u.id,
      relatedType: "user",
    }, `user-registration:${u.id}`),
    deliverToRoles("pending_approval", ["admin"], {
      title: "Account awaiting approval",
      message: `${u.email || fullName(u) || "A new account"} needs review.`,
      link: "/admin-approval",
      priority: "high",
      relatedId: u.id,
      relatedType: "user",
    }, `pending-approval:${u.id}`),
  ]);
}

async function handleUsersUpdate(before: Record<string, any>, after: Record<string, any>, userId: string) {
  const justApproved =
    after.status === "active" && (before.status !== "active" || before.approved !== true) && after.approved === true;
  if (!justApproved) return;
  await deliver("account_approved", [{ id: userId, ...after }], {
    title: "Account approved",
    message: "Your account has been approved. You can now access Tech Zone Academy.",
    link: "/login",
    priority: "high",
    relatedId: userId,
    relatedType: "user",
  }, `approved:${userId}`);
}

async function handleAssignmentUploaded(id: string, assignment: Record<string, any>) {
  const filters: Record<string, string> = { "data->>grade": assignment.grade };
  let query = supabaseAdmin.from(TABLE).select("*").eq("collection", "students").eq("data->>grade", assignment.grade);
  if (assignment.section) query = query.eq("data->>section", assignment.section);
  const { data: rows } = await query;
  const students = (rows ?? []).map((r: any) => ({ id: r.id, ...r.data }));
  const parents = (await Promise.all(students.map(resolveParents))).flat();
  const payload = {
    title: "New assignment uploaded",
    message: `${assignment.title || "A new assignment"} was posted for ${assignment.subject || assignment.grade || "your class"}.`,
    link: "/student-assignments",
    relatedId: id,
    relatedType: "assignment",
    sender: assignment.teacherName,
    senderId: assignment.teacherId,
  };
  await Promise.all([
    deliver("assignment_uploaded", students, payload, `assignment:${id}`),
    deliver("child_assignment", parents, { ...payload, link: "/parent-dashboard" }, `parent-assignment:${id}`),
  ]);
}

async function handleAttendanceMarked(id: string, attendance: Record<string, any>) {
  const student = await resolveStudent(attendance.studentId);
  if (!student) return;
  const isAlert = ["absent", "late"].includes(clean(attendance.status).toLowerCase());
  await Promise.all([
    deliver("attendance_marked", [{ id: student.id, ...student }], {
      title: "Attendance marked",
      message: `Your attendance for ${attendance.date || "today"} was marked ${attendance.status || "recorded"}.`,
      link: "/student-attendance",
      relatedId: id,
      relatedType: "attendance",
    }, `attendance:${id}`),
    isAlert
      ? resolveParents(student).then((parents) =>
          deliver("child_attendance", parents, {
            title: `${fullName(student) || attendance.studentName || "Your child"} marked ${attendance.status}`,
            message: `Attendance for ${attendance.date || "today"} was marked ${attendance.status}.`,
            link: "/parent-attendance",
            priority: "high",
            relatedId: id,
            relatedType: "attendance",
          }, `parent-attendance:${id}`)
        )
      : Promise.resolve(),
  ]);
}

async function handleAnnouncementPublished(id: string, announcement: Record<string, any>) {
  const payload = {
    title: announcement.title || "School announcement",
    message: clean(announcement.content).slice(0, 240),
    link: "/",
    priority: announcement.priority || "normal",
    expiresAt: announcement.expiresAt || null,
    relatedId: id,
    relatedType: "announcement",
    sender: announcement.createdByName,
    senderId: announcement.createdBy,
  };
  await Promise.all([
    deliverToRoles("student_announcement", ["student"], payload, `announcement-student:${id}`),
    deliverToRoles("teacher_announcement", ["teacher"], payload, `announcement-teacher:${id}`),
    deliverToRoles("parent_announcement", ["parent"], payload, `announcement-parent:${id}`),
    deliverToRoles("vp_announcement", ["vice_principal"], payload, `announcement-vp:${id}`),
  ]);
}

async function handleNotificationEvent(id: string, data: Record<string, any>) {
  const policy = NOTIFICATION_CATALOG[data.type];
  if (!policy) {
    console.error("Rejected unknown notification event", data.type);
    return;
  }
  const roles = policy.role === "all" ? [] : [policy.role];
  const directRecipients = (await usersByIds(data.targetUserIds || [])).filter(
    (u) => policy.role === "all" || u.role === policy.role
  );
  const recipients = [...directRecipients, ...(await usersByRole(roles))];
  await deliver(data.type, recipients, data, `event:${id}`);
  await supabaseAdmin
    .from(TABLE)
    .update({ data: { ...data, processedAt: new Date().toISOString(), recipientCount: recipients.length } })
    .eq("collection", "notificationEvents")
    .eq("id", id);
}

Deno.serve(async (req) => {
  try {
    const payload: WebhookPayload = await req.json();
    const row = payload.record ?? payload.old_record;
    if (!row) return new Response("ok", { status: 200 });

    const { collection, id, data } = row;

    if (collection === "users" && payload.type === "INSERT") {
      await handleUsersInsert({ id, data });
    } else if (collection === "users" && payload.type === "UPDATE") {
      await handleUsersUpdate(payload.old_record?.data ?? {}, data, id);
    } else if (collection === "results" && payload.type === "INSERT") {
      await notifyResult(data, id, `result:${id}`);
    } else if (collection === "results" && payload.type === "UPDATE") {
      const before = payload.old_record?.data ?? {};
      if (before.score !== data.score || before.outOf !== data.outOf || before.assessment !== data.assessment) {
        await notifyResult(data, id, `result-update:${id}:${Date.now()}`);
      }
    } else if (collection === "teacherAssignmentsUploads" && payload.type === "INSERT") {
      await handleAssignmentUploaded(id, data);
    } else if (collection === "attendance" && payload.type === "INSERT") {
      await handleAttendanceMarked(id, data);
    } else if (collection === "announcements" && payload.type === "INSERT") {
      await handleAnnouncementPublished(id, data);
    } else if (collection === "notificationEvents" && payload.type === "INSERT") {
      await handleNotificationEvent(id, data);
    }

    return new Response("ok", { status: 200 });
  } catch (error) {
    console.error("on-document-change error:", error);
    return new Response(String(error), { status: 500 });
  }
});
