// supabase/functions/cleanup-expired-notifications/index.ts
//
// Ported from functions/src/index.js's cleanupExpiredNotifications
// (was: onSchedule "every day 03:00"). Schedule this function with
// pg_cron — see supabase/functions_setup.sql.

import { supabaseAdmin, TABLE } from "../_shared/supabaseAdmin.ts";

Deno.serve(async (req) => {
  try {
    const authHeader = req.headers.get("Authorization") || "";
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (serviceRoleKey && authHeader !== `Bearer ${serviceRoleKey}`) {
      return new Response("Unauthorized", { status: 401 });
    }

    const now = new Date().toISOString();
    const { data: expired, error: selectError } = await supabaseAdmin
      .from(TABLE)
      .select("collection, id")
      .eq("collection", "notifications")
      .not("data->>expiresAt", "is", null)
      .lte("data->>expiresAt", now)
      .limit(500);
    if (selectError) throw selectError;

    if (expired && expired.length > 0) {
      // Delete in batches keyed by (collection, id) composite primary key.
      for (const row of expired) {
        await supabaseAdmin.from(TABLE).delete().eq("collection", row.collection).eq("id", row.id);
      }
    }

    return new Response(JSON.stringify({ deleted: expired?.length ?? 0 }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("cleanup-expired-notifications error:", error);
    return new Response(String(error), { status: 500 });
  }
});
