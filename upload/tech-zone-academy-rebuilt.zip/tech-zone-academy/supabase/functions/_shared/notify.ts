// supabase/functions/_shared/notify.ts
//
// Ported from functions/src/index.js (Firebase Cloud Functions).
// Same behavior, backed by the `documents` table instead of Firestore.

import { supabaseAdmin, TABLE } from "./supabaseAdmin.ts";
import { NOTIFICATION_CATALOG } from "./notificationCatalog.ts";

const icons: Record<string, string> = {
  account: "👤",
  academic: "📚",
  attendance: "📋",
  administrative: "📢",
  discipline: "⚠️",
  library: "📖",
};

export async function digest(value: string): Promise<string> {
  const data = new TextEncoder().encode(value);
  const hashBuffer = await crypto.subtle.digest("SHA-1", data);
  return [...new Uint8Array(hashBuffer)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

export function clean(value: unknown): string {
  return String(value ?? "").trim();
}

export function fullName(data: Record<string, any> = {}): string {
  return clean(data.fullName || [data.firstName, data.fatherName].filter(Boolean).join(" "));
}

interface Recipient {
  id: string;
  email?: string;
  role?: string;
  notificationPreferences?: { email?: boolean; inApp?: boolean };
  [key: string]: any;
}

async function fetchDocs(collection: string, filters: (q: any) => any) {
  let query = supabaseAdmin.from(TABLE).select("*").eq("collection", collection);
  query = filters(query);
  const { data, error } = await query;
  if (error) throw error;
  return (data ?? []).map((row: any) => ({ id: row.id, ...row.data }));
}

export async function usersByRole(roles: string[]): Promise<Recipient[]> {
  if (roles.length === 0) return [];
  const results = await Promise.all(
    roles.map((role) =>
      fetchDocs("users", (q) => q.eq("data->>role", role).eq("data->>status", "active"))
    )
  );
  const recipients = new Map<string, Recipient>();
  results.flat().forEach((user: any) => recipients.set(user.id, user));
  return [...recipients.values()];
}

export async function usersByIds(ids: (string | undefined | null)[]): Promise<Recipient[]> {
  const uniqueIds = [...new Set(ids.filter(Boolean))] as string[];
  if (uniqueIds.length === 0) return [];
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select("*")
    .eq("collection", "users")
    .in("id", uniqueIds);
  if (error) throw error;
  return (data ?? []).map((row: any) => ({ id: row.id, ...row.data }));
}

export async function resolveStudent(studentId?: string | null) {
  if (!studentId) return null;
  const { data: direct } = await supabaseAdmin
    .from(TABLE)
    .select("*")
    .eq("collection", "students")
    .eq("id", studentId)
    .maybeSingle();
  if (direct) return { id: direct.id, ...direct.data };

  const matches = await fetchDocs("students", (q) => q.eq("data->>studentId", studentId).limit(1));
  return matches[0] ?? null;
}

export async function resolveParents(student: Record<string, any> | null): Promise<Recipient[]> {
  if (!student) return [];
  const recipients = new Map<string, Recipient>(
    (await usersByIds([student.parentId])).map((u) => [u.id, u])
  );
  if (student.parentEmail) {
    const matches = await fetchDocs("users", (q) => q.eq("data->>email", student.parentEmail).limit(5));
    matches.forEach((user: any) => {
      if (user.role === "parent") recipients.set(user.id, user);
    });
  }
  return [...recipients.values()];
}

async function sendEmail(to: string, subject: string, text: string, html: string) {
  const apiKey = Deno.env.get("RESEND_API_KEY");
  const from = Deno.env.get("EMAIL_FROM") || "Tech Zone Academy <no-reply@techzone.com>";
  if (!apiKey) {
    // Not configured — email stays queued in the `mail` collection only.
    return;
  }
  await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ from, to: [to], subject, text, html }),
  });
}

async function queueEmail(user: Recipient, notification: Record<string, any>, eventKey: string) {
  if (!user.email || user.notificationPreferences?.email === false) return;
  const emailId = await digest(`email:${eventKey}:${user.id}:${notification.type}`);
  const subject = notification.title;
  const text = `${notification.message}\n\nOpen Tech Zone Academy to view the details.`;
  const html = `<h2>${notification.title}</h2><p>${notification.message}</p><p>Sign in to Tech Zone Academy to view the details.</p>`;

  await supabaseAdmin.from(TABLE).upsert(
    {
      collection: "mail",
      id: emailId,
      data: { to: [user.email], subject, text, html, notificationType: notification.type, userId: user.id },
      updated_at: new Date().toISOString(),
    },
    { onConflict: "collection,id" }
  );

  await sendEmail(user.email, subject, text, html);
}

export async function deliver(
  type: string,
  recipients: (Recipient | null | undefined)[],
  payload: Record<string, any>,
  eventKey: string
) {
  const policy = NOTIFICATION_CATALOG[type];
  if (!policy) throw new Error(`Unknown notification type: ${type}`);
  const unique = new Map<string, Recipient>();
  recipients.filter(Boolean).forEach((r) => unique.set((r as Recipient).id, r as Recipient));

  const jobs: Promise<any>[] = [];
  for (const user of unique.values()) {
    if (user.notificationPreferences?.inApp === false) continue;
    const notification = {
      userId: user.id,
      type,
      title: clean(payload.title) || "Tech Zone Academy update",
      message: clean(payload.message),
      body: clean(payload.body || payload.message),
      link: payload.link || null,
      read: false,
      readAt: null,
      createdAt: new Date().toISOString(),
      expiresAt: payload.expiresAt || null,
      priority: ["normal", "high", "urgent"].includes(payload.priority) ? payload.priority : "normal",
      category: policy.category,
      icon: payload.icon || icons[policy.category],
      color: payload.color || null,
      relatedId: payload.relatedId || null,
      relatedType: payload.relatedType || null,
      action: payload.action || null,
      actionLabel: payload.actionLabel || null,
      sender: payload.sender || "Tech Zone Academy",
      senderId: payload.senderId || null,
      channels: policy.channels,
      timing: policy.timing,
    };
    const id = await digest(`${eventKey}:${user.id}:${type}`);
    jobs.push(
      supabaseAdmin.from(TABLE).upsert(
        { collection: "notifications", id, data: notification, updated_at: new Date().toISOString() },
        { onConflict: "collection,id" }
      )
    );
    if (policy.channels.includes("email")) jobs.push(queueEmail(user, notification, eventKey));
  }
  await Promise.all(jobs);
}

export async function deliverToRoles(
  type: string,
  roles: string[],
  payload: Record<string, any>,
  eventKey: string
) {
  return deliver(type, await usersByRole(roles), payload, eventKey);
}
