// supabase/functions/_shared/notificationCatalog.ts
//
// Ported from the old functions/src/notificationCatalog.js (Firebase).
// Finance/cashier-only notification types (payment_receipt, cashier_*,
// admin_payment, monthly_revenue, large_payment, financial_report,
// audit_report, daily_payment_summary, student_fee_reminder,
// parent_fee_due, fine_payment, fee_structure_update, invoice_generated,
// payment_status, payment_failed, payment_discrepancy) were removed
// along with the finance module.

export type Channel = "in_app" | "email";
export type Timing =
  | "immediate"
  | "daily"
  | "weekly"
  | "monthly"
  | "end_of_day"
  | "end_of_month"
  | "end_of_term"
  | "yearly"
  | "annually"
  | "before_event"
  | "on_view"
  | "on_add"
  | "on_completion"
  | "morning";

export interface NotificationPolicy {
  role: string; // "all" or a specific role
  category: "account" | "academic" | "attendance" | "administrative" | "discipline" | "library";
  timing: Timing;
  channels: Channel[];
}

const IN_APP: Channel[] = ["in_app"];
const IMPORTANT: Channel[] = ["in_app", "email"];

function n(
  role: string,
  category: NotificationPolicy["category"],
  timing: Timing = "immediate",
  channels: Channel[] = IN_APP
): NotificationPolicy {
  return { role, category, timing, channels };
}

export const NOTIFICATION_CATALOG: Record<string, NotificationPolicy> = {
  account_created: n("all", "account"),
  account_approved: n("all", "account", "immediate", IMPORTANT),
  password_changed: n("all", "account", "immediate", IMPORTANT),

  result_published: n("student", "academic", "immediate", IMPORTANT),
  attendance_marked: n("student", "attendance", "daily"),
  assignment_uploaded: n("student", "academic"),
  low_attendance_warning: n("student", "attendance", "weekly", IMPORTANT),
  top_performer: n("student", "academic", "end_of_term"),
  student_announcement: n("student", "administrative"),
  exam_schedule: n("student", "academic", "before_event"),
  library_book_due: n("student", "library", "daily"),
  student_schedule_change: n("student", "administrative"),

  student_result_viewed: n("teacher", "academic", "on_view"),
  class_attendance_summary: n("teacher", "attendance", "end_of_day"),
  new_student: n("teacher", "administrative"),
  teacher_schedule_change: n("teacher", "administrative"),
  teacher_announcement: n("teacher", "administrative"),
  parent_message: n("teacher", "administrative"),
  assignment_submitted: n("teacher", "academic"),
  teacher_student_concern: n("teacher", "discipline"),
  staff_meeting: n("teacher", "administrative"),
  teacher_performance_review: n("teacher", "administrative", "monthly"),

  child_attendance: n("parent", "attendance", "daily", IMPORTANT),
  child_result: n("parent", "academic", "immediate", IMPORTANT),
  child_assignment: n("parent", "academic"),
  child_concern: n("parent", "discipline", "immediate", IMPORTANT),
  parent_announcement: n("parent", "administrative"),
  parent_meeting: n("parent", "administrative"),
  school_event: n("parent", "administrative", "before_event"),
  report_card: n("parent", "academic", "end_of_term", IMPORTANT),

  new_user_registration: n("admin", "account"),
  pending_approval: n("admin", "account"),
  teacher_request: n("admin", "administrative"),
  overall_low_attendance: n("admin", "attendance", "weekly", IMPORTANT),
  admin_discipline_incident: n("admin", "discipline", "immediate", IMPORTANT),
  announcement_feedback: n("admin", "administrative", "on_view"),
  report_generated: n("admin", "administrative", "on_completion"),
  parent_complaint: n("admin", "discipline", "immediate", IMPORTANT),
  admin_event_reminder: n("admin", "administrative", "before_event"),

  teacher_absence: n("vice_principal", "attendance", "daily", IMPORTANT),
  high_student_absence: n("vice_principal", "attendance", "daily"),
  vp_discipline_case: n("vice_principal", "discipline", "immediate", IMPORTANT),
  vp_student_concern: n("vice_principal", "discipline"),
  attendance_report: n("vice_principal", "attendance", "end_of_day"),
  classroom_issue: n("vice_principal", "administrative"),
  vp_announcement: n("vice_principal", "administrative"),
  pending_tasks: n("vice_principal", "administrative", "morning"),
  task_completed: n("vice_principal", "administrative", "on_completion"),
  event_planning: n("vice_principal", "administrative", "before_event"),

  book_due: n("librarian", "library", "daily"),
  new_book_added: n("librarian", "library", "on_add"),
  new_library_member: n("librarian", "library", "on_add"),
  overdue_book: n("librarian", "library"),
  book_request: n("librarian", "library"),
  library_report: n("librarian", "library", "weekly"),
  book_returned: n("librarian", "library"),
  book_reservation: n("librarian", "library"),
  library_event: n("librarian", "library", "before_event"),

  enrollment_stats: n("owner", "administrative", "monthly"),
  performance_report: n("owner", "academic", "end_of_term"),
  board_meeting: n("owner", "administrative", "before_event"),
  staff_changes: n("owner", "administrative"),
  annual_report: n("owner", "administrative", "yearly", IMPORTANT),
};

export function roleTypes(role: string): string[] {
  return Object.entries(NOTIFICATION_CATALOG)
    .filter(([, policy]) => policy.role === role || policy.role === "all")
    .map(([type]) => type);
}
