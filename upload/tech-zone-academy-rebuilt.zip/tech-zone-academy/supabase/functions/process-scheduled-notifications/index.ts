// supabase/functions/process-scheduled-notifications/index.ts
//
// Ported from functions/src/index.js's processScheduledNotifications
// (was: onSchedule "every 15 minutes"). Schedule this function with
// pg_cron — see supabase/functions_setup.sql.

import { deliver, usersByIds, usersByRole } from "../_shared/notify.ts";
import { NOTIFICATION_CATALOG } from "../_shared/notificationCatalog.ts";
import { supabaseAdmin, TABLE } from "../_shared/supabaseAdmin.ts";

Deno.serve(async (req) => {
  try {
    const authHeader = req.headers.get("Authorization") || "";
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (serviceRoleKey && authHeader !== `Bearer ${serviceRoleKey}`) {
      return new Response("Unauthorized", { status: 401 });
    }

    const now = new Date().toISOString();
    const { data: due, error } = await supabaseAdmin
      .from(TABLE)
      .select("*")
      .eq("collection", "notificationSchedules")
      .eq("data->>status", "pending")
      .lte("data->>dueAt", now)
      .limit(100);
    if (error) throw error;

    let processed = 0;
    for (const row of due ?? []) {
      const schedule = row.data;
      const policy = NOTIFICATION_CATALOG[schedule.type];
      if (!policy) {
        await supabaseAdmin
          .from(TABLE)
          .update({ data: { ...schedule, status: "failed", error: "Unknown type" } })
          .eq("collection", "notificationSchedules")
          .eq("id", row.id);
        continue;
      }
      const roles = policy.role === "all" ? [] : [policy.role];
      const directRecipients = (await usersByIds(schedule.targetUserIds || [])).filter(
        (u) => policy.role === "all" || u.role === policy.role
      );
      const recipients = [...directRecipients, ...(await usersByRole(roles))];
      await deliver(schedule.type, recipients, schedule, `schedule:${row.id}:${schedule.dueAt}`);
      await supabaseAdmin
        .from(TABLE)
        .update({
          data: { ...schedule, status: "sent", sentAt: new Date().toISOString(), recipientCount: recipients.length },
        })
        .eq("collection", "notificationSchedules")
        .eq("id", row.id);
      processed += 1;
    }

    return new Response(JSON.stringify({ processed }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("process-scheduled-notifications error:", error);
    return new Response(String(error), { status: 500 });
  }
});
