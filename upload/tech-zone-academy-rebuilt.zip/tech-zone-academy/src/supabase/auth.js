// src/supabase/auth.js
import {
  auth,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  createUserWithEmailAndPassword,
  updateProfile,
  sendEmailVerification,
  reauthenticateWithCredential,
  EmailAuthProvider,
  updatePassword,
  updateEmail,
} from "./supabase";
import { supabase } from "./supabaseClient";

// ============================================
// LOGIN USER
// ============================================
export const loginUser = async (email, password) => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return userCredential;
  } catch (error) {
    throw error;
  }
};

// ============================================
// LOGOUT USER
// ============================================
export const logoutUser = async () => {
  try {
    await signOut(auth);
  } catch (error) {
    throw new Error("Error logging out: " + error.message, { cause: error });
  }
};

// ============================================
// RESET PASSWORD
// ============================================
export const resetPassword = async (email) => {
  try {
    await sendPasswordResetEmail(auth, email);
  } catch (error) {
    throw error;
  }
};

// ============================================
// RESET PASSWORD WITH DEBUG (For testing)
// ============================================
export const resetPasswordWithDebug = async (email) => {
  try {
    await sendPasswordResetEmail(auth, email);

    console.log(`✅ Password reset email sent to: ${email}`);
    console.log(`📧 Check your email inbox or spam folder`);
    console.log(`🔗 You can also manage users from the Supabase Dashboard:`);
    console.log(`   → Authentication → Users`);

    return { success: true };
  } catch (error) {
    console.error("❌ Reset password error:", error);
    throw error;
  }
};

// ============================================
// REGISTER NEW USER
// ============================================
export const registerUser = async (email, password, displayName) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    if (displayName) {
      await updateProfile(userCredential.user, { displayName });
    }
    await sendEmailVerification(userCredential.user);
    return userCredential;
  } catch (error) {
    throw error;
  }
};

// ============================================
// CHANGE PASSWORD
// ============================================
export const changePassword = async (currentPassword, newPassword) => {
  try {
    const user = await getCurrentUser();
    if (!user) throw new Error("No user logged in");

    const credential = EmailAuthProvider.credential(user.email, currentPassword);
    await reauthenticateWithCredential(user, credential);
    await updatePassword(user, newPassword);
  } catch (error) {
    throw error;
  }
};

// ============================================
// CHANGE EMAIL
// ============================================
export const changeEmail = async (currentPassword, newEmail) => {
  try {
    const user = await getCurrentUser();
    if (!user) throw new Error("No user logged in");

    const credential = EmailAuthProvider.credential(user.email, currentPassword);
    await reauthenticateWithCredential(user, credential);
    await updateEmail(user, newEmail);
  } catch (error) {
    throw error;
  }
};

// ============================================
// GET CURRENT USER
// Note: unlike Firebase's synchronous auth.currentUser, Supabase
// sessions are fetched async. Callers should `await` this.
// ============================================
export const getCurrentUser = async () => {
  const { data } = await supabase.auth.getUser();
  return data.user;
};

// ============================================
// CHECK IF USER IS LOGGED IN
// ============================================
export const isLoggedIn = async () => {
  const { data } = await supabase.auth.getSession();
  return !!data.session;
};

// ============================================
// GET USER ID TOKEN
// ============================================
export const getUserIdToken = async () => {
  try {
    const { data } = await supabase.auth.getSession();
    if (!data.session) throw new Error("No user logged in");
    return data.session.access_token;
  } catch (error) {
    throw new Error("Error getting user token: " + error.message, { cause: error });
  }
};

// ============================================
// RELOAD USER DATA
// ============================================
export const reloadUser = async () => {
  try {
    const { data, error } = await supabase.auth.refreshSession();
    if (error) throw error;
    return data.user;
  } catch (error) {
    throw new Error("Error reloading user: " + error.message, { cause: error });
  }
};
