// src/supabase/supabase.js
import { supabase } from "./supabaseClient";

// ============================================
// DATABASE REFERENCE - EXPORT db
// ============================================
export const db = { __type: "db" };
export const storage = { __type: "storage" };

// ============================================
// TABLE MAPPING - Exact matches for your tables
// ============================================
const TABLE_MAP = {
  // Core tables
  'students': 'students',
  'teachers': 'teachers',
  'users': 'users',
  'grades': 'grades',
  'sections': 'sections',
  'subjects': 'subjects',
  'results': 'results',
  'attendance': 'attendance',
  'discipline': 'discipline',
  'parents': 'parents',
  'events': 'events',
  
  // Settings
  'schoolSettings': 'school_settings',
  'websiteSettings': 'website_settings',
  'websitePages': 'website_pages',
  
  // Teacher/Assignment
  'teacherAssignments': 'teacher_assignments',
  'homeroomAssignments': 'homeroom_assignments',
  'teacherAttendance': 'teacher_attendance',
  'teacherAssignmentsUploads': 'teacher_assignments_uploads',
  
  // Parent-Child
  'parentChildren': 'parent_children',
  
  // Audit
  'auditLogs': 'audit_logs',
  
  // VP
  'vpTasks': 'vp_tasks',
  
  // Gallery/News
  'galleryImages': 'gallery_images',
  'galleryAlbums': 'gallery_albums',
  'news': 'news',
  'announcements': 'announcements',
  
  // Notifications
  'notifications': 'notifications',
  'notificationEvents': 'notification_events',
  'notificationSchedules': 'notification_schedules',
  
  // Library
  'libraryBooks': 'library_books',
  'libraryMembers': 'library_members',
  'libraryCategories': 'library_categories',
  'libraryHistory': 'library_history',
  
  // Email
  'emailLogs': 'email_logs',

  // Schedules
  'schedules': 'schedules',

  // Gallery (video) & assignment submissions
  'galleryVideos': 'gallery_videos',
  'assignmentSubmissions': 'assignment_submissions',
  'studentDocuments': 'student_documents',
  'chatConversations': 'chat_conversations',
  'chatParticipants': 'chat_participants',
  'chatMessages': 'chat_messages',
  'academicYears': 'academic_years',
  'semesters': 'semesters',
  'promotionRecords': 'promotion_records',

  // Role profiles (created by AuthContext.createRoleProfile)
  'librarians': 'librarians',
  'vicePrincipals': 'vice_principals',
};

function getTableName(collectionPath) {
  if (!collectionPath) {
    console.warn('getTableName called with undefined collectionPath');
    return null;
  }
  const mapped = TABLE_MAP[collectionPath];
  if (!mapped) {
    console.warn(`No table mapping found for collection: "${collectionPath}", using as-is`);
    return collectionPath;
  }
  return mapped;
}

// ============================================
// camelCase <-> snake_case field conversion
// ============================================
// App code throughout the codebase reads/writes camelCase fields
// (firstName, createdBy, studentId, ...) the way it would against
// Firestore. The real Postgres tables use snake_case columns
// (first_name, created_by, student_id, ...). Rather than hand-fixing
// every call site, we translate keys automatically at the boundary:
// outgoing writes get converted to snake_case, incoming reads get
// converted (back) to camelCase, so existing app code keeps working
// unmodified against the real schema.
function toSnakeCase(key) {
  return key.replace(/([a-z0-9])([A-Z])/g, '$1_$2').toLowerCase();
}

function toCamelCase(key) {
  return key.replace(/_([a-z0-9])/g, (_, c) => c.toUpperCase());
}

function convertKeys(obj, converter) {
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return obj;
  const out = {};
  for (const [key, value] of Object.entries(obj)) {
    out[converter(key)] = value;
  }
  return out;
}

// A handful of tables are still shaped like the old generic Firestore
// document store (id, data jsonb, ...) rather than having their own
// real columns per field. For these, arbitrary app-level fields belong
// *inside* the jsonb `data` column, not as top-level columns, and their
// keys should NOT be snake_cased (they're free-form JSON, not SQL
// columns).
const JSONB_DOC_TABLES = new Set(['documents', 'school_settings', 'website_settings']);

const ROW_META_KEYS = new Set(['id', 'created_at', 'updated_at']);

// Shapes a raw Postgres row the way app code (written against a
// Firestore-style API) expects it back.
function shapeRowForApp(tableName, row) {
  if (!row) return row;
  if (JSONB_DOC_TABLES.has(tableName)) {
    // (id, data jsonb, ...) tables: app code expects doc.data() to BE
    // the jsonb payload, not a wrapper around it.
    return { id: row.id, ...(row.data || {}) };
  }
  return convertKeys(row, toCamelCase);
}

// Shapes an app-level data object for writing to Postgres.
function shapeRowForDb(tableName, data) {
  if (JSONB_DOC_TABLES.has(tableName)) {
    // Anything that isn't row metadata belongs inside the jsonb `data`
    // column, untouched (it's free-form JSON, not SQL columns).
    const { id, created_at, updated_at, createdAt, updatedAt, ...rest } = data || {};
    return { data: rest };
  }
  return convertKeys(data, toSnakeCase);
}

// ============================================
// collection() / doc()
// ============================================
export function collection(_db, path) {
  if (!path) {
    console.warn('collection() called with undefined path');
    return { __type: "collection", path: null };
  }
  return { __type: "collection", path };
}

export function doc(refOrDb, pathOrId, maybeId) {
  if (refOrDb?.__type === "db") {
    const id = maybeId ?? crypto.randomUUID?.() ?? `id-${Date.now()}`;
    return { __type: "doc", collectionPath: pathOrId, id };
  }
  if (refOrDb?.__type === "collection") {
    const id = pathOrId ?? crypto.randomUUID?.() ?? `id-${Date.now()}`;
    return { __type: "doc", collectionPath: refOrDb.path, id };
  }
  throw new Error("doc(): unsupported reference type");
}

// ============================================
// query() / where() / orderBy() / limit()
// ============================================
export function query(collectionRef, ...constraints) {
  if (!collectionRef || !collectionRef.path) {
    console.warn('query() called with invalid collectionRef:', collectionRef);
    return { __type: "query", collectionPath: null, constraints: [] };
  }
  return { __type: "query", collectionPath: collectionRef.path, constraints };
}

export function where(field, op, value) {
  // Normalize operator - Firebase uses "==", but we might get "="
  let normalizedOp = op;
  if (op === "=") normalizedOp = "==";
  if (op === "!=") normalizedOp = "!=";
  if (op === "<") normalizedOp = "<";
  if (op === "<=") normalizedOp = "<=";
  if (op === ">") normalizedOp = ">";
  if (op === ">=") normalizedOp = ">=";
  
  return { __type: "where", field, op: normalizedOp, value };
}

export function orderBy(field, direction = "asc") {
  return { __type: "orderBy", field, direction };
}

export function limit(n) {
  return { __type: "limit", n };
}

// ============================================
// buildSupabaseQuery - FIXED
// ============================================
function buildSupabaseQuery(tableName, constraints = []) {
  if (!tableName || typeof tableName !== 'string') {
    console.error('Invalid table name:', tableName);
    throw new Error(`Invalid table name: ${tableName}`);
  }
  
  let query = supabase.from(tableName).select('*');
  
  for (const c of constraints) {
    if (c.__type === "where") {
      // Remove 'data.' prefix if present (Firestore compatibility)
      let field = c.field && c.field.startsWith('data.') ? c.field.substring(5) : c.field;

      if (!field) {
        console.warn('where() called with empty field, skipping');
        continue;
      }
      field = ROW_META_KEYS.has(field) ? field : toSnakeCase(field);
      
      // Handle different operators
      switch (c.op) {
        case "==":
          query = query.eq(field, c.value);
          break;
        case "!=":
          query = query.neq(field, c.value);
          break;
        case "<":
          query = query.lt(field, c.value);
          break;
        case "<=":
          query = query.lte(field, c.value);
          break;
        case ">":
          query = query.gt(field, c.value);
          break;
        case ">=":
          query = query.gte(field, c.value);
          break;
        case "array-contains":
          query = query.contains(field, [c.value]);
          break;
        case "in":
          if (Array.isArray(c.value)) {
            query = query.in(field, c.value);
          } else {
            console.warn('in operator requires array value, skipping');
          }
          break;
        default:
          console.warn(`Unsupported where() operator: ${c.op}`);
      }
    } else if (c.__type === "orderBy") {
      const field = ROW_META_KEYS.has(c.field) ? c.field : toSnakeCase(c.field);
      query = query.order(field, { ascending: c.direction !== "desc" });
    } else if (c.__type === "limit") {
      query = query.limit(c.n);
    }
  }
  
  return query;
}

// ============================================
// getDoc()
// ============================================
export async function getDoc(docRef) {
  try {
    if (!docRef || !docRef.collectionPath) {
      console.warn('getDoc called with invalid docRef');
      return {
        id: 'unknown',
        exists: () => false,
        data: () => ({}),
        ref: { __type: "doc", collectionPath: 'unknown', id: 'unknown' },
      };
    }
    
    const tableName = getTableName(docRef.collectionPath);
    if (!tableName) {
      console.warn(`No table mapping for ${docRef.collectionPath}`);
      return {
        id: docRef.id,
        exists: () => false,
        data: () => ({}),
        ref: { __type: "doc", collectionPath: docRef.collectionPath, id: docRef.id },
      };
    }
    
    const { data, error } = await supabase
      .from(tableName)
      .select('*')
      .eq('id', docRef.id)
      .maybeSingle();
    
    if (error) {
      if (error.code === 'PGRST205' || error.message?.includes('Could not find the table')) {
        console.warn(`Table "${tableName}" not found, returning empty document`);
        return {
          id: docRef.id,
          exists: () => false,
          data: () => ({}),
          ref: { __type: "doc", collectionPath: docRef.collectionPath, id: docRef.id },
        };
      }
      throw error;
    }
    
    return {
      id: docRef.id,
      exists: () => !!data,
      data: () => shapeRowForApp(tableName, data) || {},
      ref: { __type: "doc", collectionPath: docRef.collectionPath, id: docRef.id },
    };
  } catch (error) {
    console.error(`Error in getDoc:`, error);
    return {
      id: docRef?.id || 'unknown',
      exists: () => false,
      data: () => ({}),
      ref: { __type: "doc", collectionPath: docRef?.collectionPath || 'unknown', id: docRef?.id || 'unknown' },
    };
  }
}

// ============================================
// getDocs() - FIXED
// ============================================
export async function getDocs(refOrQuery) {
  try {
    if (!refOrQuery) {
      console.warn('getDocs called with undefined refOrQuery');
      return {
        docs: [],
        empty: true,
        size: 0,
        forEach: () => {},
      };
    }
    
    const isQuery = refOrQuery.__type === "query";
    const collectionPath = isQuery ? refOrQuery.collectionPath : refOrQuery.path;
    
    if (!collectionPath) {
      console.warn('getDocs called with undefined collectionPath');
      return {
        docs: [],
        empty: true,
        size: 0,
        forEach: () => {},
      };
    }
    
    const constraints = isQuery ? (refOrQuery.constraints || []) : [];
    const tableName = getTableName(collectionPath);
    
    if (!tableName) {
      console.warn(`No table mapping for collection: "${collectionPath}"`);
      return {
        docs: [],
        empty: true,
        size: 0,
        forEach: () => {},
      };
    }
    
    const queryBuilder = buildSupabaseQuery(tableName, constraints);
    const { data: rows, error } = await queryBuilder;
    
    if (error) {
      if (error.code === 'PGRST205' || error.message?.includes('Could not find the table')) {
        console.warn(`Table "${tableName}" does not exist, returning empty result`);
        return {
          docs: [],
          empty: true,
          size: 0,
          forEach: () => {},
        };
      }
      throw error;
    }
    
    const docs = (rows || []).map(row => ({
      id: row.id,
      exists: () => true,
      data: () => shapeRowForApp(tableName, row),
      ref: { __type: "doc", collectionPath, id: row.id },
    }));
    
    return {
      docs,
      empty: docs.length === 0,
      size: docs.length,
      forEach: (cb) => docs.forEach(cb),
    };
  } catch (error) {
    console.error(`Error in getDocs:`, error);
    return {
      docs: [],
      empty: true,
      size: 0,
      forEach: () => {},
    };
  }
}

// ============================================
// getCountFromServer()
// ============================================
export async function getCountFromServer(refOrQuery) {
  try {
    const isQuery = refOrQuery.__type === "query";
    const collectionPath = refOrQuery.collectionPath;
    const constraints = isQuery ? refOrQuery.constraints : [];
    const tableName = getTableName(collectionPath);
    
    let query = supabase.from(tableName).select('*', { count: 'exact', head: true });
    
    for (const c of constraints) {
      if (c.__type === "where") {
        const field = c.field.startsWith('data.') ? c.field.substring(5) : c.field;
        const col = ROW_META_KEYS.has(field) ? field : toSnakeCase(field);
        switch (c.op) {
          case "==":
            query = query.eq(col, c.value);
            break;
          case "!=":
            query = query.neq(col, c.value);
            break;
          default:
            break;
        }
      }
    }
    
    const { count, error } = await query;
    if (error) {
      if (error.code === 'PGRST205' || error.message?.includes('Could not find the table')) {
        console.warn(`Table "${tableName}" does not exist, returning count 0`);
        return { data: () => ({ count: 0 }) };
      }
      throw error;
    }
    
    return { data: () => ({ count: count ?? 0 }) };
  } catch (error) {
    console.error('Error in getCountFromServer:', error);
    return { data: () => ({ count: 0 }) };
  }
}

// ============================================
// setDoc()
// ============================================
export async function setDoc(docRef, data, options) {
  try {
    const tableName = getTableName(docRef.collectionPath);
    const shaped = shapeRowForDb(tableName, data);

    const finalData = {
      ...shaped,
      id: docRef.id,
      updated_at: new Date().toISOString(),
    };
    
    if (!finalData.created_at) {
      finalData.created_at = new Date().toISOString();
    }
    
    const { error } = await supabase
      .from(tableName)
      .upsert(finalData, { onConflict: 'id' });
    
    if (error) throw error;
  } catch (error) {
    console.error(`Error in setDoc for ${docRef.collectionPath}/${docRef.id}:`, error);
    throw error;
  }
}

// ============================================
// updateDoc()
// ============================================
export async function updateDoc(docRef, data) {
  try {
    const tableName = getTableName(docRef.collectionPath);

    let updateData;
    if (JSONB_DOC_TABLES.has(tableName)) {
      // Merge into the existing jsonb payload rather than clobbering it,
      // since updateDoc() is meant to patch fields, not replace the doc.
      const { data: existing } = await supabase
        .from(tableName)
        .select('data')
        .eq('id', docRef.id)
        .maybeSingle();
      const { id, created_at, updated_at, createdAt, updatedAt, ...rest } = data || {};
      updateData = { data: { ...(existing?.data || {}), ...rest }, updated_at: new Date().toISOString() };
    } else {
      updateData = {
        ...convertKeys(data, toSnakeCase),
        updated_at: new Date().toISOString(),
      };
    }
    
    const { error } = await supabase
      .from(tableName)
      .update(updateData)
      .eq('id', docRef.id);
    
    if (error) throw error;
  } catch (error) {
    console.error(`Error in updateDoc for ${docRef.collectionPath}/${docRef.id}:`, error);
    throw error;
  }
}

// ============================================
// deleteDoc()
// ============================================
export async function deleteDoc(docRef) {
  try {
    const tableName = getTableName(docRef.collectionPath);
    
    const { error } = await supabase
      .from(tableName)
      .delete()
      .eq('id', docRef.id);
    
    if (error) throw error;
  } catch (error) {
    console.error(`Error in deleteDoc for ${docRef.collectionPath}/${docRef.id}:`, error);
    throw error;
  }
}

// ============================================
// addDoc()
// ============================================
export async function addDoc(collectionRef, data) {
  try {
    const id = crypto.randomUUID?.() ?? `id-${Date.now()}`;
    const tableName = getTableName(collectionRef.path);
    const shaped = shapeRowForDb(tableName, data);

    const finalData = {
      ...shaped,
      id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    
    const { error } = await supabase
      .from(tableName)
      .insert(finalData);
    
    if (error) throw error;
    
    return { __type: "doc", collectionPath: collectionRef.path, id };
  } catch (error) {
    console.error(`Error in addDoc for ${collectionRef.path}:`, error);
    throw error;
  }
}

// ============================================
// Timestamp
// ============================================
export const Timestamp = {
  now: () => ({
    __type: "timestamp",
    seconds: Math.floor(Date.now() / 1000),
    toDate: () => new Date(),
  }),
  fromDate: (date) => ({
    __type: "timestamp",
    seconds: Math.floor(date.getTime() / 1000),
    toDate: () => date,
  }),
};

export function serverTimestamp() {
  return new Date().toISOString();
}

// ============================================
// Transaction & Batch
// ============================================
export async function runTransaction(_db, updateFunction) {
  const tx = {
    get: (docRef) => getDoc(docRef),
    set: (docRef, data, options) => setDoc(docRef, data, options),
    update: (docRef, data) => updateDoc(docRef, data),
    delete: (docRef) => deleteDoc(docRef),
  };
  return updateFunction(tx);
}

export function writeBatch(_db) {
  const ops = [];
  return {
    set: (docRef, data, options) => ops.push({ type: "set", docRef, data, options }),
    update: (docRef, data) => ops.push({ type: "update", docRef, data }),
    delete: (docRef) => ops.push({ type: "delete", docRef }),
    commit: async () => {
      for (const op of ops) {
        if (op.type === "set") await setDoc(op.docRef, op.data, op.options);
        else if (op.type === "update") await updateDoc(op.docRef, op.data);
        else if (op.type === "delete") await deleteDoc(op.docRef);
      }
    },
  };
}

// ============================================
// onSnapshot()
// ============================================
export function onSnapshot(refOrQuery, onNext, onError) {
  const isQuery = refOrQuery.__type === "query";
  const collectionPath = isQuery ? refOrQuery.collectionPath : refOrQuery.path;
  
  if (!collectionPath) {
    console.warn('onSnapshot called with undefined collectionPath');
    return () => {};
  }
  
  const constraints = isQuery ? (refOrQuery.constraints || []) : [];
  const tableName = getTableName(collectionPath);
  
  if (!tableName) {
    console.warn(`No table mapping for collection: "${collectionPath}"`);
    return () => {};
  }
  
  let cancelled = false;
  
  const fetchAndEmit = async () => {
    try {
      const snapshot = await getDocs(refOrQuery);
      if (!cancelled) onNext(snapshot);
    } catch (err) {
      if (!cancelled && onError) onError(err);
    }
  };
  
  fetchAndEmit();
  
  try {
    const channel = supabase
      .channel(`table-${tableName}-${Date.now()}`)
      .on(
        'postgres_changes',
        { 
          event: '*', 
          schema: 'public', 
          table: tableName,
        },
        () => fetchAndEmit()
      )
      .subscribe();
    
    return () => {
      cancelled = true;
      supabase.removeChannel(channel);
    };
  } catch (e) {
    console.warn('Realtime subscription failed, falling back to polling', e);
    return () => { cancelled = true; };
  }
}

// ============================================
// Storage
// ============================================
// Two buckets: `public-uploads` (public=true) for genuinely public
// marketing content served via permanent URLs, and `uploads`
// (public=false) for private/access-controlled content served via
// signed URLs. Routing is based on the top-level folder in the path.
const PUBLIC_FOLDERS = new Set(["gallery", "news", "events", "website", "library"]);
const PRIVATE_BUCKET = "uploads";
const PUBLIC_BUCKET = "public-uploads";
// Private content isn't meant to be publicly link-shareable, but a
// very short expiry would mean constantly re-signing URLs just to
// display an <img>/<a> tag. A long expiry is a reasonable balance —
// RLS is the real access control (it governs who can even generate a
// signed URL), this just avoids needing a refresh mechanism.
const PRIVATE_URL_EXPIRY_SECONDS = 60 * 60 * 24 * 365; // 1 year

function bucketFor(path) {
  const topFolder = path.split("/")[0];
  return PUBLIC_FOLDERS.has(topFolder) ? PUBLIC_BUCKET : PRIVATE_BUCKET;
}

export function ref(_storage, path) {
  return { __type: "storageRef", path, bucket: bucketFor(path) };
}

export async function uploadBytes(storageRef, file) {
  const { error } = await supabase.storage
    .from(storageRef.bucket || bucketFor(storageRef.path))
    .upload(storageRef.path, file, { upsert: true });
  if (error) throw error;
  return { ref: storageRef };
}

export async function getDownloadURL(storageRef) {
  const bucket = storageRef.bucket || bucketFor(storageRef.path);
  if (bucket === PUBLIC_BUCKET) {
    const { data } = supabase.storage.from(bucket).getPublicUrl(storageRef.path);
    return data.publicUrl;
  }
  const { data, error } = await supabase.storage
    .from(bucket)
    .createSignedUrl(storageRef.path, PRIVATE_URL_EXPIRY_SECONDS);
  if (error) throw error;
  return data.signedUrl;
}

export async function deleteObject(storageRef) {
  const bucket = storageRef.bucket || bucketFor(storageRef.path);
  const { error } = await supabase.storage.from(bucket).remove([storageRef.path]);
  if (error) throw error;
}

// ============================================
// AUTH
// ============================================
export const auth = supabase.auth;

function mapSupabaseUser(user) {
  if (!user) return null;
  return {
    uid: user.id,
    email: user.email,
    displayName: user.user_metadata?.displayName ?? user.user_metadata?.display_name ?? null,
    emailVerified: !!user.email_confirmed_at,
    getIdToken: async () => {
      const { data } = await supabase.auth.getSession();
      return data.session?.access_token;
    },
  };
}

function mapAuthError(error) {
  const msg = (error?.message || "").toLowerCase();
  if (msg.includes("invalid login credentials")) {
    return new Error("Invalid email or password. Please check and try again.", { cause: error });
  }
  if (msg.includes("user already registered")) {
    return new Error("An account with this email already exists.", { cause: error });
  }
  if (msg.includes("email not confirmed")) {
    return new Error("Please verify your email before logging in.", { cause: error });
  }
  if (msg.includes("rate limit")) {
    return new Error("Too many attempts. Please try again later.", { cause: error });
  }
  return new Error(error?.message || "Authentication failed. Please try again.", { cause: error });
}

export async function createUserWithEmailAndPassword(_auth, email, password) {
  const { data, error } = await supabase.auth.signUp({ email, password });
  if (error) throw mapAuthError(error);
  return { user: mapSupabaseUser(data.user) };
}

export async function signInWithEmailAndPassword(_auth, email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw mapAuthError(error);
  return { user: mapSupabaseUser(data.user) };
}

export async function signOut(_auth) {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function sendPasswordResetEmail(_auth, email) {
  const { error } = await supabase.auth.resetPasswordForEmail(email);
  if (error) throw mapAuthError(error);
}

export function onAuthStateChanged(_auth, callback) {
  supabase.auth.getSession().then(({ data }) => {
    callback(mapSupabaseUser(data.session?.user));
  });
  
  const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
    callback(mapSupabaseUser(session?.user));
  });
  
  return () => listener.subscription.unsubscribe();
}

export async function updateProfile(_user, { displayName } = {}) {
  const { error } = await supabase.auth.updateUser({
    data: { displayName },
  });
  if (error) throw error;
}

export async function sendEmailVerification(_user) {
  const { data } = await supabase.auth.getUser();
  if (data.user?.email) {
    const { error } = await supabase.auth.resend({
      type: "signup",
      email: data.user.email,
    });
    if (error) throw error;
  }
}

export async function reauthenticateWithCredential(_user, credential) {
  const { error } = await supabase.auth.signInWithPassword({
    email: credential.email,
    password: credential.password,
  });
  if (error) throw mapAuthError(error);
}

export const EmailAuthProvider = {
  credential: (email, password) => ({ email, password }),
};

export async function updatePassword(_user, newPassword) {
  const { error } = await supabase.auth.updateUser({ password: newPassword });
  if (error) throw error;
}

export async function updateEmail(_user, newEmail) {
  const { error } = await supabase.auth.updateUser({ email: newEmail });
  if (error) throw error;
}

export async function verifyPasswordResetCode(_auth, oobCode) {
  if (oobCode) {
    const { error } = await supabase.auth.exchangeCodeForSession(oobCode);
    if (error) throw mapAuthError(error);
  }
  const { data, error } = await supabase.auth.getUser();
  if (error) throw mapAuthError(error);
  if (!data.user) throw new Error("Invalid or expired reset link.");
  return data.user.email;
}

export async function confirmPasswordReset(_auth, _oobCode, newPassword) {
  const { error } = await supabase.auth.updateUser({ password: newPassword });
  if (error) throw mapAuthError(error);
}

export default supabase;
