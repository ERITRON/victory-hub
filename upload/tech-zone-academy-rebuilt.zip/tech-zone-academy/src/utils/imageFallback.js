// src/utils/imageFallback.js
//
// Local, network-free fallback for broken/missing images.
// We used to fall back to https://via.placeholder.com/..., but that
// service is no longer reachable (net::ERR_CONNECTION_CLOSED), and every
// missing image on the site was retrying against it, flooding the
// console/network and making pages feel frozen. This fallback is a
// plain inline SVG data URI, so it always renders instantly with zero
// network requests.

function svgPlaceholder(label = "Image not available") {
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="600" height="400" viewBox="0 0 600 400">
      <rect width="600" height="400" fill="#e2e8f0"/>
      <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle"
        font-family="Arial, sans-serif" font-size="22" fill="#64748b">${label}</text>
    </svg>
  `.trim();
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export const FALLBACK_IMAGE = svgPlaceholder("Image not available");

// Attach to an <img>'s onError. Guards against infinite retry loops by
// only swapping the src once (if the fallback itself ever failed to
// load, we would otherwise loop forever).
export function handleImageError(e, label) {
  const fallback = label ? svgPlaceholder(label) : FALLBACK_IMAGE;
  if (e.target.src === fallback) return; // already showing fallback, stop
  e.target.onerror = null; // prevent any further retry loop
  e.target.src = fallback;
}
