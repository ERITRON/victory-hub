import { useMemo, useState } from "react";
import { useDebouncedSearch, normalizeSearchValue } from "../hooks/useDebouncedSearch";

const MAX_VISIBLE_RESULTS = 50;

export default function SearchableSelect({
  items,
  value,
  onChange,
  getKey = (item) => item.id,
  getLabel = (item) => item.name,
  searchFields = [],
  placeholder = "Search...",
  emptyMessage = "No matching records found",
  required = false,
  disabled = false,
}) {
  const selectedItem = useMemo(
    () => items.find((item) => String(getKey(item)) === String(value)),
    [getKey, items, value],
  );
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const debouncedQuery = useDebouncedSearch(query, 300);

  const results = useMemo(() => {
    const search = normalizeSearchValue(debouncedQuery);
    if (!search) return [];

    return items
      .filter((item) => {
        const values = [getLabel(item), ...searchFields.map((field) =>
          typeof field === "function" ? field(item) : item?.[field],
        )];
        return values.some((fieldValue) =>
          normalizeSearchValue(fieldValue).includes(search),
        );
      })
      .slice(0, MAX_VISIBLE_RESULTS);
  }, [debouncedQuery, getLabel, items, searchFields]);

  const choose = (item) => {
    onChange(getKey(item), item);
    setQuery("");
    setOpen(false);
  };

  return (
    <div className="relative">
      <input type="hidden" value={value || ""} required={required} />
      <input
        type="search"
        value={open ? query : selectedItem ? getLabel(selectedItem) : ""}
        onChange={(event) => {
          setQuery(event.target.value);
          setOpen(true);
          if (!event.target.value) onChange("", null);
        }}
        onFocus={() => {
          setQuery("");
          setOpen(true);
        }}
        onBlur={() => setTimeout(() => setOpen(false), 150)}
        placeholder={placeholder}
        disabled={disabled}
        autoComplete="off"
        className="w-full rounded-lg border p-3 outline-none transition focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100"
      />

      {open && query.trim() && (
        <div className="absolute z-50 mt-1 max-h-64 w-full overflow-y-auto rounded-lg border bg-white shadow-lg">
          {results.length ? results.map((item) => (
            <button
              key={getKey(item)}
              type="button"
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => choose(item)}
              className="block w-full border-b px-3 py-2.5 text-left text-sm last:border-0 hover:bg-blue-50"
            >
              {getLabel(item)}
            </button>
          )) : (
            <p className="px-3 py-4 text-center text-sm text-gray-500">{emptyMessage}</p>
          )}
          {results.length === MAX_VISIBLE_RESULTS && (
            <p className="sticky bottom-0 border-t bg-gray-50 px-3 py-2 text-xs text-gray-500">
              Showing the first {MAX_VISIBLE_RESULTS} matches. Refine your search for more specific results.
            </p>
          )}
        </div>
      )}
    </div>
  );
}
