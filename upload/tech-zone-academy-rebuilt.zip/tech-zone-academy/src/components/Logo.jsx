// src/components/Logo.jsx
import { Link } from "react-router-dom";
import { useWebsiteSettings } from "../context/WebsiteSettingsContext";

export default function Logo() {
  const { settings, loading } = useWebsiteSettings();
  const navSettings = settings?.navigation || {};
  const schoolName = settings?.schoolInfo?.schoolName || navSettings.websiteName || "Tech Zone Academy";

  if (loading) {
    return (
      <Link to="/" className="flex items-center gap-3">
        <div className="h-12 w-12 rounded-full bg-blue-500/30 animate-pulse"></div>
        <div className="h-6 w-24 bg-blue-500/30 rounded animate-pulse"></div>
      </Link>
    );
  }

  return (
    <Link to="/" className="flex items-center gap-3">
      {navSettings.logo ? (
        <div className="h-12 w-12 rounded-full overflow-hidden border-2 border-white/30 shadow-lg flex-shrink-0">
          <img 
            src={navSettings.logo} 
            alt={schoolName}
            className="w-full h-full object-cover"
            onError={(e) => {
              e.target.style.display = "none";
              // Show fallback when image fails
              e.target.parentElement.innerHTML = `
                <div class="w-full h-full rounded-full bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center text-white font-bold text-lg">
                  ${schoolName.charAt(0).toUpperCase()}
                </div>
              `;
            }}
          />
        </div>
      ) : (
        <div className="h-12 w-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center text-white font-bold text-lg shadow-lg flex-shrink-0">
          {schoolName.charAt(0).toUpperCase()}
        </div>
      )}
      <span className="text-xl font-bold text-white hidden sm:block">
        {schoolName}
      </span>
    </Link>
  );
}
