import { signOut, auth } from "../supabase/supabase";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

export default function LogoutButton({ className, variant = "default" }) {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const logout = async () => {
    if (!window.confirm("Are you sure you want to logout?")) return;

    setLoading(true);
    try {
      await signOut(auth);
      navigate("/login");
    } catch (error) {
      console.error("Logout error:", error);
      alert("Error logging out. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const getButtonStyles = () => {
    if (variant === "icon") {
      return `
        bg-red-600 hover:bg-red-700 
        text-white 
        p-2 rounded-lg 
        transition-all duration-200 
        hover:shadow-lg hover:shadow-red-500/30
        focus:ring-2 focus:ring-red-500 focus:ring-offset-2
        ${className || ""}
      `;
    }
    if (variant === "outline") {
      return `
        bg-transparent 
        border-2 border-red-600 
        text-red-600 
        hover:bg-red-600 hover:text-white
        px-4 py-2 rounded-lg 
        transition-all duration-200
        hover:shadow-lg hover:shadow-red-500/30
        focus:ring-2 focus:ring-red-500 focus:ring-offset-2
        ${className || ""}
      `;
    }
    return `
      bg-red-600 hover:bg-red-700 
      text-white 
      px-4 py-2 rounded-lg 
      transition-all duration-200 
      hover:shadow-lg hover:shadow-red-500/30
      focus:ring-2 focus:ring-red-500 focus:ring-offset-2
      disabled:opacity-50 disabled:cursor-not-allowed
      ${className || ""}
    `;
  };

  return (
    <button
      onClick={logout}
      disabled={loading}
      className={getButtonStyles()}
      aria-label="Logout"
    >
      {loading ? (
        <span className="flex items-center gap-2">
          <svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          Logging out...
        </span>
      ) : (
        <span className="flex items-center gap-2">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75" />
          </svg>
          Logout
        </span>
      )}
    </button>
  );
}