// src/components/NewsSection.jsx
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { db, collection, getDocs, query, orderBy, limit } from "../supabase/supabase";
import { useWebsiteSettings } from "../context/WebsiteSettingsContext";

export default function NewsSection() {
  const { settings, loading } = useWebsiteSettings();
  const newsSettings = settings?.newsSettings || {};
  const [news, setNews] = useState([]);
  const [newsLoading, setNewsLoading] = useState(true);

  const fetchNews = async () => {
    setNewsLoading(true);
    try {
      const q = query(
        collection(db, "news"),
        orderBy("date", "desc"),
        limit(newsSettings.cardCount || 6)
      );
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setNews(data);
    } catch (error) {
      console.error("Error fetching news:", error);
    } finally {
      setNewsLoading(false);
    }
  };

  useEffect(() => {
     
    fetchNews();
    // eslint-disable-next-line react-hooks/exhaustive-deps -- run once on mount
  }, []);

  if (!newsSettings.enabled) return null;

  if (loading || newsLoading) {
    return (
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse">
            <div className="h-10 w-48 bg-gray-200 rounded mx-auto mb-4"></div>
            <div className="h-6 w-64 bg-gray-200 rounded mx-auto mb-8"></div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-white rounded-xl shadow p-4 h-64"></div>
              ))}
            </div>
          </div>
        </div>
      </section>
    );
  }

  const categories = newsSettings.categories || [];

  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold text-gray-800">
            {newsSettings.title || "Latest News"}
          </h2>
          <div className="w-16 h-1 bg-blue-600 mx-auto mt-3 rounded"></div>
          <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
            {newsSettings.subtitle || "Stay updated with our latest announcements"}
          </p>
        </div>

        {news.length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <p className="text-gray-500">No news available at the moment.</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {news.map((item) => {
              const category = categories.find(c => c.name === item.category);
              return (
                <div
                  key={item.id}
                  className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition duration-300"
                >
                  {item.image && (
                    <div className="h-48 bg-gray-200 overflow-hidden">
                      <img
                        src={item.image}
                        alt={item.title}
                        className="w-full h-full object-cover hover:scale-105 transition duration-300"
                      />
                    </div>
                  )}
                  <div className="p-5">
                    <div className="flex items-center justify-between mb-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${category?.color || "bg-gray-100 text-gray-700"}`}>
                        {category?.emoji || "📌"} {item.category || "General"}
                      </span>
                      <span className="text-xs text-gray-400">
                        {item.date ? new Date(item.date).toLocaleDateString() : ""}
                      </span>
                    </div>
                    <h3 className="text-lg font-bold text-gray-800 mb-2 line-clamp-2">
                      {item.title}
                    </h3>
                    <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                      {item.content}
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-400">
                        By {item.author || "Admin"}
                      </span>
                      <Link
                        to={`/news/${item.id}`}
                        className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                      >
                        Read More →
                      </Link>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
        
        {/* View All News Button */}
        {news.length > 0 && (
          <div className="text-center mt-8">
            <Link
              to="/news"
              className="inline-block bg-blue-700 text-white px-6 py-3 rounded-lg hover:bg-blue-800 transition font-medium"
            >
              View All News →
            </Link>
          </div>
        )}
      </div>
    </section>
  );
}