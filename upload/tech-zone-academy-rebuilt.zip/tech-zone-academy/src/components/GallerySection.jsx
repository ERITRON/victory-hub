// src/components/GallerySection.jsx
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { db, collection, getDocs, query, orderBy, limit } from "../supabase/supabase";
import { useWebsiteSettings } from "../context/WebsiteSettingsContext";
import { handleImageError } from "../utils/imageFallback";
import ImageLightbox from "./ImageLightbox";

export default function GallerySection() {
  const { settings, loading } = useWebsiteSettings();
  const gallerySettings = settings?.gallerySettings || {};
  const [images, setImages] = useState([]);
  const [loadingImages, setLoadingImages] = useState(true);
  const [lightboxImage, setLightboxImage] = useState(null);

  const fetchImages = async () => {
    setLoadingImages(true);
    try {
      const q = query(
        collection(db, "galleryImages"),
        orderBy("date", "desc"),
        limit(gallerySettings.displayCount || 8)
      );
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setImages(data);
    } catch (error) {
      console.error("Error fetching gallery:", error);
    } finally {
      setLoadingImages(false);
    }
  };

  useEffect(() => {
     
    fetchImages();
    // eslint-disable-next-line react-hooks/exhaustive-deps -- run once on mount
  }, []);

  if (!gallerySettings.enabled) return null;

  if (loading || loadingImages) {
    return (
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse">
            <div className="h-10 w-48 bg-gray-200 rounded mx-auto mb-4"></div>
            <div className="h-6 w-64 bg-gray-200 rounded mx-auto mb-8"></div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="aspect-square bg-gray-200 rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold text-gray-800">
            {gallerySettings.title || "School Gallery"}
          </h2>
          <div className="w-16 h-1 bg-purple-600 mx-auto mt-3 rounded"></div>
          <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
            {gallerySettings.subtitle || "A glimpse into our vibrant school life"}
          </p>
        </div>

        {images.length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <p className="text-gray-500">No images available.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {images.map((img) => (
              <div
                key={img.id}
                className="aspect-square bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition cursor-pointer group"
                onClick={() => setLightboxImage(img)}
              >
                <div className="w-full h-full relative">
                  <img
                    src={img.imageUrl}
                    alt={img.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    onError={(e) => handleImageError(e, "No image")}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition duration-300 flex items-end">
                    <div className="p-3 text-white w-full">
                      <h3 className="font-bold text-sm truncate">{img.title}</h3>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* View All Gallery Button */}
        <div className="text-center mt-8">
          <Link
            to="/gallery"
            className="inline-block bg-purple-700 text-white px-6 py-3 rounded-lg hover:bg-purple-800 transition font-medium"
          >
            View All Gallery →
          </Link>
        </div>
      </div>

      {/* Lightbox */}
      {lightboxImage && (
        <ImageLightbox
          image={lightboxImage}
          images={images}
          onClose={() => setLightboxImage(null)}
          onNext={() => {
            const currentIndex = images.findIndex(img => img.id === lightboxImage.id);
            const nextIndex = (currentIndex + 1) % images.length;
            setLightboxImage(images[nextIndex]);
          }}
          onPrev={() => {
            const currentIndex = images.findIndex(img => img.id === lightboxImage.id);
            const prevIndex = (currentIndex - 1 + images.length) % images.length;
            setLightboxImage(images[prevIndex]);
          }}
        />
      )}
    </section>
  );
}