// src/components/SEO.jsx
// Per-page SEO/meta wrapper around react-helmet-async.
//
// App-level defaults (site title template, base description, Open Graph image)
// live in <DefaultSEO /> in App.jsx. This component overrides them per page.
// A `title` here flows through the app's titleTemplate, becoming
// "Your Title | Tech Zone Academy".
//
// Usage:
//   <SEO title="Admissions" description="Apply to Tech Zone Academy." />
//   <SEO title="Page Not Found" noindex />
import { Helmet } from "react-helmet-async";

export default function SEO({
  title,
  description,
  keywords,
  image,
  noindex = false,
  children,
}) {
  return (
    <Helmet>
      {title && <title>{title}</title>}
      {description && <meta name="description" content={description} />}
      {keywords && <meta name="keywords" content={keywords} />}
      {noindex && <meta name="robots" content="noindex, nofollow" />}

      {/* Open Graph */}
      {title && <meta property="og:title" content={title} />}
      {description && <meta property="og:description" content={description} />}
      {image && <meta property="og:image" content={image} />}

      {/* Twitter Card */}
      {title && <meta name="twitter:title" content={title} />}
      {description && <meta name="twitter:description" content={description} />}
      {image && <meta name="twitter:image" content={image} />}

      {children}
    </Helmet>
  );
}
