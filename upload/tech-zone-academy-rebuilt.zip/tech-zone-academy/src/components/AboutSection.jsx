// src/components/AboutSection.jsx
import { Link } from "react-router-dom";
import { useWebsiteSettings } from "../context/WebsiteSettingsContext";
import { handleImageError } from "../utils/imageFallback";

export default function AboutSection() {
  const { settings } = useWebsiteSettings();
  const schoolName = settings?.schoolInfo?.schoolName || "Tech Zone Academy";

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Column - Image */}
          <div className="relative">
            <div className="rounded-2xl overflow-hidden shadow-xl">
              <img
                src={settings?.aboutImage || "/images/about-default.jpg"}
                alt={`About ${schoolName}`}
                className="w-full h-80 object-cover"
                onError={(e) => handleImageError(e, "About Us")}
              />
            </div>
            <div className="absolute -bottom-6 -right-6 bg-blue-700 text-white rounded-xl p-4 shadow-lg">
              <div className="text-3xl font-bold">{settings?.aboutYearsValue || "10+"}</div>
              <div className="text-sm">{settings?.aboutYearsLabel || "Years of Excellence"}</div>
            </div>
          </div>

          {/* Right Column - Content */}
          <div>
            <span className="text-blue-700 font-semibold text-sm uppercase tracking-wider">
              {settings?.aboutLabel || "About Us"}
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-800 mt-2">
              {settings?.aboutTitle || `Welcome to ${schoolName}`}
            </h2>
            <p className="text-gray-600 mt-4 leading-relaxed">
              {settings?.aboutDescription || 
                "Tech Zone Academy is a premier educational institution dedicated to nurturing young minds with innovative teaching methods and a commitment to excellence."}
            </p>
            <p className="text-gray-600 mt-3 leading-relaxed">
              {settings?.aboutDescription2 || 
                "Our mission is to provide quality education that prepares students for the challenges of tomorrow."}
            </p>

            {/* Stats */}
            <div className="grid grid-cols-4 gap-4 mt-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-700">{settings?.aboutStudentsValue || "500+"}</div>
                <div className="text-xs text-gray-500">{settings?.aboutStudentsLabel || "Students"}</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-700">{settings?.aboutTeachersValue || "30+"}</div>
                <div className="text-xs text-gray-500">{settings?.aboutTeachersLabel || "Teachers"}</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-700">{settings?.aboutSuccessValue || "95%"}</div>
                <div className="text-xs text-gray-500">{settings?.aboutSuccessLabel || "Success Rate"}</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-700">{settings?.aboutYearsValue || "10+"}</div>
                <div className="text-xs text-gray-500">{settings?.aboutYearsLabel || "Years"}</div>
              </div>
            </div>

            <Link
              to={settings?.aboutButtonLink || "/about"}
              className="inline-block mt-6 bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-800 transition"
            >
              {settings?.aboutButtonText || "Learn More →"}
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
