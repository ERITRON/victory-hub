import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useNotifications } from "../context/NotificationContext";
import {
  formatNotificationTime,
  getNotificationStyle,
  getRoleNotificationConfig,
} from "../services/notificationModel";
import Icon from "./Icon";

export default function NotificationBell() {
  const { user, role } = useAuth();
  const {
    notifications,
    unreadCount,
    loading,
    error,
    markAsRead,
    markAllAsRead,
  } = useNotifications();
  const navigate = useNavigate();
  const containerRef = useRef(null);
  const triggerRef = useRef(null);
  const [isOpen, setIsOpen] = useState(false);
  const [isMarkingAll, setIsMarkingAll] = useState(false);
  const roleConfig = getRoleNotificationConfig(role);

  useEffect(() => {
    if (!isOpen) {
      return undefined;
    }

    const handleClickOutside = (event) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target)
      ) {
        setIsOpen(false);
      }
    };

    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        setIsOpen(false);
        triggerRef.current?.focus();
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleKeyDown);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [isOpen]);

  if (!user) {
    return null;
  }

  const handleNotificationClick = async (notification) => {
    setIsOpen(false);

    if (!notification.read) {
      try {
        await markAsRead(notification.id);
      } catch (markError) {
        console.error("Unable to mark notification as read:", markError);
      }
    }

    if (!notification.link || typeof notification.link !== "string") {
      return;
    }

    const link = notification.link.trim();
    if (!link) {
      return;
    }

    if (/^https?:\/\//i.test(link)) {
      window.location.assign(link);
      return;
    }

    navigate(link.startsWith("/") ? link : `/${link}`);
  };

  const handleMarkAllAsRead = async () => {
    if (unreadCount === 0 || isMarkingAll) {
      return;
    }

    setIsMarkingAll(true);

    try {
      await markAllAsRead();
    } catch (markError) {
      console.error("Unable to mark all notifications as read:", markError);
    } finally {
      setIsMarkingAll(false);
    }
  };

  const badgeLabel = unreadCount > 99 ? "99+" : unreadCount;

  return (
    <div ref={containerRef} className="relative inline-flex">
      <button
        ref={triggerRef}
        type="button"
        className="relative inline-flex h-10 w-10 items-center justify-center rounded-md text-current transition-colors hover:bg-black/10 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/80"
        aria-label={
          unreadCount > 0
            ? `Notifications, ${unreadCount} unread`
            : "Notifications"
        }
        aria-haspopup="dialog"
        aria-expanded={isOpen}
        onClick={() => setIsOpen((open) => !open)}
      >
        <Icon name="notification" size={18} aria-hidden="true" />

        {unreadCount > 0 && (
          <span className="absolute -right-1 -top-1 flex min-h-5 min-w-5 items-center justify-center rounded-full bg-red-600 px-1 text-[11px] font-bold leading-none text-white ring-2 ring-white">
            {badgeLabel}
          </span>
        )}
      </button>

      {isOpen && (
        <div
          role="dialog"
          aria-label="Notifications"
          className="absolute right-0 top-full z-[60] mt-2 w-[calc(100vw-2rem)] max-w-96 overflow-hidden rounded-lg border border-gray-200 bg-white text-gray-900 shadow-xl"
        >
          <div className="flex min-h-14 items-center justify-between gap-3 border-b border-gray-200 px-4 py-3">
            <div className="min-w-0">
              <h2 className="text-base font-semibold text-gray-900">
                Notifications
              </h2>
              <p className="text-xs text-gray-500">
                {unreadCount === 0
                  ? "You are all caught up"
                  : `${unreadCount} unread`}
              </p>
            </div>

            <button
              type="button"
              className="shrink-0 text-sm font-medium text-blue-600 transition-colors hover:text-blue-800 disabled:cursor-not-allowed disabled:text-gray-400"
              disabled={unreadCount === 0 || isMarkingAll}
              onClick={handleMarkAllAsRead}
            >
              {isMarkingAll ? "Marking..." : "Mark all as read"}
            </button>
          </div>

          {error && notifications.length > 0 && (
            <div
              role="alert"
              className="border-b border-red-100 bg-red-50 px-4 py-2 text-xs text-red-700"
            >
              {error}
            </div>
          )}

          <div className="max-h-[28rem] overflow-y-auto overscroll-contain">
            {loading ? (
              <div
                className="flex min-h-32 items-center justify-center px-4 py-8 text-sm text-gray-500"
                role="status"
              >
                Loading notifications...
              </div>
            ) : error && notifications.length === 0 ? (
              <div
                className="flex min-h-40 flex-col items-center justify-center px-6 py-8 text-center"
                role="alert"
              >
                <span className="mb-3 text-3xl" aria-hidden="true">
                  {"\u26A0\uFE0F"}
                </span>
                <p className="text-sm font-semibold text-gray-800">
                  Notifications are unavailable
                </p>
                <p className="mt-1 break-words text-xs text-gray-500">
                  {error}
                </p>
              </div>
            ) : notifications.length === 0 ? (
              <div className="flex min-h-40 flex-col items-center justify-center px-6 py-8 text-center">
                <span className="mb-3 text-4xl" aria-hidden="true">
                  {"\u{1F514}"}
                </span>
                <p className="text-sm font-semibold text-gray-800">
                  No notifications
                </p>
                <p className="mt-1 text-xs text-gray-500">
                  {roleConfig.emptyMessage}
                </p>
              </div>
            ) : (
              <div className="divide-y divide-gray-100">
                {notifications.map((notification) => {
                  const style = getNotificationStyle(notification);

                  return (
                    <button
                      key={notification.id}
                      type="button"
                      className={`relative flex w-full items-start gap-3 px-4 py-3 text-left transition-colors hover:bg-gray-50 focus:outline-none focus-visible:bg-blue-50 ${
                        notification.read ? "bg-white" : "bg-blue-50/60"
                      }`}
                      onClick={() =>
                        handleNotificationClick(notification)
                      }
                    >
                      <span
                        className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-md text-lg ${style.iconClass}`}
                        aria-hidden="true"
                      >
                        {style.icon}
                      </span>

                      <span className="min-w-0 flex-1">
                        <span className="flex items-start justify-between gap-2">
                          <span
                            className={`min-w-0 break-words text-sm ${
                              notification.read
                                ? "font-medium text-gray-800"
                                : "font-semibold text-gray-950"
                            }`}
                          >
                            {notification.title || "Notification"}
                          </span>

                          {!notification.read && (
                            <span
                              className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${style.dotClass}`}
                              aria-label="Unread"
                            />
                          )}
                        </span>

                        {notification.message && (
                          <span className="mt-1 block break-words text-xs leading-5 text-gray-600">
                            {notification.message}
                          </span>
                        )}

                        <span className="mt-1.5 block text-xs font-medium text-gray-400">
                          {formatNotificationTime(notification.createdAt, true)}
                        </span>
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <div className="border-t border-gray-200 bg-gray-50 px-4 py-3 text-center">
            <Link
              to="/notifications"
              className="text-sm font-semibold text-blue-600 transition-colors hover:text-blue-800"
              onClick={() => setIsOpen(false)}
            >
              View all notifications
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
