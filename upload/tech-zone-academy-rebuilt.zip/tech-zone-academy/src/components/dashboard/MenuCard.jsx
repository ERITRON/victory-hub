// src/components/dashboard/MenuCard.jsx
// Reusable navigation tile used in the "Dashboard Grid" section of every
// role dashboard (the clickable cards that route to management pages).

import { Link } from "react-router-dom";
import Icon from "../Icon";

function CardIcon({ icon, className = "" }) {
  if (!icon) return null;
  if (typeof icon === "string" && /^[a-z0-9-]+$/i.test(icon)) {
    return <Icon name={icon} className={className} />;
  }
  return <span className={className}>{icon}</span>;
}

export function MenuCard({ icon, title, description, route, color, iconColor = "" }) {
  return (
    <Link
      to={route}
      className={`
        block
        ${color}
        border-2
        rounded-xl
        p-5
        cursor-pointer
        transition-all
        duration-300
        hover:shadow-xl
        hover:-translate-y-1
        hover:border-opacity-100
      `}
    >
      <div className="flex items-start gap-3">
        <div className={`text-3xl ${iconColor}`}><CardIcon icon={icon} /></div>
        <div className="flex-1 min-w-0">
          <h3 className="text-sm sm:text-base font-bold text-gray-800 truncate">
            {title}
          </h3>
          <p className="text-xs sm:text-sm text-gray-600 mt-1 leading-relaxed">
            {description}
          </p>
        </div>
      </div>
      <div className="mt-3 flex justify-end">
        <span className="text-xs text-gray-400">→</span>
      </div>
    </Link>
  );
}

// Convenience wrapper: renders the full grid from an array of item objects.
// items = [{ icon, title, description, route, color, iconColor }, ...]
export function MenuGrid({ items, columns = "sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" }) {
  return (
    <div className={`grid ${columns} gap-4 sm:gap-6`}>
      {items.map((item, index) => (
        <MenuCard key={item.route || index} {...item} />
      ))}
    </div>
  );
}
