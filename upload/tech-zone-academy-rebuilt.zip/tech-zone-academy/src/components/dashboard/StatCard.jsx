// src/components/dashboard/StatCard.jsx
// Reusable statistic tile used across all role dashboards.
// Replaces the repeated `statCards.map(...)` block that used to be
// copy-pasted into AdminDashboard, OwnerDashboard, TeacherDashboard, etc.

import Icon from "../Icon";

function CardIcon({ icon, className = "" }) {
  if (!icon) return null;
  if (typeof icon === "string" && /^[a-z0-9-]+$/i.test(icon)) {
    return <Icon name={icon} className={className} />;
  }
  return <span className={className}>{icon}</span>;
}

export default function StatCard({ icon, value, label, color, bgColor, borderColor = "border-gray-100", loading }) {
  return (
    <div
      className={`${bgColor} rounded-xl shadow-sm p-4 text-center border ${borderColor} hover:shadow-md transition`}
    >
      <div className="mb-1 text-2xl"><CardIcon icon={icon} /></div>
      <div className={`text-2xl font-bold ${color}`}>
        {loading ? (
          <div className="animate-pulse h-8 w-12 bg-gray-200 rounded mx-auto"></div>
        ) : (
          value
        )}
      </div>
      <div className="text-xs sm:text-sm text-gray-600 mt-1">{label}</div>
    </div>
  );
}

// Convenience wrapper: renders a full stat grid from an array of stat objects.
// stats = [{ icon, value, label, color, bgColor, borderColor }, ...]
export function StatGrid({ stats, loading, columns = "grid-cols-2 md:grid-cols-4" }) {
  return (
    <div className={`grid ${columns} gap-4 mb-8`}>
      {stats.map((stat, index) => (
        <StatCard key={stat.label || index} {...stat} loading={loading} />
      ))}
    </div>
  );
}
