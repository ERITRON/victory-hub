// src/components/dashboard/DashboardShell.jsx
// Shared page shell for every role dashboard (Admin, Owner, Teacher,
// Student, Parent, VicePrincipal, Librarian, SuperAdmin).
//
// Before: each *Dashboard.jsx re-implemented this ~90-line block
// (header + badge + action buttons + stat grid + menu grid + footer)
// with only the icon/title/badge text/color differing.
//
// After: each dashboard just supplies its own data and passes it in here.
//
// Icons: the `icon` prop and each action's `icon` prop accept a name from
// the shared <Icon /> component (e.g. "dashboard", "settings"). For backward
// compatibility, an emoji string (e.g. "👔") is still rendered as-is, so
// dashboards can be migrated to named icons one at a time.
//
// Usage:
//   <DashboardShell
//     icon="dashboard"
//     title="Principal Dashboard"
//     welcomeName={user?.email || "Principal"}
//     subtitle="Manage your school from one central location"
//     badgeLabel="Principal"
//     badgeColor="bg-blue-100 text-blue-700"
//     actions={[{ label: "Settings", icon: "settings", onClick: () => navigate("/settings") }]}
//     stats={statCards}
//     statsLoading={loading}
//     menuItems={dashboardItems}
//     footerText="Tech Zone Academy - Principal Dashboard v2.0"
//   />
//
// Sticky white header variant (used by SuperAdmin/Owner-style dashboards):
//   <DashboardShell stickyHeader ... />

import Icon from "../Icon";
import { SkeletonDashboard } from "../LoadingSkeleton";
import { StatGrid } from "./StatCard";
import { MenuGrid } from "./MenuCard";

// Renders an icon that may be either a named <Icon /> key (ascii, e.g.
// "dashboard") or a legacy emoji / raw node, which is rendered unchanged.
function ShellIcon({ icon }) {
  if (!icon) return null;
  if (typeof icon === "string" && /^[a-z0-9-]+$/i.test(icon)) {
    return <Icon name={icon} />;
  }
  return <>{icon}</>;
}

function ActionButton({ label, icon, onClick, className }) {
  return (
    <button
      onClick={onClick}
      className={
        className ||
        "inline-flex items-center gap-2 bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition text-sm"
      }
    >
      {icon && <ShellIcon icon={icon} />}
      {label}
    </button>
  );
}

export default function DashboardShell({
  icon,
  title,
  welcomeName,
  subtitle,
  subtitleSecondary,
  badgeLabel,
  badgeColor = "bg-blue-100 text-blue-700",
  // Pass multiple badges: [{ label, color }, ...]. Rendered alongside badgeLabel if both given.
  badges,
  // Back-compat single-action props
  onSettingsClick,
  settingsLabel = "Settings",
  // Preferred: pass any number of buttons
  actions,
  stickyHeader = false,
  // When true, replaces the stats/content/menu area with a full skeleton.
  loading = false,
  stats = [],
  statsLoading = false,
  statsColumns,
  menuItems = [],
  menuColumns,
  footerText = "Tech Zone Academy",
  children,
}) {
  const resolvedActions =
    actions ||
    (onSettingsClick
      ? [{ label: settingsLabel, icon: "settings", onClick: onSettingsClick }]
      : []);

  const headerContent = (
    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
      <div>
        <h1 className={stickyHeader ? "text-2xl font-bold text-gray-800" : "text-2xl sm:text-3xl font-bold text-gray-800"}>
          <span className="inline-flex items-center gap-2">
            <ShellIcon icon={icon} />
            <span>{title}</span>
          </span>
        </h1>
        {welcomeName && (
          <p className={stickyHeader ? "text-sm text-gray-500" : "text-gray-600 mt-1"}>
            Welcome back, {welcomeName}!
          </p>
        )}
        {subtitle && <p className={stickyHeader ? "text-xs text-gray-400" : "text-sm text-gray-500"}>{subtitle}</p>}
        {subtitleSecondary && <p className="text-xs text-gray-400">{subtitleSecondary}</p>}
      </div>
      <div className="flex items-center gap-3">
        {badgeLabel && (
          <span className={`${badgeColor} px-3 py-1 rounded-full text-sm font-medium`}>
            {badgeLabel}
          </span>
        )}
        {badges?.map((b, i) => (
          <span key={i} className={`${b.color || badgeColor} px-3 py-1 rounded-full text-sm font-medium`}>
            {b.label}
          </span>
        ))}
        {resolvedActions.map((action, i) => (
          <ActionButton key={i} {...action} />
        ))}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {stickyHeader ? (
        <div className="bg-white border-b shadow-sm sticky top-0 z-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">{headerContent}</div>
        </div>
      ) : null}

      <div
        className={
          stickyHeader
            ? "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6"
            : "max-w-7xl mx-auto py-6 sm:py-8 px-4 sm:px-6 lg:px-8"
        }
      >
        {!stickyHeader && <div className="mb-8">{headerContent}</div>}

        {loading ? (
          <SkeletonDashboard statCount={stats.length || 4} />
        ) : (
          <>
            {/* Quick Stats */}
            {stats.length > 0 && (
              <StatGrid stats={stats} loading={statsLoading} columns={statsColumns} />
            )}

            {/* Optional extra content (charts, tables, info panels, etc.) */}
            {children}

            {/* Dashboard Grid */}
            {menuItems.length > 0 && <MenuGrid items={menuItems} columns={menuColumns} />}

            {/* Footer */}
            {!stickyHeader && (
              <div className="mt-8 pt-6 border-t border-gray-200 text-center">
                <p className="text-xs sm:text-sm text-gray-500">{footerText}</p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
