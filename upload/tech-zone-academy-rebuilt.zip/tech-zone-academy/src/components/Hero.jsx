// src/components/Hero.jsx
import { Link } from "react-router-dom";
import { useWebsiteSettings } from "../context/WebsiteSettingsContext";

export default function Hero() {
  const { settings, loading } = useWebsiteSettings();
  const hero = settings?.hero || {};
  const school = settings?.schoolInfo || {};

  const getAnimationClass = () => {
    const animation = hero.animation || "fade-in";
    switch (animation) {
      case "fade-in": return "animate-fadeIn";
      case "slide-up": return "animate-slideUp";
      case "slide-in": return "animate-slideIn";
      case "zoom-in": return "animate-zoomIn";
      default: return "";
    }
  };

  const getAlignmentClass = () => {
    const alignment = hero.alignment || "center";
    switch (alignment) {
      case "left": return "text-left";
      case "right": return "text-right";
      default: return "text-center";
    }
  };

  if (loading) {
    return (
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="animate-pulse">
            <div className="h-12 w-64 bg-blue-400/30 rounded-lg mx-auto mb-4"></div>
            <div className="h-6 w-96 bg-blue-400/30 rounded-lg mx-auto mb-6"></div>
            <div className="h-12 w-40 bg-blue-400/30 rounded-lg mx-auto"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <section 
      className={`bg-gradient-to-r ${hero.overlayColor || "from-blue-600 to-blue-800"} text-white ${hero.height || "py-20"} relative overflow-hidden`}
    >
      {/* Background Image */}
      {hero.backgroundImage && (
        <div className="absolute inset-0 z-0">
          <img 
            src={hero.backgroundImage} 
            alt="Hero Background" 
            className="w-full h-full object-cover"
          />
          <div className={`absolute inset-0 bg-black opacity-${hero.overlayOpacity || "70"}`}></div>
        </div>
      )}

      <div className={`relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 ${getAlignmentClass()}`}>
        <div className={getAnimationClass()}>
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
            {school.schoolName || "Tech Zone Academy"}
          </h1>
          <p className="text-xl sm:text-2xl md:text-3xl font-semibold mb-2 text-blue-100">
            {school.motto || hero.tagline || "Building Bright Futures"}
          </p>
          <p className="text-lg text-blue-100 mb-6 max-w-2xl mx-auto">
            {hero.description || "KG-3 to Grade 8 | Quality Education for Every Child"}
          </p>
          {hero.buttonText && (
            <Link
              to={hero.buttonLink || "/admissions"}
              className="inline-block bg-white text-blue-700 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition duration-200 shadow-lg hover:shadow-xl"
            >
              {hero.buttonText}
            </Link>
          )}
        </div>
      </div>
    </section>
  );
}
