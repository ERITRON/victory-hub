// src/components/Navbar.jsx
import { useState, useEffect, useRef } from "react";
import { useLanguage } from "../context/LanguageContext";
import { useAuth } from "../context/AuthContext";
import { useWebsiteSettings } from "../context/WebsiteSettingsContext";
import { signOut, auth } from "../supabase/supabase";
import { Link, useNavigate, useLocation } from "react-router-dom";
import Logo from "./Logo";
import NotificationBell from "./NotificationBell";

export default function Navbar() {
  const { language, changeLanguage } = useLanguage();
  const { user, role } = useAuth();
  const { settings, loading } = useWebsiteSettings();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const menuRef = useRef(null);
  const dropdownRef = useRef(null);

  // Get navigation settings
  const navSettings = settings?.navigation || {};

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setIsMenuOpen(false);
      }
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Close menu on route change
  useEffect(() => {
     
    setIsMenuOpen(false);
  }, [location]);

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Prevent body scroll when mobile menu is open
  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }

    return () => {
      document.body.style.overflow = "unset";
    };
  }, [isMenuOpen]);

  const logout = async () => {
    try {
      await signOut(auth);
      navigate("/");
      setIsMenuOpen(false);
      setIsDropdownOpen(false);
    } catch (error) {
      console.error(error);
    }
  };

  const getDashboardLink = () => {
    switch (role) {
      case "super_admin":
        return "/super-admin/dashboard";
      case "owner":
        return "/owner/dashboard";
      case "admin":
        return "/admin-dashboard";
      case "vice_principal":
        return "/vice-principal/dashboard";
      case "librarian":
        return "/librarian/dashboard";
      case "teacher":
        return "/teacher-dashboard";
      case "parent":
        return "/parent-dashboard";
      case "student":
        return "/student-dashboard";
      default:
        return "/";
    }
  };

  const getRoleLabel = (role) => {
    switch (role) {
      case "super_admin": return "👑 Super Owner";
      case "owner": return "🏢 School Owner";
      case "admin": return "👔 Principal";
      case "vice_principal": return "👔 Vice Principal";
      case "librarian": return "📚 Librarian";
      case "teacher": return "👨‍🏫 Teacher";
      case "parent": return "👨‍👩‍👦 Parent";
      case "student": return "🎓 Student";
      default: return role;
    }
  };

  // Get navigation items from settings or use defaults
  const navItems = navSettings.items || [
    { id: "1", label: "Home", path: "/", enabled: true },
    { id: "2", label: "About", path: "/about", enabled: true },
    { id: "3", label: "Admissions", path: "/admissions", enabled: true },
    { id: "4", label: "Student", path: "/student", enabled: true },
    { id: "5", label: "Teacher", path: "/teacher", enabled: true },
    { id: "6", label: "Parent", path: "/parent", enabled: true },
    { id: "7", label: "News", path: "/news", enabled: true },
    { id: "8", label: "Gallery", path: "/gallery", enabled: true },
    { id: "9", label: "Events", path: "/events", enabled: true },
    { id: "10", label: "Contact", path: "/contact", enabled: true },
  ];

  // Filter enabled items
  const enabledNavItems = navItems.filter(item => item.enabled !== false);

  // Get translation for labels if available
  const getLabel = (item) => {
    if (language !== 'en') {
      const translations = {
        'am': {
          'Home': 'መነሻ',
          'About': 'ስለ እኛ',
          'Admissions': 'ምዝገባ',
          'Student': 'ተማሪ',
          'Teacher': 'መምህር',
          'Parent': 'ወላጅ',
          'News': 'ዜና',
          'Gallery': 'ስዕላት',
          'Events': 'ክስተቶች',
          'Contact': 'አግኙን',
          'Dashboard': 'ዳሽቦርድ',
          'Profile': 'መገለጫ',
          'Login': 'ግባ',
          'Logout': 'ውጣ'
        },
        'or': {
          'Home': 'Mana',
          'About': 'Waa\'ee',
          'Admissions': 'Galmee',
          'Student': 'Baraataa',
          'Teacher': 'Barsisaa',
          'Parent': 'Maati',
          'News': 'Oduu',
          'Gallery': 'Fakkii',
          'Events': 'Tapha',
          'Contact': 'Quunnamuu',
          'Dashboard': 'Dashboordii',
          'Profile': 'Profaayilii',
          'Login': 'Seenuu',
          'Logout': 'Baasuu'
        }
      };
      return translations[language]?.[item.label] || item.label;
    }
    return item.label;
  };

  const isActive = (path) => {
    return location.pathname === path;
  };

  // Loading state
  if (loading) {
    return (
      <nav className="bg-gradient-to-r from-blue-700 to-blue-800 text-white shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="animate-pulse">
              <div className="h-8 w-32 bg-blue-500/30 rounded"></div>
            </div>
            <div className="hidden md:flex items-center space-x-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="h-6 w-16 bg-blue-500/30 rounded animate-pulse"></div>
              ))}
            </div>
          </div>
        </div>
      </nav>
    );
  }

  // Determine navbar classes
  const getNavbarClasses = () => {
    let classes = "sticky top-0 z-50 transition-all duration-300 text-white shadow-lg";

    if (navSettings.backgroundColor) {
      classes += ` bg-gradient-to-r ${navSettings.backgroundColor}`;
    } else {
      classes += " bg-gradient-to-r from-blue-700 to-blue-800";
    }

    if (navSettings.sticky === false) {
      classes = classes.replace("sticky", "relative");
    }

    if (isScrolled && navSettings.sticky !== false) {
      classes += " shadow-2xl";
      if (navSettings.backgroundColor) {
        classes += " opacity-95";
      }
    }

    return classes;
  };

  const textColorClass = navSettings.textColor || "text-white";

  return (
    <nav className={getNavbarClasses()}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo - Left */}
          <div className="flex-shrink-0">
            <Logo />
          </div>

          {/* Desktop Navigation - Center */}
          <div className="hidden lg:flex items-center space-x-1 xl:space-x-2">
            {enabledNavItems.map((item) => (
              <Link
                key={item.id || item.path}
                to={item.path}
                className={`px-3 py-2 rounded-md text-sm font-medium transition duration-200 ${textColorClass} ${
                  isActive(item.path)
                    ? "bg-blue-600 bg-opacity-30"
                    : `hover:bg-blue-600 hover:bg-opacity-30`
                }`}
              >
                {getLabel(item)}
              </Link>
            ))}
          </div>

          {/* Right Side - Desktop */}
          <div className="hidden lg:flex items-center space-x-3">
            {user ? (
              <div className="flex items-center gap-2">
                <NotificationBell />

                <div className="relative" ref={dropdownRef}>
                  <button
                    onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                    className={`flex items-center gap-2 px-3 py-2 rounded-md transition duration-200 ${textColorClass} hover:bg-white/10`}
                  >
                    <span className="text-sm font-medium">
                      {role === "super_admin" ? "👑" : 
                       role === "owner" ? "🏢" : 
                       role === "admin" ? "👔" : 
                       role === "vice_principal" ? "👔" : 
                       role === "librarian" ? "📚" : 
                       role === "teacher" ? "👨‍🏫" : 
                       role === "parent" ? "👨‍👩‍👦" : "🎓"}
                    </span>
                    <span className="text-sm font-medium hidden xl:inline">Account</span>
                    <svg
                      className={`w-4 h-4 transition-transform duration-200 ${
                        isDropdownOpen ? "rotate-180" : ""
                      }`}
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>

                  {/* Dropdown Menu */}
                  {isDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-2xl py-2 z-50 overflow-hidden">
                      <div className="px-4 py-3 border-b border-gray-100">
                        <p className="text-sm font-semibold text-gray-800 truncate">
                          {user?.displayName || "User"}
                        </p>
                        <p className="text-xs text-gray-500 truncate">{user?.email}</p>
                        <span className="inline-block mt-1 px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full text-xs font-medium capitalize">
                          {getRoleLabel(role) || "User"}
                        </span>
                      </div>

                      <Link
                        to={getDashboardLink()}
                        onClick={() => setIsDropdownOpen(false)}
                        className="flex items-center gap-3 px-4 py-3 text-sm text-gray-700 hover:bg-gray-50 transition"
                      >
                        <span>📊</span> Dashboard
                      </Link>

                      <Link
                        to="/profile"
                        onClick={() => setIsDropdownOpen(false)}
                        className="flex items-center gap-3 px-4 py-3 text-sm text-gray-700 hover:bg-gray-50 transition"
                      >
                        <span>⚙️</span> Profile Settings
                      </Link>

                      {(role === "admin" || role === "super_admin") && (
                        <Link
                          to="/website-settings"
                          onClick={() => setIsDropdownOpen(false)}
                          className="flex items-center gap-3 px-4 py-3 text-sm text-gray-700 hover:bg-gray-50 transition"
                        >
                          <span>🌐</span> Website Settings
                        </Link>
                      )}

                      {role === "vice_principal" && (
                        <Link
                          to="/vice-principal/dashboard"
                          onClick={() => setIsDropdownOpen(false)}
                          className="flex items-center gap-3 px-4 py-3 text-sm text-gray-700 hover:bg-gray-50 transition"
                        >
                          <span>👔</span> Vice Principal Dashboard
                        </Link>
                      )}

                      {role === "librarian" && (
                        <Link
                          to="/library"
                          onClick={() => setIsDropdownOpen(false)}
                          className="flex items-center gap-3 px-4 py-3 text-sm text-gray-700 hover:bg-gray-50 transition"
                        >
                          <span>📚</span> Library
                        </Link>
                      )}

                      <div className="border-t border-gray-100 my-1"></div>

                      <button
                        onClick={logout}
                        className="flex items-center gap-3 w-full text-left px-4 py-3 text-sm text-red-600 hover:bg-red-50 transition"
                      >
                        <span>🚪</span> Logout
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <Link
                to="/login"
                className={`bg-white text-blue-700 px-4 py-2 rounded-md text-sm font-medium hover:bg-gray-100 transition duration-200 shadow-md hover:shadow-lg`}
              >
                Login
              </Link>
            )}

            {/* Language Selector */}
            <select
              value={language}
              onChange={(e) => changeLanguage(e.target.value)}
              className="bg-white/10 text-white rounded-md px-3 py-2 text-sm font-medium border border-white/20 hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-blue-400 cursor-pointer transition"
            >
              <option value="en" className="text-gray-800">🇬🇧 EN</option>
              <option value="am" className="text-gray-800">🇪🇹 አማ</option>
              <option value="or" className="text-gray-800">🇪🇹 ORO</option>
            </select>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden flex items-center gap-2">
            {/* Mobile Language Selector */}
            <select
              value={language}
              onChange={(e) => changeLanguage(e.target.value)}
              className="bg-white/10 text-white rounded-md px-2 py-1.5 text-sm font-medium border border-white/20 focus:outline-none focus:ring-2 focus:ring-blue-400 cursor-pointer"
            >
              <option value="en" className="text-gray-800">🇬🇧</option>
              <option value="am" className="text-gray-800">🇪🇹</option>
              <option value="or" className="text-gray-800">🇪🇹</option>
            </select>

            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md hover:bg-white/10 focus:outline-none transition duration-200 relative"
              aria-label="Toggle menu"
            >
              <span className="sr-only">Open main menu</span>
              <div className="w-6 h-6 relative">
                <span
                  className={`absolute block h-0.5 w-6 bg-white transform transition duration-300 ease-in-out ${
                    isMenuOpen ? "rotate-45 top-3" : "rotate-0 top-1"
                  }`}
                />
                <span
                  className={`absolute block h-0.5 w-6 bg-white transform transition duration-300 ease-in-out ${
                    isMenuOpen ? "opacity-0" : "opacity-100 top-3"
                  }`}
                />
                <span
                  className={`absolute block h-0.5 w-6 bg-white transform transition duration-300 ease-in-out ${
                    isMenuOpen ? "-rotate-45 top-3" : "rotate-0 top-5"
                  }`}
                />
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu - Full Screen Overlay */}
      <div
        className={`lg:hidden fixed inset-0 bg-blue-900/95 backdrop-blur-lg transform transition-transform duration-300 ease-in-out z-40 ${
          isMenuOpen ? "translate-x-0" : "translate-x-full"
        }`}
        ref={menuRef}
      >
        <div className="flex flex-col h-full pt-20 px-6 pb-6 overflow-y-auto">
          {/* Close button */}
          <button
            onClick={() => setIsMenuOpen(false)}
            className="absolute top-4 right-4 p-2 text-white hover:bg-white/10 rounded-lg transition"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          <div className="flex-1">
            {/* User Info - Mobile */}
            {user && (
              <div className="bg-white/10 rounded-xl p-4 mb-6">
                <p className="text-white font-semibold text-lg">
                  {user?.displayName || "User"}
                </p>
                <p className="text-blue-200 text-sm">{user?.email}</p>
                <span className="inline-block mt-2 px-3 py-1 bg-blue-600 rounded-full text-xs font-medium capitalize">
                  {getRoleLabel(role) || "User"}
                </span>
              </div>
            )}

            {/* Navigation Links */}
            <div className="space-y-1">
              {enabledNavItems.map((item) => (
                <Link
                  key={item.id || item.path}
                  to={item.path}
                  onClick={() => setIsMenuOpen(false)}
                  className={`block px-4 py-3 rounded-xl text-base font-medium transition duration-200 ${
                    isActive(item.path)
                      ? "bg-blue-600 text-white"
                      : "text-white hover:bg-blue-700"
                  }`}
                >
                  {getLabel(item)}
                </Link>
              ))}
            </div>
          </div>

          {/* Bottom Section - Mobile */}
          <div className="pt-6 border-t border-blue-700 space-y-3">
            {user ? (
              <>
                <Link
                  to={getDashboardLink()}
                  onClick={() => setIsMenuOpen(false)}
                  className="flex items-center justify-center gap-2 w-full bg-green-600 text-white px-4 py-3 rounded-xl text-sm font-medium hover:bg-green-700 transition"
                >
                  📊 Dashboard
                </Link>

                <div className="flex w-full items-center justify-between rounded-xl bg-blue-800 px-4 py-2 text-white">
                  <span className="text-sm font-medium">Notifications</span>
                  <NotificationBell />
                </div>

                <Link
                  to="/profile"
                  onClick={() => setIsMenuOpen(false)}
                  className="flex items-center justify-center gap-2 w-full bg-blue-600 text-white px-4 py-3 rounded-xl text-sm font-medium hover:bg-blue-700 transition"
                >
                  ⚙️ Profile
                </Link>

                {(role === "admin" || role === "super_admin") && (
                  <Link
                    to="/website-settings"
                    onClick={() => setIsMenuOpen(false)}
                    className="flex items-center justify-center gap-2 w-full bg-purple-600 text-white px-4 py-3 rounded-xl text-sm font-medium hover:bg-purple-700 transition"
                  >
                    🌐 Website Settings
                  </Link>
                )}

                {role === "vice_principal" && (
                  <Link
                    to="/vice-principal/dashboard"
                    onClick={() => setIsMenuOpen(false)}
                    className="flex items-center justify-center gap-2 w-full bg-purple-600 text-white px-4 py-3 rounded-xl text-sm font-medium hover:bg-purple-700 transition"
                  >
                    👔 VP Dashboard
                  </Link>
                )}

                {role === "librarian" && (
                  <Link
                    to="/library"
                    onClick={() => setIsMenuOpen(false)}
                    className="flex items-center justify-center gap-2 w-full bg-indigo-600 text-white px-4 py-3 rounded-xl text-sm font-medium hover:bg-indigo-700 transition"
                  >
                    📚 Library
                  </Link>
                )}

                <button
                  onClick={logout}
                  className="flex items-center justify-center gap-2 w-full bg-red-600 text-white px-4 py-3 rounded-xl text-sm font-medium hover:bg-red-700 transition"
                >
                  🚪 Logout
                </button>
              </>
            ) : (
              <Link
                to="/login"
                onClick={() => setIsMenuOpen(false)}
                className="flex items-center justify-center w-full bg-white text-blue-700 px-4 py-3 rounded-xl text-sm font-medium hover:bg-gray-100 transition"
              >
                Login
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
