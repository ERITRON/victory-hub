// src/components/LoadingSkeleton.jsx
// Reusable loading-skeleton placeholders. Use these while data is being
// fetched to avoid layout shift and blank screens. All variants use
// Tailwind's `animate-pulse` for the shimmer effect.
//
// Usage:
//   <SkeletonCard count={3} />
//   <SkeletonTable rows={5} cols={4} />
//   <SkeletonDashboard />

// A single grey block; the shared building block for every skeleton below.
function Block({ className = "" }) {
  return <div className={`bg-gray-200 rounded ${className}`} />;
}

// SkeletonCard — one or more card placeholders.
// Props: count (number of cards), className (extra classes on each card).
export function SkeletonCard({ count = 1, className = "" }) {
  return (
    <>
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={i}
          className={`animate-pulse bg-white rounded-xl border border-gray-100 shadow-sm p-5 ${className}`}
        >
          <div className="flex items-center gap-4">
            <Block className="h-12 w-12 rounded-full" />
            <div className="flex-1 space-y-2">
              <Block className="h-4 w-3/4" />
              <Block className="h-3 w-1/2" />
            </div>
          </div>
          <div className="mt-4 space-y-2">
            <Block className="h-3 w-full" />
            <Block className="h-3 w-5/6" />
            <Block className="h-3 w-2/3" />
          </div>
        </div>
      ))}
    </>
  );
}

// SkeletonTable — a table placeholder with a header row and body rows.
// Props: rows, cols, className (extra classes on the wrapper).
export function SkeletonTable({ rows = 5, cols = 4, className = "" }) {
  return (
    <div
      className={`animate-pulse overflow-hidden rounded-xl border border-gray-100 bg-white shadow-sm ${className}`}
    >
      {/* Header */}
      <div
        className="grid gap-4 border-b border-gray-100 bg-gray-50 px-4 py-3"
        style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}
      >
        {Array.from({ length: cols }).map((_, c) => (
          <Block key={c} className="h-4 w-3/4" />
        ))}
      </div>

      {/* Body */}
      <div className="divide-y divide-gray-100">
        {Array.from({ length: rows }).map((_, r) => (
          <div
            key={r}
            className="grid items-center gap-4 px-4 py-4"
            style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}
          >
            {Array.from({ length: cols }).map((_, c) => (
              <Block
                key={c}
                className={`h-4 ${c === 0 ? "w-1/2" : "w-3/4"}`}
              />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

// SkeletonList — a vertical list of rows, each with an avatar + two text
// lines and a trailing action block. Good for member/user/notification lists.
// Props: count (number of rows), className (extra classes on the wrapper).
export function SkeletonList({ count = 5, className = "" }) {
  return (
    <div
      className={`animate-pulse divide-y divide-gray-100 rounded-xl border border-gray-100 bg-white shadow-sm ${className}`}
    >
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="flex items-center gap-4 px-4 py-4">
          <Block className="h-10 w-10 rounded-full" />
          <div className="flex-1 space-y-2">
            <Block className="h-4 w-1/3" />
            <Block className="h-3 w-1/2" />
          </div>
          <Block className="h-8 w-20 rounded-lg" />
        </div>
      ))}
    </div>
  );
}

// SkeletonDashboard — full dashboard placeholder: header, stat cards, and
// chart panels. Props: statCount, className (extra classes on the wrapper).
export function SkeletonDashboard({ statCount = 4, className = "" }) {
  return (
    <div className={`animate-pulse space-y-8 ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between gap-4">
        <div className="space-y-2">
          <Block className="h-7 w-56" />
          <Block className="h-4 w-40" />
        </div>
        <Block className="h-10 w-28 rounded-lg" />
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: statCount }).map((_, i) => (
          <div
            key={i}
            className="rounded-xl border border-gray-100 bg-white p-5 shadow-sm"
          >
            <div className="flex items-center justify-between">
              <div className="flex-1 space-y-2">
                <Block className="h-3 w-1/2" />
                <Block className="h-6 w-3/4" />
              </div>
              <Block className="h-12 w-12 rounded-full" />
            </div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="rounded-xl border border-gray-100 bg-white p-5 shadow-sm lg:col-span-2">
          <Block className="mb-4 h-4 w-40" />
          <Block className="h-64 w-full rounded-lg" />
        </div>
        <div className="rounded-xl border border-gray-100 bg-white p-5 shadow-sm">
          <Block className="mb-4 h-4 w-32" />
          <div className="flex h-64 items-center justify-center">
            <Block className="h-40 w-40 rounded-full" />
          </div>
        </div>
      </div>
    </div>
  );
}
