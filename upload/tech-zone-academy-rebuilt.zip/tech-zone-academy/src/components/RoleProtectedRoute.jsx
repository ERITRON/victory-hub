// src/components/RoleProtectedRoute.jsx
import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useState, useEffect } from "react";
import { db, doc, getDoc } from "../supabase/supabase";

export default function RoleProtectedRoute({
  children,
  allowedRole,
  allowedRoles = [], // ✅ Added support for multiple roles
  redirectTo = "/login",
  unauthorizedRedirect = "/",
}) {
  const { user, role, loading } = useAuth();
  const [userRole, setUserRole] = useState(role);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const checkUserRole = async () => {
      if (!user) {
        setChecking(false);
        return;
      }

      try {
        const userDoc = await getDoc(doc(db, "users", user.uid));
        
        if (userDoc.exists()) {
          const data = userDoc.data();
          setUserRole(data.role);
        } else {
          const studentDoc = await getDoc(doc(db, "students", user.uid));
          if (studentDoc.exists()) {
            setUserRole("student");
          } else {
            setUserRole(null);
          }
        }
      } catch (error) {
        console.error("Error checking user role:", error);
        setUserRole(null);
      } finally {
        setChecking(false);
      }
    };

    checkUserRole();
  }, [user]);

  if (loading || checking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="relative">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-700 mx-auto"></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="h-8 w-8 rounded-full bg-blue-100/20 backdrop-blur-sm"></div>
            </div>
          </div>
          <p className="mt-4 text-gray-600 font-medium">Loading...</p>
          <p className="text-sm text-gray-400 mt-1">Please wait while we verify your session</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to={redirectTo} state={{ from: window.location.pathname }} replace />;
  }

  const roleDisplay = {
    super_admin: "👑 Super Owner",
    owner: "🏢 School Owner",
    admin: "👔 Principal",
    vice_principal: "👔 Vice Principal",
    librarian: "📚 Librarian",
    teacher: "👨‍🏫 Teacher",
    parent: "👨‍👩‍👦 Parent",
    student: "🎓 Student",
  };

  // ✅ Check if user role is allowed (supports both single role and multiple roles)
  const isAllowed = () => {
    if (allowedRoles && allowedRoles.length > 0) {
      return allowedRoles.includes(userRole);
    }
    return userRole === allowedRole;
  };

  if (!isAllowed()) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">🚫</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h2>
          <p className="text-gray-600 mb-2">
            You don't have permission to access this page.
          </p>
          <p className="text-sm text-gray-500 mb-6">
            This page is for <span className="font-semibold text-blue-600">
              {allowedRoles && allowedRoles.length > 0 
                ? allowedRoles.map(r => roleDisplay[r] || r).join(" & ")
                : roleDisplay[allowedRole] || allowedRole}
            </span> users only.
            Your current role is <span className="font-semibold text-gray-700">{roleDisplay[userRole] || userRole || "not set"}</span>.
          </p>
          <button
            onClick={() => window.location.href = unauthorizedRedirect}
            className="bg-blue-700 text-white px-6 py-2.5 rounded-lg hover:bg-blue-800 transition font-medium"
          >
            Go to Home
          </button>
        </div>
      </div>
    );
  }

  return children;
}