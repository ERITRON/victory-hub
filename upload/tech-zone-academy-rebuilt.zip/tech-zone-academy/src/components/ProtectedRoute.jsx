// src/components/ProtectedRoute.jsx
import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function ProtectedRoute({ children, allowedRoles }) {
  const { user, role, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(role)) {
    switch (role) {
      case "super_admin":
        return <Navigate to="/super-admin/dashboard" replace />;
      case "owner":
        return <Navigate to="/owner/dashboard" replace />;
      case "admin":
        return <Navigate to="/admin-dashboard" replace />;
      case "vice_principal":
        return <Navigate to="/vice-principal/dashboard" replace />;
      case "librarian":
        return <Navigate to="/librarian/dashboard" replace />;
      case "teacher":
        return <Navigate to="/teacher-dashboard" replace />;
      case "parent":
        return <Navigate to="/parent-dashboard" replace />;
      case "student":
        return <Navigate to="/student-dashboard" replace />;
      default:
        return <Navigate to="/" replace />;
    }
  }

  return children;
}