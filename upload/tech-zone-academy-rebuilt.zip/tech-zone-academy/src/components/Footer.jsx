import { Link } from "react-router-dom";
import { useWebsiteSettings } from "../context/WebsiteSettingsContext";

const socialLinks = [
  { key: "facebook", label: "Facebook" },
  { key: "twitter", label: "Twitter" },
  { key: "instagram", label: "Instagram" },
  { key: "youtube", label: "YouTube" },
  { key: "telegram", label: "Telegram" },
  { key: "tiktok", label: "TikTok" },
  { key: "linkedin", label: "LinkedIn" },
];

export default function Footer() {
  const { settings, loading } = useWebsiteSettings();
  const footer = settings?.footer || {};
  const nav = settings?.navigation || {};
  const school = settings?.schoolInfo || {};
  const navItems = nav.items?.filter((item) => item.enabled !== false) || [];

  if (loading) {
    return (
      <footer className="bg-gray-900 py-8 text-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse">
            <div className="mx-auto mb-4 h-6 w-48 rounded bg-gray-700" />
            <div className="mx-auto h-4 w-64 rounded bg-gray-700" />
          </div>
        </div>
      </footer>
    );
  }

  const schoolName = school.schoolName || nav.websiteName || "Tech Zone Academy";

  return (
    <footer className="bg-gray-900 text-white">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <h3 className="mb-4 text-lg font-bold">About Us</h3>
            <p className="text-sm leading-relaxed text-gray-400">
              {schoolName}{school.motto ? ` - ${school.motto}` : ""}
            </p>
            <div className="mt-4 space-y-2 text-sm text-gray-400">
              {school.address && <p>{school.address}</p>}
              {school.addressLine2 && <p>{school.addressLine2}</p>}
              {school.phone && <p><a href={`tel:${school.phone}`} className="hover:text-white">{school.phone}</a></p>}
              {school.secondaryPhone && <p><a href={`tel:${school.secondaryPhone}`} className="hover:text-white">{school.secondaryPhone}</a></p>}
              {school.email && <p><a href={`mailto:${school.email}`} className="hover:text-white">{school.email}</a></p>}
              {school.workingHours && <p>{school.workingHours}</p>}
              {school.saturdayHours && <p>{school.saturdayHours}</p>}
            </div>
          </div>

          <div>
            <h3 className="mb-4 text-lg font-bold">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              {navItems.slice(0, 5).map((item) => (
                <li key={item.path}><Link to={item.path} className="text-gray-400 transition hover:text-white">{item.label}</Link></li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-lg font-bold">More Links</h3>
            <ul className="space-y-2 text-sm">
              {navItems.slice(5).map((item) => (
                <li key={item.path}><Link to={item.path} className="text-gray-400 transition hover:text-white">{item.label}</Link></li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-lg font-bold">Follow Us</h3>
            <div className="flex flex-wrap gap-2">
              {socialLinks.map(({ key, label }) => {
                const url = footer.social?.[key];
                return url ? (
                  <a key={key} href={url} target="_blank" rel="noopener noreferrer" className="rounded-lg bg-gray-800 px-3 py-2 text-sm transition hover:bg-gray-700" aria-label={label}>
                    {label}
                  </a>
                ) : null;
              })}
            </div>
          </div>
        </div>

        <div className="mt-8 border-t border-gray-800 pt-8 text-center text-sm text-gray-400">
          <p>{footer.copyright || `${schoolName}. All rights reserved.`}</p>
        </div>
      </div>
    </footer>
  );
}
