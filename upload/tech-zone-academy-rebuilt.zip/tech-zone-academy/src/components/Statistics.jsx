// src/components/Statistics.jsx
import { useEffect, useState } from "react";
import { db, collection, getDocs } from "../supabase/supabase";
import { useWebsiteSettings } from "../context/WebsiteSettingsContext";

export default function Statistics() {
  const { settings, loading } = useWebsiteSettings();
  const statsData = settings?.statistics || {};
  const [liveStats, setLiveStats] = useState({
    students: 0,
    teachers: 0,
    parents: 0,
    grades: 0,
  });

  const fetchLiveStats = async () => {
    try {
      const studentsSnap = await getDocs(collection(db, "students"));
      const teachersSnap = await getDocs(collection(db, "teachers"));
      const usersSnap = await getDocs(collection(db, "users"));
      const gradesSnap = await getDocs(collection(db, "grades"));

      let parents = 0;
      usersSnap.forEach((doc) => {
        const data = doc.data();
        if (data.role === "parent") parents++;
      });

      setLiveStats({
        students: studentsSnap.size,
        teachers: teachersSnap.size,
        parents: parents,
        grades: gradesSnap.size,
      });
    } catch (error) {
      console.error("Error fetching stats:", error);
    }
  };

  useEffect(() => {
     
    fetchLiveStats();
  }, []);

  if (!statsData.enabled) return null;

  if (loading) {
    return (
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="bg-white rounded-xl shadow p-4 animate-pulse">
                <div className="h-10 w-10 bg-gray-200 rounded-full mx-auto mb-2"></div>
                <div className="h-8 w-16 bg-gray-200 rounded mx-auto mb-2"></div>
                <div className="h-4 w-20 bg-gray-200 rounded mx-auto"></div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  const getStatValue = (key) => {
    const stat = statsData[key];
    if (!stat) return "0";
    if (key === "years") return stat.value || "5+";
    if (stat.manual) return stat.value || "0";
    const liveValue = liveStats[key];
    return liveValue !== undefined ? liveValue : "0";
  };

  const statKeys = ["students", "teachers", "parents", "grades", "years"];

  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
          {statKeys.map((key) => {
            const stat = statsData[key] || {};
            const value = getStatValue(key);
            return (
              <div
                key={key}
                className="bg-white rounded-xl shadow-sm p-4 text-center border border-gray-100 hover:shadow-md transition duration-300 hover:-translate-y-1"
              >
                <div className="text-3xl sm:text-4xl mb-1">{stat.icon || "📊"}</div>
                <div className="text-2xl sm:text-3xl font-bold text-gray-800">
                  {value}
                </div>
                <div className="text-xs sm:text-sm text-gray-600 mt-1">
                  {stat.label || key.charAt(0).toUpperCase() + key.slice(1)}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}