// src/components/ErrorBoundary.jsx
// App-wide error boundary. Catches render/lifecycle errors in its child tree,
// logs them, and shows a professional fallback UI instead of a blank screen.
//
// Usage:
//   <ErrorBoundary>
//     <App />
//   </ErrorBoundary>
//
//   <ErrorBoundary
//     errorMessage="We couldn't load your dashboard."
//     onError={(error, info) => Sentry.captureException(error)}
//   >
//     <Dashboard />
//   </ErrorBoundary>
import { Component } from "react";
import Icon from "./Icon";

export default class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  // Update state so the next render shows the fallback UI.
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  // Side effects: log the error and forward it to an error tracking service.
  componentDidCatch(error, errorInfo) {
    // Always log to the console for local debugging.
    console.error("ErrorBoundary caught an error:", error, errorInfo);

    // Option to send to an error tracking service (Sentry, LogRocket, etc.).
    // Pass an `onError` prop to hook this up, e.g.
    //   onError={(error, info) => Sentry.captureException(error)}
    if (typeof this.props.onError === "function") {
      this.props.onError(error, errorInfo);
    }
  }

  handleRefresh = () => {
    window.location.reload();
  };

  render() {
    const { hasError, error } = this.state;
    const {
      children,
      errorMessage = "Something went wrong. An unexpected error occurred while loading this page.",
    } = this.props;

    if (!hasError) {
      return children;
    }

    return (
      <section className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-50 via-white to-red-50 px-4 py-16">
        <div className="w-full max-w-lg text-center">
          {/* Error icon badge */}
          <div className="mx-auto mb-8 flex h-20 w-20 items-center justify-center rounded-full bg-red-100 text-red-600 shadow-sm sm:h-24 sm:w-24">
            <Icon name="error" size="2x" />
          </div>

          {/* Heading */}
          <h1 className="text-2xl font-bold text-gray-800 sm:text-3xl">
            Oops! Something Went Wrong
          </h1>

          {/* Custom / default error message */}
          <p className="mx-auto mt-3 max-w-md text-base leading-relaxed text-gray-600 sm:text-lg">
            {errorMessage}
          </p>

          {/* Technical detail (dev only) */}
          {import.meta.env.DEV && error && (
            <pre className="mx-auto mt-6 max-w-md overflow-auto rounded-lg bg-gray-900 p-4 text-left text-xs text-red-300">
              {error.toString()}
            </pre>
          )}

          {/* Actions */}
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <button
              onClick={this.handleRefresh}
              className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-red-600 px-6 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 sm:w-auto"
            >
              <Icon name="refresh" />
              Refresh Page
            </button>
            <a
              href="/"
              className="inline-flex w-full items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-6 py-3 text-sm font-semibold text-gray-700 shadow-sm transition hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 sm:w-auto"
            >
              <Icon name="home" />
              Go Home
            </a>
          </div>
        </div>
      </section>
    );
  }
}
