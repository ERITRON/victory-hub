// src/components/ImageLightbox.jsx
import { useState, useEffect } from "react";
import { handleImageError } from "../utils/imageFallback";

export default function ImageLightbox({ image, onClose, onNext, onPrev }) {
  const [zoom, setZoom] = useState(1);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") onNext();
      if (e.key === "ArrowLeft") onPrev();
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [onClose, onNext, onPrev]);

  if (!image) return null;

  return (
    <div className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center p-4">
      <button
        onClick={onClose}
        className="absolute top-4 right-4 text-white hover:text-gray-300 text-3xl z-10"
      >
        ×
      </button>

      <button
        onClick={onPrev}
        className="absolute left-4 text-white hover:text-gray-300 text-3xl z-10 hidden sm:block"
      >
        ‹
      </button>

      <button
        onClick={onNext}
        className="absolute right-4 text-white hover:text-gray-300 text-3xl z-10 hidden sm:block"
      >
        ›
      </button>

      <div className="relative max-w-5xl w-full max-h-[90vh]">
        <div className="bg-white rounded-xl overflow-hidden">
          <div className="relative overflow-hidden">
            <img
              src={image.imageUrl}
              alt={image.title}
              className="w-full max-h-[70vh] object-contain transition-transform duration-300"
              style={{ transform: `scale(${zoom})` }}
              onError={(e) => {
                handleImageError(e, "Image not found");
              }}
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4">
              <div className="flex items-center justify-between text-white">
                <div>
                  <h3 className="font-bold text-lg">{image.title}</h3>
                  {image.description && (
                    <p className="text-sm text-gray-300">{image.description}</p>
                  )}
                  <div className="flex gap-4 text-xs text-gray-400 mt-1">
                    <span>{image.category}</span>
                    <span>•</span>
                    <span>{image.date ? new Date(image.date).toLocaleDateString() : ""}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setZoom(zoom + 0.25)}
                    className="bg-white/20 hover:bg-white/30 px-3 py-1 rounded text-sm"
                  >
                    🔍+
                  </button>
                  <button
                    onClick={() => setZoom(Math.max(0.5, zoom - 0.25))}
                    className="bg-white/20 hover:bg-white/30 px-3 py-1 rounded text-sm"
                  >
                    🔍-
                  </button>
                  <button
                    onClick={() => setZoom(1)}
                    className="bg-white/20 hover:bg-white/30 px-3 py-1 rounded text-sm"
                  >
                    Reset
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}