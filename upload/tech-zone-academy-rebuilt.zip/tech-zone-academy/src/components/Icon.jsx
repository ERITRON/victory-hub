// src/components/Icon.jsx
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

// Navigation
import {
  faHouse,
  faCircleInfo,
  faUserGraduate,
  faChalkboardUser,
  faUsers,
  faGauge,
  faRightToBracket,
  faRightFromBracket,
  // Actions
  faPlus,
  faPenToSquare,
  faTrashCan,
  faFloppyDisk,
  faXmark,
  faMagnifyingGlass,
  faFilter,
  faArrowsRotate,
  faGear,
  faDownload,
  // Education
  faBook,
  faBookOpenReader,
  faGraduationCap,
  faSchool,
  faChalkboard,
  faBookOpen,
  faStar,
  faClipboardList,
  faFilePen,
  faScroll,
  faCalendarCheck,
  faCalendarDays,
  faChartLine,
  // Communication
  faEnvelope,
  faPhone,
  faMessage,
  faBell,
  faBullhorn,
  // Status
  faCircleCheck,
  faTriangleExclamation,
  faCircleXmark,
  faClock,
  faToggleOn,
  faToggleOff,
  // Fallback
  faCircleQuestion,
} from "@fortawesome/free-solid-svg-icons";

// Brands
import {
  faFacebookF,
  faXTwitter,
  faInstagram,
  faYoutube,
  faLinkedinIn,
  faTelegram,
  faTiktok,
} from "@fortawesome/free-brands-svg-icons";

// Friendly name -> Font Awesome icon definition.
const ICON_MAP = {
  // Navigation
  home: faHouse,
  about: faCircleInfo,
  student: faUserGraduate,
  teacher: faChalkboardUser,
  parent: faUsers,
  dashboard: faGauge,
  login: faRightToBracket,
  logout: faRightFromBracket,

  // Actions
  add: faPlus,
  edit: faPenToSquare,
  delete: faTrashCan,
  save: faFloppyDisk,
  cancel: faXmark,
  search: faMagnifyingGlass,
  filter: faFilter,
  refresh: faArrowsRotate,
  settings: faGear,
  download: faDownload,
  close: faXmark,

  // Education
  book: faBook,
  library: faBookOpenReader,
  graduation: faGraduationCap,
  school: faSchool,
  classroom: faChalkboard,
  subject: faBookOpen,
  grade: faStar,
  star: faStar,
  assignment: faClipboardList,
  exam: faFilePen,
  result: faScroll,
  attendance: faCalendarCheck,
  calendar: faCalendarDays,

  chart: faChartLine,

  // Communication
  email: faEnvelope,
  phone: faPhone,
  message: faMessage,
  notification: faBell,
  announcement: faBullhorn,

  // Status
  success: faCircleCheck,
  warning: faTriangleExclamation,
  error: faCircleXmark,
  info: faCircleInfo,
  pending: faClock,
  active: faToggleOn,
  inactive: faToggleOff,

  // Brands
  facebook: faFacebookF,
  twitter: faXTwitter,
  instagram: faInstagram,
  youtube: faYoutube,
  linkedin: faLinkedinIn,
  telegram: faTelegram,
  tiktok: faTiktok,
};

// Names available internally — handy for iterating or validating.
const ICON_NAMES = Object.keys(ICON_MAP);

/**
 * Icon renders a Font Awesome icon by a friendly, app-specific name.
 *
 * @param {string} name       - Key from ICON_MAP (e.g. "student", "payment").
 * @param {string} className  - Extra classes (color, spacing, etc.).
 * @param {string|number} size - Either a Font Awesome size token ("xs", "sm",
 *                               "lg", "2x", ...) or a pixel number/numeric
 *                               string, which is applied as an inline fontSize.
 * Any other props (onClick, title, spin, aria-*, ...) pass through to
 * FontAwesomeIcon.
 */
export default function Icon({ name, className = "", size, ...rest }) {
  const icon = ICON_MAP[name] || faCircleQuestion;

  if (!ICON_MAP[name] && import.meta.env.DEV) {
    console.warn(
      `[Icon] Unknown icon name "${name}". Falling back to a question mark. ` +
        `Valid names: ${ICON_NAMES.join(", ")}`
    );
  }

  // A numeric size means pixels; anything else is treated as an FA size token.
  const isPixelSize =
    typeof size === "number" ||
    (typeof size === "string" && /^\d+(\.\d+)?$/.test(size));

  return (
    <FontAwesomeIcon
      icon={icon}
      className={className}
      size={isPixelSize ? undefined : size}
      style={isPixelSize ? { fontSize: `${size}px` } : undefined}
      {...rest}
    />
  );
}
