export const translations = {
  en: {
    // Navigation
    home: "Home",
    about: "About",
    student: "Student",
    teacher: "Teacher",
    parent: "Parent",
    admin: "Admin",
    login: "Login",
    logout: "Logout",
    dashboard: "Dashboard",

    // Hero
    title: "Welcome to Tech Zone Academy",
    subtitle: "Excellence in Education from KG-3 to Grade 8",
    applyNow: "Apply Now",
    learnMore: "Learn More",

    // About
    aboutTitle: "About Tech Zone Academy",
    aboutText: "Tech Zone Academy is dedicated to providing quality education for students from KG-3 to Grade 8. Our mission is to develop knowledgeable, creative, and responsible learners who are prepared for future success.",

    // Footer
    footerTitle: "Tech Zone Academy",
    footerSubtitle: "Excellence in Education from KG-3 to Grade 8",
    email: "Email",
    phone: "Phone",
    address: "Address",
    location: "Bishoftu, Ethiopia",
    copyright: "© 2026 Tech Zone Academy. All Rights Reserved.",

    // Common
    loading: "Loading...",
    error: "An error occurred",
    success: "Success!",
    save: "Save",
    cancel: "Cancel",
    delete: "Delete",
    edit: "Edit",
    update: "Update",
    submit: "Submit",
    back: "Back",
    next: "Next",
    close: "Close",

    // Student
    studentId: "Student ID",
    firstName: "First Name",
    fatherName: "Father Name",
    grandfatherName: "Grandfather Name",
    gender: "Gender",
    grade: "Grade",
    section: "Section",
    parentName: "Parent Name",
    parentPhone: "Parent Phone",
    parentEmail: "Parent Email",
    emergencyPhone: "Emergency Phone",

    // Teacher
    teacherId: "Teacher ID",
    subject: "Subject",
    qualification: "Qualification",
    hireDate: "Hire Date",

    // Attendance
    attendance: "Attendance",
    present: "Present",
    absent: "Absent",
    late: "Late",
    date: "Date",
    month: "Month",
    year: "Year",

    // Results
    results: "Results",
    assessment: "Assessment",
    score: "Score",
    outOf: "Out Of",
    percentage: "Percentage",
    averageScore: "Average Score",

    // Messages
    welcome: "Welcome",
    welcomeBack: "Welcome back",
    noData: "No data found",
    confirmDelete: "Are you sure you want to delete this?",
    confirmLogout: "Are you sure you want to logout?",
    operationSuccessful: "Operation completed successfully!",
    operationFailed: "Operation failed. Please try again.",
  },

  am: {
    // Navigation
    home: "መነሻ",
    about: "ስለ እኛ",
    student: "ተማሪ",
    teacher: "መምህር",
    parent: "ወላጅ",
    admin: "አስተዳዳሪ",
    login: "ግባ",
    logout: "ውጣ",
    dashboard: "ዳሽቦርድ",

    // Hero
    title: "ወደ ቴክ ዞን አካዳሚ እንኳን በደህና መጡ",
    subtitle: "ከKG-3 እስከ 8ኛ ክፍል ጥራት ያለው ትምህርት",
    applyNow: "አሁን ይመዝገቡ",
    learnMore: "ተጨማሪ ይወቁ",

    // About
    aboutTitle: "ስለ ቴክ ዞን አካዳሚ",
    aboutText: "ቴክ ዞን አካዳሚ ከKG-3 እስከ 8ኛ ክፍል ጥራት ያለው ትምህርትን ለመስጠት የተቋቋመ ነው። ተልዕካችን እውቀት ያላቸው፣ ፈጠራ ያላቸው እና ሃላፊነት የሚሰማቸው ተማሪዎችን ለወደፊት ስኬት ማዘጋጀት ነው።",

    // Footer
    footerTitle: "ቴክ ዞን አካዳሚ",
    footerSubtitle: "ከKG-3 እስከ 8ኛ ክፍል ጥራት ያለው ትምህርት",
    email: "ኢሜይል",
    phone: "ስልክ",
    address: "አድራሻ",
    location: "ቢሾፍቱ, ኢትዮጵያ",
    copyright: "© 2026 ቴክ ዞን አካዳሚ። መብቱ በሙሉ የተጠበቀ ነው።",

    // Common
    loading: "በመጫን ላይ...",
    error: "ስህተት ተከስቷል",
    success: "ተሳክቷል!",
    save: "አስቀምጥ",
    cancel: "ሰርዝ",
    delete: "ሰርዝ",
    edit: "አስተካክል",
    update: "አዘምን",
    submit: "አስገባ",
    back: "ተመለስ",
    next: "ቀጥል",
    close: "ዝጋ",

    // Student
    studentId: "የተማሪ መታወቂያ",
    firstName: "ስም",
    fatherName: "የአባት ስም",
    grandfatherName: "የአያት ስም",
    gender: "ጾታ",
    grade: "ክፍል",
    section: "ክፍልፈል",
    parentName: "የወላጅ ስም",
    parentPhone: "የወላጅ ስልክ",
    parentEmail: "የወላጅ ኢሜይል",
    emergencyPhone: "የአደጋ ጊዜ ስልክ",

    // Teacher
    teacherId: "የመምህር መታወቂያ",
    subject: "ትምህርት",
    qualification: "ብቃት",
    hireDate: "የተቀጠሩበት ቀን",

    // Attendance
    attendance: "መገኘት",
    present: "ተገኝቷል",
    absent: "አልተገኘም",
    late: "ዘግይቷል",
    date: "ቀን",
    month: "ወር",
    year: "ዓመት",

    // Results
    results: "ውጤቶች",
    assessment: "ምዘና",
    score: "ነጥብ",
    outOf: "ከ",
    percentage: "መቶኛ",
    averageScore: "አማካይ ውጤት",

    // Messages
    welcome: "እንኳን ደህና መጡ",
    welcomeBack: "እንኳን በደህና ተመለሱ",
    noData: "ምንም መረጃ አልተገኘም",
    confirmDelete: "ይህንን መሰረዝ እርግጠኛ ነዎት?",
    confirmLogout: "ዘግበው መውጣት እርግጠኛ ነዎት?",
    operationSuccessful: "ስራው በሚገባ ተጠናቋል!",
    operationFailed: "ስራው አልተሳካም። እባክዎ እንደገና ይሞክሩ።",
  },

  or: {
    // Navigation
    home: "Mana",
    about: "Waa'ee Keenya",
    student: "Barataa",
    teacher: "Barsiisaa",
    parent: "Maatii",
    admin: "Bulchaa",
    login: "Seeni",
    logout: "Bahii",
    dashboard: "Dashboordii",

    // Hero
    title: "Baga Nagaan Gara Tech Zone Academy Dhuftan",
    subtitle: "Barnoota Sadarkaa Olaanaa KG-3 irraa hanga Kutaa 8",
    applyNow: "Amma Galmaa'i",
    learnMore: "Caalaatti Baradhu",

    // About
    aboutTitle: "Waa'ee Tech Zone Academy",
    aboutText: "Tech Zone Academy barnoota sadarkaa olaanaa barattoota KG-3 irraa hanga Kutaa 8f kennuuf uumamte. Dhimma keenya barattoota beekumsa qaban, uumamtuu fi itti gaafatamummaa qaban akka isaan milkaa'an barbaanna.",

    // Footer
    footerTitle: "Tech Zone Academy",
    footerSubtitle: "Barnoota Sadarkaa Olaanaa KG-3 irraa hanga Kutaa 8",
    email: "Imeelii",
    phone: "Bilbila",
    address: "Teessoo",
    location: "Bishooftuu, Itoophiyaa",
    copyright: "© 2026 Tech Zone Academy. Mirgi Hundi Kan Eegame Dha.",

    // Common
    loading: "Eeggachaa...",
    error: "Dogoggorri Ume",
    success: "Milkaa'e!",
    save: "Kutaa",
    cancel: "Haqi",
    delete: "Haqi",
    edit: "Gulaali",
    update: "Gulaali",
    submit: "Ergi",
    back: "Duubi",
    next: "Itti fufi",
    close: "Cufi",

    // Student
    studentId: "Lakkoofsa Barataa",
    firstName: "Maqaa Jalqabaa",
    fatherName: "Maqaa Abbaa",
    grandfatherName: "Maqaa Akakayyaa",
    gender: "Saala",
    grade: "Kutaa",
    section: "Qoqqooddama",
    parentName: "Maqaa Maatii",
    parentPhone: "Bilbila Maatii",
    parentEmail: "Imeelii Maatii",
    emergencyPhone: "Bilbila Yeroo Hatattamaa",

    // Teacher
    teacherId: "Lakkoofsa Barsiisaa",
    subject: "Barumsa",
    qualification: "Mindoowwan",
    hireDate: "Guyyaa Qabametti",

    // Attendance
    attendance: "Argama",
    present: "Argame",
    absent: "Hin Argamne",
    late: "Eergame",
    date: "Guyyaa",
    month: "Ji'a",
    year: "Bara",

    // Results
    results: "Budaagura",
    assessment: "Qorannoo",
    score: "Qabxii",
    outOf: "Keessaa",
    percentage: "Parasanti",
    averageScore: "Qabxii Giddu galeessa",

    // Messages
    welcome: "Baga Nagaan Dhuftan",
    welcomeBack: "Baga Nagaan Deebitan",
    noData: "Deetaan Hin Argamu",
    confirmDelete: "Kana haquu mirkaneeftaa?",
    confirmLogout: "Bahii mirkaneeftaa?",
    operationSuccessful: "Dalagaan Milkaa'e!",
    operationFailed: "Dalagaan Hin Milkaa'in. Irra deebi'aa.",
  },
};

// Helper function to get translation with fallback
export const getTranslation = (lang, key) => {
  if (!translations[lang]) {
    console.warn(`Language "${lang}" not found. Falling back to English.`);
    lang = "en";
  }
  const translation = translations[lang];
  if (!translation[key]) {
    console.warn(`Translation key "${key}" not found for language "${lang}".`);
    return key; // Return the key itself as fallback
  }
  return translation[key];
};

// Helper function to get all supported languages
export const getSupportedLanguages = () => {
  return Object.keys(translations);
};

// Helper function to check if a language is supported
export const isLanguageSupported = (lang) => {
  return !!translations[lang];
};

// Helper function to get language name
export const getLanguageName = (lang) => {
  const names = {
    en: "English",
    am: "አማርኛ (Amharic)",
    or: "Afaan Oromoo (Oromo)",
  };
  return names[lang] || lang;
};

export default translations;