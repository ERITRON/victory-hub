// src/hooks/useParentChildren.js
//
// Fetches the students linked to a given parent via the real
// `parent_children` join table (populated by the createParent edge
// function / EditParent page). Replaces the old pattern of reading a
// `children` array directly off the parent's user doc, which the
// underlying Postgres schema never actually had a column for.
import { useEffect, useState } from "react";
import { collection, db, getDocs, query, where } from "../supabase/supabase";

/**
 * @param {string|null|undefined} parentId - the parent's auth uid / users.id
 * @returns {{ children: object[], loading: boolean, error: string }}
 *   `children` is the list of linked student rows (id, studentId, firstName, ...).
 */
export function useParentChildren(parentId) {
  const [children, setChildren] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!parentId) {
      setChildren([]);
      setLoading(false);
      return;
    }
    let active = true;
    setLoading(true);
    setError("");

    (async () => {
      try {
        // parent_children.parentId links to the parent's own `parents`
        // row id, not directly to their auth uid (those only coincide
        // for parents created through the newer create-parent flow).
        // Resolve the parent's own row first.
        const parentSnapshot = await getDocs(
          query(collection(db, "parents"), where("userId", "==", parentId))
        );
        if (parentSnapshot.empty) {
          if (active) setChildren([]);
          return;
        }
        const parentRowId = parentSnapshot.docs[0].id;

        const linkSnapshot = await getDocs(
          query(collection(db, "parentChildren"), where("parentId", "==", parentRowId))
        );
        const studentIds = linkSnapshot.docs
          .map((d) => d.data().studentId)
          .filter(Boolean);

        if (studentIds.length === 0) {
          if (active) setChildren([]);
          return;
        }

        const studentSnapshot = await getDocs(
          query(collection(db, "students"), where("id", "in", studentIds))
        );
        if (active) {
          setChildren(studentSnapshot.docs.map((d) => ({ id: d.id, ...d.data() })));
        }
      } catch (err) {
        console.error("useParentChildren: failed to load linked children", err);
        if (active) setError("Your linked children could not be loaded.");
      } finally {
        if (active) setLoading(false);
      }
    })();

    return () => {
      active = false;
    };
  }, [parentId]);

  return { children, loading, error };
}
