import { useEffect, useMemo, useState } from "react";

export function normalizeSearchValue(value) {
  return String(value ?? "")
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase()
    .trim();
}

export function useDebouncedSearch(searchTerm, delay = 300) {
  const [debouncedTerm, setDebouncedTerm] = useState(searchTerm);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedTerm(searchTerm), delay);
    return () => clearTimeout(timer);
  }, [searchTerm, delay]);

  return debouncedTerm;
}

function readField(item, field) {
  if (typeof field === "function") return field(item);
  return String(field)
    .split(".")
    .reduce((value, key) => value?.[key], item);
}

export function useFilteredData(
  data,
  searchTerm,
  searchFields,
  { delay = 300, limit = Number.POSITIVE_INFINITY, predicate } = {},
) {
  const debouncedTerm = useDebouncedSearch(searchTerm, delay);

  return useMemo(() => {
    const items = Array.isArray(data) ? data : [];
    const search = normalizeSearchValue(debouncedTerm);
    const result = [];

    for (const item of items) {
      if (predicate && !predicate(item)) continue;

      const matches =
        !search ||
        searchFields.some((field) =>
          normalizeSearchValue(readField(item, field)).includes(search),
        );

      if (matches) {
        result.push(item);
        if (result.length >= limit) break;
      }
    }

    return result;
  }, [data, debouncedTerm, limit, predicate, searchFields]);
}
