// src/hooks/useWebsiteSettings.js
import { useState, useEffect } from "react";
import { db, doc, getDoc, collection, getDocs } from "../supabase/supabase";

export function useWebsiteSettings() {
  const [settings, setSettings] = useState({
    hero: null,
    about: null,
    statistics: null,
    newsSettings: null,
    gallerySettings: null,
    footer: null,
    navigation: null,
    theme: null,
    pages: {},
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const getDefaultSettings = (name) => {
    const defaults = {
      hero: {
        schoolName: "Tech Zone Academy",
        tagline: "Building Bright Futures",
        description: "KG-3 to Grade 8 | Quality Education for Every Child",
        buttonText: "Apply Now",
        buttonLink: "/admissions",
        backgroundImage: "",
        overlayColor: "from-blue-600 to-blue-800",
        height: "py-20",
        alignment: "center",
        animation: "fade-in",
        overlayOpacity: "70",
      },
      about: {
        title: "About Tech Zone Academy",
        subtitle: "Excellence in Education Since 2020",
        description: "Tech Zone Academy is a premier educational institution...",
        image: "",
        readMoreText: "Read More",
        readMoreLink: "/about",
      },
      statistics: {
        enabled: true,
        students: { icon: "👨‍🎓", label: "Students", value: "0", manual: false },
        teachers: { icon: "👨‍🏫", label: "Teachers", value: "0", manual: false },
        parents: { icon: "👨‍👩‍👦", label: "Parents", value: "0", manual: false },
        grades: { icon: "📚", label: "Grades", value: "0", manual: false },
      },
      newsSettings: {
        enabled: true,
        title: "Latest News",
        subtitle: "Stay updated with our latest announcements",
        cardCount: 6,
        featuredNews: "",
      },
      gallerySettings: {
        title: "School Gallery",
        subtitle: "A glimpse into our vibrant school life",
        layout: "grid",
        displayCount: 8,
      },
      footer: {
        address: "Addis Ababa, Ethiopia",
        phone: "+251 9XX XXX XXX",
        email: "info@techzone.com",
        workingHours: "Mon-Fri: 8:00 AM - 5:00 PM",
        copyright: "Tech Zone Academy. All rights reserved.",
        social: {
          facebook: "",
          twitter: "",
          instagram: "",
          youtube: "",
          telegram: "",
          tiktok: "",
          linkedin: "",
        },
      },
      navigation: {
        logo: "",
        websiteName: "Tech Zone Academy",
        sticky: true,
        backgroundColor: "from-blue-700 to-blue-800",
        textColor: "text-white",
        hoverColor: "hover:bg-blue-600",
        items: [
          { id: "1", label: "Home", path: "/", enabled: true },
          { id: "2", label: "About", path: "/about", enabled: true },
          { id: "3", label: "Admissions", path: "/admissions", enabled: true },
          { id: "4", label: "Student", path: "/student", enabled: true },
          { id: "5", label: "Teacher", path: "/teacher", enabled: true },
          { id: "6", label: "Parent", path: "/parent", enabled: true },
          { id: "7", label: "News", path: "/news", enabled: true },
          { id: "8", label: "Gallery", path: "/gallery", enabled: true },
          { id: "9", label: "Events", path: "/events", enabled: true },
          { id: "10", label: "Contact", path: "/contact", enabled: true },
        ],
      },
      theme: {
        primaryColor: "#1e40af",
        secondaryColor: "#1e3a5f",
        accentColor: "#f59e0b",
        backgroundColor: "#f3f4f6",
        cardColor: "#ffffff",
        buttonColor: "#1d4ed8",
        fontFamily: "sans-serif",
        fontSize: "medium",
        fontWeight: "normal",
        borderRadius: "0.5rem",
        shadow: "0 4px 6px -1px rgba(0,0,0,0.1)",
        cardBorderRadius: "0.75rem",
        cardShadow: "0 10px 15px -3px rgba(0,0,0,0.1)",
        cardBackground: "#ffffff",
        cardBorder: "1px solid #e5e7eb",
        cardAnimation: "hover:shadow-xl hover:-translate-y-1",
        hoverEffect: "hover:shadow-xl hover:-translate-y-1",
      },
    };
    return defaults[name] || {};
  };

  const fetchAllSettings = async () => {
    setLoading(true);
    setError(null);
    try {
      // Fetch all settings
      const settingNames = [
        "hero",
        "about",
        "statistics",
        "newsSettings",
        "gallerySettings",
        "footer",
        "navigation",
        "theme",
      ];

      const results = {};
      for (const name of settingNames) {
        const docRef = doc(db, "websiteSettings", name);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          results[name] = docSnap.data();
        } else {
          // Use defaults if not exists
          results[name] = getDefaultSettings(name);
        }
      }

      // Fetch page contents
      const pagesSnap = await getDocs(collection(db, "websitePages"));
      const pagesData = {};
      pagesSnap.forEach((doc) => {
        pagesData[doc.id] = doc.data();
      });
      results.pages = pagesData;

      setSettings(results);
    } catch (err) {
      console.error("Error fetching website settings:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
     
    fetchAllSettings();
    // eslint-disable-next-line react-hooks/exhaustive-deps -- run once on mount
  }, []);

  return { settings, loading, error, refresh: fetchAllSettings };
}