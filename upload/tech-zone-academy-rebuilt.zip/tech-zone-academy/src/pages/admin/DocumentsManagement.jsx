// src/pages/admin/DocumentsManagement.jsx
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  db,
  collection,
  query,
  where,
  getDocs,
  addDoc,
  deleteDoc,
  doc,
  ref,
  storage,
  uploadBytes,
  getDownloadURL,
  deleteObject,
} from "../../supabase/supabase";
import { useAuth } from "../../context/AuthContext";

const CATEGORIES = [
  { value: "report_card", label: "Report Card" },
  { value: "certificate", label: "Certificate" },
  { value: "other", label: "Other" },
];

const MAX_FILE_SIZE = 15 * 1024 * 1024; // 15MB

export default function DocumentsManagement() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [searchId, setSearchId] = useState("");
  const [student, setStudent] = useState(null);
  const [searchError, setSearchError] = useState("");
  const [searching, setSearching] = useState(false);

  const [documents, setDocuments] = useState([]);
  const [loadingDocs, setLoadingDocs] = useState(false);

  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("report_card");
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const searchStudent = async () => {
    if (!searchId.trim()) return;
    setSearching(true);
    setSearchError("");
    setStudent(null);
    setDocuments([]);
    try {
      const snapshot = await getDocs(
        query(collection(db, "students"), where("studentId", "==", searchId.trim().toUpperCase()))
      );
      if (snapshot.empty) {
        setSearchError("No student found with that ID.");
        return;
      }
      let found = null;
      snapshot.forEach((d) => { found = { id: d.id, ...d.data() }; });
      setStudent(found);
    } catch (error) {
      setSearchError("Error searching: " + error.message);
    } finally {
      setSearching(false);
    }
  };

  const loadDocuments = async (studentRowId) => {
    setLoadingDocs(true);
    try {
      const snapshot = await getDocs(query(collection(db, "studentDocuments"), where("studentId", "==", studentRowId)));
      const rows = [];
      snapshot.forEach((d) => rows.push({ id: d.id, ...d.data() }));
      rows.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
      setDocuments(rows);
    } catch (error) {
      console.error("Error loading documents:", error);
    } finally {
      setLoadingDocs(false);
    }
  };

  useEffect(() => {
    if (student?.id) loadDocuments(student.id);
  }, [student?.id]);

  const handleUpload = async () => {
    if (!student || !file || !title.trim()) {
      setUploadError("Please choose a student, a title, and a file.");
      return;
    }
    if (!student.userId) {
      setUploadError("This student doesn't have a linked login account yet, so documents can't be attached.");
      return;
    }
    if (file.size > MAX_FILE_SIZE) {
      setUploadError("File must be under 15MB.");
      return;
    }
    setUploading(true);
    setUploadError("");
    setSuccessMessage("");
    try {
      const uniqueName = `${Date.now()}-${file.name}`;
      const storageRef = ref(storage, `student-documents/${student.userId}/${uniqueName}`);
      const snapshot = await uploadBytes(storageRef, file);
      const fileUrl = await getDownloadURL(snapshot.ref);

      await addDoc(collection(db, "studentDocuments"), {
        studentId: student.id,
        title: title.trim(),
        category,
        filePath: storageRef.path,
        fileUrl,
        fileSize: file.size,
        uploadedBy: user.uid,
      });

      // Notify the student directly (staff-authored notification event,
      // delivered by the on-document-change pipeline once its database
      // webhook is set up).
      await addDoc(collection(db, "notificationEvents"), {
        type: "document_uploaded",
        title: "New document available",
        message: `"${title.trim()}" was added to your documents.`,
        link: "/my-documents",
        targetUserIds: [student.userId],
      }).catch(() => {});

      setTitle("");
      setFile(null);
      setSuccessMessage("✅ Document uploaded.");
      setTimeout(() => setSuccessMessage(""), 3000);
      await loadDocuments(student.id);
    } catch (error) {
      setUploadError("Upload failed: " + error.message);
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (documentRow) => {
    if (!window.confirm(`Delete "${documentRow.title}"?`)) return;
    try {
      if (documentRow.filePath) {
        await deleteObject(ref(storage, documentRow.filePath)).catch(() => {});
      }
      await deleteDoc(doc(db, "studentDocuments", documentRow.id));
      setDocuments((prev) => prev.filter((d) => d.id !== documentRow.id));
    } catch (error) {
      alert("Error deleting: " + error.message);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="mb-6 flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="text-gray-600 hover:text-gray-800">← Back</button>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">📄 Student Documents</h1>
            <p className="text-gray-600 mt-1">Upload report cards, certificates, and other files for a student.</p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow p-6 mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">Find a student by Student ID</label>
          <div className="flex gap-3">
            <input
              type="text"
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && searchStudent()}
              placeholder="e.g. STU001"
              className="flex-1 border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
            <button
              onClick={searchStudent}
              disabled={searching}
              className="bg-blue-700 text-white px-6 py-3 rounded-lg hover:bg-blue-800 disabled:bg-gray-400"
            >
              {searching ? "Searching…" : "Search"}
            </button>
          </div>
          {searchError && <p className="mt-2 text-sm text-rose-600">{searchError}</p>}
        </div>

        {student && (
          <>
            <div className="bg-white rounded-xl shadow p-6 mb-6">
              <p className="font-semibold text-gray-800">{student.firstName} {student.fatherName}</p>
              <p className="text-sm text-gray-500">{student.studentId} • {student.grade} - Section {student.section}</p>

              <div className="border-t border-gray-200 mt-4 pt-4 space-y-3">
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Document title (e.g. Term 1 Report Card)"
                  className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                />
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  {CATEGORIES.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
                </select>
                <input
                  type="file"
                  onChange={(e) => setFile(e.target.files?.[0] || null)}
                  className="w-full text-sm"
                />
                <button
                  onClick={handleUpload}
                  disabled={uploading}
                  className="w-full bg-blue-700 text-white py-3 rounded-lg font-semibold hover:bg-blue-800 disabled:bg-gray-400"
                >
                  {uploading ? "Uploading…" : "Upload Document"}
                </button>
                {uploadError && <p className="text-sm text-rose-600">{uploadError}</p>}
                {successMessage && <p className="text-sm text-emerald-600">{successMessage}</p>}
              </div>
            </div>

            <div className="bg-white rounded-xl shadow p-6">
              <h3 className="font-semibold text-gray-800 mb-4">Existing Documents</h3>
              {loadingDocs ? (
                <p className="text-sm text-gray-500">Loading…</p>
              ) : documents.length === 0 ? (
                <p className="text-sm text-gray-500">No documents uploaded yet.</p>
              ) : (
                <div className="space-y-3">
                  {documents.map((d) => (
                    <div key={d.id} className="flex items-center justify-between border rounded-lg p-3">
                      <div>
                        <p className="font-medium text-gray-800">{d.title}</p>
                        <p className="text-xs text-gray-500">
                          {CATEGORIES.find((c) => c.value === d.category)?.label || d.category} •{" "}
                          {d.createdAt ? new Date(d.createdAt).toLocaleDateString() : ""}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <a
                          href={d.fileUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-700 hover:text-blue-900 text-sm font-semibold"
                        >
                          View
                        </a>
                        <button
                          onClick={() => handleDelete(d)}
                          className="text-red-600 hover:text-red-800 text-sm font-semibold"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
