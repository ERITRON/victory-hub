// src/pages/admin/AnnouncementsManagement.jsx
import { useEffect, useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { db, collection, getDocs, addDoc, updateDoc, deleteDoc, doc, query, orderBy } from "../../supabase/supabase";

export default function AnnouncementsManagement() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [announcements, setAnnouncements] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingAnnouncement, setEditingAnnouncement] = useState(null);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    priority: "normal",
    expiresAt: "",
  });

  const priorities = [
    { value: "low", label: "🟢 Low", color: "bg-green-100 text-green-700" },
    { value: "normal", label: "🔵 Normal", color: "bg-blue-100 text-blue-700" },
    { value: "high", label: "🟠 High", color: "bg-orange-100 text-orange-700" },
    { value: "urgent", label: "🔴 Urgent", color: "bg-red-100 text-red-700" },
  ];

  const fetchAnnouncements = async () => {
    setLoading(true);
    try {
      const q = query(collection(db, "announcements"), orderBy("createdAt", "desc"));
      const snap = await getDocs(q);
      const data = snap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setAnnouncements(data);
    } catch (error) {
      setErrorMessage("Error loading announcements: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
     
    fetchAnnouncements();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMessage("");
    setSuccessMessage("");

    if (!formData.title.trim()) {
      setErrorMessage("Title is required");
      setLoading(false);
      return;
    }
    if (!formData.content.trim()) {
      setErrorMessage("Content is required");
      setLoading(false);
      return;
    }

    try {
      const data = {
        ...formData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        createdBy: user?.uid,
        createdByName: user?.displayName || user?.email || "System",
      };

      if (editingAnnouncement) {
        await updateDoc(doc(db, "announcements", editingAnnouncement.id), data);
        setSuccessMessage("✅ Announcement updated successfully!");
      } else {
        await addDoc(collection(db, "announcements"), data);
        setSuccessMessage("✅ Announcement added successfully!");
      }

      setShowModal(false);
      setEditingAnnouncement(null);
      resetForm();
      await fetchAnnouncements();
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error saving announcement: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this announcement?")) return;
    try {
      await deleteDoc(doc(db, "announcements", id));
      setSuccessMessage("✅ Announcement deleted successfully!");
      await fetchAnnouncements();
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error deleting announcement: " + error.message);
    }
  };

  const resetForm = () => {
    setFormData({
      title: "",
      content: "",
      priority: "normal",
      expiresAt: "",
    });
  };

  const getPriorityBadge = (priority) => {
    const found = priorities.find((p) => p.value === priority);
    return found ? found.color : "bg-gray-100 text-gray-700";
  };

  const getPriorityIcon = (priority) => {
    const found = priorities.find((p) => p.value === priority);
    return found ? found.label.split(" ")[0] : "📌";
  };

  if (loading && announcements.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading announcements...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              📢 Announcements
            </h1>
            <p className="text-gray-600 mt-1">
              Create and manage school announcements
            </p>
          </div>
          <button
            onClick={() => {
              setEditingAnnouncement(null);
              resetForm();
              setShowModal(true);
            }}
            className="bg-blue-700 text-white px-4 py-2 rounded-lg hover:bg-blue-800 transition"
          >
            ➕ Add Announcement
          </button>
        </div>

        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {announcements.length === 0 ? (
            <div className="col-span-full bg-white rounded-xl shadow p-12 text-center">
              <div className="text-6xl mb-4">📭</div>
              <h3 className="text-xl font-semibold text-gray-700 mb-2">No Announcements</h3>
              <p className="text-gray-500">Click "Add Announcement" to create one.</p>
            </div>
          ) : (
            announcements.map((announcement) => (
              <div
                key={announcement.id}
                className={`bg-white rounded-xl shadow-md p-5 border-l-4 ${
                  announcement.priority === "urgent"
                    ? "border-red-500"
                    : announcement.priority === "high"
                    ? "border-orange-500"
                    : announcement.priority === "normal"
                    ? "border-blue-500"
                    : "border-green-500"
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span
                        className={`px-2 py-0.5 rounded-full text-xs font-medium ${getPriorityBadge(
                          announcement.priority
                        )}`}
                      >
                        {getPriorityIcon(announcement.priority)} {announcement.priority || "normal"}
                      </span>
                      {announcement.expiresAt && (
                        <span className="text-xs text-gray-400">
                          Expires: {new Date(announcement.expiresAt).toLocaleDateString()}
                        </span>
                      )}
                    </div>
                    <h3 className="text-lg font-bold text-gray-800 mt-2">
                      {announcement.title}
                    </h3>
                    <p className="text-gray-600 text-sm mt-1">{announcement.content}</p>
                    <p className="text-xs text-gray-400 mt-2">
                      {announcement.createdAt
                        ? new Date(announcement.createdAt).toLocaleString()
                        : "N/A"}
                    </p>
                  </div>
                  <div className="flex gap-1 ml-2">
                    <button
                      onClick={() => {
                        setEditingAnnouncement(announcement);
                        setFormData({
                          title: announcement.title || "",
                          content: announcement.content || "",
                          priority: announcement.priority || "normal",
                          expiresAt: announcement.expiresAt || "",
                        });
                        setShowModal(true);
                      }}
                      className="text-blue-600 hover:text-blue-800 text-sm p-1 hover:bg-blue-50 rounded"
                    >
                      ✏️
                    </button>
                    <button
                      onClick={() => handleDelete(announcement.id)}
                      className="text-red-600 hover:text-red-800 text-sm p-1 hover:bg-red-50 rounded"
                    >
                      🗑️
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Add/Edit Announcement Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800">
                  {editingAnnouncement ? "✏️ Edit Announcement" : "📢 Add Announcement"}
                </h2>
                <button
                  onClick={() => {
                    setShowModal(false);
                    setEditingAnnouncement(null);
                    setErrorMessage("");
                  }}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Title *
                  </label>
                  <input
                    type="text"
                    name="title"
                    value={formData.title}
                    onChange={handleInputChange}
                    required
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="Announcement title"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Content *
                  </label>
                  <textarea
                    name="content"
                    value={formData.content}
                    onChange={handleInputChange}
                    rows="4"
                    required
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="Announcement content..."
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Priority
                    </label>
                    <select
                      name="priority"
                      value={formData.priority}
                      onChange={handleInputChange}
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                    >
                      {priorities.map((p) => (
                        <option key={p.value} value={p.value}>
                          {p.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Expires At
                    </label>
                    <input
                      type="date"
                      name="expiresAt"
                      value={formData.expiresAt}
                      onChange={handleInputChange}
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                </div>

                <div className="flex gap-3 pt-4 border-t">
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition disabled:bg-gray-400 font-medium"
                  >
                    {loading ? "Saving..." : editingAnnouncement ? "💾 Update" : "✅ Add Announcement"}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowModal(false);
                      setEditingAnnouncement(null);
                      setErrorMessage("");
                    }}
                    className="px-6 py-3 rounded-lg bg-gray-200 text-gray-700 hover:bg-gray-300 transition font-medium"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}