// src/pages/admin/AcademicCalendar.jsx
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { db, collection, query, where, getDocs } from "../../supabase/supabase";
import { useAuth } from "../../context/AuthContext";
import {
  getCurrentSemester,
  getAllSemesters,
  getGradeOrder,
  getNextGrade,
  endSemesterOneStartSemesterTwo,
  runPromotionAndStartNewYear,
} from "../../services/academicCalendarService";

const snap = (snapshot) => snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));

const DECISION_LABELS = {
  promoted: "Promote",
  repeated: "Repeat grade",
  graduated: "Graduate",
  transferred_out: "Transfer out",
};

export default function AcademicCalendar() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [currentSemester, setCurrentSemester] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const [showWizard, setShowWizard] = useState(false);
  const [gradeOrder, setGradeOrder] = useState([]);
  const [students, setStudents] = useState([]);
  const [decisions, setDecisions] = useState({}); // studentId -> { decision, toGrade, toSection }
  const [wizardLoading, setWizardLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    setError("");
    try {
      const [current, all] = await Promise.all([getCurrentSemester(), getAllSemesters()]);
      setCurrentSemester(current);
      setHistory(all);
    } catch (loadError) {
      setError("Could not load the academic calendar: " + loadError.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleEndSemesterOne = async () => {
    if (!window.confirm(`End ${currentSemester.name} of ${currentSemester.academicYearLabel}? Its results, attendance, and discipline records will become read-only, and Semester 2 will begin.`)) return;
    setBusy(true);
    setError("");
    try {
      await endSemesterOneStartSemesterTwo(currentSemester, user.uid);
      setSuccessMessage("✅ Semester 1 ended. Semester 2 has begun.");
      setTimeout(() => setSuccessMessage(""), 4000);
      await load();
    } catch (endError) {
      setError("Could not end the semester: " + endError.message);
    } finally {
      setBusy(false);
    }
  };

  const openPromotionWizard = async () => {
    setWizardLoading(true);
    setError("");
    try {
      const [order, studentSnapshot] = await Promise.all([
        getGradeOrder(),
        getDocs(query(collection(db, "students"), where("status", "==", "active"))),
      ]);
      const activeStudents = snap(studentSnapshot).sort((a, b) => (a.grade || "").localeCompare(b.grade || "") || (a.firstName || "").localeCompare(b.firstName || ""));
      setGradeOrder(order);
      setStudents(activeStudents);

      const initialDecisions = {};
      activeStudents.forEach((s) => {
        const next = getNextGrade(order, s.grade);
        initialDecisions[s.id] = {
          decision: next ? "promoted" : "graduated",
          toGrade: next || s.grade,
          toSection: s.section,
        };
      });
      setDecisions(initialDecisions);
      setShowWizard(true);
    } catch (wizardError) {
      setError("Could not load students for promotion: " + wizardError.message);
    } finally {
      setWizardLoading(false);
    }
  };

  const updateDecision = (studentId, patch) => {
    setDecisions((prev) => ({ ...prev, [studentId]: { ...prev[studentId], ...patch } }));
  };

  const confirmPromotion = async () => {
    const summary = Object.values(decisions).reduce((acc, d) => {
      acc[d.decision] = (acc[d.decision] || 0) + 1;
      return acc;
    }, {});
    const summaryText = Object.entries(summary).map(([k, v]) => `${v} ${DECISION_LABELS[k].toLowerCase()}`).join(", ");
    if (!window.confirm(`This will end ${currentSemester.academicYearLabel}, start a new academic year, and apply: ${summaryText}. This cannot be undone. Continue?`)) return;

    setBusy(true);
    setError("");
    try {
      const decisionList = students.map((s) => ({
        studentId: s.id,
        fromGrade: s.grade,
        fromSection: s.section,
        ...decisions[s.id],
      }));
      const result = await runPromotionAndStartNewYear(currentSemester, decisionList, user.uid);
      setShowWizard(false);
      setSuccessMessage(`✅ New academic year started. ${result.succeeded} students updated.${result.failed.length ? ` ${result.failed.length} failed — please review.` : ""}`);
      await load();
    } catch (promoteError) {
      setError("Promotion could not be completed: " + promoteError.message);
    } finally {
      setBusy(false);
    }
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center text-gray-500">Loading…</div>;

  if (showWizard) {
    return (
      <div className="min-h-screen bg-gray-50 py-8 px-4">
        <div className="max-w-5xl mx-auto">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-800">🎓 Promote Students — Year-End Review</h1>
              <p className="text-gray-600 mt-1">Review each student before starting the new academic year.</p>
            </div>
            <button onClick={() => setShowWizard(false)} className="text-gray-600 hover:text-gray-800">Cancel</button>
          </div>

          {error && <div className="mb-4 rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">{error}</div>}

          <div className="bg-white rounded-xl shadow overflow-hidden mb-6">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 text-left text-xs uppercase text-gray-500">
                <tr>
                  <th className="px-4 py-3">Student</th>
                  <th className="px-4 py-3">Current</th>
                  <th className="px-4 py-3">Decision</th>
                  <th className="px-4 py-3">New Grade</th>
                  <th className="px-4 py-3">New Section</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {students.map((s) => {
                  const d = decisions[s.id] || {};
                  return (
                    <tr key={s.id}>
                      <td className="px-4 py-2 font-medium text-gray-800">{s.firstName} {s.fatherName} <span className="text-xs text-gray-400">({s.studentId})</span></td>
                      <td className="px-4 py-2 text-gray-500">{s.grade} - {s.section}</td>
                      <td className="px-4 py-2">
                        <select
                          value={d.decision}
                          onChange={(e) => updateDecision(s.id, { decision: e.target.value })}
                          className="border rounded p-1.5 text-sm"
                        >
                          {Object.entries(DECISION_LABELS).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
                        </select>
                      </td>
                      <td className="px-4 py-2">
                        {(d.decision === "promoted" || d.decision === "repeated") ? (
                          <input value={d.toGrade || ""} onChange={(e) => updateDecision(s.id, { toGrade: e.target.value })} className="border rounded p-1.5 text-sm w-28" />
                        ) : <span className="text-gray-300">—</span>}
                      </td>
                      <td className="px-4 py-2">
                        {(d.decision === "promoted" || d.decision === "repeated") ? (
                          <input value={d.toSection || ""} onChange={(e) => updateDecision(s.id, { toSection: e.target.value })} className="border rounded p-1.5 text-sm w-20" />
                        ) : <span className="text-gray-300">—</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <button
            onClick={confirmPromotion}
            disabled={busy}
            className="w-full bg-blue-700 text-white py-3 rounded-lg font-semibold hover:bg-blue-800 disabled:bg-gray-400"
          >
            {busy ? "Applying…" : `Confirm & Start New Academic Year (${students.length} students)`}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="mb-6 flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="text-gray-600 hover:text-gray-800">← Back</button>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">📅 Academic Calendar</h1>
            <p className="text-gray-600 mt-1">Manage semesters, academic years, and year-end promotion.</p>
          </div>
        </div>

        {error && <div className="mb-4 rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">{error}</div>}
        {successMessage && <div className="mb-4 rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-700">{successMessage}</div>}

        {currentSemester ? (
          <div className="bg-white rounded-xl shadow p-6 mb-6">
            <p className="text-xs font-bold uppercase text-blue-600">Currently active</p>
            <p className="mt-1 text-xl font-bold text-gray-800">{currentSemester.name} · {currentSemester.academicYearLabel}</p>
            <p className="mt-1 text-sm text-gray-500">Results, attendance, and discipline entered from here on are automatically tagged to this term.</p>

            <div className="mt-5 flex flex-col sm:flex-row gap-3">
              {currentSemester.termNumber === 1 ? (
                <button onClick={handleEndSemesterOne} disabled={busy} className="flex-1 bg-blue-700 text-white py-3 rounded-lg font-semibold hover:bg-blue-800 disabled:bg-gray-400">
                  {busy ? "Ending…" : "End Semester 1 → Start Semester 2"}
                </button>
              ) : (
                <button onClick={openPromotionWizard} disabled={wizardLoading} className="flex-1 bg-emerald-700 text-white py-3 rounded-lg font-semibold hover:bg-emerald-800 disabled:bg-gray-400">
                  {wizardLoading ? "Loading students…" : "End Semester 2 → Review Promotion & Start New Year"}
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-6 mb-6 text-amber-800">No active semester found. Please contact support.</div>
        )}

        <div className="bg-white rounded-xl shadow p-6">
          <h3 className="font-semibold text-gray-800 mb-4">History</h3>
          <div className="space-y-2">
            {history.map((s) => (
              <div key={s.id} className="flex items-center justify-between border-b border-gray-100 py-2 last:border-0">
                <span className="text-sm text-gray-700">{s.name}</span>
                <span className={`text-xs px-2 py-1 rounded-full font-semibold ${s.status === "active" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                  {s.status === "active" ? "Active" : "Ended"}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
