// src/pages/admin/AdmissionsManagement.jsx
import { useState, useEffect } from "react";
import { useAuth } from "../../context/AuthContext";
import { db, storage, doc, getDoc, setDoc, ref, uploadBytes, getDownloadURL } from "../../supabase/supabase";

export default function AdmissionsManagement() {
  const { user, role } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [activeTab, setActiveTab] = useState("hero");

  // Form states
  const [heroData, setHeroData] = useState({
    title: "Admissions",
    content: "Join Tech Zone Academy and give your child the gift of quality education. We welcome students from KG-1 to Grade 8.",
    background: "from-teal-600 to-teal-800",
  });

  const [requirements, setRequirements] = useState([
    "Birth Certificate",
    "Health Records",
    "Parent/Guardian ID",
    "Previous School Report Card (if applicable)",
    "Passport-sized Photos (4)",
    "Transfer Letter (if applicable)"
  ]);

  const [newRequirement, setNewRequirement] = useState("");
  const [editingRequirement, setEditingRequirement] = useState(null);

  const [processSteps, setProcessSteps] = useState([
    "Fill out the online application form",
    "Submit required documents",
    "Student assessment and placement test",
    "Complete enrollment"
  ]);

  const [newProcessStep, setNewProcessStep] = useState("");
  const [editingProcessStep, setEditingProcessStep] = useState(null);

  const [grades, setGrades] = useState([
    "KG-1", "KG-2", "KG-3",
    "Grade 1", "Grade 2", "Grade 3",
    "Grade 4", "Grade 5", "Grade 6",
    "Grade 7", "Grade 8"
  ]);

  const [newGrade, setNewGrade] = useState("");
  const [editingGrade, setEditingGrade] = useState(null);

  const [feeItems, setFeeItems] = useState([
    { id: "1", item: "Application Fee", amount: "20", isTotal: false },
    { id: "2", item: "Registration Fee", amount: "50", isTotal: false },
    { id: "3", item: "Tuition (per term)", amount: "500", isTotal: false },
    { id: "4", item: "Materials & Books", amount: "100", isTotal: false },
    { id: "5", item: "Activity Fee", amount: "50", isTotal: false },
    { id: "6", item: "Total (Approx.)", amount: "720", isTotal: true },
  ]);

  const [currency, setCurrency] = useState("$");
  const [newFeeItem, setNewFeeItem] = useState({ item: "", amount: "", isTotal: false });
  const [editingFeeItem, setEditingFeeItem] = useState(null);

  // Load data from Firestore
  const loadAdmissionsData = async () => {
    setLoading(true);
    try {
      const docRef = doc(db, "websitePages", "admissions");
      const docSnap = await getDoc(docRef);
      
      if (docSnap.exists()) {
        const data = docSnap.data();
        const sections = data.sections || [];
        
        // Load hero
        const hero = sections.find(s => s.type === "hero");
        if (hero) {
          setHeroData({
            title: hero.title || "Admissions",
            content: hero.content || "",
            background: hero.background || "from-teal-600 to-teal-800",
          });
        }

        // Load requirements
        const reqSection = sections.find(s => s.type === "requirements");
        if (reqSection && reqSection.items) {
          setRequirements(reqSection.items);
        }

        // Load process steps
        const procSection = sections.find(s => s.type === "process");
        if (procSection && procSection.items) {
          setProcessSteps(procSection.items);
        }

        // Load grades
        const gradesSection = sections.find(s => s.type === "grades");
        if (gradesSection && gradesSection.items) {
          setGrades(gradesSection.items);
        }

        // Load fees
        const feesSection = sections.find(s => s.type === "fees");
        if (feesSection) {
          if (feesSection.items) {
            setFeeItems(feesSection.items);
          }
          if (feesSection.currency) {
            setCurrency(feesSection.currency);
          }
        }
      }
    } catch (error) {
      setErrorMessage("Error loading admissions data: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
     
    loadAdmissionsData();
  }, []);

  const saveAdmissionsData = async () => {
    setSaving(true);
    setErrorMessage("");
    setSuccessMessage("");

    try {
      const sections = [
        {
          type: "hero",
          title: heroData.title,
          content: heroData.content,
          background: heroData.background,
        },
        {
          type: "requirements",
          items: requirements,
        },
        {
          type: "process",
          items: processSteps,
        },
        {
          type: "grades",
          items: grades,
        },
        {
          type: "fees",
          items: feeItems,
          currency: currency,
        },
      ];

      await setDoc(doc(db, "websitePages", "admissions"), {
        sections: sections,
        updatedAt: new Date().toISOString(),
        updatedBy: user?.email || "Admin",
      });

      setSuccessMessage("✅ Admissions data saved successfully!");
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error saving: " + error.message);
    } finally {
      setSaving(false);
    }
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    try {
      const timestamp = Date.now();
      const fileName = `${timestamp}_${file.name}`;
      const storageRef = ref(storage, `admissions/${fileName}`);
      const snapshot = await uploadBytes(storageRef, file);
      const url = await getDownloadURL(snapshot.ref);
      
      // You can add a background image field to heroData if needed
      setHeroData(prev => ({ ...prev, backgroundImage: url }));
      setSuccessMessage("✅ Image uploaded successfully!");
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error uploading image: " + error.message);
    } finally {
      setUploading(false);
    }
  };

  // ============================================
  // REQUIREMENT FUNCTIONS
  // ============================================
  const addRequirement = () => {
    if (!newRequirement.trim()) return;
    setRequirements([...requirements, newRequirement.trim()]);
    setNewRequirement("");
  };

  const updateRequirement = () => {
    if (!editingRequirement || !editingRequirement.text.trim()) return;
    const updated = [...requirements];
    updated[editingRequirement.index] = editingRequirement.text.trim();
    setRequirements(updated);
    setEditingRequirement(null);
  };

  const deleteRequirement = (index) => {
    if (!window.confirm("Delete this requirement?")) return;
    setRequirements(requirements.filter((_, i) => i !== index));
  };

  // ============================================
  // PROCESS STEP FUNCTIONS
  // ============================================
  const addProcessStep = () => {
    if (!newProcessStep.trim()) return;
    setProcessSteps([...processSteps, newProcessStep.trim()]);
    setNewProcessStep("");
  };

  const updateProcessStep = () => {
    if (!editingProcessStep || !editingProcessStep.text.trim()) return;
    const updated = [...processSteps];
    updated[editingProcessStep.index] = editingProcessStep.text.trim();
    setProcessSteps(updated);
    setEditingProcessStep(null);
  };

  const deleteProcessStep = (index) => {
    if (!window.confirm("Delete this process step?")) return;
    setProcessSteps(processSteps.filter((_, i) => i !== index));
  };

  // ============================================
  // GRADE FUNCTIONS
  // ============================================
  const addGrade = () => {
    if (!newGrade.trim()) return;
    setGrades([...grades, newGrade.trim()]);
    setNewGrade("");
  };

  const updateGrade = () => {
    if (!editingGrade || !editingGrade.text.trim()) return;
    const updated = [...grades];
    updated[editingGrade.index] = editingGrade.text.trim();
    setGrades(updated);
    setEditingGrade(null);
  };

  const deleteGrade = (index) => {
    if (!window.confirm("Delete this grade?")) return;
    setGrades(grades.filter((_, i) => i !== index));
  };

  // ============================================
  // FEE FUNCTIONS
  // ============================================
  const addFeeItem = () => {
    if (!newFeeItem.item.trim() || !newFeeItem.amount.trim()) return;
    setFeeItems([...feeItems, { ...newFeeItem, id: Date.now().toString() }]);
    setNewFeeItem({ item: "", amount: "", isTotal: false });
  };

  const updateFeeItem = () => {
    if (!editingFeeItem) return;
    const updated = [...feeItems];
    updated[editingFeeItem.index] = editingFeeItem.data;
    setFeeItems(updated);
    setEditingFeeItem(null);
  };

  const deleteFeeItem = (index) => {
    if (!window.confirm("Delete this fee item?")) return;
    setFeeItems(feeItems.filter((_, i) => i !== index));
  };

  // ============================================
  // RENDER FUNCTIONS
  // ============================================
  const renderHeroEditor = () => (
    <div className="space-y-4">
      <h3 className="text-xl font-bold text-gray-800">🎓 Hero Section</h3>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
        <input
          type="text"
          value={heroData.title}
          onChange={(e) => setHeroData({ ...heroData, title: e.target.value })}
          className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-teal-500 outline-none"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Content</label>
        <textarea
          value={heroData.content}
          onChange={(e) => setHeroData({ ...heroData, content: e.target.value })}
          rows="3"
          className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-teal-500 outline-none"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Background Color</label>
        <select
          value={heroData.background}
          onChange={(e) => setHeroData({ ...heroData, background: e.target.value })}
          className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-teal-500 outline-none"
        >
          <option value="from-teal-600 to-teal-800">Teal</option>
          <option value="from-blue-600 to-blue-800">Blue</option>
          <option value="from-purple-600 to-purple-800">Purple</option>
          <option value="from-green-600 to-green-800">Green</option>
          <option value="from-orange-600 to-orange-800">Orange</option>
          <option value="from-red-600 to-red-800">Red</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Background Image</label>
        <div className="flex gap-3">
          <input
            type="text"
            value={heroData.backgroundImage || ""}
            onChange={(e) => setHeroData({ ...heroData, backgroundImage: e.target.value })}
            className="flex-1 border rounded-lg p-3 focus:ring-2 focus:ring-teal-500 outline-none"
            placeholder="Image URL"
          />
          <label className="bg-gray-200 hover:bg-gray-300 px-4 py-3 rounded-lg cursor-pointer transition">
            {uploading ? "Uploading..." : "📁 Upload"}
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleImageUpload}
              disabled={uploading}
            />
          </label>
        </div>
        {heroData.backgroundImage && (
          <div className="mt-2 h-32 w-full rounded-lg overflow-hidden bg-gray-200">
            <img src={heroData.backgroundImage} alt="Preview" className="w-full h-full object-cover" />
          </div>
        )}
      </div>
    </div>
  );

  const renderRequirementsEditor = () => (
    <div className="space-y-4">
      <h3 className="text-xl font-bold text-gray-800">📋 Requirements</h3>
      
      <div className="flex gap-2">
        <input
          type="text"
          value={newRequirement}
          onChange={(e) => setNewRequirement(e.target.value)}
          placeholder="Enter requirement"
          className="flex-1 border rounded-lg p-3 focus:ring-2 focus:ring-teal-500 outline-none"
          onKeyPress={(e) => e.key === "Enter" && addRequirement()}
        />
        <button
          onClick={addRequirement}
          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition"
        >
          Add
        </button>
      </div>

      <div className="space-y-2">
        {requirements.map((req, index) => (
          <div key={index} className="flex items-center gap-3 bg-gray-50 rounded-lg p-3">
            <span className="text-green-600 text-xl">✅</span>
            {editingRequirement && editingRequirement.index === index ? (
              <input
                type="text"
                value={editingRequirement.text}
                onChange={(e) => setEditingRequirement({ ...editingRequirement, text: e.target.value })}
                className="flex-1 border rounded p-1"
                onKeyPress={(e) => e.key === "Enter" && updateRequirement()}
              />
            ) : (
              <span className="flex-1 text-gray-700">{req}</span>
            )}
            <div className="flex gap-2">
              {editingRequirement && editingRequirement.index === index ? (
                <button onClick={updateRequirement} className="text-green-600 hover:text-green-800">✓</button>
              ) : (
                <button onClick={() => setEditingRequirement({ text: req, index })} className="text-blue-600 hover:text-blue-800">✏️</button>
              )}
              <button onClick={() => deleteRequirement(index)} className="text-red-600 hover:text-red-800">🗑️</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderProcessEditor = () => (
    <div className="space-y-4">
      <h3 className="text-xl font-bold text-gray-800">📝 Process Steps</h3>
      
      <div className="flex gap-2">
        <input
          type="text"
          value={newProcessStep}
          onChange={(e) => setNewProcessStep(e.target.value)}
          placeholder="Enter process step"
          className="flex-1 border rounded-lg p-3 focus:ring-2 focus:ring-teal-500 outline-none"
          onKeyPress={(e) => e.key === "Enter" && addProcessStep()}
        />
        <button
          onClick={addProcessStep}
          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition"
        >
          Add
        </button>
      </div>

      <div className="space-y-2">
        {processSteps.map((step, index) => (
          <div key={index} className="flex items-center gap-3 bg-gray-50 rounded-lg p-3">
            <span className="text-2xl">📌</span>
            {editingProcessStep && editingProcessStep.index === index ? (
              <input
                type="text"
                value={editingProcessStep.text}
                onChange={(e) => setEditingProcessStep({ ...editingProcessStep, text: e.target.value })}
                className="flex-1 border rounded p-1"
                onKeyPress={(e) => e.key === "Enter" && updateProcessStep()}
              />
            ) : (
              <span className="flex-1 text-gray-700">Step {index + 1}: {step}</span>
            )}
            <div className="flex gap-2">
              {editingProcessStep && editingProcessStep.index === index ? (
                <button onClick={updateProcessStep} className="text-green-600 hover:text-green-800">✓</button>
              ) : (
                <button onClick={() => setEditingProcessStep({ text: step, index })} className="text-blue-600 hover:text-blue-800">✏️</button>
              )}
              <button onClick={() => deleteProcessStep(index)} className="text-red-600 hover:text-red-800">🗑️</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderGradesEditor = () => (
    <div className="space-y-4">
      <h3 className="text-xl font-bold text-gray-800">📚 Grades</h3>
      
      <div className="flex gap-2">
        <input
          type="text"
          value={newGrade}
          onChange={(e) => setNewGrade(e.target.value)}
          placeholder="Enter grade (e.g., Grade 9)"
          className="flex-1 border rounded-lg p-3 focus:ring-2 focus:ring-teal-500 outline-none"
          onKeyPress={(e) => e.key === "Enter" && addGrade()}
        />
        <button
          onClick={addGrade}
          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition"
        >
          Add
        </button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        {grades.map((grade, index) => (
          <div key={index} className="bg-gray-50 rounded-lg p-3 flex items-center justify-between">
            {editingGrade && editingGrade.index === index ? (
              <input
                type="text"
                value={editingGrade.text}
                onChange={(e) => setEditingGrade({ ...editingGrade, text: e.target.value })}
                className="flex-1 border rounded p-1"
                onKeyPress={(e) => e.key === "Enter" && updateGrade()}
              />
            ) : (
              <span className="font-medium text-gray-700">{grade}</span>
            )}
            <div className="flex gap-2">
              {editingGrade && editingGrade.index === index ? (
                <button onClick={updateGrade} className="text-green-600 hover:text-green-800">✓</button>
              ) : (
                <button onClick={() => setEditingGrade({ text: grade, index })} className="text-blue-600 hover:text-blue-800">✏️</button>
              )}
              <button onClick={() => deleteGrade(index)} className="text-red-600 hover:text-red-800">🗑️</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderFeesEditor = () => (
    <div className="space-y-4">
      <h3 className="text-xl font-bold text-gray-800">💰 Fee Structure</h3>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Currency Symbol</label>
        <input
          type="text"
          value={currency}
          onChange={(e) => setCurrency(e.target.value)}
          className="w-20 border rounded-lg p-3 focus:ring-2 focus:ring-teal-500 outline-none"
          placeholder="$"
        />
        <span className="ml-2 text-sm text-gray-500">(e.g., $, €, £, Br, etc.)</span>
      </div>

      <div className="grid grid-cols-3 gap-2">
        <input
          type="text"
          value={newFeeItem.item}
          onChange={(e) => setNewFeeItem({ ...newFeeItem, item: e.target.value })}
          placeholder="Item name"
          className="border rounded-lg p-3 focus:ring-2 focus:ring-teal-500 outline-none"
        />
        <input
          type="text"
          value={newFeeItem.amount}
          onChange={(e) => setNewFeeItem({ ...newFeeItem, amount: e.target.value })}
          placeholder="Amount"
          className="border rounded-lg p-3 focus:ring-2 focus:ring-teal-500 outline-none"
        />
        <div className="flex gap-2">
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={newFeeItem.isTotal}
              onChange={(e) => setNewFeeItem({ ...newFeeItem, isTotal: e.target.checked })}
              className="w-4 h-4"
            />
            Total
          </label>
          <button
            onClick={addFeeItem}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition"
          >
            Add
          </button>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg overflow-hidden">
        <table className="w-full">
          <thead className="bg-teal-600 text-white">
            <tr>
              <th className="px-4 py-2 text-left">Item</th>
              <th className="px-4 py-2 text-right">Amount</th>
              <th className="px-4 py-2 text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {feeItems.map((fee, index) => {
              const isTotal = fee.isTotal || fee.item.toLowerCase().includes("total");
              return (
                <tr key={fee.id || index} className={isTotal ? "bg-gray-100 font-bold" : "border-b border-gray-200"}>
                  <td className="px-4 py-2 text-gray-700">
                    {editingFeeItem && editingFeeItem.index === index ? (
                      <input
                        type="text"
                        value={editingFeeItem.data.item}
                        onChange={(e) => setEditingFeeItem({
                          ...editingFeeItem,
                          data: { ...editingFeeItem.data, item: e.target.value }
                        })}
                        className="border rounded p-1 w-full"
                      />
                    ) : (
                      fee.item
                    )}
                  </td>
                  <td className="px-4 py-2 text-right font-medium text-gray-800">
                    {editingFeeItem && editingFeeItem.index === index ? (
                      <input
                        type="text"
                        value={editingFeeItem.data.amount}
                        onChange={(e) => setEditingFeeItem({
                          ...editingFeeItem,
                          data: { ...editingFeeItem.data, amount: e.target.value }
                        })}
                        className="border rounded p-1 w-20 text-right"
                      />
                    ) : (
                      `${currency}${fee.amount}`
                    )}
                  </td>
                  <td className="px-4 py-2 text-center">
                    {editingFeeItem && editingFeeItem.index === index ? (
                      <button onClick={updateFeeItem} className="text-green-600 hover:text-green-800 mr-2">✓</button>
                    ) : (
                      <button onClick={() => setEditingFeeItem({ data: fee, index })} className="text-blue-600 hover:text-blue-800 mr-2">✏️</button>
                    )}
                    <button onClick={() => deleteFeeItem(index)} className="text-red-600 hover:text-red-800">🗑️</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );

  if (role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">🚫</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h2>
          <p className="text-gray-600">You need admin privileges to access this page.</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading admissions data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              📝 Admissions Management
            </h1>
            <p className="text-gray-600 mt-1">Manage your admissions page content</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={saveAdmissionsData}
              disabled={saving}
              className={`px-6 py-2 rounded-lg font-semibold text-white transition ${
                saving ? "bg-gray-400 cursor-not-allowed" : "bg-teal-700 hover:bg-teal-800"
              }`}
            >
              {saving ? "Saving..." : "💾 Save All"}
            </button>
          </div>
        </div>

        {/* Messages */}
        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Tabs */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="border-b border-gray-200 overflow-x-auto">
            <div className="flex whitespace-nowrap">
              {[
                { id: "hero", label: "🎓 Hero" },
                { id: "requirements", label: "📋 Requirements" },
                { id: "process", label: "📝 Process" },
                { id: "grades", label: "📚 Grades" },
                { id: "fees", label: "💰 Fees" },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-4 py-3 font-medium transition ${
                    activeTab === tab.id
                      ? "bg-teal-50 text-teal-700 border-b-2 border-teal-700"
                      : "text-gray-600 hover:text-gray-800 hover:bg-gray-50"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          <div className="p-6">
            {activeTab === "hero" && renderHeroEditor()}
            {activeTab === "requirements" && renderRequirementsEditor()}
            {activeTab === "process" && renderProcessEditor()}
            {activeTab === "grades" && renderGradesEditor()}
            {activeTab === "fees" && renderFeesEditor()}
          </div>
        </div>

        {/* Preview Button */}
        <div className="mt-6 text-center">
          <button
            onClick={() => window.open("/admissions", "_blank")}
            className="bg-gray-200 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-300 transition"
          >
            🔍 Preview Admissions Page
          </button>
        </div>
      </div>
    </div>
  );
}