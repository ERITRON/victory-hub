// src/pages/admin/EventsManagement.jsx
import { useState, useEffect, useMemo } from "react";
import { useAuth } from "../../context/AuthContext";
import { db, storage, collection, addDoc, getDocs, deleteDoc, doc, query, orderBy, updateDoc, getDoc, ref, uploadBytes, getDownloadURL, deleteObject } from "../../supabase/supabase";

// Used when websiteSettings/eventsSettings has no categories yet. Same shape
// as the settings editor produces: { id, name, color } with Tailwind classes.
const FALLBACK_CATEGORIES = [
  { id: "academic", name: "Academic", color: "bg-blue-100 text-blue-700" },
  { id: "sports", name: "Sports", color: "bg-green-100 text-green-700" },
  { id: "cultural", name: "Cultural", color: "bg-purple-100 text-purple-700" },
  { id: "holiday", name: "Holiday", color: "bg-red-100 text-red-700" },
  { id: "meeting", name: "Meeting", color: "bg-yellow-100 text-yellow-700" },
  { id: "general", name: "General", color: "bg-gray-100 text-gray-700" },
];

export default function EventsManagement() {
  const { user, role } = useAuth();
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [categories, setCategories] = useState(FALLBACK_CATEGORIES);
  const [categoryFilter, setCategoryFilter] = useState("");

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    date: new Date().toISOString().split("T")[0],
    time: "",
    location: "",
    banner: "",
    registrationLink: "",
    status: "upcoming",
  });

  const fetchEvents = async () => {
    setLoading(true);
    try {
      const q = query(collection(db, "events"), orderBy("date", "asc"));
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setEvents(data);
    } catch (error) {
      setErrorMessage("Error loading events: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const settingsDoc = await getDoc(doc(db, "websiteSettings", "eventsSettings"));
      const fromSettings = settingsDoc.exists()
        ? settingsDoc.data().categories
        : null;
      // Fall back to the defaults when settings has no categories yet.
      setCategories(
        Array.isArray(fromSettings) && fromSettings.length > 0
          ? fromSettings
          : FALLBACK_CATEGORIES
      );
    } catch (error) {
      console.error("Error fetching categories:", error);
      setCategories(FALLBACK_CATEGORIES);
    }
  };

  useEffect(() => {

    fetchEvents();
    fetchCategories();
  }, []);

  // Badge classes for a category name; gray for unknown/uncategorized.
  const getCategoryStyle = (name) => {
    const found = categories.find((c) => c.name === name);
    return found?.color || "bg-gray-100 text-gray-700";
  };

  // Filter tabs: the settings categories plus any category that exists on an
  // event but was removed from settings — so no event is ever unreachable.
  const filterTabs = useMemo(() => {
    const known = new Set(categories.map((c) => c.name));
    const extras = [
      ...new Set(
        events
          .map((e) => e.category)
          .filter((name) => name && !known.has(name))
      ),
    ].map((name) => ({ id: `legacy-${name}`, name, color: "bg-gray-100 text-gray-700" }));
    return [...categories, ...extras];
  }, [categories, events]);

  const filteredEvents = useMemo(() => {
    if (!categoryFilter) return events;
    return events.filter((e) => (e.category || "") === categoryFilter);
  }, [events, categoryFilter]);

  const countFor = (name) =>
    name ? events.filter((e) => e.category === name).length : events.length;

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    try {
      const timestamp = Date.now();
      const fileName = `${timestamp}_${file.name}`;
      const storageRef = ref(storage, `events/${fileName}`);
      const snapshot = await uploadBytes(storageRef, file);
      const url = await getDownloadURL(snapshot.ref);
      setFormData((prev) => ({ ...prev, banner: url }));
      setSuccessMessage("✅ Banner uploaded successfully!");
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error uploading banner: " + error.message);
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = {
        ...formData,
        createdBy: user?.email || "Admin",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      if (editingItem) {
        await updateDoc(doc(db, "events", editingItem.id), data);
        setSuccessMessage("✅ Event updated successfully!");
      } else {
        await addDoc(collection(db, "events"), data);
        setSuccessMessage("✅ Event created successfully!");
      }

      setShowModal(false);
      setEditingItem(null);
      setFormData({
        title: "",
        description: "",
        category: "",
        date: new Date().toISOString().split("T")[0],
        time: "",
        location: "",
        banner: "",
        registrationLink: "",
        status: "upcoming",
      });
      await fetchEvents();
    } catch (error) {
      setErrorMessage("Error saving event: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this event?")) return;
    try {
      const item = events.find(e => e.id === id);
      if (item?.banner) {
        try {
          const imageRef = ref(storage, item.banner);
          await deleteObject(imageRef);
        } catch {
          console.log("Banner not found in storage");
        }
      }
      await deleteDoc(doc(db, "events", id));
      setSuccessMessage("✅ Event deleted successfully!");
      await fetchEvents();
    } catch (error) {
      setErrorMessage("Error deleting event: " + error.message);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "upcoming": return "bg-blue-100 text-blue-700";
      case "ongoing": return "bg-green-100 text-green-700";
      case "past": return "bg-gray-100 text-gray-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  if (role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">🚫</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h2>
          <p className="text-gray-600">You need admin privileges to access this page.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">📅 Events Management</h1>
            <p className="text-gray-600 mt-1">Create, edit, and manage school events</p>
          </div>
          <button
            onClick={() => {
              setEditingItem(null);
              setFormData({
                title: "",
                description: "",
                category: "",
                date: new Date().toISOString().split("T")[0],
                time: "",
                location: "",
                banner: "",
                registrationLink: "",
                status: "upcoming",
              });
              setShowModal(true);
            }}
            className="bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition flex items-center gap-2"
          >
            <span className="text-xl">+</span> Add Event
          </button>
        </div>

        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Category filter tabs */}
        <div className="flex flex-wrap items-center gap-2 mb-6">
          <button
            onClick={() => setCategoryFilter("")}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition border ${
              categoryFilter === ""
                ? "bg-blue-700 text-white border-blue-700"
                : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"
            }`}
          >
            All ({countFor("")})
          </button>
          {filterTabs.map((cat) => (
            <button
              key={cat.id || cat.name}
              onClick={() =>
                setCategoryFilter(categoryFilter === cat.name ? "" : cat.name)
              }
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition border ${
                categoryFilter === cat.name
                  ? "bg-blue-700 text-white border-blue-700"
                  : `${cat.color} border-transparent hover:opacity-80`
              }`}
            >
              {cat.name} ({countFor(cat.name)})
            </button>
          ))}
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading events...</p>
          </div>
        ) : events.length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-6xl mb-4">📭</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No Events</h3>
            <p className="text-gray-500">Click "Add Event" to create your first event.</p>
          </div>
        ) : filteredEvents.length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              No "{categoryFilter}" Events
            </h3>
            <p className="text-gray-500 mb-4">No events found in this category.</p>
            <button
              onClick={() => setCategoryFilter("")}
              className="text-blue-600 hover:text-blue-800 text-sm font-medium"
            >
              Show all events
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEvents.map((event) => (
              <div key={event.id} className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition">
                {event.banner && (
                  <div className="h-48 bg-gray-200 overflow-hidden">
                    <img src={event.banner} alt={event.title} className="w-full h-full object-cover" />
                  </div>
                )}
                <div className="p-5">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(event.status)}`}>
                        {event.status || "Upcoming"}
                      </span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getCategoryStyle(event.category)}`}>
                        {event.category || "Uncategorized"}
                      </span>
                    </div>
                    <span className="text-xs text-gray-400">
                      {event.date ? new Date(event.date).toLocaleDateString() : ""}
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-gray-800 mb-2">{event.title}</h3>
                  <p className="text-gray-600 text-sm mb-3 line-clamp-2">{event.description}</p>
                  <div className="flex items-center gap-3 text-sm text-gray-500">
                    <span>📍 {event.location || "TBD"}</span>
                    <span>🕐 {event.time || "TBD"}</span>
                  </div>
                  <div className="flex items-center justify-between mt-4 pt-3 border-t">
                    <span className="text-xs text-gray-400 truncate max-w-[45%]">
                      {event.createdBy || ""}
                    </span>
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setEditingItem(event);
                          setFormData({
                            title: event.title || "",
                            description: event.description || "",
                            category: event.category || "",
                            date: event.date || new Date().toISOString().split("T")[0],
                            time: event.time || "",
                            location: event.location || "",
                            banner: event.banner || "",
                            registrationLink: event.registrationLink || "",
                            status: event.status || "upcoming",
                          });
                          setShowModal(true);
                        }}
                        className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                      >
                        ✏️ Edit
                      </button>
                      <button
                        onClick={() => handleDelete(event.id)}
                        className="text-red-600 hover:text-red-800 text-sm font-medium"
                      >
                        🗑️ Delete
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 sm:p-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800">
                  {editingItem ? "✏️ Edit Event" : "📅 Add Event"}
                </h2>
                <button onClick={() => { setShowModal(false); setEditingItem(null); }} className="text-gray-500 hover:text-gray-700 text-2xl">×</button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Title *</label>
                  <input type="text" name="title" value={formData.title} onChange={handleInputChange} required className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Enter event title" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <textarea name="description" value={formData.description} onChange={handleInputChange} rows="4" className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Event description" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                  <select name="category" value={formData.category} onChange={handleInputChange} className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none">
                    <option value="">Select Category</option>
                    {categories.map((cat) => (
                      <option key={cat.id || cat.name} value={cat.name}>{cat.name}</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                    <input type="date" name="date" value={formData.date} onChange={handleInputChange} className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Time</label>
                    <input type="time" name="time" value={formData.time} onChange={handleInputChange} className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                  <input type="text" name="location" value={formData.location} onChange={handleInputChange} className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Event location" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Banner Image</label>
                  <div className="flex gap-3">
                    <input type="text" name="banner" value={formData.banner} onChange={handleInputChange} className="flex-1 border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Banner URL" />
                    <label className="bg-gray-200 hover:bg-gray-300 px-4 py-3 rounded-lg cursor-pointer transition">
                      {uploading ? "Uploading..." : "📁 Upload"}
                      <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} disabled={uploading} />
                    </label>
                  </div>
                  {formData.banner && (
                    <div className="mt-2 h-32 w-full rounded-lg overflow-hidden bg-gray-200">
                      <img src={formData.banner} alt="Preview" className="w-full h-full object-cover" />
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Registration Link</label>
                  <input type="text" name="registrationLink" value={formData.registrationLink} onChange={handleInputChange} className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="https://..." />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                  <select name="status" value={formData.status} onChange={handleInputChange} className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none">
                    <option value="upcoming">📅 Upcoming</option>
                    <option value="ongoing">🔄 Ongoing</option>
                    <option value="past">✅ Past</option>
                  </select>
                </div>

                <div className="flex gap-3 pt-4">
                  <button type="submit" disabled={loading || uploading} className={`flex-1 py-3 rounded-lg font-semibold text-white transition ${loading || uploading ? "bg-gray-400 cursor-not-allowed" : "bg-blue-700 hover:bg-blue-800"}`}>
                    {loading ? "Saving..." : editingItem ? "Update Event" : "Add Event"}
                  </button>
                  <button type="button" onClick={() => { setShowModal(false); setEditingItem(null); }} className="px-6 py-3 rounded-lg font-semibold text-gray-700 bg-gray-200 hover:bg-gray-300 transition">Cancel</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}