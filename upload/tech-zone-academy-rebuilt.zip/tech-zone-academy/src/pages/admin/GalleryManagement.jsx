// src/pages/admin/GalleryManagement.jsx
import { useState, useEffect } from "react";
import { useAuth } from "../../context/AuthContext";
import { db, storage, collection, addDoc, getDocs, deleteDoc, doc, query, orderBy, updateDoc, getDoc, ref, uploadBytes, getDownloadURL, deleteObject } from "../../supabase/supabase";

export default function GalleryManagement() {
  const { user, role } = useAuth();
  const [images, setImages] = useState([]);
  const [albums, setAlbums] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showAlbumModal, setShowAlbumModal] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [editingAlbum, setEditingAlbum] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [activeTab, setActiveTab] = useState("images");
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [categories, setCategories] = useState([]);

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    imageUrl: "",
    date: new Date().toISOString().split("T")[0],
    albumId: "",
  });

  const [albumForm, setAlbumForm] = useState({
    name: "",
    description: "",
    coverImage: "",
    date: new Date().toISOString().split("T")[0],
    featured: false,
  });

  const fetchGalleryData = async () => {
    setLoading(true);
    try {
      const imagesSnap = await getDocs(query(collection(db, "galleryImages"), orderBy("date", "desc")));
      const imagesData = imagesSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setImages(imagesData);

      const albumsSnap = await getDocs(query(collection(db, "galleryAlbums"), orderBy("date", "desc")));
      const albumsData = albumsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setAlbums(albumsData);
    } catch (error) {
      setErrorMessage("Error loading gallery: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const settingsDoc = await getDoc(doc(db, "websiteSettings", "gallerySettings"));
      if (settingsDoc.exists()) {
        const data = settingsDoc.data();
        setCategories(data.categories || []);
      }
    } catch (error) {
      console.error("Error fetching categories:", error);
    }
  };

  useEffect(() => {
     
    fetchGalleryData();
    fetchCategories();
  }, []);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleAlbumInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setAlbumForm((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleImageUpload = async (e, setter, field) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);
    try {
      const uploadedUrls = [];
      for (const file of files) {
        const timestamp = Date.now();
        const fileName = `${timestamp}_${file.name}`;
        const storageRef = ref(storage, `gallery/${fileName}`);
        const snapshot = await uploadBytes(storageRef, file);
        const url = await getDownloadURL(snapshot.ref);
        uploadedUrls.push(url);
      }

      if (uploadedUrls.length === 1) {
        setter((prev) => ({ ...prev, [field]: uploadedUrls[0] }));
      } else {
        for (const url of uploadedUrls) {
          await addDoc(collection(db, "galleryImages"), {
            title: formData.title || `Image ${Date.now()}`,
            description: formData.description || "",
            category: formData.category || "",
            imageUrl: url,
            date: formData.date || new Date().toISOString().split("T")[0],
            albumId: formData.albumId || "",
            uploadedBy: user?.email || "Admin",
            createdAt: new Date().toISOString(),
          });
        }
        setSuccessMessage(`✅ ${uploadedUrls.length} images uploaded successfully!`);
        await fetchGalleryData();
      }
    } catch (error) {
      setErrorMessage("Error uploading images: " + error.message);
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = {
        ...formData,
        uploadedBy: user?.email || "Admin",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      if (editingItem) {
        await updateDoc(doc(db, "galleryImages", editingItem.id), data);
        setSuccessMessage("✅ Image updated successfully!");
      } else {
        await addDoc(collection(db, "galleryImages"), data);
        setSuccessMessage("✅ Image added successfully!");
      }

      setShowModal(false);
      setEditingItem(null);
      setFormData({
        title: "",
        description: "",
        category: "",
        imageUrl: "",
        date: new Date().toISOString().split("T")[0],
        albumId: "",
      });
      await fetchGalleryData();
    } catch (error) {
      setErrorMessage("Error saving image: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAlbumSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = {
        ...albumForm,
        photoCount: 0,
        createdBy: user?.email || "Admin",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      if (editingAlbum) {
        await updateDoc(doc(db, "galleryAlbums", editingAlbum.id), data);
        setSuccessMessage("✅ Album updated successfully!");
      } else {
        await addDoc(collection(db, "galleryAlbums"), data);
        setSuccessMessage("✅ Album created successfully!");
      }

      setShowAlbumModal(false);
      setEditingAlbum(null);
      setAlbumForm({
        name: "",
        description: "",
        coverImage: "",
        date: new Date().toISOString().split("T")[0],
        featured: false,
      });
      await fetchGalleryData();
    } catch (error) {
      setErrorMessage("Error saving album: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id, collectionName) => {
    if (!window.confirm("Are you sure you want to delete this?")) return;
    try {
      const item = collectionName === "images" 
        ? images.find(i => i.id === id) 
        : albums.find(a => a.id === id);
      
      if (item?.imageUrl || item?.coverImage) {
        try {
          const imageRef = ref(storage, item.imageUrl || item.coverImage);
          await deleteObject(imageRef);
        } catch {
          console.log("Image not found in storage");
        }
      }

      await deleteDoc(doc(db, collectionName === "images" ? "galleryImages" : "galleryAlbums", id));
      setSuccessMessage("✅ Deleted successfully!");
      await fetchGalleryData();
    } catch (error) {
      setErrorMessage("Error deleting: " + error.message);
    }
  };

  if (role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">🚫</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h2>
          <p className="text-gray-600">You need admin privileges to access this page.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">🖼️ Gallery Management</h1>
            <p className="text-gray-600 mt-1">Manage images, albums, and videos</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => {
                setEditingItem(null);
                setFormData({
                  title: "",
                  description: "",
                  category: "",
                  imageUrl: "",
                  date: new Date().toISOString().split("T")[0],
                  albumId: "",
                });
                setShowModal(true);
              }}
              className="bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition flex items-center gap-2"
            >
              <span className="text-xl">+</span> Add Image
            </button>
            <button
              onClick={() => {
                setEditingAlbum(null);
                setAlbumForm({
                  name: "",
                  description: "",
                  coverImage: "",
                  date: new Date().toISOString().split("T")[0],
                  featured: false,
                });
                setShowAlbumModal(true);
              }}
              className="bg-purple-700 text-white px-6 py-2 rounded-lg hover:bg-purple-800 transition flex items-center gap-2"
            >
              <span className="text-xl">+</span> Add Album
            </button>
          </div>
        </div>

        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        <div className="flex flex-wrap gap-2 border-b border-gray-200 pb-4 mb-6">
          <button
            onClick={() => setActiveTab("images")}
            className={`px-6 py-2 rounded-lg font-medium transition ${
              activeTab === "images"
                ? "bg-blue-700 text-white"
                : "bg-gray-200 text-gray-700 hover:bg-gray-300"
            }`}
          >
            📸 Images ({images.length})
          </button>
          <button
            onClick={() => setActiveTab("albums")}
            className={`px-6 py-2 rounded-lg font-medium transition ${
              activeTab === "albums"
                ? "bg-blue-700 text-white"
                : "bg-gray-200 text-gray-700 hover:bg-gray-300"
            }`}
          >
            📁 Albums ({albums.length})
          </button>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading...</p>
          </div>
        ) : activeTab === "images" ? (
          images.length === 0 ? (
            <div className="bg-white rounded-xl shadow p-12 text-center">
              <div className="text-6xl mb-4">📭</div>
              <h3 className="text-xl font-semibold text-gray-700 mb-2">No Images</h3>
              <p className="text-gray-500">Click "Add Image" to upload your first image.</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {images.map((img) => (
                <div key={img.id} className="bg-white rounded-xl shadow-md overflow-hidden group">
                  <div className="aspect-square bg-gray-200 relative">
                    <img src={img.imageUrl} alt={img.title} className="w-full h-full object-cover" />
                    <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition">
                      <button
                        onClick={() => handleDelete(img.id, "images")}
                        className="bg-red-600 text-white p-1 rounded-lg hover:bg-red-700"
                      >
                        🗑️
                      </button>
                    </div>
                  </div>
                  <div className="p-3">
                    <p className="font-medium text-sm truncate">{img.title}</p>
                    <p className="text-xs text-gray-500">{img.category || "Uncategorized"}</p>
                    <button
                      onClick={() => {
                        setEditingItem(img);
                        setFormData({
                          title: img.title || "",
                          description: img.description || "",
                          category: img.category || "",
                          imageUrl: img.imageUrl || "",
                          date: img.date || new Date().toISOString().split("T")[0],
                          albumId: img.albumId || "",
                        });
                        setShowModal(true);
                      }}
                      className="mt-2 text-blue-600 hover:text-blue-800 text-sm font-medium"
                    >
                      ✏️ Edit
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )
        ) : (
          albums.length === 0 ? (
            <div className="bg-white rounded-xl shadow p-12 text-center">
              <div className="text-6xl mb-4">📁</div>
              <h3 className="text-xl font-semibold text-gray-700 mb-2">No Albums</h3>
              <p className="text-gray-500">Click "Add Album" to create your first album.</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {albums.map((album) => (
                <div key={album.id} className="bg-white rounded-xl shadow-md overflow-hidden group">
                  <div className="aspect-video bg-gray-200 relative">
                    {album.coverImage ? (
                      <img src={album.coverImage} alt={album.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-4xl text-gray-400">📁</div>
                    )}
                    {album.featured && (
                      <span className="absolute top-2 left-2 bg-yellow-500 text-white px-2 py-1 rounded text-xs font-medium">⭐ Featured</span>
                    )}
                    <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition">
                      <button
                        onClick={() => handleDelete(album.id, "albums")}
                        className="bg-red-600 text-white p-1 rounded-lg hover:bg-red-700"
                      >
                        🗑️
                      </button>
                    </div>
                  </div>
                  <div className="p-3">
                    <p className="font-medium text-sm truncate">{album.name}</p>
                    <p className="text-xs text-gray-500">{album.photoCount || 0} photos</p>
                    <button
                      onClick={() => {
                        setEditingAlbum(album);
                        setAlbumForm({
                          name: album.name || "",
                          description: album.description || "",
                          coverImage: album.coverImage || "",
                          date: album.date || new Date().toISOString().split("T")[0],
                          featured: album.featured || false,
                        });
                        setShowAlbumModal(true);
                      }}
                      className="mt-2 text-blue-600 hover:text-blue-800 text-sm font-medium"
                    >
                      ✏️ Edit
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 sm:p-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800">
                  {editingItem ? "✏️ Edit Image" : "📷 Add Image"}
                </h2>
                <button onClick={() => { setShowModal(false); setEditingItem(null); }} className="text-gray-500 hover:text-gray-700 text-2xl">×</button>
              </div>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                  <input type="text" name="title" value={formData.title} onChange={handleInputChange} required className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Image title" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <textarea name="description" value={formData.description} onChange={handleInputChange} rows="3" className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Image description" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                  <select name="category" value={formData.category} onChange={handleInputChange} className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none">
                    <option value="">Select Category</option>
                    {categories.map((cat) => (
                      <option key={cat.id} value={cat.name}>{cat.emoji || "📌"} {cat.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Album</label>
                  <select name="albumId" value={formData.albumId} onChange={handleInputChange} className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none">
                    <option value="">No Album</option>
                    {albums.map((album) => (
                      <option key={album.id} value={album.id}>{album.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Image</label>
                  <div className="flex gap-3">
                    <input type="text" name="imageUrl" value={formData.imageUrl} onChange={handleInputChange} className="flex-1 border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Image URL" />
                    <label className="bg-gray-200 hover:bg-gray-300 px-4 py-3 rounded-lg cursor-pointer transition">
                      {uploading ? "Uploading..." : "📁 Upload"}
                      <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => handleImageUpload(e, setFormData, "imageUrl")} disabled={uploading} />
                    </label>
                  </div>
                  {formData.imageUrl && (
                    <div className="mt-2 h-32 w-full rounded-lg overflow-hidden bg-gray-200">
                      <img src={formData.imageUrl} alt="Preview" className="w-full h-full object-cover" />
                    </div>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                  <input type="date" name="date" value={formData.date} onChange={handleInputChange} className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none" />
                </div>
                <div className="flex gap-3 pt-4">
                  <button type="submit" disabled={loading || uploading} className={`flex-1 py-3 rounded-lg font-semibold text-white transition ${loading || uploading ? "bg-gray-400 cursor-not-allowed" : "bg-blue-700 hover:bg-blue-800"}`}>
                    {loading ? "Saving..." : editingItem ? "Update Image" : "Add Image"}
                  </button>
                  <button type="button" onClick={() => { setShowModal(false); setEditingItem(null); }} className="px-6 py-3 rounded-lg font-semibold text-gray-700 bg-gray-200 hover:bg-gray-300 transition">Cancel</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {showAlbumModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 sm:p-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800">
                  {editingAlbum ? "✏️ Edit Album" : "📁 Create Album"}
                </h2>
                <button onClick={() => { setShowAlbumModal(false); setEditingAlbum(null); }} className="text-gray-500 hover:text-gray-700 text-2xl">×</button>
              </div>
              <form onSubmit={handleAlbumSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Album Name *</label>
                  <input type="text" name="name" value={albumForm.name} onChange={handleAlbumInputChange} required className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Enter album name" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <textarea name="description" value={albumForm.description} onChange={handleAlbumInputChange} rows="3" className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Album description" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Cover Image</label>
                  <div className="flex gap-3">
                    <input type="text" name="coverImage" value={albumForm.coverImage} onChange={handleAlbumInputChange} className="flex-1 border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Cover image URL" />
                    <label className="bg-gray-200 hover:bg-gray-300 px-4 py-3 rounded-lg cursor-pointer transition">
                      {uploading ? "Uploading..." : "📁 Upload"}
                      <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, setAlbumForm, "coverImage")} disabled={uploading} />
                    </label>
                  </div>
                  {albumForm.coverImage && (
                    <div className="mt-2 h-32 w-full rounded-lg overflow-hidden bg-gray-200">
                      <img src={albumForm.coverImage} alt="Preview" className="w-full h-full object-cover" />
                    </div>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                  <input type="date" name="date" value={albumForm.date} onChange={handleAlbumInputChange} className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none" />
                </div>
                <div className="flex items-center gap-2">
                  <input type="checkbox" name="featured" checked={albumForm.featured} onChange={handleAlbumInputChange} className="w-4 h-4 text-blue-600" />
                  <label className="text-sm text-gray-700">⭐ Featured Album</label>
                </div>
                <div className="flex gap-3 pt-4">
                  <button type="submit" disabled={loading || uploading} className={`flex-1 py-3 rounded-lg font-semibold text-white transition ${loading || uploading ? "bg-gray-400 cursor-not-allowed" : "bg-purple-700 hover:bg-purple-800"}`}>
                    {loading ? "Saving..." : editingAlbum ? "Update Album" : "Create Album"}
                  </button>
                  <button type="button" onClick={() => { setShowAlbumModal(false); setEditingAlbum(null); }} className="px-6 py-3 rounded-lg font-semibold text-gray-700 bg-gray-200 hover:bg-gray-300 transition">Cancel</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}