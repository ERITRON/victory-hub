// src/pages/MyDocuments.jsx
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { db, doc, getDoc, collection, query, where, getDocs } from "../../supabase/supabase";
import { useAuth } from "../../context/AuthContext";
import { useParentChildren } from "../../hooks/useParentChildren";
import Icon from "../../components/Icon";
import SEO from "../../components/SEO";

const CATEGORY_LABELS = {
  report_card: "Report Card",
  certificate: "Certificate",
  other: "Document",
};

const snapshotData = (snapshot) => snapshot.docs.map((item) => ({ id: item.id, ...item.data() }));

function DocumentCard({ document }) {
  return (
    <div className="flex items-center justify-between rounded-lg border border-slate-200 bg-white p-4">
      <div className="min-w-0">
        <p className="text-xs font-semibold uppercase text-blue-600">{CATEGORY_LABELS[document.category] || document.category}</p>
        <p className="mt-0.5 truncate text-sm font-semibold text-slate-800">{document.title}</p>
        <p className="mt-0.5 text-xs text-slate-500">{document.createdAt ? new Date(document.createdAt).toLocaleDateString() : ""}</p>
      </div>
      <a
        href={document.fileUrl}
        target="_blank"
        rel="noopener noreferrer"
        download
        className="inline-flex shrink-0 items-center gap-2 rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-800"
      >
        <Icon name="download" />Download
      </a>
    </div>
  );
}

export default function MyDocuments() {
  const { user, role } = useAuth();
  const navigate = useNavigate();
  const isParent = role === "parent";
  const { children, loading: childrenLoading } = useParentChildren(isParent ? user?.uid : null);

  const [ownDocuments, setOwnDocuments] = useState([]);
  const [childDocuments, setChildDocuments] = useState({}); // { studentRowId: [...] }
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!user) return;
    let active = true;

    async function load() {
      setLoading(true);
      setError("");
      try {
        if (isParent) {
          const entries = await Promise.all(
            children.map(async (child) => {
              const snapshot = await getDocs(query(collection(db, "studentDocuments"), where("studentId", "==", child.id)));
              return [child.id, snapshotData(snapshot)];
            })
          );
          if (active) setChildDocuments(Object.fromEntries(entries));
        } else {
          const studentDoc = await getDoc(doc(db, "students", user.uid));
          if (!studentDoc.exists()) {
            if (active) setOwnDocuments([]);
            return;
          }
          const snapshot = await getDocs(query(collection(db, "studentDocuments"), where("studentId", "==", studentDoc.id)));
          if (active) setOwnDocuments(snapshotData(snapshot));
        }
      } catch (loadError) {
        console.error("Unable to load documents", loadError);
        if (active) setError("Documents could not be loaded. Please try again.");
      } finally {
        if (active) setLoading(false);
      }
    }

    if (!isParent || !childrenLoading) load();
    return () => { active = false; };
  }, [user, isParent, childrenLoading, children]);

  const isLoading = loading || (isParent && childrenLoading);

  return (
    <>
      <SEO title="My Documents" noindex />
      <main className="min-h-screen bg-slate-50 px-4 py-8">
        <div className="mx-auto max-w-4xl">
          <div className="mb-7 flex items-center gap-4">
            <button type="button" onClick={() => navigate(-1)} className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-700">Back</button>
            <div>
              <h1 className="text-2xl font-bold text-slate-900 sm:text-3xl">My Documents</h1>
              <p className="mt-1 text-sm text-slate-500">
                {isParent ? "Report cards, certificates, and other documents for your children." : "Your report cards, certificates, and other documents."}
              </p>
            </div>
          </div>

          {error && <div className="mb-5 rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">{error}</div>}

          {isLoading ? (
            <div className="rounded-xl border border-slate-200 bg-white p-12 text-center text-slate-500">Loading…</div>
          ) : isParent ? (
            children.length === 0 ? (
              <div className="rounded-xl border border-slate-200 bg-white p-12 text-center text-slate-600">No children are linked to this account.</div>
            ) : (
              <div className="space-y-6">
                {children.map((child) => {
                  const docs = childDocuments[child.id] || [];
                  return (
                    <div key={child.id}>
                      <h2 className="mb-3 text-sm font-bold text-slate-900">{child.firstName} {child.fatherName} <span className="font-normal text-slate-500">— {child.grade} / Section {child.section}</span></h2>
                      {docs.length === 0 ? (
                        <p className="rounded-lg border border-dashed border-slate-300 bg-white p-4 text-sm text-slate-500">No documents uploaded yet.</p>
                      ) : (
                        <div className="space-y-3">{docs.map((d) => <DocumentCard key={d.id} document={d} />)}</div>
                      )}
                    </div>
                  );
                })}
              </div>
            )
          ) : ownDocuments.length === 0 ? (
            <div className="rounded-xl border border-slate-200 bg-white p-12 text-center text-slate-600">No documents have been uploaded for you yet.</div>
          ) : (
            <div className="space-y-3">{ownDocuments.map((d) => <DocumentCard key={d.id} document={d} />)}</div>
          )}
        </div>
      </main>
    </>
  );
}
