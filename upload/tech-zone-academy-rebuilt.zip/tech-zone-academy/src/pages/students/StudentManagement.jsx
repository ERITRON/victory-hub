// src/pages/students/StudentManagement.jsx
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "../../supabase/supabaseClient";
import { getCollectionCount } from "../../services/statsService";

export default function StudentManagement() {
 const navigate = useNavigate();
 const [stats, setStats] = useState({
   totalStudents: 0,
   totalGrades: 0,
   totalSections: 0,
   totalBoys: 0,
   totalGirls: 0,
 });
 const [loading, setLoading] = useState(true);

 const fetchStats = async () => {
   try {
     // Get students count
     const totalStudents = await getCollectionCount('students');
     
     // Get grades count
     const { count: totalGrades, error: gradesError } = await supabase
       .from('grades')
       .select('*', { count: 'exact', head: true });
     
     // Get sections count
     const { count: totalSections, error: sectionsError } = await supabase
       .from('sections')
       .select('*', { count: 'exact', head: true });
     
     // Get gender breakdown
     const { data: students, error: studentsError } = await supabase
       .from('students')
       .select('gender');
     
     let boys = 0;
     let girls = 0;
     if (students) {
       students.forEach(student => {
         if (student.gender === 'Male') boys++;
         else if (student.gender === 'Female') girls++;
       });
     }

     setStats({
       totalStudents: totalStudents || 0,
       totalGrades: totalGrades || 0,
       totalSections: totalSections || 0,
       totalBoys: boys,
       totalGirls: girls,
     });
   } catch (error) {
     console.error("Error fetching stats:", error);
   } finally {
     setLoading(false);
   }
 };

 useEffect(() => {
   fetchStats();
 }, []);

 const menuItems = [
   {
     icon: "➕",
     title: "Add Student",
     description: "Create a new student account",
     route: "/add-student",
     color: "bg-blue-50 hover:bg-blue-100 border-blue-200",
     iconColor: "text-blue-700",
   },
   {
     icon: "📋",
     title: "Students List",
     description: "View, Edit and Delete students",
     route: "/student-list",
     color: "bg-green-50 hover:bg-green-100 border-green-200",
     iconColor: "text-green-700",
   },
   {
     icon: "📊",
     title: "Student Reports",
     description: "Generate and view student reports",
     route: "/student-reports",
     color: "bg-purple-50 hover:bg-purple-100 border-purple-200",
     iconColor: "text-purple-700",
   },
   {
     icon: "📈",
     title: "Performance Analysis",
     description: "Analyze student performance trends",
     route: "/performance-analysis",
     color: "bg-orange-50 hover:bg-orange-100 border-orange-200",
     iconColor: "text-orange-700",
   },
   {
     icon: "⚙️",
     title: "Grade Management",
     description: "Manage grades and sections",
     route: "/settings",
     color: "bg-red-50 hover:bg-red-100 border-red-200",
     iconColor: "text-red-700",
   },
 ];

 if (loading) {
   return (
     <div className="min-h-screen flex items-center justify-center bg-gray-50">
       <div className="text-center">
         <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
         <p className="mt-4 text-gray-600">Loading statistics...</p>
       </div>
     </div>
   );
 }

 return (
   <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
     <div className="max-w-7xl mx-auto">
       {/* Header */}
       <div className="mb-8">
         <div>
           <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
             👨‍🎓 Student Management
           </h1>
           <p className="text-gray-600 mt-1">
             Manage students, view records, and analyze performance
           </p>
         </div>
       </div>
       
       {/* Stats Cards */}
       <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 mb-8">
         <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-blue-500">
           <div className="text-2xl font-bold text-blue-700">{stats.totalStudents}</div>
           <div className="text-xs sm:text-sm text-gray-600">Total Students</div>
         </div>
         <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-green-500">
           <div className="text-2xl font-bold text-green-700">{stats.totalGrades}</div>
           <div className="text-xs sm:text-sm text-gray-600">Grades</div>
         </div>
         <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-purple-500">
           <div className="text-2xl font-bold text-purple-700">{stats.totalSections}</div>
           <div className="text-xs sm:text-sm text-gray-600">Sections</div>
         </div>
         <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-blue-500">
           <div className="text-2xl font-bold text-blue-600">{stats.totalBoys}</div>
           <div className="text-xs sm:text-sm text-gray-600">Boys</div>
         </div>
         <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-pink-500">
           <div className="text-2xl font-bold text-pink-600">{stats.totalGirls}</div>
           <div className="text-xs sm:text-sm text-gray-600">Girls</div>
         </div>
       </div>
       
       {/* Quick Actions */}
       <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
         <button
           onClick={() => navigate("/add-student")}
           className="bg-blue-700 text-white px-4 py-3 rounded-lg hover:bg-blue-800 transition text-sm font-medium"
         >
           ➕ Add Student
         </button>
         <button
           onClick={() => navigate("/student-list")}
           className="bg-green-700 text-white px-4 py-3 rounded-lg hover:bg-green-800 transition text-sm font-medium"
         >
           📋 View All Students
         </button>
         <button
           onClick={() => navigate("/student-reports")}
           className="bg-purple-700 text-white px-4 py-3 rounded-lg hover:bg-purple-800 transition text-sm font-medium"
         >
           📊 Reports
         </button>
         <button
           onClick={() => navigate("/settings")}
           className="bg-gray-700 text-white px-4 py-3 rounded-lg hover:bg-gray-800 transition text-sm font-medium"
         >
           ⚙ Settings
         </button>
       </div>
       
       {/* Menu Grid */}
       <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
         {menuItems.map((item, index) => (
           <div
             key={index}
             onClick={() => navigate(item.route)}
             className={`
               ${item.color}
               border-2
               rounded-xl
               p-6
               cursor-pointer
               transition-all
               duration-300
               hover:shadow-xl
               hover:-translate-y-1
               hover:border-opacity-100
             `}
           >
             <div className="flex items-start gap-4">
               <div className={`text-4xl ${item.iconColor}`}>
                 {item.icon}
               </div>
               <div className="flex-1">
                 <h3 className="text-lg font-bold text-gray-800">
                   {item.title}
                 </h3>
                 <p className="text-sm text-gray-600 mt-1">
                   {item.description}
                 </p>
               </div>
             </div>
             <div className="mt-3 flex justify-end">
               <span className="text-sm text-gray-400">→</span>
             </div>
           </div>
         ))}
       </div>
       
       {/* Quick Tips */}
       <div className="mt-8 bg-white rounded-xl shadow-md p-6">
         <h3 className="text-lg font-bold text-gray-800 mb-3">💡 Quick Tips</h3>
         <ul className="space-y-2 text-sm text-gray-600">
           <li className="flex items-start gap-2">
             <span className="text-blue-600">•</span>
             Use "Add Student" to enroll new students
           </li>
           <li className="flex items-start gap-2">
             <span className="text-blue-600">•</span>
             View all students and manage their records
           </li>
           <li className="flex items-start gap-2">
             <span className="text-blue-600">•</span>
             Generate reports to track student performance
           </li>
           <li className="flex items-start gap-2">
             <span className="text-blue-600">•</span>
             Manage grades and sections in Settings
           </li>
         </ul>
       </div>
     </div>
   </div>
 );
}