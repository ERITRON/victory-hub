import { useEffect, useMemo, useState } from "react";
import { collection, doc, getDoc, getDocs, query, where, addDoc, ref, storage, uploadBytes, getDownloadURL } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { db } from "../../supabase/supabase";
import Icon from "../../components/Icon";
import SEO from "../../components/SEO";
import {
  assignmentDueDate,
  assignmentMatchesStudent,
  firstValue,
  isSubmitted,
  studentId,
} from "../dashboardUtils";

const MAX_SUBMISSION_SIZE = 15 * 1024 * 1024; // 15MB

const snapshotData = (snapshot) => snapshot.docs.map((item) => ({ id: item.id, ...item.data() }));

const descriptionParagraphs = (description) => String(description || "")
  .split(/\r?\n+|(?<=[.!?])\s+/)
  .map((part) => part.trim())
  .filter(Boolean);

const fileName = (assignment) => {
  const storedName = firstValue(assignment, ["fileName", "filename", "attachmentName"]);
  if (storedName) return String(storedName);
  if (!assignment.fileUrl) return "";
  try {
    const pathName = new URL(assignment.fileUrl).pathname.split("/").filter(Boolean).pop();
    return pathName ? decodeURIComponent(pathName) : "Attached file";
  } catch {
    return "Attached file";
  }
};

const fileSize = (assignment) => {
  const value = firstValue(assignment, ["fileSize", "size", "attachmentSize"], null);
  if (value === null) return "";
  const bytes = Number(value);
  if (!Number.isFinite(bytes)) return String(value);
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
};

const assignmentStatus = (assignment, submitted) => {
  if (submitted) return { label: "Completed", style: "bg-emerald-100 text-emerald-700" };
  const due = assignmentDueDate(assignment);
  if (!due) return { label: "Upcoming", style: "bg-blue-100 text-blue-700" };
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const dueDay = new Date(due);
  dueDay.setHours(0, 0, 0, 0);
  const days = Math.ceil((dueDay - today) / 86400000);
  if (days < 0) return { label: "Overdue", style: "bg-rose-100 text-rose-700" };
  if (days <= 2) return { label: "Due Soon", style: "bg-amber-100 text-amber-700" };
  return { label: "Upcoming", style: "bg-blue-100 text-blue-700" };
};

export default function StudentAssignments() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [student, setStudent] = useState(null);
  const [assignments, setAssignments] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectedAssignment, setSelectedAssignment] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");

  const reloadSubmissions = async () => {
    const submissionSnapshot = await getDocs(collection(db, "assignmentSubmissions")).catch(() => null);
    setSubmissions(submissionSnapshot ? snapshotData(submissionSnapshot) : []);
  };

  const handleSubmissionUpload = async (assignment, file) => {
    if (!file || !student) return;
    if (file.size > MAX_SUBMISSION_SIZE) {
      setSubmitError("File must be under 15MB.");
      return;
    }
    setSubmitting(true);
    setSubmitError("");
    try {
      const uniqueName = `${Date.now()}-${file.name}`;
      const storageRef = ref(storage, `assignment-submissions/${user.uid}/${uniqueName}`);
      const snapshot = await uploadBytes(storageRef, file);
      const fileUrl = await getDownloadURL(snapshot.ref);

      await addDoc(collection(db, "assignmentSubmissions"), {
        assignmentId: assignment.id,
        studentId: studentId(student),
        studentName: `${student.firstName || ""} ${student.fatherName || ""}`.trim(),
        submissionDate: new Date().toISOString(),
        fileUrl,
        fileName: file.name,
        fileSize: file.size,
        filePath: storageRef.path,
        status: "submitted",
      });

      await reloadSubmissions();
    } catch (uploadError) {
      setSubmitError(uploadError.message || "Upload failed. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  useEffect(() => {
    if (!user) return;
    let active = true;

    async function loadAssignments() {
      setLoading(true);
      setError("");
      try {
        const directStudent = await getDoc(doc(db, "students", user.uid));
        let currentStudent = directStudent.exists() ? { id: directStudent.id, ...directStudent.data() } : null;
        if (!currentStudent) {
          const studentSnapshot = await getDocs(query(collection(db, "students"), where("studentId", "==", user.uid)));
          currentStudent = snapshotData(studentSnapshot)[0] || null;
        }
        if (!currentStudent) {
          if (active) setStudent(null);
          return;
        }
        const [assignmentSnapshot, submissionSnapshot] = await Promise.all([
          getDocs(collection(db, "teacherAssignmentsUploads")),
          getDocs(collection(db, "assignmentSubmissions")).catch(() => null),
        ]);
        if (active) {
          setStudent(currentStudent);
          setAssignments(snapshotData(assignmentSnapshot).filter((item) => assignmentMatchesStudent(item, currentStudent)));
          setSubmissions(submissionSnapshot ? snapshotData(submissionSnapshot) : []);
        }
      } catch (loadError) {
        console.error("Unable to load student assignments", loadError);
        if (active) setError("Assignments could not be loaded. Please try again.");
      } finally {
        if (active) setLoading(false);
      }
    }

    loadAssignments();
    return () => { active = false; };
  }, [user]);

  const sortedAssignments = useMemo(() => [...assignments].sort((a, b) => {
    const firstDue = assignmentDueDate(a);
    const secondDue = assignmentDueDate(b);
    if (!firstDue && !secondDue) return String(a.title || "").localeCompare(String(b.title || ""));
    if (!firstDue) return 1;
    if (!secondDue) return -1;
    return firstDue - secondDue;
  }), [assignments]);

  useEffect(() => {
    if (!selectedAssignment) return undefined;
    const handleKeyDown = (event) => {
      if (event.key === "Escape") setSelectedAssignment(null);
    };
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [selectedAssignment]);

  if (loading) return <main className="min-h-screen bg-slate-50 px-4 py-8"><div className="mx-auto max-w-6xl"><div className="h-10 w-64 animate-pulse rounded bg-slate-200" /><div className="mt-8 grid gap-5 md:grid-cols-2">{[1, 2, 3, 4].map((item) => <div key={item} className="h-64 animate-pulse rounded-xl bg-slate-200" />)}</div></div></main>;

  return <>
    <SEO title="Student Assignments" noindex />
    <main className="min-h-screen bg-slate-50 px-4 py-8">
      <div className="mx-auto max-w-6xl">
        <div className="mb-7 flex flex-col items-start gap-3 sm:flex-row sm:items-center sm:gap-4"><button type="button" onClick={() => navigate(-1)} className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-700">Back</button><div className="min-w-0"><h1 className="break-words text-2xl font-bold text-slate-900 sm:text-3xl">My Assignments</h1><p className="mt-1 break-words text-sm text-slate-500">{student ? `${student.grade || "Grade not set"} / Section ${student.section || "not set"}` : "Student profile not found"}</p></div></div>
        {error && <div className="mb-5 rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">{error}</div>}
        {!student ? <div className="rounded-xl border border-slate-200 bg-white p-12 text-center text-slate-600">No student profile is linked to this account.</div> : !sortedAssignments.length ? <div className="rounded-xl border border-slate-200 bg-white p-12 text-center"><h2 className="font-bold text-slate-800">No assignments found</h2><p className="mt-2 text-sm text-slate-500">No assignments have been uploaded for your grade and section.</p></div> : <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{sortedAssignments.map((assignment) => {
          const submitted = submissions.some((item) => isSubmitted(item, assignment, student));
          const status = assignmentStatus(assignment, submitted);
          const due = assignmentDueDate(assignment);
          return <button type="button" key={assignment.id} onClick={() => setSelectedAssignment(assignment)} className="flex min-h-56 w-full flex-col rounded-xl border border-slate-200 bg-white p-5 text-left shadow-sm transition hover:-translate-y-0.5 hover:border-blue-300 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
            <div className="flex w-full items-start justify-between gap-3"><div className="min-w-0"><p className="text-xs font-semibold uppercase text-blue-600">{assignment.subject || "Subject not set"}</p><h2 className="mt-1 break-words text-lg font-bold text-slate-900">{assignment.title || "Untitled assignment"}</h2></div><span className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold ${status.style}`}>{status.label}</span></div>
            <p className="mt-3 line-clamp-3 break-words text-sm leading-6 text-slate-600">{assignment.description || "No description provided."}</p>
            <div className="mt-auto grid w-full grid-cols-2 gap-3 border-t border-slate-100 pt-4 text-sm"><div><p className="text-xs text-slate-500">Due date</p><p className="mt-0.5 font-semibold text-slate-800">{due ? due.toLocaleDateString() : "Not set"}</p></div><div><p className="text-xs text-slate-500">Type</p><p className="mt-0.5 font-semibold capitalize text-slate-800">{assignment.type || "Assignment"}</p></div></div>
            <span className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-blue-700">View details <span aria-hidden="true">&rarr;</span></span>
          </button>;
        })}</div>}
      </div>
    </main>

    {selectedAssignment && (() => {
      const submitted = submissions.some((item) => isSubmitted(item, selectedAssignment, student));
      const status = assignmentStatus(selectedAssignment, submitted);
      const due = assignmentDueDate(selectedAssignment);
      const paragraphs = descriptionParagraphs(selectedAssignment.description);
      return <div className="fixed inset-0 z-50 flex items-end bg-slate-950/60 sm:items-center sm:justify-center sm:p-4" onMouseDown={(event) => { if (event.target === event.currentTarget) setSelectedAssignment(null); }}>
        <section role="dialog" aria-modal="true" aria-labelledby="assignment-detail-title" className="flex max-h-[100dvh] w-full flex-col overflow-hidden bg-white shadow-2xl sm:max-h-[calc(100dvh-2rem)] sm:max-w-3xl sm:rounded-xl">
          <header className="flex shrink-0 items-start justify-between gap-4 border-b border-slate-200 px-4 py-4 sm:px-6">
            <div className="min-w-0"><p className="text-xs font-semibold uppercase text-blue-600">{selectedAssignment.subject || "Subject not set"}</p><h2 id="assignment-detail-title" className="mt-1 break-words text-xl font-bold text-slate-900 sm:text-2xl">{selectedAssignment.title || "Untitled assignment"}</h2></div>
            <button type="button" onClick={() => setSelectedAssignment(null)} className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-800" aria-label="Close assignment details"><Icon name="close" /></button>
          </header>

          <div className="min-h-0 flex-1 overflow-y-auto px-4 py-5 sm:px-6 sm:py-6">
            <div className="flex flex-wrap items-center gap-2"><span className={`rounded-full px-3 py-1 text-xs font-semibold ${status.style}`}>{status.label}</span><span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold capitalize text-slate-700">{selectedAssignment.type || "Assignment"}</span></div>

            <div className="mt-6"><h3 className="text-sm font-bold text-slate-900">Description</h3><div className="mt-2 space-y-3 break-words text-sm leading-7 text-slate-600 sm:text-base">{paragraphs.length ? paragraphs.map((paragraph, index) => <p key={`${selectedAssignment.id}-detail-${index}`}>{paragraph}</p>) : <p>No description provided.</p>}</div></div>

            <dl className="mt-6 grid grid-cols-1 gap-4 border-y border-slate-200 py-5 min-[420px]:grid-cols-2 sm:grid-cols-4">
              <div><dt className="text-xs text-slate-500">Class</dt><dd className="mt-1 break-words text-sm font-semibold text-slate-800">{selectedAssignment.grade || "-"} / {selectedAssignment.section || "-"}</dd></div>
              <div><dt className="text-xs text-slate-500">Due date</dt><dd className="mt-1 break-words text-sm font-semibold text-slate-800">{due ? due.toLocaleDateString() : "Not set"}</dd></div>
              <div><dt className="text-xs text-slate-500">Teacher</dt><dd className="mt-1 break-words text-sm font-semibold text-slate-800">{selectedAssignment.teacherName || "Not set"}</dd></div>
              <div><dt className="text-xs text-slate-500">Submission</dt><dd className="mt-1 break-words text-sm font-semibold text-slate-800">{submitted ? "Submitted" : "Not submitted"}</dd></div>
            </dl>

            <div className="mt-6"><h3 className="text-sm font-bold text-slate-900">Attachment</h3>{selectedAssignment.fileUrl ? <div className="mt-2 flex min-w-0 flex-col gap-3 rounded-lg border border-slate-200 bg-slate-50 p-4 sm:flex-row sm:items-center sm:justify-between"><div className="min-w-0"><p className="break-all text-sm font-semibold text-slate-800">{fileName(selectedAssignment)}</p>{fileSize(selectedAssignment) && <p className="mt-1 text-xs text-slate-500">{fileSize(selectedAssignment)}</p>}</div><a href={selectedAssignment.fileUrl} target="_blank" rel="noopener noreferrer" download className="inline-flex shrink-0 items-center justify-center gap-2 rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-800"><Icon name="download" />Download</a></div> : <p className="mt-2 rounded-lg bg-slate-50 p-4 text-sm text-slate-500">No file attached.</p>}</div>

            <div className="mt-6">
              <h3 className="text-sm font-bold text-slate-900">Your Submission</h3>
              {(() => {
                const mySubmission = submissions.find((item) => isSubmitted(item, selectedAssignment, student));
                return mySubmission ? (
                  <div className="mt-2 flex min-w-0 flex-col gap-3 rounded-lg border border-emerald-200 bg-emerald-50 p-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="min-w-0">
                      <p className="break-all text-sm font-semibold text-emerald-800">{mySubmission.fileName || "Submitted file"}</p>
                      <p className="mt-1 text-xs text-emerald-700">Submitted {mySubmission.submissionDate ? new Date(mySubmission.submissionDate).toLocaleString() : ""}</p>
                    </div>
                    {mySubmission.fileUrl && (
                      <a href={mySubmission.fileUrl} target="_blank" rel="noopener noreferrer" download className="inline-flex shrink-0 items-center justify-center gap-2 rounded-lg border border-emerald-300 bg-white px-4 py-2.5 text-sm font-semibold text-emerald-800 hover:bg-emerald-100"><Icon name="download" />View submitted file</a>
                    )}
                  </div>
                ) : (
                  <div className="mt-2 rounded-lg border border-dashed border-slate-300 bg-slate-50 p-4">
                    <label className="flex cursor-pointer flex-col items-center justify-center gap-2 text-center">
                      <span className="text-sm font-semibold text-blue-700">{submitting ? "Uploading…" : "Click to upload your work"}</span>
                      <span className="text-xs text-slate-500">PDF, image, or document, up to 15MB</span>
                      <input
                        type="file"
                        className="hidden"
                        disabled={submitting}
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          e.target.value = "";
                          if (file) handleSubmissionUpload(selectedAssignment, file);
                        }}
                      />
                    </label>
                  </div>
                );
              })()}
              {submitError && <p className="mt-2 text-sm text-rose-600">{submitError}</p>}
            </div>
          </div>

          <footer className="shrink-0 border-t border-slate-200 bg-white px-4 py-3 sm:px-6"><button type="button" onClick={() => setSelectedAssignment(null)} className="w-full rounded-lg border border-slate-300 px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 sm:ml-auto sm:block sm:w-auto">Close</button></footer>
        </section>
      </div>;
    })()}
  </>;
}
