import { useEffect, useMemo, useState } from "react";
import { collection, doc, getDoc, getDocs, query, where } from "../../supabase/supabase";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { db } from "../../supabase/supabase";
import DashboardShell from "../../components/dashboard/DashboardShell";
import { SkeletonDashboard } from "../../components/LoadingSkeleton";
import SEO from "../../components/SEO";
import {
  assignmentDueDate,
  assignmentMatchesStudent,
  attendanceSummary,
  firstValue,
  formatPercent,
  recordDate,
  resultPercentage,
  studentId,
  studentName,
} from "../dashboardUtils";

const snapshotData = (snapshot) => snapshot.docs.map((item) => ({ id: item.id, ...item.data() }));

const resultDate = (result) => recordDate(result) || new Date(0);

export default function StudentDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [student, setStudent] = useState(null);
  const [results, setResults] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!user) return;
    let active = true;

    async function loadDashboard() {
      setLoading(true);
      setError("");
      try {
        const directStudent = await getDoc(doc(db, "students", user.uid));
        let currentStudent = directStudent.exists()
          ? { id: directStudent.id, ...directStudent.data() }
          : null;

        if (!currentStudent) {
          const studentSnapshot = await getDocs(
            query(collection(db, "students"), where("studentId", "==", user.uid)),
          );
          currentStudent = snapshotData(studentSnapshot)[0] || null;
        }

        if (!currentStudent) {
          if (active) setStudent(null);
          return;
        }

        const [resultsSnapshot, attendanceSnapshot, assignmentsSnapshot] = await Promise.all([
          getDocs(collection(db, "results")),
          getDocs(collection(db, "attendance")),
          getDocs(collection(db, "teacherAssignmentsUploads")),
        ]);
        const identifiers = new Set([String(currentStudent.id), studentId(currentStudent)]);

        if (active) {
          setStudent(currentStudent);
          setResults(snapshotData(resultsSnapshot).filter((item) => identifiers.has(String(item.studentId))));
          setAttendance(snapshotData(attendanceSnapshot).filter((item) => identifiers.has(String(item.studentId))));
          setAssignments(snapshotData(assignmentsSnapshot).filter((item) => assignmentMatchesStudent(item, currentStudent)));
        }
      } catch (loadError) {
        console.error("Unable to load student dashboard", loadError);
        if (active) setError("The dashboard data could not be loaded. Please try again.");
      } finally {
        if (active) setLoading(false);
      }
    }

    loadDashboard();
    return () => { active = false; };
  }, [user]);

  const validResults = useMemo(
    () => results.map((item) => ({ ...item, percentage: resultPercentage(item) })).filter((item) => item.percentage !== null),
    [results],
  );
  const averageScore = validResults.length
    ? validResults.reduce((sum, item) => sum + item.percentage, 0) / validResults.length
    : null;
  const attendanceStats = useMemo(() => attendanceSummary(attendance), [attendance]);
  const recentResults = useMemo(
    () => [...results].sort((a, b) => resultDate(b) - resultDate(a)).slice(0, 5),
    [results],
  );
  const upcomingAssignments = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return assignments
      .filter((item) => {
        const due = assignmentDueDate(item);
        return due && due >= today;
      })
      .sort((a, b) => assignmentDueDate(a) - assignmentDueDate(b))
      .slice(0, 5);
  }, [assignments]);
  const trend = useMemo(() => {
    const chronological = [...validResults].sort((a, b) => resultDate(a) - resultDate(b));
    if (chronological.length < 2) return { label: "Not enough data", style: "bg-slate-100 text-slate-700" };
    const splitAt = Math.floor(chronological.length / 2);
    const earlier = chronological.slice(0, splitAt);
    const later = chronological.slice(splitAt);
    const earlierAverage = earlier.reduce((sum, item) => sum + item.percentage, 0) / earlier.length;
    const laterAverage = later.reduce((sum, item) => sum + item.percentage, 0) / later.length;
    if (laterAverage > earlierAverage) return { label: "Improving", style: "bg-emerald-100 text-emerald-700" };
    if (laterAverage < earlierAverage) return { label: "Declining", style: "bg-rose-100 text-rose-700" };
    return { label: "Stable", style: "bg-blue-100 text-blue-700" };
  }, [validResults]);

  const statCards = [
    { label: "Total Results", value: results.length, icon: "result", color: "text-blue-700", bgColor: "bg-blue-50", borderColor: "border-blue-200" },
    { label: "Average Score", value: formatPercent(averageScore), icon: "chart", color: "text-emerald-700", bgColor: "bg-emerald-50", borderColor: "border-emerald-200" },
    { label: "Attendance Rate", value: formatPercent(attendanceStats.rate), icon: "attendance", color: "text-amber-700", bgColor: "bg-amber-50", borderColor: "border-amber-200" },
    { label: "Current Grade", value: student?.grade || "Not set", icon: "grade", color: "text-violet-700", bgColor: "bg-violet-50", borderColor: "border-violet-200" },
  ];

  const dashboardItems = [
    { icon: "result", title: "My Results", description: "View all assessment results", route: "/student-results", color: "bg-emerald-50 hover:bg-emerald-100 border-emerald-200", iconColor: "text-emerald-700" },
    { icon: "assignment", title: "Assignments", description: "View class assignments and files", route: "/student-assignments", color: "bg-violet-50 hover:bg-violet-100 border-violet-200", iconColor: "text-violet-700" },
    { icon: "attendance", title: "Attendance", description: "Review attendance records", route: "/student-attendance", color: "bg-amber-50 hover:bg-amber-100 border-amber-200", iconColor: "text-amber-700" },
    { icon: "calendar", title: "Class Schedule", description: "View the class timetable", route: "/student-schedule", color: "bg-rose-50 hover:bg-rose-100 border-rose-200", iconColor: "text-rose-700" },
    { icon: "download", title: "My Documents", description: "Report cards, certificates, and files", route: "/my-documents", color: "bg-indigo-50 hover:bg-indigo-100 border-indigo-200", iconColor: "text-indigo-700" },
    { icon: "message", title: "Messages", description: "Messaging will be available soon", route: "/student-messages", color: "bg-cyan-50 hover:bg-cyan-100 border-cyan-200", iconColor: "text-cyan-700" },
    { icon: "settings", title: "Security Settings", description: "Update password and security", route: "/profile", color: "bg-slate-50 hover:bg-slate-100 border-slate-200", iconColor: "text-slate-700" },
  ];

  if (loading) return <div className="min-h-screen bg-slate-50 px-4 py-8"><div className="mx-auto max-w-7xl"><SkeletonDashboard /></div></div>;
  if (!student) return <main className="flex min-h-screen items-center justify-center bg-slate-50 px-4"><div className="max-w-md rounded-xl border border-slate-200 bg-white p-8 text-center shadow-sm"><h1 className="text-xl font-bold text-slate-900">No student profile found</h1><p className="mt-2 text-slate-600">Contact the school administrator to link your account.</p><button type="button" onClick={() => navigate("/")} className="mt-5 rounded-lg bg-blue-700 px-5 py-2.5 text-white">Go home</button></div></main>;

  return <>
    <SEO title="Student Dashboard" noindex />
    <DashboardShell icon="dashboard" title="Student Dashboard" welcomeName={studentName(student)} subtitle={`${student.grade || "Grade not set"} / Section ${student.section || "not set"}`} badgeLabel="Student" badgeColor="bg-blue-100 text-blue-700" stats={statCards} statsColumns="grid-cols-2 md:grid-cols-4" menuItems={dashboardItems} footerText="Tech Zone Academy - Student Dashboard">
      {error && <div className="mb-6 rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">{error}</div>}

      <section className="mb-6 grid gap-6 lg:grid-cols-[1fr_1.5fr]">
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="flex items-start justify-between gap-3"><div><p className="text-xs font-semibold uppercase text-blue-600">Student information</p><h2 className="mt-1 text-xl font-bold text-slate-900">{studentName(student)}</h2></div><span className={`rounded-full px-3 py-1 text-xs font-semibold ${trend.style}`}>{trend.label}</span></div>
          <dl className="mt-5 grid grid-cols-2 gap-4 text-sm">
            {[["Student ID", studentId(student) || "Not set"], ["Grade", student.grade || "Not set"], ["Section", student.section || "Not set"], ["Gender", student.gender || "Not set"]].map(([label, value]) => <div key={label}><dt className="text-slate-500">{label}</dt><dd className="mt-1 font-semibold text-slate-800">{value}</dd></div>)}
          </dl>
          <div className="mt-5 border-t border-slate-100 pt-4"><span className={`rounded-full px-3 py-1 text-xs font-semibold ${attendanceStats.rate === null ? "bg-slate-100 text-slate-700" : attendanceStats.rate >= 75 ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"}`}>Attendance: {formatPercent(attendanceStats.rate)}</span><p className="mt-2 text-xs text-slate-500">{attendanceStats.present} present from {attendanceStats.total} records</p></div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4"><h2 className="font-bold text-slate-900">Recent Results</h2><Link to="/student-results" className="text-sm font-semibold text-blue-700">View all</Link></div>
          {!recentResults.length ? <p className="p-8 text-center text-sm text-slate-500">No results have been recorded.</p> : <div className="divide-y divide-slate-100">{recentResults.map((result) => { const percentage = resultPercentage(result); return <div key={result.id} className="grid gap-2 px-5 py-4 sm:grid-cols-[1fr_auto] sm:items-center"><div><p className="font-semibold text-slate-800">{result.subject || "Subject not set"}</p><p className="text-xs text-slate-500">{firstValue(result, ["assessmentName", "assessment", "examName", "type"], "Assessment")}</p></div><div className="sm:text-right"><p className="font-semibold text-slate-800">{firstValue(result, ["score", "marks", "marksObtained"], "-")} / {firstValue(result, ["outOf", "maxScore", "totalMarks", "maxMarks"], "-")}</p><p className="text-xs text-slate-500">{formatPercent(percentage)}</p></div></div>; })}</div>}
        </div>
      </section>

      <section className="mb-8 rounded-xl border border-slate-200 bg-white shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4"><h2 className="font-bold text-slate-900">Upcoming Assignments</h2><Link to="/student-assignments" className="text-sm font-semibold text-blue-700">View all</Link></div>
        {!upcomingAssignments.length ? <p className="p-8 text-center text-sm text-slate-500">No upcoming assignments with a due date.</p> : <div className="grid gap-3 p-4 md:grid-cols-2 xl:grid-cols-3">{upcomingAssignments.map((assignment) => <div key={assignment.id} className="rounded-lg border border-slate-200 p-4"><p className="text-xs font-semibold uppercase text-violet-600">{assignment.subject || "Subject not set"}</p><h3 className="mt-1 font-bold text-slate-900">{assignment.title || "Untitled assignment"}</h3><p className="mt-3 text-sm text-slate-500">Due {assignmentDueDate(assignment).toLocaleDateString()}</p></div>)}</div>}
      </section>
    </DashboardShell>
  </>;
}
