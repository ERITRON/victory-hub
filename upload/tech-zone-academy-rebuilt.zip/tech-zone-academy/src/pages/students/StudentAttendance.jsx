// src/pages/StudentAttendance.jsx
import { useAuth } from "../../context/AuthContext";
import { useEffect, useState } from "react";
import { useAttendance } from "../../context/AttendanceContext";
import { db, doc, getDoc, collection, getDocs, query, where } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";

export default function StudentAttendance() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const {
    attendanceData,
    setAttendanceData,
    loading,
    setLoading,
    getAttendanceStatus,
  } = useAttendance();

  const [studentData, setStudentData] = useState(null);
  const [studentAttendance, setStudentAttendance] = useState([]);
  const [summary, setSummary] = useState(null);
  const [viewType, setViewType] = useState("weekly");
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0]);
  const [errorMessage, setErrorMessage] = useState("");

  const fetchStudentData = async () => {
    setLoading(true);
    try {
      // Try to find student by UID first
      let studentDoc = await getDoc(doc(db, "students", user.uid));

      // If not found, try to find by studentId
      if (!studentDoc.exists()) {
        const studentsQuery = query(
          collection(db, "students"),
          where("studentId", "==", user.uid)
        );
        const studentsSnap = await getDocs(studentsQuery);
        if (!studentsSnap.empty) {
          studentsSnap.forEach((doc) => {
            studentDoc = doc;
          });
        }
      }

      if (studentDoc && studentDoc.exists()) {
        const data = studentDoc.data();
        setStudentData(data);

        // Fetch attendance data if not already loaded
        if (attendanceData.length === 0) {
          const attSnap = await getDocs(collection(db, "attendance"));
          const attData = attSnap.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          }));
          setAttendanceData(attData);
        }
      } else {
        setErrorMessage("Student data not found.");
      }
    } catch (error) {
      setErrorMessage("Error loading data: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const updateStudentData = () => {
    if (!studentData) return;

    let records = attendanceData.filter(
      (a) => a.studentId === (studentData.studentId || studentData.id)
    );

    // Apply view type filters
    if (viewType === "daily") {
      records = records.filter((a) => a.date === selectedDate);
    } else if (viewType === "weekly") {
      const date = new Date(selectedDate);
      const start = new Date(date);
      start.setDate(date.getDate() - date.getDay());
      const end = new Date(start);
      end.setDate(start.getDate() + 6);
      records = records.filter((a) => {
        const d = new Date(a.date);
        return d >= start && d <= end;
      });
    } else if (viewType === "monthly") {
      const date = new Date(selectedDate);
      records = records.filter((a) => {
        const d = new Date(a.date);
        return d.getMonth() === date.getMonth() && d.getFullYear() === date.getFullYear();
      });
    } else if (viewType === "yearly") {
      const year = new Date(selectedDate).getFullYear();
      records = records.filter((a) => new Date(a.date).getFullYear() === year);
    }

    // Sort by date (newest first)
    records = records.sort((a, b) => new Date(b.date) - new Date(a.date));

    setStudentAttendance(records);

    // Calculate summary
    const total = records.length;
    const present = records.filter((a) => a.status === "Present").length;
    const absent = records.filter((a) => a.status === "Absent").length;
    const late = records.filter((a) => a.status === "Late").length;
    const excused = records.filter((a) => a.status === "Excused").length;
    const percentage = total > 0 ? Math.round((present / total) * 100) : 0;
    const status = getAttendanceStatus(percentage);

    setSummary({ total, present, absent, late, excused, percentage, status });
  };

  useEffect(() => {
    if (user) {
      fetchStudentData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- re-run only when the authenticated user changes
  }, [user]);

  useEffect(() => {
    if (studentData) {
      updateStudentData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- recompute view when attendance data or filters change; updateStudentData is stable
  }, [attendanceData, studentData, viewType, selectedDate]);

  const getStatusBadge = (status) => {
    const styles = {
      Present: "bg-green-100 text-green-700 border-green-200",
      Absent: "bg-red-100 text-red-700 border-red-200",
      Late: "bg-yellow-100 text-yellow-700 border-yellow-200",
      Excused: "bg-blue-100 text-blue-700 border-blue-200",
    };
    return styles[status] || "bg-gray-100 text-gray-700 border-gray-200";
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case "Present": return "✅";
      case "Absent": return "❌";
      case "Late": return "⏰";
      case "Excused": return "📝";
      default: return "—";
    }
  };

  const getDayName = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", { weekday: "long" });
  };

  const getDateRangeLabel = () => {
    const date = new Date(selectedDate);
    if (viewType === "daily") {
      return date.toLocaleDateString("en-US", { 
        weekday: "long", 
        year: "numeric", 
        month: "long", 
        day: "numeric" 
      });
    } else if (viewType === "weekly") {
      const start = new Date(date);
      start.setDate(date.getDate() - date.getDay());
      const end = new Date(start);
      end.setDate(start.getDate() + 6);
      return `${start.toLocaleDateString()} - ${end.toLocaleDateString()}`;
    } else if (viewType === "monthly") {
      return date.toLocaleDateString("en-US", { month: "long", year: "numeric" });
    } else {
      return date.getFullYear().toString();
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading your attendance...</p>
        </div>
      </div>
    );
  }

  if (!studentData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">📭</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">No Student Data</h2>
          <p className="text-gray-600">Please contact the school administrator.</p>
          <button
            onClick={() => navigate("/student-dashboard")}
            className="mt-4 bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-6 sm:py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <button 
            onClick={() => navigate("/student-dashboard")} 
            className="text-gray-600 hover:text-gray-800 transition"
          >
            ← Back
          </button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              📋 My Attendance
            </h1>
            <p className="text-gray-600 text-sm mt-1">
              {studentData.firstName} {studentData.fatherName}
              <span className="ml-2 text-xs text-gray-400">
                • {getDateRangeLabel()}
              </span>
            </p>
          </div>
          <div className="ml-auto">
            <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
              🎓 Student
            </span>
          </div>
        </div>

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Controls */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">View Type</label>
              <select
                value={viewType}
                onChange={(e) => setViewType(e.target.value)}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none bg-white"
              >
                <option value="daily">📅 Daily</option>
                <option value="weekly">📆 Weekly</option>
                <option value="monthly">📊 Monthly</option>
                <option value="yearly">📈 Yearly</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Date</label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Student Info */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <div className="flex flex-wrap gap-2">
            <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
              📚 {studentData.grade || "N/A"}
            </span>
            <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
              📋 Section {studentData.section || "N/A"}
            </span>
            <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-medium">
              🆔 {studentData.studentId || studentData.id}
            </span>
            <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium">
              📅 {viewType.charAt(0).toUpperCase() + viewType.slice(1)} View
            </span>
          </div>
        </div>

        {/* Summary Cards */}
        {summary && (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 mb-6">
              <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-blue-500">
                <div className="text-xl sm:text-2xl font-bold text-blue-700">{summary.total}</div>
                <div className="text-[10px] sm:text-xs text-gray-600">Total Days</div>
              </div>
              <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-green-500">
                <div className="text-xl sm:text-2xl font-bold text-green-700">{summary.present}</div>
                <div className="text-[10px] sm:text-xs text-gray-600">✅ Present</div>
              </div>
              <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-red-500">
                <div className="text-xl sm:text-2xl font-bold text-red-700">{summary.absent}</div>
                <div className="text-[10px] sm:text-xs text-gray-600">❌ Absent</div>
              </div>
              <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-yellow-500">
                <div className="text-xl sm:text-2xl font-bold text-yellow-700">{summary.late}</div>
                <div className="text-[10px] sm:text-xs text-gray-600">⏰ Late</div>
              </div>
              <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-purple-500">
                <div className="text-xl sm:text-2xl font-bold text-purple-700">{summary.excused}</div>
                <div className="text-[10px] sm:text-xs text-gray-600">📝 Excused</div>
              </div>
              <div className={`bg-white rounded-xl shadow p-4 text-center border-l-4 ${summary.percentage >= 90 ? 'border-green-500' : summary.percentage >= 75 ? 'border-yellow-500' : 'border-red-500'}`}>
                <div className={`text-xl sm:text-2xl font-bold ${summary.percentage >= 90 ? 'text-green-700' : summary.percentage >= 75 ? 'text-yellow-700' : 'text-red-700'}`}>
                  {summary.percentage}%
                </div>
                <div className="text-[10px] sm:text-xs text-gray-600">Attendance Rate</div>
              </div>
            </div>

            {/* Status Card */}
            {summary.total > 0 && (
              <div className="bg-white rounded-xl shadow-md p-4 mb-6 flex items-center gap-3 border-l-4 border-purple-500">
                <div className="text-2xl">{summary.status.icon}</div>
                <div>
                  <div className="font-semibold text-gray-800">Your Attendance Status</div>
                  <div className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${summary.status.color}`}>
                    {summary.status.label}
                  </div>
                  <span className="text-xs text-gray-500 ml-2">
                    ({summary.present} out of {summary.total} days present)
                  </span>
                </div>
              </div>
            )}
          </>
        )}

        {/* Records Table */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="px-4 sm:px-6 py-3 border-b bg-gray-50 flex justify-between items-center">
            <h3 className="text-sm font-semibold text-gray-800">
              📋 Attendance Records ({studentAttendance.length})
            </h3>
            <span className="text-xs text-gray-500">
              {viewType.charAt(0).toUpperCase() + viewType.slice(1)} View
            </span>
          </div>
          {studentAttendance.length === 0 ? (
            <div className="p-12 text-center">
              <div className="text-6xl mb-4">📭</div>
              <h3 className="text-xl font-semibold text-gray-700 mb-2">No Records Found</h3>
              <p className="text-gray-500">
                No attendance records found for this period.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-3 sm:px-4 py-2 text-left text-xs font-semibold text-gray-600">#</th>
                    <th className="px-3 sm:px-4 py-2 text-left text-xs font-semibold text-gray-600">Date</th>
                    <th className="px-3 sm:px-4 py-2 text-left text-xs font-semibold text-gray-600">Day</th>
                    <th className="px-3 sm:px-4 py-2 text-center text-xs font-semibold text-gray-600">Status</th>
                    <th className="px-3 sm:px-4 py-2 text-left text-xs font-semibold text-gray-600">Remark</th>
                  </tr>
                </thead>
                <tbody>
                  {studentAttendance.map((record, index) => (
                    <tr key={record.id || index} className="border-b hover:bg-gray-50 transition">
                      <td className="px-3 sm:px-4 py-2 text-sm text-gray-500">{index + 1}</td>
                      <td className="px-3 sm:px-4 py-2 text-sm text-gray-600">{record.date}</td>
                      <td className="px-3 sm:px-4 py-2 text-sm text-gray-600">
                        {record.day || getDayName(record.date)}
                      </td>
                      <td className="px-3 sm:px-4 py-2 text-center">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusBadge(record.status)}`}>
                          {getStatusIcon(record.status)} {record.status}
                        </span>
                      </td>
                      <td className="px-3 sm:px-4 py-2 text-sm text-gray-500">{record.remark || "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}