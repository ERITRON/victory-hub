// src/pages/StudentResults.jsx
import { useAuth } from "../../context/AuthContext";
import { useEffect, useState } from "react";
import { db, doc, getDoc, collection, query, where, getDocs } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";

export default function StudentResults() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [studentData, setStudentData] = useState(null);
  const [results, setResults] = useState([]);
  const [groupedResults, setGroupedResults] = useState({});
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");
  const [expandedSubject, setExpandedSubject] = useState(null);
  
  // Cumulative scoring
  const [cumulativeData, setCumulativeData] = useState({
    totalScore: 0,
    totalMaxScore: 0,
    overallPercentage: 0,
    subjectAverages: {},
  });

  const fetchStudentData = async () => {
    try {
      // Try to find student by UID first
      let studentDoc = await getDoc(doc(db, "students", user.uid));

      // If not found, try by studentId
      if (!studentDoc.exists()) {
        const q = query(
          collection(db, "students"),
          where("studentId", "==", user.uid)
        );
        const snapshot = await getDocs(q);
        if (!snapshot.empty) {
          snapshot.forEach((doc) => {
            studentDoc = doc;
          });
        }
      }

      if (studentDoc && studentDoc.exists()) {
        const data = studentDoc.data();
        setStudentData(data);
        await fetchResults(data.studentId || user.uid);
      } else {
        setErrorMessage("Student data not found.");
        setLoading(false);
      }
    } catch (error) {
      setErrorMessage("Error loading data: " + error.message);
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchStudentData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- re-run only when the authenticated user changes
  }, [user]);

  async function fetchResults(studentId) {
    try {
      const q = query(
        collection(db, "results"),
        where("studentId", "==", studentId)
      );
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setResults(data);
      
      // Calculate cumulative scores
      let totalScore = 0;
      let totalMaxScore = 0;
      const subjectData = {};
      
      data.forEach((result) => {
        const score = result.score || 0;
        const maxScore = result.outOf || 0;
        totalScore += score;
        totalMaxScore += maxScore;
        
        const subject = result.subject || "Unknown";
        if (!subjectData[subject]) {
          subjectData[subject] = {
            totalScore: 0,
            totalMaxScore: 0,
            count: 0,
          };
        }
        subjectData[subject].totalScore += score;
        subjectData[subject].totalMaxScore += maxScore;
        subjectData[subject].count++;
      });
      
      // Calculate subject averages
      const subjectAverages = {};
      Object.keys(subjectData).forEach((subject) => {
        const data = subjectData[subject];
        subjectAverages[subject] = {
          average: data.totalMaxScore > 0 
            ? Math.round((data.totalScore / data.totalMaxScore) * 100) 
            : 0,
          totalScore: data.totalScore,
          totalMaxScore: data.totalMaxScore,
          count: data.count,
        };
      });
      
      setCumulativeData({
        totalScore,
        totalMaxScore,
        overallPercentage: totalMaxScore > 0 
          ? Math.round((totalScore / totalMaxScore) * 100) 
          : 0,
        subjectAverages,
      });
      
      // Group results by subject
      const grouped = data.reduce((acc, result) => {
        const subject = result.subject || "Unknown";
        if (!acc[subject]) {
          acc[subject] = [];
        }
        acc[subject].push(result);
        return acc;
      }, {});
      
      setGroupedResults(grouped);
      
      const subjects = Object.keys(grouped);
      if (subjects.length > 0) {
        setExpandedSubject(subjects[0]);
      }
      
      setLoading(false);
      
    } catch (error) {
      setErrorMessage("Error loading results: " + error.message);
      setLoading(false);
    }
  }

  const getScoreColor = (score, outOf) => {
    const percentage = (score / outOf) * 100;
    if (percentage >= 80) return "text-green-600";
    if (percentage >= 60) return "text-yellow-600";
    if (percentage >= 40) return "text-orange-600";
    return "text-red-600";
  };

  const getScoreBadge = (score, outOf) => {
    const percentage = (score / outOf) * 100;
    if (percentage >= 80) return "bg-green-100 text-green-700";
    if (percentage >= 60) return "bg-yellow-100 text-yellow-700";
    if (percentage >= 40) return "bg-orange-100 text-orange-700";
    return "bg-red-100 text-red-700";
  };

  const getGradeLetter = (percentage) => {
    if (percentage >= 90) return "A+";
    if (percentage >= 80) return "A";
    if (percentage >= 70) return "B";
    if (percentage >= 60) return "C";
    if (percentage >= 50) return "D";
    return "F";
  };

  const calculateSubjectAverage = (subjectResults) => {
    if (subjectResults.length === 0) return 0;
    let totalScore = 0;
    let totalMaxScore = 0;
    subjectResults.forEach((r) => {
      totalScore += r.score || 0;
      totalMaxScore += r.outOf || 0;
    });
    return totalMaxScore > 0 ? Math.round((totalScore / totalMaxScore) * 100) : 0;
  };

  const toggleSubject = (subject) => {
    setExpandedSubject(expandedSubject === subject ? null : subject);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading results...</p>
        </div>
      </div>
    );
  }

  if (errorMessage) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="bg-white rounded-xl shadow p-8 max-w-md w-full text-center">
          <div className="text-5xl mb-4">📭</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Error Loading Results</h2>
          <p className="text-gray-600">{errorMessage}</p>
          <button
            onClick={() => navigate("/student-dashboard")}
            className="mt-4 bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  if (!studentData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="bg-white rounded-xl shadow p-8 max-w-md w-full text-center">
          <div className="text-5xl mb-4">📭</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">No Student Data Found</h2>
          <p className="text-gray-600">Please contact the school administrator.</p>
        </div>
      </div>
    );
  }

  const subjects = Object.keys(groupedResults);
  const totalResults = results.length;
  const overallPercentage = cumulativeData.overallPercentage;

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button onClick={() => navigate(-1)} className="text-gray-600 hover:text-gray-800 transition">
            ← Back
          </button>
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">📊 My Results</h1>
        </div>

        {/* Student Info Card with Cumulative Score */}
        <div className="bg-white rounded-xl shadow-md p-4 sm:p-6 mb-6">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <div className="flex-1">
              <h2 className="text-xl font-bold text-gray-800">
                {studentData.fullName || `${studentData.firstName} ${studentData.fatherName}`}
              </h2>
              <p className="text-sm text-gray-500">Student ID: {studentData.studentId}</p>
              <div className="flex flex-wrap gap-2 mt-2">
                <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs font-medium">
                  {studentData.grade}
                </span>
                <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs font-medium">
                  Section {studentData.section}
                </span>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="bg-blue-50 rounded-lg p-3">
                <p className="text-2xl font-bold text-blue-700">{totalResults}</p>
                <p className="text-xs text-gray-500">Total Results</p>
              </div>
              <div className="bg-purple-50 rounded-lg p-3">
                <p className="text-2xl font-bold text-purple-700">
                  {cumulativeData.totalScore} / {cumulativeData.totalMaxScore}
                </p>
                <p className="text-xs text-gray-500">Total Score</p>
              </div>
              <div className="bg-green-50 rounded-lg p-3">
                <p className={`text-2xl font-bold ${getScoreColor(overallPercentage, 100)}`}>
                  {overallPercentage}%
                </p>
                <p className="text-xs text-gray-500">Overall Average</p>
              </div>
            </div>
          </div>
        </div>

        {/* Subject Averages Summary */}
        {Object.keys(cumulativeData.subjectAverages).length > 0 && (
          <div className="bg-white rounded-xl shadow-md p-4 mb-6">
            <h3 className="text-sm font-semibold text-gray-700 mb-3">📊 Subject Averages</h3>
            <div className="flex flex-wrap gap-3">
              {Object.entries(cumulativeData.subjectAverages).map(([subject, data]) => (
                <div key={subject} className="bg-gray-50 rounded-lg px-3 py-2 flex items-center gap-2">
                  <span className="font-medium text-sm">{subject}:</span>
                  <span className={`text-sm font-bold ${getScoreColor(data.average, 100)}`}>
                    {data.average}%
                  </span>
                  <span className="text-xs text-gray-400">
                    ({data.totalScore}/{data.totalMaxScore})
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Grouped Results by Subject */}
        {subjects.length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-6xl mb-4">📭</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No Results Found</h3>
            <p className="text-gray-500">You don't have any results yet. Check back later.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {subjects.map((subject) => {
              const subjectResults = groupedResults[subject];
              const subjectAverage = calculateSubjectAverage(subjectResults);
              const isExpanded = expandedSubject === subject;
              
              return (
                <div key={subject} className="bg-white rounded-xl shadow-md overflow-hidden">
                  {/* Subject Header */}
                  <div
                    className="flex items-center justify-between p-4 cursor-pointer hover:bg-gray-50 transition"
                    onClick={() => toggleSubject(subject)}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">📖</span>
                      <h3 className="text-lg font-bold text-gray-800">{subject}</h3>
                      <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded text-xs">
                        {subjectResults.length} {subjectResults.length === 1 ? 'result' : 'results'}
                      </span>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className={`text-sm font-bold ${getScoreColor(subjectAverage, 100)}`}>
                          Avg: {subjectAverage}%
                        </p>
                      </div>
                      <span className="text-gray-400">
                        {isExpanded ? '▼' : '▶'}
                      </span>
                    </div>
                  </div>

                  {/* Subject Results */}
                  {isExpanded && (
                    <div className="p-4 pt-0 border-t border-gray-100">
                      <div className="space-y-3 mt-3">
                        {subjectResults.map((result, index) => {
                          const percentage = ((result.score / result.outOf) * 100).toFixed(1);
                          return (
                            <div
                              key={result.id || index}
                              className="bg-gray-50 rounded-lg p-3 flex flex-wrap justify-between items-center hover:bg-gray-100 transition"
                            >
                              <div>
                                <p className="font-medium text-gray-800">{result.assessment}</p>
                                <p className="text-xs text-gray-400">
                                  {result.date ? new Date(result.date).toLocaleDateString() : ''}
                                </p>
                              </div>
                              <div className="text-right">
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-gray-800">
                                    {result.score} <span className="text-gray-400 text-sm">/ {result.outOf}</span>
                                  </span>
                                  <span className={`font-semibold ${getScoreColor(result.score, result.outOf)}`}>
                                    ({percentage}%)
                                  </span>
                                  <span className={`px-2 py-0.5 rounded text-sm font-bold ${getScoreBadge(result.score, result.outOf)}`}>
                                    {getGradeLetter(percentage)}
                                  </span>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}