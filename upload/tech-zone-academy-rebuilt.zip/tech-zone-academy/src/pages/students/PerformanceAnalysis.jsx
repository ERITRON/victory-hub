// src/pages/students/PerformanceAnalysis.jsx
import { useEffect, useMemo, useState } from "react";
import { db, collection, getDocs } from "../../supabase/supabase";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import dayjs from "dayjs";
import toast from "react-hot-toast";
import SEO from "../../components/SEO";
import Icon from "../../components/Icon";
import { SkeletonDashboard } from "../../components/LoadingSkeleton";

const SCHOOL_NAME = "Tech Zone Academy";

// Chart ink (single-hue sequential: the charts compare magnitude, so one blue,
// never a rainbow). Validated ≥3:1 against the white card surface.
const SERIES = "#2a78d6";
const GRID = "#e1e0d9";
const MUTED = "#898781";
const INK = "#0b0b0b";

const pct = (score, outOf) => (outOf > 0 ? (score / outOf) * 100 : 0);

// ---------- SVG chart primitives ----------

// Vertical columns: avg % (0–100) per category. ≤24px columns, 4px rounded
// caps, hairline gridlines, value on each cap, hover tooltip.
function ColumnChart({ data, height = 240 }) {
  const [hover, setHover] = useState(null);
  const W = Math.max(data.length * 72, 360);
  const H = height;
  const pad = { top: 24, right: 12, bottom: 30, left: 36 };
  const plotW = W - pad.left - pad.right;
  const plotH = H - pad.top - pad.bottom;
  const colW = 24;
  const step = plotW / data.length;
  const y = (v) => pad.top + plotH - (v / 100) * plotH;

  return (
    <div className="relative overflow-x-auto">
      <svg viewBox={`0 0 ${W} ${H}`} width={W} height={H} className="max-w-none">
        {[0, 25, 50, 75, 100].map((tick) => (
          <g key={tick}>
            <line x1={pad.left} x2={W - pad.right} y1={y(tick)} y2={y(tick)} stroke={GRID} strokeWidth="1" />
            <text x={pad.left - 6} y={y(tick) + 3} textAnchor="end" fontSize="10" fill={MUTED}>
              {tick}
            </text>
          </g>
        ))}
        {data.map((d, i) => {
          const cx = pad.left + i * step + step / 2;
          const barH = Math.max((d.value / 100) * plotH, d.value > 0 ? 3 : 0);
          const top = pad.top + plotH - barH;
          const r = Math.min(4, barH); // rounded data-end, square baseline
          return (
            <g
              key={d.label}
              onMouseEnter={() => setHover(i)}
              onMouseLeave={() => setHover(null)}
            >
              {/* invisible hit target wider than the mark */}
              <rect x={cx - step / 2} y={pad.top} width={step} height={plotH} fill="transparent" />
              {barH > 0 && (
                <path
                  d={`M ${cx - colW / 2} ${top + r}
                      Q ${cx - colW / 2} ${top} ${cx - colW / 2 + r} ${top}
                      L ${cx + colW / 2 - r} ${top}
                      Q ${cx + colW / 2} ${top} ${cx + colW / 2} ${top + r}
                      L ${cx + colW / 2} ${pad.top + plotH}
                      L ${cx - colW / 2} ${pad.top + plotH} Z`}
                  fill={SERIES}
                  opacity={hover === null || hover === i ? 1 : 0.45}
                />
              )}
              <text x={cx} y={top - 5} textAnchor="middle" fontSize="10" fontWeight="600" fill={INK}>
                {Math.round(d.value)}%
              </text>
              <text x={cx} y={H - 10} textAnchor="middle" fontSize="10" fill={MUTED}>
                {d.label.length > 10 ? `${d.label.slice(0, 9)}…` : d.label}
              </text>
            </g>
          );
        })}
        <line x1={pad.left} x2={W - pad.right} y1={pad.top + plotH} y2={pad.top + plotH} stroke="#c3c2b7" strokeWidth="1" />
      </svg>
      {hover !== null && data[hover] && (
        <div className="absolute top-1 left-1/2 -translate-x-1/2 bg-gray-900 text-white text-xs rounded-lg px-3 py-1.5 pointer-events-none whitespace-nowrap">
          {data[hover].label}: {data[hover].value.toFixed(1)}% avg · {data[hover].count} results
        </div>
      )}
    </div>
  );
}

// Horizontal bars: avg % per category, sorted by the caller. Value at the tip.
function HBarChart({ data }) {
  const max = 100;
  return (
    <div className="space-y-2.5">
      {data.map((d) => (
        <div key={d.label} className="flex items-center gap-3 group" title={`${d.label}: ${d.value.toFixed(1)}% avg · ${d.count} results`}>
          <div className="w-28 shrink-0 text-sm text-gray-700 truncate text-right">{d.label}</div>
          <div className="flex-1 h-4 rounded-r bg-gray-100 overflow-hidden">
            <div
              className="h-full rounded-r-[4px] transition-opacity group-hover:opacity-80"
              style={{ width: `${Math.min(d.value, max)}%`, backgroundColor: SERIES }}
            />
          </div>
          <div className="w-11 shrink-0 text-sm font-semibold text-gray-800 tabular-nums">
            {Math.round(d.value)}%
          </div>
        </div>
      ))}
    </div>
  );
}

// Trend line: avg % per month. 2px line, ≥8px end markers with a surface ring,
// endpoint direct-labeled, hover tooltip per point.
function TrendChart({ data, height = 220 }) {
  const [hover, setHover] = useState(null);
  const W = 620;
  const H = height;
  const pad = { top: 20, right: 44, bottom: 28, left: 36 };
  const plotW = W - pad.left - pad.right;
  const plotH = H - pad.top - pad.bottom;
  const x = (i) => pad.left + (data.length === 1 ? plotW / 2 : (i / (data.length - 1)) * plotW);
  const y = (v) => pad.top + plotH - (v / 100) * plotH;
  const path = data.map((d, i) => `${i === 0 ? "M" : "L"} ${x(i)} ${y(d.value)}`).join(" ");
  const last = data[data.length - 1];

  return (
    <div className="relative">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-auto">
        {[0, 25, 50, 75, 100].map((tick) => (
          <g key={tick}>
            <line x1={pad.left} x2={W - pad.right} y1={y(tick)} y2={y(tick)} stroke={GRID} strokeWidth="1" />
            <text x={pad.left - 6} y={y(tick) + 3} textAnchor="end" fontSize="10" fill={MUTED}>
              {tick}
            </text>
          </g>
        ))}
        <path d={path} fill="none" stroke={SERIES} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
        {data.map((d, i) => (
          <g key={d.label} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
            <circle cx={x(i)} cy={y(d.value)} r="10" fill="transparent" />
            <circle cx={x(i)} cy={y(d.value)} r="4" fill={SERIES} stroke="#ffffff" strokeWidth="2" />
            <text x={x(i)} y={H - 8} textAnchor="middle" fontSize="10" fill={MUTED}>
              {d.label}
            </text>
          </g>
        ))}
        {last && (
          <text x={x(data.length - 1) + 8} y={y(last.value) + 4} fontSize="11" fontWeight="600" fill={INK}>
            {Math.round(last.value)}%
          </text>
        )}
      </svg>
      {hover !== null && data[hover] && (
        <div className="absolute top-0 left-1/2 -translate-x-1/2 bg-gray-900 text-white text-xs rounded-lg px-3 py-1.5 pointer-events-none whitespace-nowrap">
          {data[hover].label}: {data[hover].value.toFixed(1)}% avg · {data[hover].count} results
        </div>
      )}
    </div>
  );
}

function StatTile({ label, value, sub, icon, iconColor }) {
  return (
    <div className="bg-white rounded-xl shadow p-4">
      <div className="flex items-center justify-between">
        <div className="text-sm text-gray-600">{label}</div>
        <Icon name={icon} className={iconColor} />
      </div>
      <div className="text-2xl font-bold text-gray-900 mt-1">{value}</div>
      {sub && <div className="text-xs text-gray-500 mt-0.5">{sub}</div>}
    </div>
  );
}

// ---------- Page ----------

export default function PerformanceAnalysis() {
  const [loading, setLoading] = useState(true);
  const [students, setStudents] = useState([]);
  const [results, setResults] = useState([]);
  const [grades, setGrades] = useState([]);
  const [sections, setSections] = useState([]);

  const [gradeFilter, setGradeFilter] = useState("");
  const [sectionFilter, setSectionFilter] = useState("");
  const [subjectFilter, setSubjectFilter] = useState("");

  const fetchAllData = async () => {
    setLoading(true);
    try {
      const [studentsSnap, resultsSnap, gradesSnap, sectionsSnap] = await Promise.all([
        getDocs(collection(db, "students")),
        getDocs(collection(db, "results")),
        getDocs(collection(db, "grades")),
        getDocs(collection(db, "sections")),
      ]);
      setStudents(studentsSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
      setResults(resultsSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
      setGrades(
        gradesSnap.docs
          .map((doc) => ({ id: doc.id, ...doc.data() }))
          .sort((a, b) => a.name.localeCompare(b.name))
      );
      setSections(
        sectionsSnap.docs
          .map((doc) => ({ id: doc.id, ...doc.data() }))
          .sort((a, b) => a.name.localeCompare(b.name))
      );
    } catch (error) {
      console.error("Error fetching analytics data:", error);
      toast.error("Failed to load analytics data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  const studentMap = useMemo(() => {
    const map = {};
    students.forEach((s) => {
      map[s.studentId || s.id] = s;
    });
    return map;
  }, [students]);

  // Every result enriched with grade/section (from the result itself, falling
  // back to the student record) — the single dataset all analytics run on.
  const enriched = useMemo(() => {
    return results
      .filter((r) => (r.outOf || 0) > 0)
      .map((r) => {
        const student = studentMap[r.studentId];
        return {
          ...r,
          pct: pct(r.score || 0, r.outOf),
          grade: r.grade || student?.grade || "Unknown",
          section: r.section || student?.section || "Unknown",
          subject: r.subject || "Other",
          studentName: student?.fullName || student?.firstName || r.studentId,
        };
      });
  }, [results, studentMap]);

  const subjects = useMemo(
    () => [...new Set(enriched.map((r) => r.subject))].sort(),
    [enriched]
  );

  const filtered = useMemo(() => {
    return enriched.filter((r) => {
      if (gradeFilter && r.grade !== gradeFilter) return false;
      if (sectionFilter && r.section !== sectionFilter) return false;
      if (subjectFilter && r.subject !== subjectFilter) return false;
      return true;
    });
  }, [enriched, gradeFilter, sectionFilter, subjectFilter]);

  const groupAvg = (rows, keyFn) => {
    const groups = {};
    rows.forEach((r) => {
      const key = keyFn(r);
      if (!groups[key]) groups[key] = { score: 0, outOf: 0, count: 0 };
      groups[key].score += r.score || 0;
      groups[key].outOf += r.outOf;
      groups[key].count += 1;
    });
    return Object.entries(groups).map(([label, g]) => ({
      label,
      value: pct(g.score, g.outOf),
      count: g.count,
    }));
  };

  const analytics = useMemo(() => {
    const totalScore = filtered.reduce((s, r) => s + (r.score || 0), 0);
    const totalOutOf = filtered.reduce((s, r) => s + r.outOf, 0);
    const overallAvg = pct(totalScore, totalOutOf);
    const passRate =
      filtered.length > 0
        ? (filtered.filter((r) => r.pct >= 50).length / filtered.length) * 100
        : 0;

    const byGrade = groupAvg(filtered, (r) => r.grade).sort((a, b) =>
      a.label.localeCompare(b.label, undefined, { numeric: true })
    );
    const bySubject = groupAvg(filtered, (r) => r.subject).sort((a, b) => b.value - a.value);

    // Monthly trend from dated results
    const dated = filtered.filter((r) => r.date && dayjs(r.date).isValid());
    const byMonth = {};
    dated.forEach((r) => {
      const key = dayjs(r.date).format("YYYY-MM");
      if (!byMonth[key]) byMonth[key] = { score: 0, outOf: 0, count: 0 };
      byMonth[key].score += r.score || 0;
      byMonth[key].outOf += r.outOf;
      byMonth[key].count += 1;
    });
    const trend = Object.entries(byMonth)
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-12)
      .map(([key, g]) => ({
        label: dayjs(key + "-01").format("MMM YY"),
        value: pct(g.score, g.outOf),
        count: g.count,
      }));

    // Per-student averages for top / struggling lists
    const perStudent = {};
    filtered.forEach((r) => {
      if (!perStudent[r.studentId]) {
        perStudent[r.studentId] = { score: 0, outOf: 0, count: 0, name: r.studentName, grade: r.grade, section: r.section };
      }
      perStudent[r.studentId].score += r.score || 0;
      perStudent[r.studentId].outOf += r.outOf;
      perStudent[r.studentId].count += 1;
    });
    const studentRows = Object.entries(perStudent).map(([id, s]) => ({
      id,
      name: s.name,
      grade: s.grade,
      section: s.section,
      count: s.count,
      avg: pct(s.score, s.outOf),
    }));
    const topPerformers = [...studentRows].sort((a, b) => b.avg - a.avg).slice(0, 5);
    const struggling = studentRows
      .filter((s) => s.avg < 50)
      .sort((a, b) => a.avg - b.avg)
      .slice(0, 5);

    return {
      totalResults: filtered.length,
      studentsAnalyzed: studentRows.length,
      overallAvg,
      passRate,
      byGrade,
      bySubject,
      trend,
      topPerformers,
      struggling,
      studentRows,
    };
  }, [filtered]);

  const filterLabel = () => {
    const parts = [];
    if (gradeFilter) parts.push(gradeFilter);
    if (sectionFilter) parts.push(`Section ${sectionFilter}`);
    if (subjectFilter) parts.push(subjectFilter);
    return parts.length ? parts.join(" - ") : "All Students";
  };

  const handleExportPDF = () => {
    if (analytics.totalResults === 0) {
      toast.error("No data to export");
      return;
    }
    try {
      const doc = new jsPDF("p", "mm", "a4");
      doc.setFontSize(18);
      doc.text(SCHOOL_NAME, 14, 20);
      doc.setFontSize(13);
      doc.text(`Performance Analysis — ${filterLabel()}`, 14, 29);
      doc.setFontSize(9);
      doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 36);
      doc.setFontSize(10);
      doc.text(
        `Overall average: ${analytics.overallAvg.toFixed(1)}%   Pass rate: ${analytics.passRate.toFixed(1)}%   Results: ${analytics.totalResults}   Students: ${analytics.studentsAnalyzed}`,
        14,
        44
      );

      autoTable(doc, {
        startY: 50,
        head: [["Grade", "Average %", "Results"]],
        body: analytics.byGrade.map((g) => [g.label, g.value.toFixed(1), g.count]),
        theme: "striped",
        styles: { fontSize: 8 },
        headStyles: { fillColor: [42, 120, 214] },
      });
      autoTable(doc, {
        startY: doc.lastAutoTable.finalY + 8,
        head: [["Subject", "Average %", "Results"]],
        body: analytics.bySubject.map((s) => [s.label, s.value.toFixed(1), s.count]),
        theme: "striped",
        styles: { fontSize: 8 },
        headStyles: { fillColor: [42, 120, 214] },
      });
      autoTable(doc, {
        startY: doc.lastAutoTable.finalY + 8,
        head: [["Top Performers", "Grade", "Average %", "Results"]],
        body: analytics.topPerformers.map((s) => [s.name, `${s.grade} ${s.section}`, s.avg.toFixed(1), s.count]),
        theme: "striped",
        styles: { fontSize: 8 },
        headStyles: { fillColor: [12, 163, 12] },
      });
      if (analytics.struggling.length > 0) {
        autoTable(doc, {
          startY: doc.lastAutoTable.finalY + 8,
          head: [["Needs Support (below 50%)", "Grade", "Average %", "Results"]],
          body: analytics.struggling.map((s) => [s.name, `${s.grade} ${s.section}`, s.avg.toFixed(1), s.count]),
          theme: "striped",
          styles: { fontSize: 8 },
          headStyles: { fillColor: [208, 59, 59] },
        });
      }

      doc.save(`performance-analysis-${new Date().toISOString().slice(0, 10)}.pdf`);
      toast.success("PDF exported");
    } catch (error) {
      console.error("PDF export failed:", error);
      toast.error("PDF export failed");
    }
  };

  const handleExportExcel = () => {
    if (analytics.totalResults === 0) {
      toast.error("No data to export");
      return;
    }
    try {
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(
        workbook,
        XLSX.utils.json_to_sheet(
          analytics.byGrade.map((g) => ({ Grade: g.label, "Average %": +g.value.toFixed(1), Results: g.count }))
        ),
        "By Grade"
      );
      XLSX.utils.book_append_sheet(
        workbook,
        XLSX.utils.json_to_sheet(
          analytics.bySubject.map((s) => ({ Subject: s.label, "Average %": +s.value.toFixed(1), Results: s.count }))
        ),
        "By Subject"
      );
      XLSX.utils.book_append_sheet(
        workbook,
        XLSX.utils.json_to_sheet(
          [...analytics.studentRows]
            .sort((a, b) => b.avg - a.avg)
            .map((s) => ({
              Student: s.name,
              "Student ID": s.id,
              Grade: s.grade,
              Section: s.section,
              "Average %": +s.avg.toFixed(1),
              Results: s.count,
            }))
        ),
        "By Student"
      );
      XLSX.writeFile(workbook, `performance-analysis-${new Date().toISOString().slice(0, 10)}.xlsx`);
      toast.success("Excel exported");
    } catch (error) {
      console.error("Excel export failed:", error);
      toast.error("Excel export failed");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto py-6 sm:py-8 px-4 sm:px-6 lg:px-8">
          <SkeletonDashboard />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <SEO
        title="Performance Analysis"
        description="School-wide academic performance analytics and trends"
        noindex
      />

      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 inline-flex items-center gap-3">
              <Icon name="chart" className="text-blue-700" />
              Performance Analysis
            </h1>
            <p className="text-gray-600 mt-1">
              Academic performance across grades, subjects, and time
            </p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={handleExportPDF}
              className="inline-flex items-center gap-2 bg-red-600 text-white px-4 py-2.5 rounded-lg hover:bg-red-700 transition text-sm font-medium"
            >
              <Icon name="download" />
              Export PDF
            </button>
            <button
              onClick={handleExportExcel}
              className="inline-flex items-center gap-2 bg-green-600 text-white px-4 py-2.5 rounded-lg hover:bg-green-700 transition text-sm font-medium"
            >
              <Icon name="download" />
              Export Excel
            </button>
          </div>
        </div>

        {/* Filters — one row above the charts */}
        <div className="bg-white rounded-xl shadow p-4 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <select
              value={gradeFilter}
              onChange={(e) => setGradeFilter(e.target.value)}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm bg-white"
            >
              <option value="">All Grades</option>
              {grades.map((g) => (
                <option key={g.id} value={g.name}>{g.name}</option>
              ))}
            </select>
            <select
              value={sectionFilter}
              onChange={(e) => setSectionFilter(e.target.value)}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm bg-white"
            >
              <option value="">All Sections</option>
              {sections.map((s) => (
                <option key={s.id} value={s.name}>{s.name}</option>
              ))}
            </select>
            <select
              value={subjectFilter}
              onChange={(e) => setSubjectFilter(e.target.value)}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm bg-white"
            >
              <option value="">All Subjects</option>
              {subjects.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
        </div>

        {analytics.totalResults === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-gray-300 mb-3">
              <Icon name="chart" size="3x" />
            </div>
            <h3 className="text-lg font-semibold text-gray-700">No results found</h3>
            <p className="text-sm text-gray-500 mt-1">
              No results match the current filters yet.
            </p>
          </div>
        ) : (
          <>
            {/* Overall school performance — KPI row */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <StatTile
                label="Overall Average"
                value={`${analytics.overallAvg.toFixed(1)}%`}
                sub={filterLabel()}
                icon="chart"
                iconColor="text-blue-600"
              />
              <StatTile
                label="Pass Rate"
                value={`${analytics.passRate.toFixed(1)}%`}
                sub="Results scoring 50% or above"
                icon="success"
                iconColor="text-green-600"
              />
              <StatTile
                label="Total Results"
                value={analytics.totalResults.toLocaleString()}
                sub="Assessments recorded"
                icon="result"
                iconColor="text-purple-600"
              />
              <StatTile
                label="Students Analyzed"
                value={analytics.studentsAnalyzed.toLocaleString()}
                sub="With at least one result"
                icon="student"
                iconColor="text-orange-600"
              />
            </div>

            {/* Performance by grade */}
            <div className="bg-white rounded-xl shadow p-5 mb-6">
              <h2 className="text-base font-bold text-gray-800 mb-1">Average score by grade</h2>
              <p className="text-xs text-gray-500 mb-4">
                Percentage of total marks earned per grade · hover a column for detail
              </p>
              <ColumnChart data={analytics.byGrade} />
            </div>

            <div className="grid lg:grid-cols-2 gap-6 mb-6">
              {/* Performance by subject */}
              <div className="bg-white rounded-xl shadow p-5">
                <h2 className="text-base font-bold text-gray-800 mb-1">Average score by subject</h2>
                <p className="text-xs text-gray-500 mb-4">Sorted highest to lowest</p>
                <HBarChart data={analytics.bySubject} />
              </div>

              {/* Trend over time */}
              <div className="bg-white rounded-xl shadow p-5">
                <h2 className="text-base font-bold text-gray-800 mb-1">Performance trend</h2>
                <p className="text-xs text-gray-500 mb-4">Monthly average score, last 12 months</p>
                {analytics.trend.length >= 2 ? (
                  <TrendChart data={analytics.trend} />
                ) : (
                  <p className="text-sm text-gray-500 py-10 text-center">
                    Not enough dated results to draw a trend yet.
                  </p>
                )}
              </div>
            </div>

            {/* Top performers & struggling students */}
            <div className="grid lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl shadow overflow-hidden">
                <div className="px-5 py-4 border-b bg-green-50 flex items-center gap-2">
                  <Icon name="grade" className="text-green-600" />
                  <h2 className="text-base font-bold text-gray-800">Top Performers</h2>
                </div>
                <div>
                  {analytics.topPerformers.map((s, i) => (
                    <div key={s.id} className="flex items-center gap-3 px-5 py-3 border-b border-gray-50 last:border-0">
                      <span className="w-7 h-7 shrink-0 rounded-full bg-green-100 text-green-700 text-xs font-bold flex items-center justify-center">
                        {i + 1}
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-medium text-gray-800 truncate">{s.name}</div>
                        <div className="text-xs text-gray-500">
                          {s.grade} · Section {s.section} · {s.count} results
                        </div>
                      </div>
                      <span className="text-sm font-bold text-green-700 tabular-nums">
                        {s.avg.toFixed(1)}%
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-xl shadow overflow-hidden">
                <div className="px-5 py-4 border-b bg-red-50 flex items-center gap-2">
                  <Icon name="warning" className="text-red-600" />
                  <h2 className="text-base font-bold text-gray-800">Needs Support</h2>
                  <span className="text-xs text-gray-500 ml-auto">Average below 50%</span>
                </div>
                {analytics.struggling.length === 0 ? (
                  <p className="text-sm text-gray-500 px-5 py-8 text-center">
                    No students below 50% average. 🎉
                  </p>
                ) : (
                  <div>
                    {analytics.struggling.map((s) => (
                      <div key={s.id} className="flex items-center gap-3 px-5 py-3 border-b border-gray-50 last:border-0">
                        <span className="w-7 h-7 shrink-0 rounded-full bg-red-100 text-red-700 flex items-center justify-center">
                          <Icon name="warning" size="xs" />
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="text-sm font-medium text-gray-800 truncate">{s.name}</div>
                          <div className="text-xs text-gray-500">
                            {s.grade} · Section {s.section} · {s.count} results
                          </div>
                        </div>
                        <span className="text-sm font-bold text-red-700 tabular-nums">
                          {s.avg.toFixed(1)}%
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
