import { useEffect, useState } from "react";
import { collection, getDocs, query, where, db } from "../../supabase/supabase";
import { deleteAccount } from "../../services/adminService";
import { useNavigate, useParams } from "react-router-dom";

export default function SectionStudents() {
  const { grade, section } = useParams();
  const navigate = useNavigate();

  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  const fetchStudents = async () => {
    setLoading(true);
    setErrorMessage("");

    try {
      const q = query(
        collection(db, "students"),
        where("grade", "==", grade),
        where("section", "==", section)
      );
      const snapshot = await getDocs(q);

      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));

      setStudents(data);
    } catch (error) {
      setErrorMessage("Error loading students: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStudents();
    // eslint-disable-next-line react-hooks/exhaustive-deps -- re-run only when the grade/section route params change
  }, [grade, section]);

  const deleteStudent = async (id, name) => {
    if (!window.confirm(`Delete student ${name}? This action cannot be undone.`)) {
      return;
    }

    try {
      await deleteAccount(id, "student");
      setSuccessMessage(`✅ Student ${name} deleted successfully!`);
      setTimeout(() => setSuccessMessage(""), 3000);
      fetchStudents();
    } catch (error) {
      setErrorMessage(`❌ ${error.message}`);
      setTimeout(() => setErrorMessage(""), 4000);
    }
  };

  const filteredStudents = students.filter((student) => {
    const fullName = `${student.firstName} ${student.fatherName}`.toLowerCase();
    const search = searchTerm.toLowerCase();
    return fullName.includes(search) || student.studentId?.toLowerCase().includes(search);
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading students...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => navigate(`/student-list/${grade}`)}
                  className="text-gray-600 hover:text-gray-800 transition"
                >
                  ← Back
                </button>
                <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
                  📚 {grade} - Section {section}
                </h1>
              </div>
              <p className="text-gray-600 mt-1">
                {students.length} student{students.length !== 1 ? "s" : ""} enrolled
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => navigate("/add-student")}
                className="bg-blue-700 text-white px-4 py-2 rounded-lg hover:bg-blue-800 transition text-sm flex items-center gap-2"
              >
                <span className="text-lg">+</span> Add Student
              </button>
              <button
                onClick={fetchStudents}
                className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition text-sm flex items-center gap-2"
              >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h3.992v3.992m0-3.992-6.3 6.3a2.25 2.25 0 01-3.182 0l-3.7-3.7a2.25 2.25 0 010-3.182l6.3-6.3a2.25 2.25 0 013.182 0l3.7 3.7z" />
                </svg>
                Refresh
              </button>
            </div>
          </div>
        </div>

        {/* Messages */}
        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Search */}
        <div className="bg-white rounded-xl shadow-md p-4 sm:p-6 mb-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Search Students
              </label>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by name or student ID..."
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
              />
            </div>
            <div className="flex items-end">
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm("")}
                  className="bg-gray-200 text-gray-700 px-4 py-2.5 rounded-lg hover:bg-gray-300 transition font-medium"
                >
                  Clear
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="flex flex-wrap gap-4 mb-6">
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Total Students:</span>
            <span className="ml-2 font-bold text-blue-700">{students.length}</span>
          </div>
          {searchTerm && (
            <div className="bg-white rounded-lg shadow px-4 py-2">
              <span className="text-sm text-gray-600">Filtered:</span>
              <span className="ml-2 font-bold text-green-700">{filteredStudents.length}</span>
            </div>
          )}
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Class:</span>
            <span className="ml-2 font-bold text-purple-700">{grade} - Section {section}</span>
          </div>
        </div>

        {/* Students Grid */}
        {filteredStudents.length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-6xl mb-4">📭</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              {students.length === 0 ? "No Students Enrolled" : "No Students Found"}
            </h3>
            <p className="text-gray-500">
              {students.length === 0 
                ? `No students are currently enrolled in ${grade} - Section ${section}.` 
                : "No students match your search criteria."}
            </p>
            {students.length === 0 && (
              <button
                onClick={() => navigate("/add-student")}
                className="mt-4 bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition"
              >
                + Add First Student
              </button>
            )}
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {filteredStudents.map((student) => (
              <div
                key={student.id}
                className="bg-white rounded-xl shadow-md p-5 hover:shadow-xl transition duration-300 border-l-4 border-blue-500"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-gray-800">
                      {student.firstName} {student.fatherName}
                    </h3>
                    <p className="text-sm text-gray-500">
                      ID: {student.studentId}
                    </p>
                  </div>
                  <div className="text-3xl">
                    {student.gender === "Female" ? "👧" : "👦"}
                  </div>
                </div>

                <div className="mt-3 space-y-1">
                  <p className="text-sm text-gray-600">
                    <span className="font-medium">Grade:</span> {student.grade}
                  </p>
                  <p className="text-sm text-gray-600">
                    <span className="font-medium">Section:</span> {student.section}
                  </p>
                  {student.parentName && (
                    <p className="text-sm text-gray-600">
                      <span className="font-medium">Parent:</span> {student.parentName}
                    </p>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-gray-100 flex flex-wrap gap-2">
                  <button
                    onClick={() => navigate(`/edit-student/${student.id}`)}
                    className="bg-yellow-500 text-white px-4 py-1.5 rounded-lg hover:bg-yellow-600 transition font-medium text-sm flex-1"
                  >
                    ✏️ Edit
                  </button>
                  <button
                    onClick={() => deleteStudent(student.id, `${student.firstName} ${student.fatherName}`)}
                    className="bg-red-600 text-white px-4 py-1.5 rounded-lg hover:bg-red-700 transition font-medium text-sm flex-1"
                  >
                    🗑️ Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}