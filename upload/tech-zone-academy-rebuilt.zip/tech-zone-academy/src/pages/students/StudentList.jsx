import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { db, collection, getDocs } from "../../supabase/supabase";

export default function StudentsList() {
  const navigate = useNavigate();
  const [grades, setGrades] = useState([]);
  const [studentCounts, setStudentCounts] = useState({});
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [stats, setStats] = useState({
    totalStudents: 0,
    totalGrades: 0,
    totalSections: 0,
  });

  const fetchData = async () => {
    setLoading(true);
    setErrorMessage("");

    try {
      // Fetch grades
      const gradesSnap = await getDocs(collection(db, "grades"));
      const gradesData = gradesSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setGrades(gradesData.sort((a, b) => a.name.localeCompare(b.name)));

      // Fetch students to count per grade
      const studentsSnap = await getDocs(collection(db, "students"));
      const students = studentsSnap.docs.map((doc) => doc.data());

      // Count students per grade
      const counts = {};
      const uniqueSections = new Set();
      students.forEach((student) => {
        if (student.grade) {
          counts[student.grade] = (counts[student.grade] || 0) + 1;
        }
        if (student.section) {
          uniqueSections.add(student.section);
        }
      });
      setStudentCounts(counts);

      // Calculate stats
      setStats({
        totalStudents: students.length,
        totalGrades: gradesData.length,
        totalSections: uniqueSections.size,
      });

    } catch (error) {
      setErrorMessage("Error loading data: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
     
  }, []);

  const getGradeColor = (gradeName) => {
    const colors = [
      "border-l-4 border-blue-500 hover:bg-blue-50",
      "border-l-4 border-green-500 hover:bg-green-50",
      "border-l-4 border-purple-500 hover:bg-purple-50",
      "border-l-4 border-orange-500 hover:bg-orange-50",
      "border-l-4 border-red-500 hover:bg-red-50",
      "border-l-4 border-teal-500 hover:bg-teal-50",
      "border-l-4 border-pink-500 hover:bg-pink-50",
      "border-l-4 border-indigo-500 hover:bg-indigo-50",
      "border-l-4 border-yellow-500 hover:bg-yellow-50",
      "border-l-4 border-cyan-500 hover:bg-cyan-50",
      "border-l-4 border-rose-500 hover:bg-rose-50",
    ];
    return colors[grades.findIndex(g => g.name === gradeName) % colors.length];
  };

  const filteredGrades = grades.filter((grade) =>
    grade.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading students...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
                📚 Student Management
              </h1>
              <p className="text-gray-600 mt-1">
                Select a grade to view students
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => navigate("/add-student")}
                className="bg-blue-700 text-white px-4 py-2 rounded-lg hover:bg-blue-800 transition text-sm flex items-center gap-2"
              >
                <span className="text-lg">+</span> Add Student
              </button>
              <button
                onClick={fetchData}
                className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition text-sm flex items-center gap-2"
              >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h3.992v3.992m0-3.992-6.3 6.3a2.25 2.25 0 01-3.182 0l-3.7-3.7a2.25 2.25 0 010-3.182l6.3-6.3a2.25 2.25 0 013.182 0l3.7 3.7z" />
                </svg>
                Refresh
              </button>
            </div>
          </div>
        </div>

        {/* Error Message */}
        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-blue-500">
            <div className="text-2xl font-bold text-blue-700">{stats.totalStudents}</div>
            <div className="text-xs sm:text-sm text-gray-600">Total Students</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-green-500">
            <div className="text-2xl font-bold text-green-700">{stats.totalGrades}</div>
            <div className="text-xs sm:text-sm text-gray-600">Total Grades</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-purple-500">
            <div className="text-2xl font-bold text-purple-700">{stats.totalSections}</div>
            <div className="text-xs sm:text-sm text-gray-600">Total Sections</div>
          </div>
        </div>

        {/* Search */}
        <div className="bg-white rounded-xl shadow-md p-4 sm:p-6 mb-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Search Grades
              </label>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by grade name..."
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
              />
            </div>
            {searchTerm && (
              <div className="flex items-end">
                <button
                  onClick={() => setSearchTerm("")}
                  className="bg-gray-200 text-gray-700 px-4 py-2.5 rounded-lg hover:bg-gray-300 transition font-medium"
                >
                  Clear
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Grades Grid */}
        {filteredGrades.length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-6xl mb-4">📭</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              {grades.length === 0 ? "No Grades Found" : "No Grades Match"}
            </h3>
            <p className="text-gray-500">
              {grades.length === 0 
                ? "No grades have been added to the system yet." 
                : "No grades match your search criteria."}
            </p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
            {filteredGrades.map((grade) => {
              const count = studentCounts[grade.name] || 0;
              const colorClass = getGradeColor(grade.name);
              
              return (
                <div
                  key={grade.id}
                  onClick={() => navigate(`/student-list/${grade.name}`)}
                  className={`
                    bg-white rounded-xl shadow-md p-5 cursor-pointer 
                    transition-all duration-300 hover:shadow-xl hover:-translate-y-1
                    ${colorClass}
                  `}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-xl font-bold text-gray-800">
                        {grade.name}
                      </h3>
                      <p className="text-sm text-gray-500 mt-1">
                        {count} student{count !== 1 ? "s" : ""}
                      </p>
                    </div>
                    <div className={`text-3xl ${count > 0 ? "opacity-100" : "opacity-30"}`}>
                      {count > 0 ? "👨‍🎓" : "📭"}
                    </div>
                  </div>

                  <div className="mt-3 flex items-center gap-2">
                    <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-blue-600 rounded-full transition-all duration-500"
                        style={{ 
                          width: count > 0 ? `${Math.min((count / 50) * 100, 100)}%` : "0%" 
                        }}
                      />
                    </div>
                    <span className="text-xs text-gray-500">
                      {count > 0 ? `${Math.min(Math.round((count / 50) * 100), 100)}%` : "0%"}
                    </span>
                  </div>

                  <div className="mt-3 flex justify-end">
                    <span className="text-sm text-blue-600 font-medium">
                      View Sections →
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Summary Footer */}
        {filteredGrades.length > 0 && (
          <div className="mt-8 bg-white rounded-xl shadow p-4 text-center">
            <p className="text-sm text-gray-600">
              Showing <strong>{filteredGrades.length}</strong> of <strong>{grades.length}</strong> grades
              {stats.totalStudents > 0 && (
                <> with <strong>{stats.totalStudents}</strong> total students</>
              )}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}