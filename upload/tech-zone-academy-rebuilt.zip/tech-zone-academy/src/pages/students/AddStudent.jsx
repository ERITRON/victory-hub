// src/pages/AddStudent.jsx
import { useState, useEffect } from "react";
import { db } from "../../supabase/supabase";
import { collection, getDocs } from "../../supabase/supabase";
import { createStudent } from "../../services/adminService";

export default function AddStudent() {
  const [nextStudentId, setNextStudentId] = useState("");
  const [grades, setGrades] = useState([]);
  const [sections, setSections] = useState([]);
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const [formData, setFormData] = useState({
    firstName: "",
    fatherName: "",
    grandfatherName: "",
    gender: "",
    grade: "",
    section: "",
    parentName: "",
    parentPhone: "",
    parentEmail: "",
    emergencyPhone: "",
    password: "",
    confirmPassword: "",
  });

  const nameRegex = /^[A-Za-z\s]+$/;
  const phoneRegex = /^(09\d{8}|07\d{8}|\+2519\d{8}|\+2517\d{8})$/;

  const loadNextStudentId = async () => {
    try {
      const snapshot = await getDocs(collection(db, "students"));
      if (snapshot.empty) {
        setNextStudentId("STU001");
        return;
      }
      let highest = 0;
      snapshot.forEach((doc) => {
        const data = doc.data();
        if (data.student_id) {
          const num = parseInt(data.student_id.replace("STU", ""));
          if (!isNaN(num) && num > highest) {
            highest = num;
          }
        }
      });
      if (highest === 0) {
        setNextStudentId("STU001");
      } else {
        const next = highest + 1;
        setNextStudentId(`STU${String(next).padStart(3, "0")}`);
      }
    } catch (error) {
      console.error("Error loading next student ID:", error);
      setNextStudentId("STU001");
    }
  };

  const loadGrades = async () => {
    try {
      const snapshot = await getDocs(collection(db, "grades"));
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setGrades(data.sort((a, b) => a.name.localeCompare(b.name)));
    } catch (error) {
      console.error("Error loading grades:", error);
    }
  };

  const loadSections = async () => {
    try {
      const snapshot = await getDocs(collection(db, "sections"));
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSections(data.sort((a, b) => a.name.localeCompare(b.name)));
    } catch (error) {
      console.error("Error loading sections:", error);
    }
  };

  useEffect(() => {
    loadNextStudentId();
    loadGrades();
    loadSections();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    const {
      firstName,
      fatherName,
      grandfatherName,
      gender,
      grade,
      section,
      parentName,
      parentPhone,
      password,
      confirmPassword,
    } = formData;

    if (!firstName) {
      setErrorMessage("First Name is required");
      return false;
    }
    if (!nameRegex.test(firstName)) {
      setErrorMessage("First Name must contain letters only");
      return false;
    }
    if (!fatherName) {
      setErrorMessage("Father Name is required");
      return false;
    }
    if (!nameRegex.test(fatherName)) {
      setErrorMessage("Father Name must contain letters only");
      return false;
    }
    if (!grandfatherName) {
      setErrorMessage("Grandfather Name is required");
      return false;
    }
    if (!nameRegex.test(grandfatherName)) {
      setErrorMessage("Grandfather Name must contain letters only");
      return false;
    }
    if (!gender) {
      setErrorMessage("Please select gender");
      return false;
    }
    if (!grade) {
      setErrorMessage("Please select grade");
      return false;
    }
    if (!section) {
      setErrorMessage("Please select section");
      return false;
    }
    if (!parentName) {
      setErrorMessage("Parent Name is required");
      return false;
    }
    if (!nameRegex.test(parentName)) {
      setErrorMessage("Parent Name must contain letters only");
      return false;
    }
    if (!parentPhone) {
      setErrorMessage("Parent Phone is required");
      return false;
    }
    if (!phoneRegex.test(parentPhone)) {
      setErrorMessage("Please enter a valid Ethiopian phone number");
      return false;
    }
    if (!password) {
      setErrorMessage("Password is required");
      return false;
    }
    if (password.length < 6) {
      setErrorMessage("Password must be at least 6 characters");
      return false;
    }
    if (password !== confirmPassword) {
      setErrorMessage("Passwords do not match");
      return false;
    }
    return true;
  };

  const addStudent = async () => {
    setLoading(true);
    setErrorMessage("");
    setSuccessMessage("");

    if (!validateForm()) {
      setLoading(false);
      return;
    }

    try {
      const {
        firstName,
        fatherName,
        grandfatherName,
        gender,
        grade,
        section,
        parentName,
        parentPhone,
        parentEmail,
        emergencyPhone,
        password,
      } = formData;

      // Account creation happens server-side (Supabase Edge Function,
      // service role) so the admin's own session is never touched and
      // no admin password needs to live in the browser.
      const result = await createStudent({
        firstName,
        fatherName,
        grandfatherName,
        gender,
        grade,
        section,
        parentName,
        parentPhone,
        parentEmail,
        emergencyPhone,
        password,
      });

      setSuccessMessage(
        `✅ Student Created Successfully!\n\n` +
        `Student ID: ${result.studentId}\n` +
        `Name: ${firstName} ${fatherName}\n` +
        `Grade: ${grade} - Section ${section}\n` +
        `Password: ${password}\n\n` +
        `📌 Please give these login credentials to the student.\n` +
        `🔑 Login with Student ID: ${result.studentId}`
      );

      // Reset form
      setFormData({
        firstName: "",
        fatherName: "",
        grandfatherName: "",
        gender: "",
        grade: "",
        section: "",
        parentName: "",
        parentPhone: "",
        parentEmail: "",
        emergencyPhone: "",
        password: "",
        confirmPassword: "",
      });

      await loadNextStudentId();

      setTimeout(() => setSuccessMessage(""), 8000);

    } catch (error) {
      setErrorMessage(`❌ ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // ✅ Only check required fields (email is auto-generated, hidden from admin)
  const isFormValid =
    formData.firstName &&
    formData.fatherName &&
    formData.grandfatherName &&
    formData.gender &&
    formData.grade &&
    formData.section &&
    formData.parentName &&
    formData.parentPhone &&
    formData.password &&
    formData.password === formData.confirmPassword;

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">📚 Add Student</h1>
          <p className="text-gray-600 mt-1">Student will login with their Student ID</p>
        </div>

        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4 whitespace-pre-line">
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4 whitespace-pre-line">
            {errorMessage}
          </div>
        )}

        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-6 sm:p-8">
            <div className="grid gap-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-2">
                <p className="text-sm text-gray-600">Student ID (Login)</p>
                <p className="text-2xl font-bold text-blue-700">{nextStudentId || "Loading..."}</p>
                <p className="text-xs text-gray-500 mt-1">Student will use this ID to login</p>
              </div>

              <div className="border-b border-gray-200 pb-4 mb-2">
                <h2 className="text-lg font-semibold text-gray-700 mb-3">👤 Personal Information</h2>
                <div className="grid sm:grid-cols-2 gap-3">
                  <input name="firstName" value={formData.firstName} onChange={handleChange} placeholder="First Name *" className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition" />
                  <input name="fatherName" value={formData.fatherName} onChange={handleChange} placeholder="Father Name *" className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition" />
                  <input name="grandfatherName" value={formData.grandfatherName} onChange={handleChange} placeholder="Grandfather Name *" className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition" />
                  <select name="gender" value={formData.gender} onChange={handleChange} className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white">
                    <option value="">Select Gender *</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>
              </div>

              <div className="border-b border-gray-200 pb-4 mb-2">
                <h2 className="text-lg font-semibold text-gray-700 mb-3">📖 Academic Information</h2>
                <div className="grid sm:grid-cols-2 gap-3">
                  <select name="grade" value={formData.grade} onChange={handleChange} className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white">
                    <option value="">Select Grade *</option>
                    {grades.map((g) => (
                      <option key={g.id} value={g.name}>{g.name}</option>
                    ))}
                  </select>
                  <select name="section" value={formData.section} onChange={handleChange} className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white">
                    <option value="">Select Section *</option>
                    {sections.map((s) => (
                      <option key={s.id} value={s.name}>{s.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="border-b border-gray-200 pb-4 mb-2">
                <h2 className="text-lg font-semibold text-gray-700 mb-3">👨‍👩‍👦 Parent Information</h2>
                <div className="grid sm:grid-cols-2 gap-3">
                  <input name="parentName" value={formData.parentName} onChange={handleChange} placeholder="Parent Name *" className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition" />
                  <input type="tel" name="parentPhone" value={formData.parentPhone} onChange={handleChange} placeholder="Parent Phone *" className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition" />
                  <input type="email" name="parentEmail" value={formData.parentEmail} onChange={handleChange} placeholder="Parent Email" className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition" />
                  <input type="tel" name="emergencyPhone" value={formData.emergencyPhone} onChange={handleChange} placeholder="Emergency Phone" className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition" />
                </div>
              </div>

              <div className="pb-2">
                <h2 className="text-lg font-semibold text-gray-700 mb-3">🔐 Login Credentials</h2>
                <div className="grid gap-3">
                  <div className="relative">
                    <input type={showPassword ? "text" : "password"} name="password" value={formData.password} onChange={handleChange} placeholder="Password (min 6 chars) *" className="border rounded-lg p-3 w-full focus:ring-2 focus:ring-blue-500 outline-none transition pr-12" minLength="6" />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700">
                      {showPassword ? "🙈" : "👁️"}
                    </button>
                  </div>
                  <input type={showPassword ? "text" : "password"} name="confirmPassword" value={formData.confirmPassword} onChange={handleChange} placeholder="Confirm Password *" className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition" />
                </div>
                <p className="text-xs text-gray-400 mt-2">ℹ️ Student will login using: <strong>{nextStudentId || "Student ID"}</strong></p>
              </div>

              <button onClick={addStudent} disabled={!isFormValid || loading} className={`w-full py-4 rounded-lg font-semibold text-white transition ${isFormValid && !loading ? "bg-blue-700 hover:bg-blue-800 hover:shadow-lg" : "bg-gray-400 cursor-not-allowed"}`}>
                {loading ? (
                  <span className="flex items-center justify-center gap-2">
                    <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Creating Student Account...
                  </span>
                ) : (
                  "Create Student Account"
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}