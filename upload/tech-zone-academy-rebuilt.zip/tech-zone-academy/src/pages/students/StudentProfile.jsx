// src/pages/StudentProfile.jsx
import { useAuth } from "../../context/AuthContext";
import { useEffect, useState } from "react";
import { db, doc, getDoc, collection, query, where, getDocs } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";
import SEO from "../../components/SEO";
import { formatPercent, resultPercentage, studentName } from "../dashboardUtils";

export default function StudentProfile() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [studentData, setStudentData] = useState(null);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchStudentData = async () => {
    try {
      // Get student data
      const studentDoc = await getDoc(doc(db, "students", user.uid));
      if (studentDoc.exists()) {
        setStudentData({ id: studentDoc.id, ...studentDoc.data() });

        // Get student results
        const q = query(
          collection(db, "results"),
          where("studentId", "==", studentDoc.data().studentId)
        );
        const snapshot = await getDocs(q);
        const resultsData = [];
        snapshot.forEach((doc) => {
          resultsData.push(doc.data());
        });
        setResults(resultsData);
      }
    } catch (error) {
      console.error("Error fetching student data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchStudentData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- re-run only when the authenticated user changes
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading profile...</p>
        </div>
      </div>
    );
  }

  if (!studentData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <p className="text-gray-600">No student data found.</p>
        </div>
      </div>
    );
  }

  const validPercentages = results.map(resultPercentage).filter((value) => value !== null);
  const average = validPercentages.length
    ? validPercentages.reduce((sum, value) => sum + value, 0) / validPercentages.length
    : null;

  return (
    <>
    <SEO title="Student Profile" noindex />
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <button onClick={() => navigate(-1)} className="text-gray-600 hover:text-gray-800 transition">
            ← Back
          </button>
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">🎓 Student Profile</h1>
        </div>

        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-orange-600 to-orange-800 px-6 py-8">
            <div className="flex items-center gap-6">
              <div className="w-24 h-24 rounded-full bg-white/20 flex items-center justify-center text-4xl text-white font-bold border-4 border-white">
                {studentData.firstName?.charAt(0) || "S"}
              </div>
              <div className="text-white">
                <h2 className="text-2xl font-bold">{studentName(studentData)}</h2>
                <p className="text-orange-200">ID: {studentData.studentId}</p>
                <div className="flex flex-wrap gap-2 mt-2">
                  <span className="bg-orange-700 px-3 py-1 rounded-full text-sm font-medium">
                    {studentData.grade}
                  </span>
                  <span className="bg-orange-700 px-3 py-1 rounded-full text-sm font-medium">
                    Section {studentData.section}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="p-6 space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Student ID</p>
                <p className="font-semibold text-gray-800">{studentData.studentId || "N/A"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Grade</p>
                <p className="font-semibold text-gray-800">{studentData.grade || "N/A"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Section</p>
                <p className="font-semibold text-gray-800">{studentData.section || "N/A"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Gender</p>
                <p className="font-semibold text-gray-800">{studentData.gender || "N/A"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Parent Name</p>
                <p className="font-semibold text-gray-800">{studentData.parentName || "N/A"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Parent Phone</p>
                <p className="font-semibold text-gray-800">{studentData.parentPhone || "N/A"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Parent Email</p>
                <p className="break-words font-semibold text-gray-800">{studentData.parentEmail || "N/A"}</p>
              </div>
            </div>

            {results.length > 0 && (
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500 mb-2">Results Summary</p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <div className="bg-white rounded p-2 text-center">
                    <p className="text-lg font-bold text-blue-600">{results.length}</p>
                    <p className="text-xs text-gray-500">Total Results</p>
                  </div>
                  <div className="bg-white rounded p-2 text-center">
                    <p className="text-lg font-bold text-green-600">
                      {formatPercent(average)}
                    </p>
                    <p className="text-xs text-gray-500">Average</p>
                  </div>
                </div>
              </div>
            )}

            <button
              onClick={() => navigate("/profile")}
              className="w-full bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition font-medium"
            >
              ⚙️ Edit Profile & Security
            </button>
          </div>
        </div>
      </div>
    </div>
    </>
  );
}
