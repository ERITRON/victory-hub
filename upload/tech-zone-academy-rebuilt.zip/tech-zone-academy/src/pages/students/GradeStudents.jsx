import { useNavigate, useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { db, collection, getDocs, query, where } from "../../supabase/supabase";

export default function GradeStudents() {
  const { grade } = useParams();
  const navigate = useNavigate();

  const [sections, setSections] = useState([]);
  const [studentCounts, setStudentCounts] = useState({});
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");

  const fetchData = async () => {
    setLoading(true);
    setErrorMessage("");

    try {
      // Fetch sections from Firestore
      const sectionsSnap = await getDocs(collection(db, "sections"));
      const sectionsData = sectionsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSections(sectionsData.sort((a, b) => a.name.localeCompare(b.name)));

      // Fetch student counts per section
      const counts = {};
      for (const section of sectionsData) {
        const q = query(
          collection(db, "students"),
          where("grade", "==", grade),
          where("section", "==", section.name)
        );
        const snapshot = await getDocs(q);
        counts[section.name] = snapshot.size;
      }
      setStudentCounts(counts);

    } catch (error) {
      setErrorMessage("Error loading data: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps -- re-run only when the grade route param changes
  }, [grade]);

  const getStudentCount = (sectionName) => {
    return studentCounts[sectionName] || 0;
  };

  const getSectionColor = (index) => {
    const colors = [
      "border-l-4 border-blue-500 hover:bg-blue-50",
      "border-l-4 border-green-500 hover:bg-green-50",
      "border-l-4 border-purple-500 hover:bg-purple-50",
      "border-l-4 border-orange-500 hover:bg-orange-50",
      "border-l-4 border-red-500 hover:bg-red-50",
      "border-l-4 border-teal-500 hover:bg-teal-50",
      "border-l-4 border-pink-500 hover:bg-pink-50",
      "border-l-4 border-indigo-500 hover:bg-indigo-50",
    ];
    return colors[index % colors.length];
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading sections...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => navigate("/student-list")}
                  className="text-gray-600 hover:text-gray-800 transition"
                >
                  ← Back
                </button>
                <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
                  📚 {grade}
                </h1>
              </div>
              <p className="text-gray-600 mt-1">
                Select a section to view students
              </p>
            </div>
            <div className="flex items-center gap-3">
              <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
                {sections.length} Sections
              </span>
              <button
                onClick={fetchData}
                className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition text-sm flex items-center gap-2"
              >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h3.992v3.992m0-3.992-6.3 6.3a2.25 2.25 0 01-3.182 0l-3.7-3.7a2.25 2.25 0 010-3.182l6.3-6.3a2.25 2.25 0 013.182 0l3.7 3.7z" />
                </svg>
                Refresh
              </button>
            </div>
          </div>
        </div>

        {/* Error Message */}
        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Sections Grid */}
        {sections.length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-6xl mb-4">📭</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No Sections Found</h3>
            <p className="text-gray-500">
              No sections have been added to the system yet.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
            {sections.map((section, index) => {
              const count = getStudentCount(section.name);
              return (
                <div
                  key={section.id}
                  onClick={() =>
                    navigate(`/student-list/${grade}/${section.name}`)
                  }
                  className={`
                    bg-white rounded-xl shadow-md p-6 cursor-pointer 
                    transition-all duration-300 hover:shadow-xl hover:-translate-y-1
                    ${getSectionColor(index)}
                  `}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h2 className="text-2xl font-bold text-gray-800">
                        Section {section.name}
                      </h2>
                      <p className="text-sm text-gray-500 mt-1">
                        {count} student{count !== 1 ? "s" : ""}
                      </p>
                    </div>
                    <div className="text-3xl">
                      {count > 0 ? "👨‍🎓" : "📭"}
                    </div>
                  </div>
                  
                  <div className="mt-4 flex items-center gap-2">
                    <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-blue-600 rounded-full transition-all duration-500"
                        style={{ 
                          width: count > 0 ? `${Math.min((count / 50) * 100, 100)}%` : "0%" 
                        }}
                      />
                    </div>
                    <span className="text-xs text-gray-500">
                      {count > 0 ? `${Math.min(Math.round((count / 50) * 100), 100)}%` : "0%"}
                    </span>
                  </div>

                  <div className="mt-3 flex justify-end">
                    <span className="text-sm text-blue-600 font-medium">
                      View Students →
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Summary Footer */}
        {sections.length > 0 && (
          <div className="mt-8 bg-white rounded-xl shadow p-4 text-center">
            <p className="text-sm text-gray-600">
              Showing <strong>{sections.length}</strong> sections for <strong>{grade}</strong>
              {Object.values(studentCounts).reduce((a, b) => a + b, 0) > 0 && (
                <> with <strong>{Object.values(studentCounts).reduce((a, b) => a + b, 0)}</strong> total students</>
              )}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}