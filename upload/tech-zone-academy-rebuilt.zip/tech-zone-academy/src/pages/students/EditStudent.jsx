import { useState, useEffect } from "react";
import { db, doc, getDoc, updateDoc, collection, getDocs } from "../../supabase/supabase";
import { useParams, useNavigate } from "react-router-dom";

export default function EditStudent() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [grades, setGrades] = useState([]);
  const [sections, setSections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const [formData, setFormData] = useState({
    studentId: "",
    firstName: "",
    fatherName: "",
    grandfatherName: "",
    gender: "",
    grade: "",
    section: "",
    parentName: "",
    parentPhone: "",
    parentEmail: "",
    emergencyPhone: "",
  });

  const nameRegex = /^[A-Za-z\s]+$/;
  const phoneRegex = /^(09\d{8}|07\d{8}|\+2519\d{8}|\+2517\d{8})$/;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  const fetchStudent = async () => {
    try {
      const docRef = doc(db, "students", id);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const data = docSnap.data();
        setFormData({
          studentId: data.studentId || "",
          firstName: data.firstName || "",
          fatherName: data.fatherName || "",
          grandfatherName: data.grandfatherName || "",
          gender: data.gender || "",
          grade: data.grade || "",
          section: data.section || "",
          parentName: data.parentName || "",
          parentPhone: data.parentPhone || "",
          parentEmail: data.parentEmail || "",
          emergencyPhone: data.emergencyPhone || "",
        });
      } else {
        setErrorMessage("Student not found");
        setTimeout(() => navigate("/student-list"), 2000);
      }
    } catch (error) {
      setErrorMessage("Error loading student: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    }
  };

  const fetchAllData = async () => {
    setLoading(true);
    setErrorMessage("");

    try {
      // Fetch grades
      const gradesSnap = await getDocs(collection(db, "grades"));
      const gradesData = gradesSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setGrades(gradesData.sort((a, b) => a.name.localeCompare(b.name)));

      // Fetch sections
      const sectionsSnap = await getDocs(collection(db, "sections"));
      const sectionsData = sectionsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSections(sectionsData.sort((a, b) => a.name.localeCompare(b.name)));

      // Fetch student
      await fetchStudent();

    } catch (error) {
      setErrorMessage("Error loading data: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
    // eslint-disable-next-line react-hooks/exhaustive-deps -- re-run only when the student id changes; fetchAllData is stable for a given id
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    const {
      firstName,
      fatherName,
      gender,
      grade,
      section,
      parentName,
      parentPhone,
      parentEmail,
      emergencyPhone,
    } = formData;

    if (!firstName) {
      setErrorMessage("First Name is required");
      return false;
    }
    if (!nameRegex.test(firstName)) {
      setErrorMessage("First Name must contain letters only");
      return false;
    }
    if (!fatherName) {
      setErrorMessage("Father Name is required");
      return false;
    }
    if (!nameRegex.test(fatherName)) {
      setErrorMessage("Father Name must contain letters only");
      return false;
    }
    if (!gender) {
      setErrorMessage("Please select gender");
      return false;
    }
    if (!grade) {
      setErrorMessage("Please select grade");
      return false;
    }
    if (!section) {
      setErrorMessage("Please select section");
      return false;
    }
    if (!parentName) {
      setErrorMessage("Parent Name is required");
      return false;
    }
    if (!nameRegex.test(parentName)) {
      setErrorMessage("Parent Name must contain letters only");
      return false;
    }
    if (!parentPhone) {
      setErrorMessage("Parent Phone is required");
      return false;
    }
    if (!phoneRegex.test(parentPhone)) {
      setErrorMessage("Please enter a valid Ethiopian phone number");
      return false;
    }
    if (parentEmail && !emailRegex.test(parentEmail)) {
      setErrorMessage("Please enter a valid email address");
      return false;
    }
    if (emergencyPhone && !phoneRegex.test(emergencyPhone)) {
      setErrorMessage("Please enter a valid emergency phone number");
      return false;
    }
    return true;
  };

  const updateStudent = async () => {
    setSubmitting(true);
    setErrorMessage("");
    setSuccessMessage("");

    if (!validateForm()) {
      setSubmitting(false);
      return;
    }

    try {
      const {
        studentId,
        firstName,
        fatherName,
        grandfatherName,
        gender,
        grade,
        section,
        parentName,
        parentPhone,
        parentEmail,
        emergencyPhone,
      } = formData;

      await updateDoc(doc(db, "students", id), {
        studentId,
        firstName,
        fatherName,
        grandfatherName,
        gender,
        grade,
        section,
        parentName,
        parentPhone,
        parentEmail: parentEmail || "",
        emergencyPhone: emergencyPhone || "",
        updatedAt: new Date().toISOString(),
      });

      setSuccessMessage(`✅ Student ${firstName} ${fatherName} updated successfully!`);
      
      setTimeout(() => {
        navigate(`/student-list/${grade}/${section}`);
      }, 1500);

    } catch (error) {
      setErrorMessage("Error updating student: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setSubmitting(false);
    }
  };

  const isFormValid = 
    formData.firstName &&
    formData.fatherName &&
    formData.gender &&
    formData.grade &&
    formData.section &&
    formData.parentName &&
    formData.parentPhone;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading student data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate(-1)}
              className="text-gray-600 hover:text-gray-800 transition"
            >
              ← Back
            </button>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
                ✏️ Edit Student
              </h1>
              <p className="text-gray-600 mt-1">
                Update student information
              </p>
            </div>
          </div>
        </div>

        {/* Messages */}
        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Form Card */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-6 sm:p-8">
            {/* Student ID Display */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <p className="text-sm text-gray-600">Student ID</p>
              <p className="text-2xl font-bold text-blue-700">{formData.studentId}</p>
            </div>

            <div className="grid gap-4">
              {/* Personal Information */}
              <div className="border-b border-gray-200 pb-4 mb-2">
                <h2 className="text-lg font-semibold text-gray-700 mb-3">
                  👤 Personal Information
                </h2>
                <div className="grid sm:grid-cols-2 gap-3">
                  <input
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleChange}
                    placeholder="First Name *"
                    className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition"
                  />
                  <input
                    name="fatherName"
                    value={formData.fatherName}
                    onChange={handleChange}
                    placeholder="Father Name *"
                    className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition"
                  />
                  <input
                    name="grandfatherName"
                    value={formData.grandfatherName}
                    onChange={handleChange}
                    placeholder="Grandfather Name"
                    className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition"
                  />
                  <select
                    name="gender"
                    value={formData.gender}
                    onChange={handleChange}
                    className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
                  >
                    <option value="">Select Gender *</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>
              </div>

              {/* Academic Information */}
              <div className="border-b border-gray-200 pb-4 mb-2">
                <h2 className="text-lg font-semibold text-gray-700 mb-3">
                  📖 Academic Information
                </h2>
                <div className="grid sm:grid-cols-2 gap-3">
                  <select
                    name="grade"
                    value={formData.grade}
                    onChange={handleChange}
                    className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
                  >
                    <option value="">Select Grade *</option>
                    {grades.map((g) => (
                      <option key={g.id} value={g.name}>{g.name}</option>
                    ))}
                  </select>
                  <select
                    name="section"
                    value={formData.section}
                    onChange={handleChange}
                    className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
                  >
                    <option value="">Select Section *</option>
                    {sections.map((s) => (
                      <option key={s.id} value={s.name}>{s.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Parent Information */}
              <div className="border-b border-gray-200 pb-4 mb-2">
                <h2 className="text-lg font-semibold text-gray-700 mb-3">
                  👨‍👩‍👦 Parent Information
                </h2>
                <div className="grid sm:grid-cols-2 gap-3">
                  <input
                    name="parentName"
                    value={formData.parentName}
                    onChange={handleChange}
                    placeholder="Parent Name *"
                    className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition"
                  />
                  <input
                    type="tel"
                    name="parentPhone"
                    value={formData.parentPhone}
                    onChange={handleChange}
                    placeholder="Parent Phone *"
                    className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition"
                  />
                  <input
                    type="email"
                    name="parentEmail"
                    value={formData.parentEmail}
                    onChange={handleChange}
                    placeholder="Parent Email"
                    className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition"
                  />
                  <input
                    type="tel"
                    name="emergencyPhone"
                    value={formData.emergencyPhone}
                    onChange={handleChange}
                    placeholder="Emergency Phone"
                    className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 mt-4">
                <button
                  onClick={updateStudent}
                  disabled={!isFormValid || submitting}
                  className={`flex-1 py-3 rounded-lg font-semibold text-white transition ${
                    isFormValid && !submitting
                      ? "bg-blue-700 hover:bg-blue-800 hover:shadow-lg"
                      : "bg-gray-400 cursor-not-allowed"
                  }`}
                >
                  {submitting ? (
                    <span className="flex items-center justify-center gap-2">
                      <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Updating...
                    </span>
                  ) : (
                    "💾 Update Student"
                  )}
                </button>
                <button
                  onClick={() => navigate(-1)}
                  className="px-6 py-3 rounded-lg font-semibold text-gray-700 bg-gray-200 hover:bg-gray-300 transition"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}