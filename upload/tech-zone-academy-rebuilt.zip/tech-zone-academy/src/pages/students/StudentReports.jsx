// src/pages/students/StudentReports.jsx
import { useEffect, useMemo, useState } from "react";
import { db, collection, getDocs } from "../../supabase/supabase";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import toast from "react-hot-toast";
import SEO from "../../components/SEO";
import Icon from "../../components/Icon";
import { SkeletonTable } from "../../components/LoadingSkeleton";

const SCHOOL_NAME = "Tech Zone Academy";

function averageColor(avg) {
  if (avg >= 80) return "text-green-700";
  if (avg >= 60) return "text-yellow-700";
  return "text-red-700";
}

function attendanceColor(pct) {
  if (pct >= 90) return "text-green-700";
  if (pct >= 75) return "text-yellow-700";
  return "text-red-700";
}

export default function StudentReports() {
  const [loading, setLoading] = useState(true);
  const [students, setStudents] = useState([]);
  const [results, setResults] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [grades, setGrades] = useState([]);
  const [sections, setSections] = useState([]);

  const [searchTerm, setSearchTerm] = useState("");
  const [selectedGrade, setSelectedGrade] = useState("");
  const [selectedSection, setSelectedSection] = useState("");
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [exporting, setExporting] = useState(false);

  const fetchAllData = async () => {
    setLoading(true);
    try {
      const [studentsSnap, resultsSnap, attendanceSnap, gradesSnap, sectionsSnap] =
        await Promise.all([
          getDocs(collection(db, "students")),
          getDocs(collection(db, "results")),
          getDocs(collection(db, "attendance")),
          getDocs(collection(db, "grades")),
          getDocs(collection(db, "sections")),
        ]);

      setStudents(studentsSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
      setResults(resultsSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
      setAttendance(attendanceSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
      setGrades(
        gradesSnap.docs
          .map((doc) => ({ id: doc.id, ...doc.data() }))
          .sort((a, b) => a.name.localeCompare(b.name))
      );
      setSections(
        sectionsSnap.docs
          .map((doc) => ({ id: doc.id, ...doc.data() }))
          .sort((a, b) => a.name.localeCompare(b.name))
      );
    } catch (error) {
      console.error("Error fetching report data:", error);
      toast.error("Failed to load report data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  // Build one report row per student: results count, average score, attendance %
  const reportRows = useMemo(() => {
    return students.map((student) => {
      const sid = student.studentId || student.id;

      const studentResults = results.filter((r) => r.studentId === sid);
      let totalScore = 0;
      let totalMax = 0;
      studentResults.forEach((r) => {
        totalScore += r.score || 0;
        totalMax += r.outOf || 0;
      });
      const averageScore = totalMax > 0 ? Math.round((totalScore / totalMax) * 100) : 0;

      const studentAttendance = attendance.filter((a) => a.studentId === sid);
      const presentCount = studentAttendance.filter(
        (a) => a.status === "Present" || a.status === "Late"
      ).length;
      const attendancePct =
        studentAttendance.length > 0
          ? Math.round((presentCount / studentAttendance.length) * 100)
          : 0;

      return {
        ...student,
        sid,
        resultsCount: studentResults.length,
        averageScore,
        attendancePct,
        hasAttendance: studentAttendance.length > 0,
      };
    });
  }, [students, results, attendance]);

  const filteredRows = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();
    return reportRows.filter((row) => {
      if (selectedGrade && row.grade !== selectedGrade) return false;
      if (selectedSection && row.section !== selectedSection) return false;
      if (term) {
        const name = (row.fullName || row.firstName || "").toLowerCase();
        const id = (row.sid || "").toString().toLowerCase();
        if (!name.includes(term) && !id.includes(term)) return false;
      }
      return true;
    });
  }, [reportRows, searchTerm, selectedGrade, selectedSection]);

  // Summary stats over the filtered set
  const summary = useMemo(() => {
    const total = filteredRows.length;
    const withResults = filteredRows.filter((r) => r.resultsCount > 0);
    const avgScore =
      withResults.length > 0
        ? Math.round(
            withResults.reduce((sum, r) => sum + r.averageScore, 0) / withResults.length
          )
        : 0;
    const withAttendance = filteredRows.filter((r) => r.hasAttendance);
    const avgAttendance =
      withAttendance.length > 0
        ? Math.round(
            withAttendance.reduce((sum, r) => sum + r.attendancePct, 0) /
              withAttendance.length
          )
        : 0;
    return { total, avgScore, avgAttendance };
  }, [filteredRows]);

  const exportRows = () =>
    filteredRows.map((row) => ({
      name: row.fullName || row.firstName || "—",
      id: row.sid,
      grade: row.grade || "—",
      section: row.section || "—",
      resultsCount: row.resultsCount,
      averageScore: `${row.averageScore}%`,
      attendance: row.hasAttendance ? `${row.attendancePct}%` : "N/A",
    }));

  const filterLabel = () => {
    const parts = [];
    if (selectedGrade) parts.push(selectedGrade);
    if (selectedSection) parts.push(`Section ${selectedSection}`);
    return parts.length ? parts.join(" - ") : "All Students";
  };

  const handleExportPDF = () => {
    if (filteredRows.length === 0) {
      toast.error("No students to export");
      return;
    }
    setExporting(true);
    try {
      const doc = new jsPDF("p", "mm", "a4");
      doc.setFontSize(18);
      doc.text(SCHOOL_NAME, 14, 20);
      doc.setFontSize(13);
      doc.text(`Student Report — ${filterLabel()}`, 14, 29);
      doc.setFontSize(9);
      doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 36);

      autoTable(doc, {
        startY: 42,
        head: [["Name", "ID", "Grade", "Section", "Results", "Avg Score", "Attendance"]],
        body: exportRows().map((r) => Object.values(r)),
        theme: "striped",
        styles: { fontSize: 8 },
        headStyles: { fillColor: [29, 78, 216] },
      });

      const pageCount = doc.internal.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.text(
          `Page ${i} of ${pageCount}`,
          doc.internal.pageSize.width / 2,
          doc.internal.pageSize.height - 8,
          { align: "center" }
        );
      }

      doc.save(`student-report-${new Date().toISOString().slice(0, 10)}.pdf`);
      toast.success("PDF exported");
    } catch (error) {
      console.error("PDF export failed:", error);
      toast.error("PDF export failed");
    } finally {
      setExporting(false);
    }
  };

  const handleExportExcel = () => {
    if (filteredRows.length === 0) {
      toast.error("No students to export");
      return;
    }
    setExporting(true);
    try {
      const worksheet = XLSX.utils.json_to_sheet(
        exportRows().map((r) => ({
          Name: r.name,
          "Student ID": r.id,
          Grade: r.grade,
          Section: r.section,
          "Results Count": r.resultsCount,
          "Average Score": r.averageScore,
          "Attendance %": r.attendance,
        }))
      );
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Student Report");
      XLSX.writeFile(
        workbook,
        `student-report-${new Date().toISOString().slice(0, 10)}.xlsx`
      );
      toast.success("Excel exported");
    } catch (error) {
      console.error("Excel export failed:", error);
      toast.error("Excel export failed");
    } finally {
      setExporting(false);
    }
  };

  // ---- Detailed report for the clicked student ----
  const studentDetail = useMemo(() => {
    if (!selectedStudent) return null;
    const sid = selectedStudent.sid;

    const studentResults = results.filter((r) => r.studentId === sid);

    // Per-subject breakdown
    const subjects = {};
    studentResults.forEach((r) => {
      const key = r.subject || "Other";
      if (!subjects[key]) subjects[key] = { score: 0, outOf: 0, count: 0 };
      subjects[key].score += r.score || 0;
      subjects[key].outOf += r.outOf || 0;
      subjects[key].count += 1;
    });
    const subjectRows = Object.entries(subjects)
      .map(([subject, s]) => ({
        subject,
        count: s.count,
        percentage: s.outOf > 0 ? Math.round((s.score / s.outOf) * 100) : 0,
      }))
      .sort((a, b) => a.subject.localeCompare(b.subject));

    const studentAttendance = attendance.filter((a) => a.studentId === sid);
    const attendanceSummary = {
      total: studentAttendance.length,
      present: studentAttendance.filter((a) => a.status === "Present").length,
      absent: studentAttendance.filter((a) => a.status === "Absent").length,
      late: studentAttendance.filter((a) => a.status === "Late").length,
      excused: studentAttendance.filter((a) => a.status === "Excused").length,
    };

    return { subjectRows, attendanceSummary };
  }, [selectedStudent, results, attendance]);

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <SEO
        title="Student Reports"
        description="Generate and view student academic and attendance reports"
        noindex
      />

      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 inline-flex items-center gap-3">
              <Icon name="chart" className="text-blue-700" />
              Student Reports
            </h1>
            <p className="text-gray-600 mt-1">
              Academic results and attendance overview for every student
            </p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={handleExportPDF}
              disabled={exporting || loading}
              className="inline-flex items-center gap-2 bg-red-600 text-white px-4 py-2.5 rounded-lg hover:bg-red-700 transition text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Icon name="download" />
              Export PDF
            </button>
            <button
              onClick={handleExportExcel}
              disabled={exporting || loading}
              className="inline-flex items-center gap-2 bg-green-600 text-white px-4 py-2.5 rounded-lg hover:bg-green-700 transition text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Icon name="download" />
              Export Excel
            </button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-xl shadow p-4 border-l-4 border-blue-500">
            <div className="text-2xl font-bold text-blue-700">{summary.total}</div>
            <div className="text-sm text-gray-600">Students Shown</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 border-l-4 border-green-500">
            <div className={`text-2xl font-bold ${averageColor(summary.avgScore)}`}>
              {summary.avgScore}%
            </div>
            <div className="text-sm text-gray-600">Average Score</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 border-l-4 border-purple-500">
            <div className={`text-2xl font-bold ${attendanceColor(summary.avgAttendance)}`}>
              {summary.avgAttendance}%
            </div>
            <div className="text-sm text-gray-600">Average Attendance</div>
          </div>
        </div>

        {/* Search + Filters */}
        <div className="bg-white rounded-xl shadow p-4 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                <Icon name="search" />
              </span>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by name or student ID..."
                className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm"
              />
            </div>
            <select
              value={selectedGrade}
              onChange={(e) => setSelectedGrade(e.target.value)}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm bg-white"
            >
              <option value="">All Grades</option>
              {grades.map((g) => (
                <option key={g.id} value={g.name}>
                  {g.name}
                </option>
              ))}
            </select>
            <select
              value={selectedSection}
              onChange={(e) => setSelectedSection(e.target.value)}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm bg-white"
            >
              <option value="">All Sections</option>
              {sections.map((s) => (
                <option key={s.id} value={s.name}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Student Cards */}
        {loading ? (
          <SkeletonTable rows={8} cols={4} />
        ) : filteredRows.length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-gray-300 mb-3">
              <Icon name="search" size="3x" />
            </div>
            <h3 className="text-lg font-semibold text-gray-700">No students found</h3>
            <p className="text-sm text-gray-500 mt-1">
              Try adjusting your search or filters
            </p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {filteredRows.map((row) => (
              <div
                key={row.id}
                onClick={() => setSelectedStudent(row)}
                className="bg-white border-2 border-gray-100 rounded-xl p-5 cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-blue-200"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 className="text-base font-bold text-gray-800 truncate">
                      {row.fullName || row.firstName || "Unnamed Student"}
                    </h3>
                    <p className="text-xs text-gray-500 mt-0.5">{row.sid}</p>
                  </div>
                  <span className="shrink-0 text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200 rounded-full px-2.5 py-1">
                    {row.grade || "—"} {row.section ? `• ${row.section}` : ""}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 mt-4 text-center">
                  <div className="bg-gray-50 rounded-lg py-2">
                    <div className="text-lg font-bold text-gray-800">
                      {row.resultsCount}
                    </div>
                    <div className="text-[10px] text-gray-500">Results</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg py-2">
                    <div className={`text-lg font-bold ${averageColor(row.averageScore)}`}>
                      {row.resultsCount > 0 ? `${row.averageScore}%` : "—"}
                    </div>
                    <div className="text-[10px] text-gray-500">Avg Score</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg py-2">
                    <div
                      className={`text-lg font-bold ${
                        row.hasAttendance ? attendanceColor(row.attendancePct) : "text-gray-400"
                      }`}
                    >
                      {row.hasAttendance ? `${row.attendancePct}%` : "—"}
                    </div>
                    <div className="text-[10px] text-gray-500">Attendance</div>
                  </div>
                </div>

                <div className="mt-3 flex justify-end text-xs text-blue-600 font-medium">
                  View detailed report →
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Detailed Report Modal */}
      {selectedStudent && studentDetail && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
          onClick={() => setSelectedStudent(null)}
        >
          <div
            className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[85vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal header */}
            <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 flex items-center justify-between rounded-t-2xl">
              <div>
                <h2 className="text-lg font-bold text-gray-800">
                  {selectedStudent.fullName || selectedStudent.firstName}
                </h2>
                <p className="text-xs text-gray-500">
                  {selectedStudent.sid} • {selectedStudent.grade || "—"}
                  {selectedStudent.section ? ` • Section ${selectedStudent.section}` : ""}
                </p>
              </div>
              <button
                onClick={() => setSelectedStudent(null)}
                className="text-gray-400 hover:text-gray-600 transition p-1"
                aria-label="Close"
              >
                <Icon name="close" size="lg" />
              </button>
            </div>

            <div className="px-6 py-5 space-y-6">
              {/* Overview */}
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-blue-50 border border-blue-100 rounded-lg py-3">
                  <div className="text-xl font-bold text-blue-700">
                    {selectedStudent.resultsCount}
                  </div>
                  <div className="text-xs text-gray-600">Total Results</div>
                </div>
                <div className="bg-green-50 border border-green-100 rounded-lg py-3">
                  <div
                    className={`text-xl font-bold ${averageColor(selectedStudent.averageScore)}`}
                  >
                    {selectedStudent.resultsCount > 0
                      ? `${selectedStudent.averageScore}%`
                      : "—"}
                  </div>
                  <div className="text-xs text-gray-600">Average Score</div>
                </div>
                <div className="bg-purple-50 border border-purple-100 rounded-lg py-3">
                  <div
                    className={`text-xl font-bold ${
                      selectedStudent.hasAttendance
                        ? attendanceColor(selectedStudent.attendancePct)
                        : "text-gray-400"
                    }`}
                  >
                    {selectedStudent.hasAttendance
                      ? `${selectedStudent.attendancePct}%`
                      : "—"}
                  </div>
                  <div className="text-xs text-gray-600">Attendance</div>
                </div>
              </div>

              {/* Subject breakdown */}
              <div>
                <h3 className="text-sm font-bold text-gray-700 mb-2 inline-flex items-center gap-2">
                  <Icon name="book" className="text-blue-600" />
                  Performance by Subject
                </h3>
                {studentDetail.subjectRows.length === 0 ? (
                  <p className="text-sm text-gray-500">No results recorded yet.</p>
                ) : (
                  <div className="space-y-2">
                    {studentDetail.subjectRows.map((s) => (
                      <div key={s.subject} className="flex items-center gap-3">
                        <div className="w-32 shrink-0 text-sm text-gray-700 truncate">
                          {s.subject}
                        </div>
                        <div className="flex-1 bg-gray-100 rounded-full h-2.5 overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              s.percentage >= 80
                                ? "bg-green-500"
                                : s.percentage >= 60
                                  ? "bg-yellow-500"
                                  : "bg-red-500"
                            }`}
                            style={{ width: `${Math.min(s.percentage, 100)}%` }}
                          />
                        </div>
                        <div
                          className={`w-12 shrink-0 text-right text-sm font-semibold ${averageColor(s.percentage)}`}
                        >
                          {s.percentage}%
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Attendance breakdown */}
              <div>
                <h3 className="text-sm font-bold text-gray-700 mb-2 inline-flex items-center gap-2">
                  <Icon name="calendar" className="text-purple-600" />
                  Attendance Summary
                </h3>
                {studentDetail.attendanceSummary.total === 0 ? (
                  <p className="text-sm text-gray-500">No attendance records yet.</p>
                ) : (
                  <div className="grid grid-cols-4 gap-2 text-center">
                    <div className="bg-green-50 border border-green-100 rounded-lg py-2">
                      <div className="text-lg font-bold text-green-700">
                        {studentDetail.attendanceSummary.present}
                      </div>
                      <div className="text-[10px] text-gray-600">Present</div>
                    </div>
                    <div className="bg-red-50 border border-red-100 rounded-lg py-2">
                      <div className="text-lg font-bold text-red-700">
                        {studentDetail.attendanceSummary.absent}
                      </div>
                      <div className="text-[10px] text-gray-600">Absent</div>
                    </div>
                    <div className="bg-yellow-50 border border-yellow-100 rounded-lg py-2">
                      <div className="text-lg font-bold text-yellow-700">
                        {studentDetail.attendanceSummary.late}
                      </div>
                      <div className="text-[10px] text-gray-600">Late</div>
                    </div>
                    <div className="bg-purple-50 border border-purple-100 rounded-lg py-2">
                      <div className="text-lg font-bold text-purple-700">
                        {studentDetail.attendanceSummary.excused}
                      </div>
                      <div className="text-[10px] text-gray-600">Excused</div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
