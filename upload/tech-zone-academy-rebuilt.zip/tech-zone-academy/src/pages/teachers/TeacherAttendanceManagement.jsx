// src/pages/TeacherAttendanceManagement.jsx
import { useEffect, useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { db, collection, getDocs, addDoc, updateDoc, deleteDoc, doc, query, where } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";

export default function TeacherAttendanceManagement() {
  const { user, role } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [teachers, setTeachers] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [selectedDate, setSelectedDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [searchTerm, setSearchTerm] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editingRecord, setEditingRecord] = useState(null);
  const [formData, setFormData] = useState({
    teacherId: "",
    teacherName: "",
    status: "Present",
    time: "",
    date: new Date().toISOString().split("T")[0],
    note: "",
  });

  const statusOptions = [
    { value: "Present", label: "✅ Present", color: "bg-green-100 text-green-700" },
    { value: "Late", label: "⏰ Late", color: "bg-yellow-100 text-yellow-700" },
    { value: "Absent", label: "❌ Absent", color: "bg-red-100 text-red-700" },
    { value: "Excused", label: "📝 Excused", color: "bg-blue-100 text-blue-700" },
    { value: "Leave", label: "🏖️ Leave", color: "bg-purple-100 text-purple-700" },
  ];

  useEffect(() => {
    if (role === "admin" || role === "vice_principal") {
      fetchData();
    }
  }, [selectedDate]);

  // ✅ Check if user has access (Admin or Vice Principal)
  if (role !== "admin" && role !== "vice_principal") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">🚫</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h2>
          <p className="text-gray-600">You need admin or vice principal privileges to access this page.</p>
          <button
            onClick={() => navigate(role === "vice_principal" ? "/vice-principal/dashboard" : "/admin-dashboard")}
            className="mt-4 bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  async function fetchData() {
    setLoading(true);
    try {
      // Fetch teachers
      const teachersSnap = await getDocs(collection(db, "teachers"));
      const teachersData = teachersSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setTeachers(teachersData);

      // ✅ FIXED: Remove orderBy to avoid composite index
      const attendanceSnap = await getDocs(
        query(
          collection(db, "teacherAttendance"),
          where("date", "==", selectedDate)
        )
      );
      const attendanceData = attendanceSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      
      // ✅ Sort in JavaScript instead of using orderBy
      setAttendance(attendanceData.sort((a, b) => {
        return new Date(b.createdAt) - new Date(a.createdAt);
      }));
    } catch (error) {
      setErrorMessage("Error loading data: " + error.message);
    } finally {
      setLoading(false);
    }
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleTeacherSelect = (teacherId) => {
    const teacher = teachers.find((t) => t.id === teacherId);
    if (teacher) {
      setFormData((prev) => ({
        ...prev,
        teacherId: teacherId,
        teacherName: `${teacher.firstName} ${teacher.fatherName}`,
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMessage("");
    setSuccessMessage("");

    if (!formData.teacherId) {
      setErrorMessage("Please select a teacher");
      setLoading(false);
      return;
    }

    if (!formData.time) {
      setErrorMessage("Please enter the time");
      setLoading(false);
      return;
    }

    try {
      // Check if attendance already exists for this teacher on this date
      const existingQuery = query(
        collection(db, "teacherAttendance"),
        where("teacherId", "==", formData.teacherId),
        where("date", "==", selectedDate)
      );
      const existingSnap = await getDocs(existingQuery);

      if (!existingSnap.empty && !editingRecord) {
        setErrorMessage("Attendance already recorded for this teacher today");
        setLoading(false);
        return;
      }

      const data = {
        ...formData,
        date: selectedDate,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        recordedBy: user?.uid,
        recordedByName: user?.displayName || user?.email || "System",
      };

      if (editingRecord) {
        await updateDoc(doc(db, "teacherAttendance", editingRecord.id), data);
        setSuccessMessage("✅ Attendance updated successfully!");
      } else {
        await addDoc(collection(db, "teacherAttendance"), data);
        setSuccessMessage("✅ Attendance recorded successfully!");
      }

      setShowModal(false);
      setEditingRecord(null);
      setFormData({
        teacherId: "",
        teacherName: "",
        status: "Present",
        time: "",
        date: selectedDate,
        note: "",
      });
      await fetchData();
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error saving attendance: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this record?")) return;
    try {
      await deleteDoc(doc(db, "teacherAttendance", id));
      setSuccessMessage("✅ Record deleted successfully!");
      await fetchData();
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error deleting record: " + error.message);
    }
  };

  const getStatusBadge = (status) => {
    const found = statusOptions.find((s) => s.value === status);
    return found ? found.color : "bg-gray-100 text-gray-700";
  };

  const getStatusIcon = (status) => {
    const found = statusOptions.find((s) => s.value === status);
    return found ? found.label.split(" ")[0] : "📌";
  };

  const filteredTeachers = teachers.filter((teacher) => {
    const fullName = `${teacher.firstName} ${teacher.fatherName}`.toLowerCase();
    return fullName.includes(searchTerm.toLowerCase()) ||
      teacher.teacherId?.toLowerCase().includes(searchTerm.toLowerCase());
  });

  // Calculate stats
  const presentCount = attendance.filter((a) => a.status === "Present").length;
  const lateCount = attendance.filter((a) => a.status === "Late").length;
  const absentCount = attendance.filter((a) => a.status === "Absent").length;
  const leaveCount = attendance.filter((a) => a.status === "Leave").length;
  const totalRecorded = attendance.length;
  const totalTeachers = teachers.length;
  const notRecorded = totalTeachers - totalRecorded;

  if (loading && teachers.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading teacher attendance...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              👨‍🏫 Teacher Attendance
            </h1>
            <p className="text-gray-600 mt-1">
              Record and manage teacher attendance
            </p>
            {role === "vice_principal" && (
              <p className="text-sm text-purple-600 mt-1">
                👔 Vice Principal • Managing teacher attendance
              </p>
            )}
          </div>
          <div className="flex items-center gap-3">
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
            />
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${
              role === "admin" ? "bg-blue-100 text-blue-700" : "bg-purple-100 text-purple-700"
            }`}>
              {role === "admin" ? "👔 Principal" : "👔 Vice Principal"}
            </span>
            <button
              onClick={() => {
                setEditingRecord(null);
                setFormData({
                  teacherId: "",
                  teacherName: "",
                  status: "Present",
                  time: new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
                  date: selectedDate,
                  note: "",
                });
                setShowModal(true);
              }}
              className="bg-blue-700 text-white px-4 py-2 rounded-lg hover:bg-blue-800 transition"
            >
              ➕ Add Record
            </button>
          </div>
        </div>

        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-blue-500">
            <div className="text-2xl font-bold text-blue-700">{totalTeachers}</div>
            <div className="text-xs text-gray-600">Total Teachers</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-green-500">
            <div className="text-2xl font-bold text-green-700">{presentCount}</div>
            <div className="text-xs text-gray-600">✅ Present</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-yellow-500">
            <div className="text-2xl font-bold text-yellow-700">{lateCount}</div>
            <div className="text-xs text-gray-600">⏰ Late</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-red-500">
            <div className="text-2xl font-bold text-red-700">{absentCount}</div>
            <div className="text-xs text-gray-600">❌ Absent</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-purple-500">
            <div className="text-2xl font-bold text-purple-700">{leaveCount}</div>
            <div className="text-xs text-gray-600">🏖️ Leave</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-orange-500">
            <div className="text-2xl font-bold text-orange-700">{notRecorded}</div>
            <div className="text-xs text-gray-600">Not Recorded</div>
          </div>
        </div>

        {/* Search Teachers */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="🔍 Search teachers by name or ID..."
            className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>

        {/* Attendance Table */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Teacher</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">ID</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Status</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Time</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Note</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan="6" className="px-4 py-8 text-center text-gray-500">
                      <div className="animate-pulse">Loading...</div>
                    </td>
                  </tr>
                ) : attendance.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="px-4 py-8 text-center text-gray-500">
                      No attendance records for {new Date(selectedDate).toLocaleDateString()}
                    </td>
                  </tr>
                ) : (
                  attendance.map((record) => (
                    <tr key={record.id} className="border-b hover:bg-gray-50 transition">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 text-sm font-bold">
                            {record.teacherName?.charAt(0) || "T"}
                          </div>
                          <div>
                            <p className="font-medium text-gray-800">{record.teacherName}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-500">{record.teacherId || "---"}</td>
                      <td className="px-4 py-3 text-center">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(record.status)}`}>
                          {getStatusIcon(record.status)} {record.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center text-sm text-gray-600">{record.time || "---"}</td>
                      <td className="px-4 py-3 text-sm text-gray-500">{record.note || "---"}</td>
                      <td className="px-4 py-3 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => {
                              setEditingRecord(record);
                              setFormData({
                                teacherId: record.teacherId || "",
                                teacherName: record.teacherName || "",
                                status: record.status || "Present",
                                time: record.time || "",
                                date: record.date || selectedDate,
                                note: record.note || "",
                              });
                              setShowModal(true);
                            }}
                            className="text-blue-600 hover:text-blue-800 text-sm"
                            title="Edit"
                          >
                            ✏️
                          </button>
                          <button
                            onClick={() => handleDelete(record.id)}
                            className="text-red-600 hover:text-red-800 text-sm"
                            title="Delete"
                          >
                            🗑️
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          <div className="px-4 py-3 border-t flex items-center justify-between">
            <p className="text-sm text-gray-500">
              Showing {attendance.length} records for {new Date(selectedDate).toLocaleDateString()}
            </p>
            <span className="text-sm text-gray-400">
              {presentCount} Present • {lateCount} Late • {absentCount} Absent • {leaveCount} Leave
            </span>
          </div>
        </div>
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800">
                  {editingRecord ? "✏️ Edit Attendance" : "📋 Record Attendance"}
                </h2>
                <button
                  onClick={() => {
                    setShowModal(false);
                    setEditingRecord(null);
                    setErrorMessage("");
                  }}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ✕
                </button>
              </div>

              {editingRecord && (
                <div className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-700">
                    Editing: <span className="font-semibold">{editingRecord.teacherName}</span>
                  </p>
                  <p className="text-xs text-blue-600">
                    Date: {editingRecord.date} • Status: {editingRecord.status}
                  </p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Teacher *
                  </label>
                  <select
                    value={formData.teacherId}
                    onChange={(e) => handleTeacherSelect(e.target.value)}
                    required
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                  >
                    <option value="">Select Teacher</option>
                    {filteredTeachers.map((teacher) => (
                      <option key={teacher.id} value={teacher.id}>
                        {teacher.firstName} {teacher.fatherName} ({teacher.teacherId})
                      </option>
                    ))}
                  </select>
                  {formData.teacherName && (
                    <p className="text-xs text-green-600 mt-1">
                      Selected: {formData.teacherName}
                    </p>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Status *
                    </label>
                    <select
                      name="status"
                      value={formData.status}
                      onChange={handleInputChange}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                    >
                      {statusOptions.map((status) => (
                        <option key={status.value} value={status.value}>
                          {status.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Time *
                    </label>
                    <input
                      type="time"
                      name="time"
                      value={formData.time}
                      onChange={handleInputChange}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Note
                  </label>
                  <input
                    type="text"
                    name="note"
                    value={formData.note}
                    onChange={handleInputChange}
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="Additional note..."
                  />
                </div>

                <div className="flex gap-3 pt-4 border-t">
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition disabled:bg-gray-400 font-medium"
                  >
                    {loading ? "Saving..." : editingRecord ? "💾 Update" : "✅ Save Record"}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowModal(false);
                      setEditingRecord(null);
                      setErrorMessage("");
                    }}
                    className="px-6 py-3 rounded-lg bg-gray-200 text-gray-700 hover:bg-gray-300 transition font-medium"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}