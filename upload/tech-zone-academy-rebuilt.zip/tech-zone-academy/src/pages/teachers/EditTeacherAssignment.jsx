import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { db, doc, getDoc, updateDoc, collection, getDocs, query, where } from "../../supabase/supabase";

export default function EditTeacherAssignment() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [teachers, setTeachers] = useState([]);
  const [grades, setGrades] = useState([]);
  const [sections, setSections] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const [formData, setFormData] = useState({
    teacherId: "",
    teacherName: "",
    grade: "",
    section: "",
    subject: "",
  });

  const fetchAllData = async () => {
    setLoading(true);
    setErrorMessage("");
    
    try {
      // Fetch teachers
      const teachersSnap = await getDocs(collection(db, "teachers"));
      const teachersData = teachersSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setTeachers(teachersData);

      // Fetch grades
      const gradesSnap = await getDocs(collection(db, "grades"));
      const gradesData = gradesSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setGrades(gradesData.sort((a, b) => a.name.localeCompare(b.name)));

      // Fetch sections
      const sectionsSnap = await getDocs(collection(db, "sections"));
      const sectionsData = sectionsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSections(sectionsData.sort((a, b) => a.name.localeCompare(b.name)));

      // Fetch subjects
      const subjectsSnap = await getDocs(collection(db, "subjects"));
      const subjectsData = subjectsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSubjects(subjectsData.sort((a, b) => a.name.localeCompare(b.name)));

      // Fetch assignment
      await fetchAssignment();

    } catch (error) {
      setErrorMessage("Error loading data: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setLoading(false);
    }
  };

   
  useEffect(() => {
    fetchAllData();
  }, [id]);

  async function fetchAssignment() {
    try {
      const docRef = doc(db, "teacherAssignments", id);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const data = docSnap.data();
        setFormData({
          teacherId: data.teacherId || "",
          teacherName: data.teacherName || "",
          grade: data.grade || "",
          section: data.section || "",
          subject: data.subject || "",
        });
      } else {
        setErrorMessage("Assignment not found");
        setTimeout(() => navigate("/teacher-assignments"), 2000);
      }
    } catch (error) {
      setErrorMessage("Error loading assignment: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    }
  }

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    if (name === "teacherId") {
      const selectedTeacher = teachers.find((teacher) => teacher.id === value);
      if (selectedTeacher) {
        setFormData({
          ...formData,
          teacherId: value,
          teacherName: `${selectedTeacher.firstName} ${selectedTeacher.fatherName}`,
        });
      }
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const updateAssignment = async () => {
    setSubmitting(true);
    setErrorMessage("");
    setSuccessMessage("");

    const { teacherId, teacherName, grade, section, subject } = formData;

    // Validation
    if (!teacherId) {
      setErrorMessage("Please select a teacher");
      setSubmitting(false);
      return;
    }
    if (!grade) {
      setErrorMessage("Please select a grade");
      setSubmitting(false);
      return;
    }
    if (!section) {
      setErrorMessage("Please select a section");
      setSubmitting(false);
      return;
    }
    if (!subject) {
      setErrorMessage("Please select a subject");
      setSubmitting(false);
      return;
    }

    try {
      // Check if another assignment exists for this grade, section, subject (excluding current)
      const assignmentQuery = query(
        collection(db, "teacherAssignments"),
        where("grade", "==", grade),
        where("section", "==", section),
        where("subject", "==", subject)
      );
      const existingAssignments = await getDocs(assignmentQuery);
      
      let duplicateFound = false;
      existingAssignments.forEach((doc) => {
        if (doc.id !== id) {
          duplicateFound = true;
        }
      });

      if (duplicateFound) {
        setErrorMessage(`Another teacher is already assigned to ${grade} - ${section} for ${subject}`);
        setSubmitting(false);
        return;
      }

      await updateDoc(
        doc(db, "teacherAssignments", id),
        {
          teacherId,
          teacherName,
          grade,
          section,
          subject,
          updatedAt: new Date().toISOString(),
        }
      );

      setSuccessMessage(`✅ Assignment updated successfully!`);
      
      setTimeout(() => {
        navigate("/teacher-assignments");
      }, 1500);

    } catch (error) {
      setErrorMessage("Error updating assignment: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setSubmitting(false);
    }
  };

  const isFormValid = formData.teacherId && formData.grade && formData.section && formData.subject;
  const selectedTeacherName = formData.teacherId 
    ? teachers.find(t => t.id === formData.teacherId)?.firstName + " " + teachers.find(t => t.id === formData.teacherId)?.fatherName
    : formData.teacherName;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading assignment...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/teacher-assignments")}
              className="text-gray-600 hover:text-gray-800 transition"
            >
              ← Back
            </button>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
                ✏️ Edit Teacher Assignment
              </h1>
              <p className="text-gray-600 mt-1">
                Update teacher assignment details
              </p>
            </div>
          </div>
        </div>

        {/* Messages */}
        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Form Card */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-6 sm:p-8">
            <div className="grid gap-5">
              {/* Current Assignment Info */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h3 className="font-semibold text-blue-800 mb-2">📋 Current Assignment</h3>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-gray-600">Teacher:</span>
                    <span className="font-medium text-gray-800 block">{formData.teacherName || "Not set"}</span>
                  </div>
                  <div>
                    <span className="text-gray-600">Subject:</span>
                    <span className="font-medium text-gray-800 block">{formData.subject || "Not set"}</span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-gray-600">Class:</span>
                    <span className="font-medium text-gray-800 block">
                      {formData.grade && formData.section 
                        ? `${formData.grade} - ${formData.section}` 
                        : "Not set"}
                    </span>
                  </div>
                </div>
              </div>

              {/* Teacher Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Teacher *
                </label>
                <select
                  name="teacherId"
                  value={formData.teacherId}
                  onChange={handleChange}
                  className={`w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white ${
                    formData.teacherId ? "border-green-500" : "border-gray-300"
                  }`}
                >
                  <option value="">Select Teacher</option>
                  {teachers.map((teacher) => (
                    <option key={teacher.id} value={teacher.id}>
                      {teacher.firstName} {teacher.fatherName} ({teacher.teacherId})
                    </option>
                  ))}
                </select>
                {formData.teacherId && (
                  <p className="text-sm text-green-600 mt-1">
                    Selected: {selectedTeacherName}
                  </p>
                )}
              </div>

              {/* Grade Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Grade *
                </label>
                <select
                  name="grade"
                  value={formData.grade}
                  onChange={handleChange}
                  className={`w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white ${
                    formData.grade ? "border-green-500" : "border-gray-300"
                  }`}
                >
                  <option value="">Select Grade</option>
                  {grades.map((grade) => (
                    <option key={grade.id} value={grade.name}>
                      {grade.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Section Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Section *
                </label>
                <select
                  name="section"
                  value={formData.section}
                  onChange={handleChange}
                  className={`w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white ${
                    formData.section ? "border-green-500" : "border-gray-300"
                  }`}
                >
                  <option value="">Select Section</option>
                  {sections.map((section) => (
                    <option key={section.id} value={section.name}>
                      {section.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Subject Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Subject *
                </label>
                <select
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  className={`w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white ${
                    formData.subject ? "border-green-500" : "border-gray-300"
                  }`}
                >
                  <option value="">Select Subject</option>
                  {subjects.map((subject) => (
                    <option key={subject.id} value={subject.name}>
                      {subject.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Summary Card */}
              {formData.teacherId && formData.grade && formData.section && formData.subject && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 mt-2">
                  <h3 className="font-semibold text-green-800 mb-2">📋 Updated Assignment</h3>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="text-gray-600">Teacher:</span>
                      <span className="font-medium text-gray-800 block">{selectedTeacherName}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Subject:</span>
                      <span className="font-medium text-gray-800 block">{formData.subject}</span>
                    </div>
                    <div className="col-span-2">
                      <span className="text-gray-600">Class:</span>
                      <span className="font-medium text-gray-800 block">{formData.grade} - {formData.section}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 mt-4">
                <button
                  onClick={updateAssignment}
                  disabled={!isFormValid || submitting}
                  className={`flex-1 py-3 rounded-lg font-semibold text-white transition ${
                    isFormValid && !submitting
                      ? "bg-blue-700 hover:bg-blue-800 hover:shadow-lg"
                      : "bg-gray-400 cursor-not-allowed"
                  }`}
                >
                  {submitting ? (
                    <span className="flex items-center justify-center gap-2">
                      <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Updating...
                    </span>
                  ) : (
                    "💾 Update Assignment"
                  )}
                </button>
                <button
                  onClick={() => navigate("/teacher-assignments")}
                  className="px-6 py-3 rounded-lg font-semibold text-gray-700 bg-gray-200 hover:bg-gray-300 transition"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}