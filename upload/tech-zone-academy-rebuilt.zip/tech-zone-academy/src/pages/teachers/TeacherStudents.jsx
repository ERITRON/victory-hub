import { useEffect, useMemo, useState } from "react";
import { collection, getDocs, query, where } from "../../supabase/supabase";
import { useSearchParams } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { db } from "../../supabase/supabase";
import SEO from "../../components/SEO";
import { classKey, sortStudents, studentId, studentName } from "../dashboardUtils";

export default function TeacherStudents() {
  const { user } = useAuth();
  const [params] = useSearchParams();
  const [assignments, setAssignments] = useState([]);
  const [students, setStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [grade, setGrade] = useState(params.get("grade") || "All");
  const [section, setSection] = useState(params.get("section") || "All");

  useEffect(() => {
    if (!user) return;
    let active = true;
    Promise.all([
      getDocs(query(collection(db, "teacherAssignments"), where("teacherId", "==", user.uid))),
      getDocs(collection(db, "students")),
    ]).then(([assignmentSnapshot, studentSnapshot]) => {
      if (!active) return;
      setAssignments(assignmentSnapshot.docs.map((item) => ({ id: item.id, ...item.data() })));
      setStudents(studentSnapshot.docs.map((item) => ({ id: item.id, ...item.data() })));
    }).catch((loadError) => {
      console.error("Unable to load assigned students", loadError);
      if (active) setError("Assigned students could not be loaded.");
    }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [user]);

  const assigned = useMemo(() => {
    const keys = new Set(assignments.map(classKey));
    return sortStudents(students.filter((student) => keys.has(classKey(student))));
  }, [assignments, students]);
  const grades = useMemo(() => [...new Set(assigned.map((item) => item.grade).filter(Boolean))].sort((a, b) => String(a).localeCompare(String(b), undefined, { numeric: true })), [assigned]);
  const sections = useMemo(() => [...new Set(assigned.filter((item) => grade === "All" || item.grade === grade).map((item) => item.section).filter(Boolean))].sort((a, b) => String(a).localeCompare(String(b), undefined, { numeric: true })), [assigned, grade]);
  const filtered = useMemo(() => assigned.filter((item) => (grade === "All" || item.grade === grade) && (section === "All" || item.section === section) && `${studentName(item)} ${studentId(item)}`.toLowerCase().includes(search.trim().toLowerCase())), [assigned, grade, search, section]);

  return <>
    <SEO title="My Students" noindex />
    <main className="min-h-screen bg-slate-50 px-4 py-8">
      <div className="mx-auto max-w-6xl">
        <h1 className="text-3xl font-bold text-slate-900">My Students</h1>
        <p className="mt-1 text-slate-500">Students from every class assigned to you.</p>
        {error && <div className="mt-5 rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">{error}</div>}
        <div className="my-6 grid gap-3 rounded-xl border border-slate-200 bg-white p-4 sm:grid-cols-3">
          <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search name or student ID" className="rounded-lg border border-slate-200 px-3 py-2.5 text-sm" />
          <select value={grade} onChange={(event) => { setGrade(event.target.value); setSection("All"); }} className="rounded-lg border border-slate-200 px-3 py-2.5 text-sm"><option value="All">All grades</option>{grades.map((item) => <option key={item}>{item}</option>)}</select>
          <select value={section} onChange={(event) => setSection(event.target.value)} className="rounded-lg border border-slate-200 px-3 py-2.5 text-sm"><option value="All">All sections</option>{sections.map((item) => <option key={item}>{item}</option>)}</select>
        </div>
        {loading ? <div className="h-80 animate-pulse rounded-xl bg-slate-200" /> : !filtered.length ? <div className="rounded-xl border border-slate-200 bg-white p-12 text-center text-slate-500">No students found.</div> : <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-sm"><table className="w-full min-w-[700px] text-left"><thead className="bg-slate-50 text-xs uppercase text-slate-500"><tr>{["#", "Student Name", "Student ID", "Grade", "Section"].map((item) => <th key={item} className="px-5 py-4">{item}</th>)}</tr></thead><tbody className="divide-y divide-slate-100">{filtered.map((student, index) => <tr key={student.id} onClick={() => setSelectedStudent(student)} className="cursor-pointer hover:bg-indigo-50"><td className="px-5 py-4 text-sm text-slate-500">{index + 1}</td><td className="px-5 py-4 font-semibold text-slate-800">{studentName(student)}</td><td className="px-5 py-4 text-sm text-slate-600">{studentId(student) || "Not set"}</td><td className="px-5 py-4 text-sm text-slate-600">{student.grade || "Not set"}</td><td className="px-5 py-4 text-sm text-slate-600">{student.section || "Not set"}</td></tr>)}</tbody></table></div>}
      </div>
    </main>
    {selectedStudent && <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4" role="dialog" aria-modal="true" aria-labelledby="student-detail-title" onMouseDown={(event) => { if (event.target === event.currentTarget) setSelectedStudent(null); }}><div className="w-full max-w-lg rounded-xl bg-white p-6 shadow-2xl"><div className="flex items-start justify-between gap-4"><div><p className="text-xs font-semibold uppercase text-indigo-600">Assigned student</p><h2 id="student-detail-title" className="mt-1 text-2xl font-bold text-slate-900">{studentName(selectedStudent)}</h2></div><button type="button" onClick={() => setSelectedStudent(null)} className="rounded-lg border border-slate-200 px-3 py-1.5 text-sm font-semibold text-slate-600">Close</button></div><dl className="mt-6 grid grid-cols-2 gap-4 text-sm">{[["Student ID", studentId(selectedStudent) || "Not set"], ["Grade", selectedStudent.grade || "Not set"], ["Section", selectedStudent.section || "Not set"], ["Gender", selectedStudent.gender || "Not set"], ["Parent Name", selectedStudent.parentName || "Not set"], ["Parent Email", selectedStudent.parentEmail || "Not set"]].map(([label, value]) => <div key={label} className="rounded-lg bg-slate-50 p-3"><dt className="text-slate-500">{label}</dt><dd className="mt-1 break-words font-semibold text-slate-800">{value}</dd></div>)}</dl></div></div>}
  </>;
}
