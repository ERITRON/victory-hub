// src/pages/TeacherProfile.jsx
import { useAuth } from "../../context/AuthContext";
import { useEffect, useState } from "react";
import { db, doc, getDoc, collection, query, where, getDocs } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";

export default function TeacherProfile() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [teacherData, setTeacherData] = useState(null);
  const [assignedClasses, setAssignedClasses] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchTeacherData = async () => {
    try {
      // Get teacher data
      const teacherDoc = await getDoc(doc(db, "teachers", user.uid));
      if (teacherDoc.exists()) {
        setTeacherData(teacherDoc.data());
      }

      // Get assigned classes
      const q = query(
        collection(db, "teacherAssignments"),
        where("teacherId", "==", user.uid)
      );
      const snapshot = await getDocs(q);
      const classes = [];
      snapshot.forEach((doc) => {
        classes.push(doc.data());
      });
      setAssignedClasses(classes);
    } catch (error) {
      console.error("Error fetching teacher data:", error);
    } finally {
      setLoading(false);
    }
  };

   
  useEffect(() => {
    if (user) {
      fetchTeacherData();
    }
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading profile...</p>
        </div>
      </div>
    );
  }

  if (!teacherData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <p className="text-gray-600">No teacher data found.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <button onClick={() => navigate(-1)} className="text-gray-600 hover:text-gray-800 transition">
            ← Back
          </button>
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">👨‍🏫 Teacher Profile</h1>
        </div>

        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-blue-800 px-6 py-8">
            <div className="flex items-center gap-6">
              <div className="w-24 h-24 rounded-full bg-white/20 flex items-center justify-center text-4xl text-white font-bold border-4 border-white">
                {teacherData.firstName?.charAt(0) || "T"}
              </div>
              <div className="text-white">
                <h2 className="text-2xl font-bold">{teacherData.fullName || `${teacherData.firstName} ${teacherData.fatherName}`}</h2>
                <p className="text-blue-200">{teacherData.email}</p>
                <span className="inline-block bg-blue-700 px-3 py-1 rounded-full text-sm font-medium mt-2">
                  👨‍🏫 Teacher
                </span>
              </div>
            </div>
          </div>

          <div className="p-6 space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Teacher ID</p>
                <p className="font-semibold text-gray-800">{teacherData.teacherId || "N/A"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Subject</p>
                <p className="font-semibold text-gray-800">{teacherData.subject || "N/A"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Phone</p>
                <p className="font-semibold text-gray-800">{teacherData.phone || "Not set"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Email</p>
                <p className="font-semibold text-gray-800">{teacherData.email || "N/A"}</p>
              </div>
            </div>

            {assignedClasses.length > 0 && (
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500 mb-2">Assigned Classes</p>
                <div className="flex flex-wrap gap-2">
                  {assignedClasses.map((cls, index) => (
                    <span key={index} className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm">
                      {cls.grade} - {cls.section} ({cls.subject})
                    </span>
                  ))}
                </div>
              </div>
            )}

            <button
              onClick={() => navigate("/profile")}
              className="w-full bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition font-medium"
            >
              ⚙️ Edit Profile & Security
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}