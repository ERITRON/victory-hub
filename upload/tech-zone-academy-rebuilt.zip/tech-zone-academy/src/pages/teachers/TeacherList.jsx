import { useState, useEffect } from "react";
import { db, collection, getDocs } from "../../supabase/supabase";
import { deleteAccount } from "../../services/adminService";
import { Link } from "react-router-dom";

export default function TeacherList() {
  const [teachers, setTeachers] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchTeachers = async () => {
    try {
      setLoading(true);
      const snapshot = await getDocs(collection(db, "teachers"));
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setTeachers(data);
    } catch (error) {
      console.error("Error fetching teachers:", error);
      alert("Error loading teachers");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTeachers();
  }, []);

  const deleteTeacher = async (id, teacherName) => {
    if (!window.confirm(`Delete teacher ${teacherName}?`)) return;
    try {
      await deleteAccount(id, "teacher");
      await fetchTeachers();
      alert("Teacher deleted successfully!");
    } catch (error) {
      alert("Error: " + error.message);
    }
  };

  if (loading) {
    return <div className="p-6">Loading teachers...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-blue-700">👨‍🏫 Teacher List</h1>
          <Link
            to="/add-teacher"
            className="bg-blue-700 text-white px-4 py-2 rounded hover:bg-blue-800"
          >
            + Add Teacher
          </Link>
        </div>

        {teachers.length === 0 ? (
          <p className="text-gray-500">No teachers found.</p>
        ) : (
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-100">
                <tr>
                  <th className="px-4 py-3 text-left">Teacher ID</th>
                  <th className="px-4 py-3 text-left">Name</th>
                  <th className="px-4 py-3 text-left">Subject</th>
                  <th className="px-4 py-3 text-left">Phone</th>
                  <th className="px-4 py-3 text-left">Login Status</th>
                  <th className="px-4 py-3 text-left">Actions</th>
                </tr>
              </thead>
              <tbody>
                {teachers.map((teacher) => (
                  <tr key={teacher.id} className="border-t">
                    <td className="px-4 py-3 font-medium">{teacher.teacherId}</td>
                    <td className="px-4 py-3">
                      {teacher.firstName} {teacher.fatherName}
                    </td>
                    <td className="px-4 py-3">{teacher.subject}</td>
                    <td className="px-4 py-3">{teacher.phone}</td>
                    <td className="px-4 py-3">
                      {teacher.userId ? (
                        <span className="bg-green-100 text-green-700 px-2 py-1 rounded text-sm">
                          ✅ Has Login
                        </span>
                      ) : (
                        <span className="bg-yellow-100 text-yellow-700 px-2 py-1 rounded text-sm">
                          ⚠️ No Login
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex gap-2">
                        <Link
                          to={`/edit-teacher/${teacher.id}`}
                          className="text-blue-600 hover:text-blue-800"
                        >
                          ✏️
                        </Link>
                        <button
                          onClick={() => deleteTeacher(teacher.id, teacher.firstName)}
                          className="text-red-600 hover:text-red-800"
                        >
                          🗑️
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}