import { useEffect, useMemo, useState } from "react";
import { collection, getDocs, query, where } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { db } from "../../supabase/supabase";
import SEO from "../../components/SEO";
import { classKey, sameClass } from "../dashboardUtils";

export default function TeacherClasses() {
  const { user } = useAuth(); const navigate = useNavigate();
  const [assignments, setAssignments] = useState([]); const [students, setStudents] = useState([]); const [loading, setLoading] = useState(true);
  useEffect(() => { if (!user) return; Promise.all([getDocs(query(collection(db, "teacherAssignments"), where("teacherId", "==", user.uid))), getDocs(collection(db, "students"))]).then(([a, s]) => { setAssignments(a.docs.map((item) => ({ id: item.id, ...item.data() }))); setStudents(s.docs.map((item) => ({ id: item.id, ...item.data() }))); }).finally(() => setLoading(false)); }, [user]);
  const classes = useMemo(() => [...new Map(assignments.map((item) => [classKey(item) + `::${item.subject || ""}`, item])).values()].map((item) => ({ ...item, studentCount: students.filter((student) => sameClass(student, item)).length })).sort((a, b) => String(a.grade).localeCompare(String(b.grade), undefined, { numeric: true }) || String(a.section).localeCompare(String(b.section)) || String(a.subject).localeCompare(String(b.subject))), [assignments, students]);
  return <><SEO title="My Classes" noindex /><main className="min-h-screen bg-slate-50 px-4 py-8"><div className="mx-auto max-w-6xl"><div className="mb-6"><h1 className="text-3xl font-bold text-slate-900">My Classes</h1><p className="mt-1 text-slate-500">Classes assigned through teacher assignments.</p></div>{loading ? <div className="grid gap-4 md:grid-cols-2">{[1,2,3,4].map((item) => <div key={item} className="h-40 animate-pulse rounded-2xl bg-slate-200" />)}</div> : !classes.length ? <div className="rounded-2xl bg-white p-12 text-center shadow-sm"><h2 className="font-bold text-slate-800">No assigned classes</h2></div> : <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{classes.map((item) => <button type="button" key={`${item.id}-${item.subject}`} onClick={() => navigate(`/teacher-students?grade=${encodeURIComponent(item.grade)}&section=${encodeURIComponent(item.section)}`)} className="rounded-2xl border border-slate-200 bg-white p-5 text-left shadow-sm transition hover:border-indigo-300 hover:shadow-md"><p className="text-xs font-semibold uppercase text-indigo-600">{item.subject || "Subject not set"}</p><h2 className="mt-2 text-xl font-bold text-slate-900">{item.grade} · Section {item.section}</h2><p className="mt-4 text-sm text-slate-500">{item.studentCount} student{item.studentCount === 1 ? "" : "s"}</p><p className="mt-4 text-sm font-semibold text-indigo-600">View students →</p></button>)}</div>}</div></main></>;
}
