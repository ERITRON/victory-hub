import { useEffect, useState } from "react";
import { db, collection, addDoc, getDocs, query, where } from "../../supabase/supabase";

export default function AssignTeacher() {
  const [teachers, setTeachers] = useState([]);
  const [grades, setGrades] = useState([]);
  const [sections, setSections] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const [formData, setFormData] = useState({
    teacherId: "",
    teacherName: "",
    grade: "",
    section: "",
    subject: "",
  });

  const fetchAllData = async () => {
    setLoading(true);
    setErrorMessage("");
    
    try {
      // Fetch teachers
      const teachersSnap = await getDocs(collection(db, "teachers"));
      const teachersData = teachersSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setTeachers(teachersData);

      // Fetch grades
      const gradesSnap = await getDocs(collection(db, "grades"));
      const gradesData = gradesSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setGrades(gradesData.sort((a, b) => a.name.localeCompare(b.name)));

      // Fetch sections
      const sectionsSnap = await getDocs(collection(db, "sections"));
      const sectionsData = sectionsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSections(sectionsData.sort((a, b) => a.name.localeCompare(b.name)));

      // Fetch subjects
      const subjectsSnap = await getDocs(collection(db, "subjects"));
      const subjectsData = subjectsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSubjects(subjectsData.sort((a, b) => a.name.localeCompare(b.name)));

    } catch (error) {
      setErrorMessage("Error loading data: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    // If teacher is selected, update teacher name
    if (name === "teacherId") {
      const selectedTeacher = teachers.find((teacher) => teacher.id === value);
      if (selectedTeacher) {
        setFormData({
          ...formData,
          teacherId: value,
          teacherName: `${selectedTeacher.firstName} ${selectedTeacher.fatherName}`,
        });
      }
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const saveAssignment = async () => {
    setLoading(true);
    setErrorMessage("");
    setSuccessMessage("");

    const { teacherId, teacherName, grade, section, subject } = formData;

    // Validation
    if (!teacherId) {
      setErrorMessage("Please select a teacher");
      setLoading(false);
      return;
    }
    if (!grade) {
      setErrorMessage("Please select a grade");
      setLoading(false);
      return;
    }
    if (!section) {
      setErrorMessage("Please select a section");
      setLoading(false);
      return;
    }
    if (!subject) {
      setErrorMessage("Please select a subject");
      setLoading(false);
      return;
    }

    try {
      // Check for duplicate assignment
      const assignmentQuery = query(
        collection(db, "teacherAssignments"),
        where("grade", "==", grade),
        where("section", "==", section),
        where("subject", "==", subject)
      );
      const existingAssignment = await getDocs(assignmentQuery);

      if (!existingAssignment.empty) {
        setErrorMessage(`A teacher is already assigned to ${grade} - ${section} for ${subject}`);
        setLoading(false);
        return;
      }

      await addDoc(collection(db, "teacherAssignments"), {
        teacherId,
        teacherName,
        grade,
        section,
        subject,
        createdAt: new Date().toISOString(),
      });

      setSuccessMessage(`✅ ${teacherName} assigned to ${grade} - ${section} for ${subject}`);

      // Reset form
      setFormData({
        teacherId: "",
        teacherName: "",
        grade: "",
        section: "",
        subject: "",
      });

      // Auto-hide success message after 5 seconds
      setTimeout(() => setSuccessMessage(""), 5000);

    } catch (error) {
      setErrorMessage("Error saving assignment: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setLoading(false);
    }
  };

  const isFormValid = formData.teacherId && formData.grade && formData.section && formData.subject;

  // Get the selected teacher's name for display
  const selectedTeacherName = formData.teacherId 
    ? teachers.find(t => t.id === formData.teacherId)?.firstName + " " + teachers.find(t => t.id === formData.teacherId)?.fatherName
    : "";

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
            📚 Assign Teacher
          </h1>
          <p className="text-gray-600 mt-1">
            Assign a teacher to a class and subject
          </p>
        </div>

        {/* Messages */}
        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Form Card */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-6 sm:p-8">
            <div className="grid gap-5">
              {/* Teacher Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Teacher *
                </label>
                <select
                  name="teacherId"
                  value={formData.teacherId}
                  onChange={handleChange}
                  className={`w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white ${
                    formData.teacherId ? "border-green-500" : "border-gray-300"
                  }`}
                  disabled={loading}
                >
                  <option value="">Select Teacher</option>
                  {teachers.map((teacher) => (
                    <option key={teacher.id} value={teacher.id}>
                      {teacher.firstName} {teacher.fatherName} ({teacher.teacherId})
                    </option>
                  ))}
                </select>
                {formData.teacherId && (
                  <p className="text-sm text-green-600 mt-1">
                    Selected: {selectedTeacherName}
                  </p>
                )}
              </div>

              {/* Grade Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Grade *
                </label>
                <select
                  name="grade"
                  value={formData.grade}
                  onChange={handleChange}
                  className={`w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white ${
                    formData.grade ? "border-green-500" : "border-gray-300"
                  }`}
                  disabled={loading}
                >
                  <option value="">Select Grade</option>
                  {grades.map((grade) => (
                    <option key={grade.id} value={grade.name}>
                      {grade.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Section Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Section *
                </label>
                <select
                  name="section"
                  value={formData.section}
                  onChange={handleChange}
                  className={`w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white ${
                    formData.section ? "border-green-500" : "border-gray-300"
                  }`}
                  disabled={loading}
                >
                  <option value="">Select Section</option>
                  {sections.map((section) => (
                    <option key={section.id} value={section.name}>
                      {section.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Subject Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Subject *
                </label>
                <select
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  className={`w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white ${
                    formData.subject ? "border-green-500" : "border-gray-300"
                  }`}
                  disabled={loading}
                >
                  <option value="">Select Subject</option>
                  {subjects.map((subject) => (
                    <option key={subject.id} value={subject.name}>
                      {subject.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Summary Card */}
              {formData.teacherId && formData.grade && formData.section && formData.subject && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-2">
                  <h3 className="font-semibold text-blue-800 mb-2">📋 Assignment Summary</h3>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="text-gray-600">Teacher:</span>
                      <span className="font-medium text-gray-800 block">{selectedTeacherName}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Subject:</span>
                      <span className="font-medium text-gray-800 block">{formData.subject}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Class:</span>
                      <span className="font-medium text-gray-800 block">{formData.grade} - {formData.section}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Submit Button */}
              <button
                onClick={saveAssignment}
                disabled={!isFormValid || loading}
                className={`w-full py-4 rounded-lg font-semibold text-white transition mt-4 ${
                  isFormValid && !loading
                    ? "bg-blue-700 hover:bg-blue-800 hover:shadow-lg"
                    : "bg-gray-400 cursor-not-allowed"
                }`}
              >
                {loading ? (
                  <span className="flex items-center justify-center gap-2">
                    <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Saving Assignment...
                  </span>
                ) : (
                  "Save Assignment"
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}