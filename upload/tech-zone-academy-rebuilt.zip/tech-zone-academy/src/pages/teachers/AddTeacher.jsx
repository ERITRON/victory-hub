// src/pages/AddTeacher.jsx
import { useState, useEffect } from "react";
import { db } from "../../supabase/supabase";
import { collection, getDocs } from "../../supabase/supabase";
import { createTeacher } from "../../services/adminService";

export default function AddTeacher() {
  const [nextTeacherId, setNextTeacherId] = useState("");
  const [subjects, setSubjects] = useState([]);
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const [formData, setFormData] = useState({
    firstName: "",
    fatherName: "",
    gender: "",
    subject: "",
    phone: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const phoneRegex = /^(09\d{8}|07\d{8}|\+2519\d{8}|\+2517\d{8})$/;

  const loadNextTeacherId = async () => {
    try {
      const snapshot = await getDocs(collection(db, "teachers"));
      if (snapshot.empty) {
        setNextTeacherId("TCH001");
        return;
      }
      let highest = 0;
      snapshot.forEach((doc) => {
        const data = doc.data();
        if (data.teacher_id) {
          const num = parseInt(data.teacher_id.replace("TCH", ""));
          if (!isNaN(num) && num > highest) {
            highest = num;
          }
        }
      });
      const next = highest + 1;
      setNextTeacherId(`TCH${String(next).padStart(3, "0")}`);
    } catch (error) {
      console.error(error);
    }
  };

  const loadSubjects = async () => {
    try {
      const snapshot = await getDocs(collection(db, "subjects"));
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSubjects(data.sort((a, b) => a.name.localeCompare(b.name)));
    } catch (error) {
      console.error("Error loading subjects:", error);
    }
  };

  useEffect(() => {
     
    loadNextTeacherId();
    loadSubjects();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    const { firstName, fatherName, gender, subject, phone, password, confirmPassword } = formData;

    if (!firstName) {
      setErrorMessage("First Name is required");
      return false;
    }
    if (!fatherName) {
      setErrorMessage("Father Name is required");
      return false;
    }
    if (!gender) {
      setErrorMessage("Please select gender");
      return false;
    }
    if (!subject) {
      setErrorMessage("Please select a subject");
      return false;
    }
    if (!phone) {
      setErrorMessage("Phone number is required");
      return false;
    }
    if (!phoneRegex.test(phone)) {
      setErrorMessage("Please enter a valid Ethiopian phone number");
      return false;
    }
    if (!password) {
      setErrorMessage("Password is required");
      return false;
    }
    if (password.length < 6) {
      setErrorMessage("Password must be at least 6 characters");
      return false;
    }
    if (password !== confirmPassword) {
      setErrorMessage("Passwords do not match");
      return false;
    }
    return true;
  };

  const addTeacher = async () => {
    setLoading(true);
    setErrorMessage("");
    setSuccessMessage("");

    if (!validateForm()) {
      setLoading(false);
      return;
    }

    try {
      const { firstName, fatherName, gender, subject, phone, email, password } = formData;

      // Account creation happens server-side (Supabase Edge Function,
      // service role) so the admin's own session is never touched and
      // no admin password needs to live in the browser.
      const result = await createTeacher({
        firstName,
        fatherName,
        gender,
        subject,
        phone,
        email,
        password,
      });

      setSuccessMessage(
        `✅ Teacher Created Successfully!\n\n` +
        `Teacher ID: ${result.teacherId}\n` +
        `Name: ${result.fullName}\n` +
        `Email: ${result.email}\n` +
        `Phone: ${phone}\n` +
        `Password: ${password}\n\n` +
        `📌 Login with Email: ${result.email}\n` +
        `📌 Login with Phone: ${phone}`
      );

      setFormData({
        firstName: "",
        fatherName: "",
        gender: "",
        subject: "",
        phone: "",
        email: "",
        password: "",
        confirmPassword: "",
      });
      loadNextTeacherId();

      setTimeout(() => setSuccessMessage(""), 8000);

    } catch (error) {
      setErrorMessage(`❌ ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // ✅ Only check required fields (email is optional)
  const isFormValid =
    formData.firstName &&
    formData.fatherName &&
    formData.gender &&
    formData.subject &&
    formData.phone &&
    formData.password &&
    formData.password === formData.confirmPassword;

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">👨‍🏫 Add Teacher with Login</h1>
          <p className="text-gray-600 mt-1">Email is optional - can login with phone number</p>
        </div>

        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4 whitespace-pre-line">
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-6 sm:p-8">
            <div className="grid gap-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-2">
                <p className="text-sm text-gray-600">Teacher ID</p>
                <p className="text-2xl font-bold text-blue-700">{nextTeacherId}</p>
              </div>

              <div className="border-b border-gray-200 pb-4 mb-2">
                <h2 className="text-lg font-semibold text-gray-700 mb-3">👤 Personal Information</h2>
                <div className="grid sm:grid-cols-2 gap-3">
                  <input name="firstName" value={formData.firstName} onChange={handleChange} placeholder="First Name *" className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition" />
                  <input name="fatherName" value={formData.fatherName} onChange={handleChange} placeholder="Father Name *" className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition" />
                  <select name="gender" value={formData.gender} onChange={handleChange} className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white">
                    <option value="">Select Gender *</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                  <select name="subject" value={formData.subject} onChange={handleChange} className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white">
                    <option value="">Select Subject *</option>
                    {subjects.map((s) => (
                      <option key={s.id} value={s.name}>{s.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="border-b border-gray-200 pb-4 mb-2">
                <h2 className="text-lg font-semibold text-gray-700 mb-3">📞 Contact Information</h2>
                <div className="grid sm:grid-cols-2 gap-3">
                  <input type="tel" name="phone" value={formData.phone} onChange={handleChange} placeholder="Phone Number (Login) *" className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition" />
                  <input type="email" name="email" value={formData.email} onChange={handleChange} placeholder="Email Address (Optional)" className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition" />
                </div>
                <p className="text-xs text-gray-400 mt-1">User can login with either Phone Number or Email</p>
              </div>

              <div className="pb-2">
                <h2 className="text-lg font-semibold text-gray-700 mb-3">🔐 Login Credentials</h2>
                <div className="grid gap-3">
                  <div className="relative">
                    <input type={showPassword ? "text" : "password"} name="password" value={formData.password} onChange={handleChange} placeholder="Password (min 6 chars) *" className="border rounded-lg p-3 w-full focus:ring-2 focus:ring-blue-500 outline-none transition pr-12" minLength="6" />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700">
                      {showPassword ? "🙈" : "👁️"}
                    </button>
                  </div>
                  <input type={showPassword ? "text" : "password"} name="confirmPassword" value={formData.confirmPassword} onChange={handleChange} placeholder="Confirm Password *" className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition" />
                </div>
                <p className="text-xs text-gray-400 mt-2">🔑 Login with: <strong>Phone Number</strong> or <strong>Email</strong></p>
              </div>

              <button onClick={addTeacher} disabled={!isFormValid || loading} className={`w-full py-4 rounded-lg font-semibold text-white transition ${isFormValid && !loading ? "bg-blue-700 hover:bg-blue-800 hover:shadow-lg" : "bg-gray-400 cursor-not-allowed"}`}>
                {loading ? "Creating Account..." : "Create Teacher Account"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}