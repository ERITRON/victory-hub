// src/pages/TeacherAssignmentsUpload.jsx
import { useEffect, useRef, useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { db, deleteObject, getDownloadURL, ref, storage, uploadBytes, collection, addDoc, getDocs, query, where, doc, getDoc } from "../../supabase/supabase";

export default function TeacherAssignmentsUpload() {
  const { user } = useAuth();
  const [teacherData, setTeacherData] = useState(null);
  const [assignedClasses, setAssignedClasses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [selectedFile, setSelectedFile] = useState(null);
  const fileInputRef = useRef(null);

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    subject: "",
    grade: "",
    section: "",
    type: "assignment", // assignment, homework, notes
    dueDate: "",
    fileUrl: "",
  });

  useEffect(() => {
    if (user) {
      fetchTeacherData();
    }
  }, [user]);

  async function fetchTeacherData() {
    setLoading(true);
    try {
      const teacherDoc = await getDoc(doc(db, "teachers", user.uid));
      if (teacherDoc.exists()) {
        setTeacherData(teacherDoc.data());
      }

      const assignmentsQuery = query(
        collection(db, "teacherAssignments"),
        where("teacherId", "==", user.uid)
      );
      const snapshot = await getDocs(assignmentsQuery);
      const classes = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        if (!classes.find(c => c.grade === data.grade && c.section === data.section)) {
          classes.push({ grade: data.grade, section: data.section });
        }
      });
      setAssignedClasses(classes);
    } catch (error) {
      setErrorMessage("Error loading data: " + error.message);
    } finally {
      setLoading(false);
    }
  }

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMessage("");
    setSuccessMessage("");

    const { title, description, subject, grade, section, type, dueDate, fileUrl } = formData;

    if (!title || !description || !grade || !section || !type) {
      setErrorMessage("Please fill all required fields.");
      setLoading(false);
      return;
    }

    let uploadedFileRef = null;
    try {
      let resolvedFileUrl = fileUrl || "";
      let uploadedFileName = "";
      let uploadedFileSize = null;
      let uploadedFileType = "";

      if (selectedFile) {
        const safeName = selectedFile.name.replace(/[^a-zA-Z0-9._-]/g, "_");
        const uniqueName = `${crypto.randomUUID()}-${safeName}`;
        uploadedFileRef = ref(storage, `teacher-assignments/${user.uid}/${uniqueName}`);
        const uploadSnapshot = await uploadBytes(uploadedFileRef, selectedFile, {
          contentType: selectedFile.type || undefined,
        });
        resolvedFileUrl = await getDownloadURL(uploadSnapshot.ref);
        uploadedFileName = selectedFile.name;
        uploadedFileSize = selectedFile.size;
        uploadedFileType = selectedFile.type || "";
      }

      await addDoc(collection(db, "teacherAssignmentsUploads"), {
        title,
        description,
        subject: subject || teacherData?.subject || "",
        grade,
        section,
        type,
        dueDate: dueDate || "",
        fileUrl: resolvedFileUrl,
        fileName: uploadedFileName,
        fileSize: uploadedFileSize,
        fileType: uploadedFileType,
        teacherId: user.uid,
        teacherName: teacherData?.fullName || "",
        createdAt: new Date().toISOString(),
      });

      setSuccessMessage("✅ Assignment uploaded successfully!");

      setFormData({
        title: "",
        description: "",
        subject: "",
        grade: "",
        section: "",
        type: "assignment",
        dueDate: "",
        fileUrl: "",
      });
      setSelectedFile(null);
      if (fileInputRef.current) fileInputRef.current.value = "";

      setTimeout(() => setSuccessMessage(""), 5000);

    } catch (error) {
      if (uploadedFileRef) {
        await deleteObject(uploadedFileRef).catch(() => {});
      }
      setErrorMessage("Error uploading assignment: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
            📝 Upload Assignment
          </h1>
          <p className="text-gray-600 mt-1">
            Upload homework, notes, and assignments for your students
          </p>
        </div>

        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-6 sm:p-8">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Assignment Type *
                </label>
                <select
                  name="type"
                  value={formData.type}
                  onChange={handleChange}
                  className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
                  required
                >
                  <option value="assignment">📝 Assignment</option>
                  <option value="homework">📖 Homework</option>
                  <option value="notes">📓 Notes</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Title *
                </label>
                <input
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                  placeholder="Enter title"
                  className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description *
                </label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  placeholder="Enter description"
                  rows="4"
                  className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Subject *
                  </label>
                  <input
                    type="text"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    placeholder="Enter subject"
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Due Date
                  </label>
                  <input
                    type="date"
                    name="dueDate"
                    value={formData.dueDate}
                    onChange={handleChange}
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Grade *
                  </label>
                  <select
                    name="grade"
                    value={formData.grade}
                    onChange={handleChange}
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
                    required
                  >
                    <option value="">Select Grade</option>
                    {assignedClasses.map((cls, index) => (
                      <option key={index} value={cls.grade}>
                        {cls.grade}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Section *
                  </label>
                  <select
                    name="section"
                    value={formData.section}
                    onChange={handleChange}
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
                    required
                  >
                    <option value="">Select Section</option>
                    {assignedClasses.map((cls, index) => (
                      <option key={index} value={cls.section}>
                        {cls.section}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  File (Optional)
                </label>
                <div className="flex flex-col gap-3 sm:flex-row">
                  <input
                    type="url"
                    name="fileUrl"
                    value={formData.fileUrl}
                    onChange={handleChange}
                    placeholder="File URL"
                    disabled={Boolean(selectedFile)}
                    className="min-w-0 flex-1 border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition disabled:bg-gray-100 disabled:text-gray-500"
                  />
                  <label
                    className={`shrink-0 px-4 py-3 rounded-lg font-medium transition ${
                      loading
                        ? "cursor-not-allowed bg-gray-200 text-gray-500"
                        : "cursor-pointer bg-gray-200 text-gray-700 hover:bg-gray-300"
                    }`}
                  >
                    {selectedFile ? "Change File" : "Upload"}
                    <input
                      ref={fileInputRef}
                      type="file"
                      onChange={(event) => setSelectedFile(event.target.files?.[0] || null)}
                      disabled={loading}
                      className="hidden"
                    />
                  </label>
                </div>
                {selectedFile && (
                  <div className="mt-2 flex items-center justify-between gap-3 rounded-lg bg-blue-50 px-3 py-2 text-sm">
                    <div className="min-w-0">
                      <p className="truncate font-medium text-blue-900">{selectedFile.name}</p>
                      <p className="text-xs text-blue-700">
                        {selectedFile.size < 1024 * 1024
                          ? `${(selectedFile.size / 1024).toFixed(1)} KB`
                          : `${(selectedFile.size / (1024 * 1024)).toFixed(1)} MB`}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedFile(null);
                        if (fileInputRef.current) fileInputRef.current.value = "";
                      }}
                      className="shrink-0 rounded-md px-2 py-1 font-medium text-red-700 hover:bg-red-50"
                    >
                      Remove
                    </button>
                  </div>
                )}
                <p className="text-xs text-gray-400 mt-1">
                  Choose a file from your device or paste a direct file URL.
                </p>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-blue-700 text-white py-3 rounded-lg font-semibold hover:bg-blue-800 transition disabled:bg-gray-400"
              >
                {loading ? "Uploading..." : "📤 Upload Assignment"}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
