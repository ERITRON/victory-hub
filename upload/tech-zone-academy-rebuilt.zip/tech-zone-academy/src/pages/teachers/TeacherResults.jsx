// src/pages/TeacherResults.jsx
import { useAuth } from "../../context/AuthContext";
import { useEffect, useState } from "react";
import { db, collection, getDocs, query, where, orderBy, doc, getDoc, deleteDoc } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";
import { sortStudents } from "../dashboardUtils";

export default function TeacherResults() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");
  const [teacherData, setTeacherData] = useState(null);
  const [assignedClasses, setAssignedClasses] = useState([]);
  const [, setHomeroomClass] = useState(null);
  const [students, setStudents] = useState([]);
  const [results, setResults] = useState([]);
  const [selectedGrade, setSelectedGrade] = useState("");
  const [selectedSection, setSelectedSection] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("");
  const [, setFilteredResults] = useState([]);
  const [expandedStudent, setExpandedStudent] = useState(null);
  
  // Cumulative data per student
  const [studentCumulative, setStudentCumulative] = useState({});

  useEffect(() => {
    if (user) {
      fetchTeacherData();
    }
  }, [user]);

  useEffect(() => {
    if (results.length > 0 && students.length > 0) {
      filterResults();
    }
  }, [results, students, selectedGrade, selectedSection, selectedSubject]);

  async function fetchTeacherData() {
    setLoading(true);
    try {
      const teacherDoc = await getDoc(doc(db, "teachers", user.uid));
      if (teacherDoc.exists()) {
        setTeacherData(teacherDoc.data());
      }

      const assignmentsQuery = query(
        collection(db, "teacherAssignments"),
        where("teacherId", "==", user.uid)
      );
      const assignmentsSnapshot = await getDocs(assignmentsQuery);
      const assignments = [];
      assignmentsSnapshot.forEach((doc) => {
        assignments.push({ id: doc.id, ...doc.data() });
      });
      setAssignedClasses(assignments);

      const homeroomQuery = query(
        collection(db, "homeroomAssignments"),
        where("teacherId", "==", user.uid)
      );
      const homeroomSnapshot = await getDocs(homeroomQuery);
      if (!homeroomSnapshot.empty) {
        homeroomSnapshot.forEach((doc) => {
          setHomeroomClass({ id: doc.id, ...doc.data() });
        });
      }

      if (assignments.length > 0) {
        setSelectedGrade(assignments[0].grade);
        setSelectedSection(assignments[0].section);
        setSelectedSubject(assignments[0].subject);
      }

      await fetchStudentsAndResults(assignments);

    } catch (error) {
      setErrorMessage("Error loading data: " + error.message);
    } finally {
      setLoading(false);
    }
  }

  const fetchStudentsAndResults = async (assignments) => {
    try {
      const allStudents = [];
      const grades = [...new Set(assignments.map(a => a.grade))];
      const sections = [...new Set(assignments.map(a => a.section))];

      for (const grade of grades) {
        for (const section of sections) {
          const studentsQuery = query(
            collection(db, "students"),
            where("grade", "==", grade),
            where("section", "==", section)
          );
          const studentsSnap = await getDocs(studentsQuery);
          studentsSnap.forEach((doc) => {
            allStudents.push({ id: doc.id, ...doc.data() });
          });
        }
      }
      setStudents(sortStudents(allStudents));

      const resultsSnap = await getDocs(
        query(collection(db, "results"), orderBy("createdAt", "desc"))
      );
      const allResults = resultsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setResults(allResults);

    } catch (error) {
      setErrorMessage("Error fetching data: " + error.message);
    }
  };

  function filterResults() {
    let filteredStudents = students;
    if (selectedGrade) {
      filteredStudents = filteredStudents.filter(s => s.grade === selectedGrade);
    }
    if (selectedSection) {
      filteredStudents = filteredStudents.filter(s => s.section === selectedSection);
    }

    const studentIds = filteredStudents.map(s => s.studentId);

    let filtered = results.filter(r => studentIds.includes(r.studentId));
    if (selectedSubject) {
      filtered = filtered.filter(r => r.subject === selectedSubject);
    }

    setFilteredResults(filtered);

    // Calculate cumulative scores per student
    const cumulative = {};
    filtered.forEach((result) => {
      const studentId = result.studentId;
      if (!cumulative[studentId]) {
        const student = filteredStudents.find(s => s.studentId === studentId);
        cumulative[studentId] = {
          studentId: studentId,
          studentName: student ? `${student.firstName} ${student.fatherName}` : "Unknown",
          grade: student ? student.grade : "",
          section: student ? student.section : "",
          totalScore: 0,
          totalMaxScore: 0,
          count: 0,
          subjects: {},
          results: [],
        };
      }
      cumulative[studentId].totalScore += result.score || 0;
      cumulative[studentId].totalMaxScore += result.outOf || 0;
      cumulative[studentId].count++;
      cumulative[studentId].results.push(result);
      
      const subject = result.subject || "Unknown";
      if (!cumulative[studentId].subjects[subject]) {
        cumulative[studentId].subjects[subject] = {
          totalScore: 0,
          totalMaxScore: 0,
          count: 0,
        };
      }
      cumulative[studentId].subjects[subject].totalScore += result.score || 0;
      cumulative[studentId].subjects[subject].totalMaxScore += result.outOf || 0;
      cumulative[studentId].subjects[subject].count++;
    });

    Object.keys(cumulative).forEach((key) => {
      const student = cumulative[key];
      student.percentage = student.totalMaxScore > 0 
        ? Math.round((student.totalScore / student.totalMaxScore) * 100) 
        : 0;
      
      Object.keys(student.subjects).forEach((subject) => {
        const data = student.subjects[subject];
        data.percentage = data.totalMaxScore > 0 
          ? Math.round((data.totalScore / data.totalMaxScore) * 100) 
          : 0;
      });
    });

    setStudentCumulative(cumulative);
  }

  // ✅ Navigate to edit page
  const handleEditResult = (resultId) => {
    navigate(`/edit-result/${resultId}`);
  };

  // ✅ Delete result
  const handleDeleteResult = async (resultId, studentName) => {
    if (!window.confirm(`Are you sure you want to delete this result for ${studentName}?`)) {
      return;
    }
    
    try {
      await deleteDoc(doc(db, "results", resultId));
      setResults(results.filter(r => r.id !== resultId));
      // Refresh the view
      filterResults();
      setErrorMessage("");
    } catch (error) {
      setErrorMessage("Error deleting result: " + error.message);
    }
  };

  const getScoreColor = (percentage) => {
    if (percentage >= 80) return "text-green-600";
    if (percentage >= 60) return "text-yellow-600";
    if (percentage >= 40) return "text-orange-600";
    return "text-red-600";
  };

  const getScoreBadge = (percentage) => {
    if (percentage >= 80) return "bg-green-100 text-green-700";
    if (percentage >= 60) return "bg-yellow-100 text-yellow-700";
    if (percentage >= 40) return "bg-orange-100 text-orange-700";
    return "bg-red-100 text-red-700";
  };

  const toggleStudent = (studentId) => {
    setExpandedStudent(expandedStudent === studentId ? null : studentId);
  };

  const uniqueSubjects = [...new Set(assignedClasses.map(a => a.subject))];
  const alphabeticalStudentResults = Object.values(studentCumulative).sort((a, b) =>
    a.studentName.localeCompare(b.studentName, undefined, { sensitivity: "base" })
  );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading teacher results...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <button onClick={() => navigate(-1)} className="text-gray-600 hover:text-gray-800 transition">
            ← Back
          </button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              📊 My Students' Results
            </h1>
            <p className="text-gray-600 text-sm mt-1">
              {teacherData?.fullName || teacherData?.firstName} • {assignedClasses.length} classes assigned
            </p>
          </div>
          <div className="ml-auto flex gap-3">
            <button
              onClick={() => navigate("/add-result")}
              className="bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition text-sm font-medium"
            >
              + Add Result
            </button>
            <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
              👨‍🏫 Teacher
            </span>
          </div>
        </div>

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Grade</label>
              <select
                value={selectedGrade}
                onChange={(e) => setSelectedGrade(e.target.value)}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none bg-white"
              >
                {[...new Set(assignedClasses.map(a => a.grade))].map((grade) => (
                  <option key={grade} value={grade}>{grade}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Section</label>
              <select
                value={selectedSection}
                onChange={(e) => setSelectedSection(e.target.value)}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none bg-white"
              >
                {[...new Set(assignedClasses.map(a => a.section))].map((section) => (
                  <option key={section} value={section}>{section}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Subject</label>
              <select
                value={selectedSubject}
                onChange={(e) => setSelectedSubject(e.target.value)}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none bg-white"
              >
                {uniqueSubjects.map((subject) => (
                  <option key={subject} value={subject}>{subject}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Student Cards */}
        {Object.keys(studentCumulative).length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-6xl mb-4">📭</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No Results Found</h3>
            <p className="text-gray-500">No results available for the selected filters.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {alphabeticalStudentResults.map((student) => {
              const isExpanded = expandedStudent === student.studentId;
              
              return (
                <div
                  key={student.studentId}
                  className={`bg-white rounded-xl shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg ${
                    isExpanded ? 'ring-2 ring-blue-500 shadow-xl' : ''
                  }`}
                >
                  {/* Card Header - Click to expand */}
                  <div className="p-4 border-b bg-gradient-to-r from-gray-50 to-white cursor-pointer" onClick={() => toggleStudent(student.studentId)}>
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold text-gray-800">
                          {student.studentName}
                        </h4>
                        <div className="flex items-center gap-2 text-xs text-gray-500">
                          <span className="bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">{student.grade}</span>
                          <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Section {student.section}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getScoreBadge(student.percentage)}`}>
                          {student.percentage}%
                        </span>
                        <svg
                          className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${
                            isExpanded ? 'rotate-180' : ''
                          }`}
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                      </div>
                    </div>
                  </div>

                  {/* Card Stats */}
                  <div className="grid grid-cols-3 gap-1 p-3 bg-gray-50">
                    <div className="text-center">
                      <div className="text-sm font-bold text-blue-600">{student.count}</div>
                      <div className="text-[10px] text-gray-500">Results</div>
                    </div>
                    <div className="text-center">
                      <div className="text-sm font-bold text-purple-600">
                        {student.totalScore} / {student.totalMaxScore}
                      </div>
                      <div className="text-[10px] text-gray-500">Total Score</div>
                    </div>
                    <div className="text-center">
                      <div className={`text-sm font-bold ${getScoreColor(student.percentage)}`}>
                        {student.percentage}%
                      </div>
                      <div className="text-[10px] text-gray-500">Average</div>
                    </div>
                  </div>

                  {/* Expanded Content */}
                  {isExpanded && (
                    <div className="p-4 border-t bg-white">
                      <div className="mb-3 flex items-center justify-between">
                        <h5 className="text-sm font-semibold text-gray-700">📋 All Results</h5>
                        <span className="text-xs text-gray-500">
                          {student.results.length} records
                        </span>
                      </div>
                      
                      {/* Subject Breakdown */}
                      {Object.keys(student.subjects).length > 0 && (
                        <div className="mb-3 flex flex-wrap gap-2">
                          {Object.entries(student.subjects).map(([subject, data]) => (
                            <span key={subject} className={`px-2 py-0.5 rounded-full text-xs font-medium ${getScoreBadge(data.percentage)}`}>
                              {subject}: {data.percentage}%
                            </span>
                          ))}
                        </div>
                      )}
                      
                      {student.results.length === 0 ? (
                        <div className="text-center py-4 text-gray-500 text-sm">
                          No attendance records found.
                        </div>
                      ) : (
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead className="bg-gray-50">
                              <tr>
                                <th className="px-2 py-1 text-left text-xs font-semibold text-gray-600">#</th>
                                <th className="px-2 py-1 text-left text-xs font-semibold text-gray-600">Subject</th>
                                <th className="px-2 py-1 text-left text-xs font-semibold text-gray-600">Assessment</th>
                                <th className="px-2 py-1 text-center text-xs font-semibold text-gray-600">Score</th>
                                <th className="px-2 py-1 text-center text-xs font-semibold text-gray-600">%</th>
                                <th className="px-2 py-1 text-center text-xs font-semibold text-gray-600">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                              {student.results.map((result, idx) => {
                                const percentage = ((result.score / result.outOf) * 100).toFixed(1);
                                return (
                                  <tr key={result.id || idx} className="border-b hover:bg-gray-50">
                                    <td className="px-2 py-1 text-xs text-gray-500">{idx + 1}</td>
                                    <td className="px-2 py-1 text-xs text-gray-600">{result.subject}</td>
                                    <td className="px-2 py-1 text-xs text-gray-600">{result.assessment}</td>
                                    <td className="px-2 py-1 text-center text-xs font-medium">
                                      {result.score} / {result.outOf}
                                    </td>
                                    <td className={`px-2 py-1 text-center text-xs font-bold ${getScoreColor(percentage)}`}>
                                      {percentage}%
                                    </td>
                                    <td className="px-2 py-1 text-center">
                                      <div className="flex items-center justify-center gap-1">
                                        {/* ✅ Edit button - Navigates to EditResult page */}
                                        <button
                                          onClick={() => handleEditResult(result.id)}
                                          className="text-blue-600 hover:text-blue-800 text-xs font-medium px-1 py-0.5 rounded hover:bg-blue-50"
                                          title="Edit Result"
                                        >
                                          ✏️
                                        </button>
                                        {/* ✅ Delete button */}
                                        <button
                                          onClick={() => handleDeleteResult(result.id, student.studentName)}
                                          className="text-red-600 hover:text-red-800 text-xs font-medium px-1 py-0.5 rounded hover:bg-red-50"
                                          title="Delete Result"
                                        >
                                          🗑️
                                        </button>
                                      </div>
                                    </td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                      )}
                      <div className="mt-3 pt-2 border-t flex justify-between text-xs text-gray-500">
                        <span>Overall: <span className={`font-bold ${getScoreColor(student.percentage)}`}>
                          {student.percentage}%
                        </span></span>
                        <span className="flex items-center gap-2">
                          <span className="text-purple-600">📊 {student.count} results</span>
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
