import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { db, collection, getDocs, deleteDoc, doc, query, orderBy } from "../../supabase/supabase";

export default function TeacherAssignmentsList() {
  const [assignments, setAssignments] = useState([]);
  const [grades, setGrades] = useState([]);
  const [sections, setSections] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [filters, setFilters] = useState({
    grade: "",
    section: "",
    subject: "",
  });

  const navigate = useNavigate();

  const fetchAllData = async () => {
    setLoading(true);
    setErrorMessage("");

    try {
      // Fetch assignments
      const q = query(collection(db, "teacherAssignments"), orderBy("createdAt", "desc"));
      const querySnapshot = await getDocs(q);
      const data = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setAssignments(data);

      // Fetch grades
      const gradesSnap = await getDocs(collection(db, "grades"));
      const gradesData = gradesSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setGrades(gradesData.sort((a, b) => a.name.localeCompare(b.name)));

      // Fetch sections
      const sectionsSnap = await getDocs(collection(db, "sections"));
      const sectionsData = sectionsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSections(sectionsData.sort((a, b) => a.name.localeCompare(b.name)));

      // Fetch subjects
      const subjectsSnap = await getDocs(collection(db, "subjects"));
      const subjectsData = subjectsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSubjects(subjectsData.sort((a, b) => a.name.localeCompare(b.name)));

    } catch (error) {
      setErrorMessage("Error loading data: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setLoading(false);
    }
  };

   
  useEffect(() => {
    fetchAllData();
  }, []);

  const deleteAssignment = async (id, teacherName, grade, section, subject) => {
    if (!window.confirm(`Delete assignment for ${teacherName} (${grade} - ${section} - ${subject})?`)) {
      return;
    }

    try {
      await deleteDoc(doc(db, "teacherAssignments", id));
      setAssignments(assignments.filter((assignment) => assignment.id !== id));
      setSuccessMessage(`✅ Assignment deleted successfully!`);
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error deleting assignment: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  const clearFilters = () => {
    setFilters({
      grade: "",
      section: "",
      subject: "",
    });
    setSearchTerm("");
  };

  const filteredAssignments = assignments.filter((assignment) => {
    const matchGrade = filters.grade === "" || assignment.grade === filters.grade;
    const matchSection = filters.section === "" || assignment.section === filters.section;
    const matchSubject = filters.subject === "" || assignment.subject === filters.subject;
    const matchSearch = 
      assignment.teacherName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      assignment.subject?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      assignment.grade?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchGrade && matchSection && matchSubject && matchSearch;
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading assignments...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
                📚 Teacher Assignments
              </h1>
              <p className="text-gray-600 mt-1">
                Manage teacher subject assignments
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => navigate("/assign-teacher")}
                className="bg-blue-700 text-white px-4 py-2 rounded-lg hover:bg-blue-800 transition text-sm flex items-center gap-2"
              >
                <span className="text-lg">+</span> Assign Teacher
              </button>
              <button
                onClick={fetchAllData}
                className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition text-sm flex items-center gap-2"
              >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h3.992v3.992m0-3.992-6.3 6.3a2.25 2.25 0 01-3.182 0l-3.7-3.7a2.25 2.25 0 010-3.182l6.3-6.3a2.25 2.25 0 013.182 0l3.7 3.7z" />
                </svg>
                Refresh
              </button>
            </div>
          </div>
        </div>

        {/* Messages */}
        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Search & Filters */}
        <div className="bg-white rounded-xl shadow-md p-4 sm:p-6 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="lg:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Search
              </label>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by teacher, subject, or grade..."
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Grade
              </label>
              <select
                name="grade"
                value={filters.grade}
                onChange={handleFilterChange}
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
              >
                <option value="">All Grades</option>
                {grades.map((grade) => (
                  <option key={grade.id} value={grade.name}>
                    {grade.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Section
              </label>
              <select
                name="section"
                value={filters.section}
                onChange={handleFilterChange}
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
              >
                <option value="">All Sections</option>
                {sections.map((section) => (
                  <option key={section.id} value={section.name}>
                    {section.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Subject
              </label>
              <select
                name="subject"
                value={filters.subject}
                onChange={handleFilterChange}
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
              >
                <option value="">All Subjects</option>
                {subjects.map((subject) => (
                  <option key={subject.id} value={subject.name}>
                    {subject.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex justify-end mt-4">
            <button
              onClick={clearFilters}
              className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition font-medium text-sm"
            >
              Clear All Filters
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="flex flex-wrap gap-4 mb-6">
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Total Assignments:</span>
            <span className="ml-2 font-bold text-blue-700">{assignments.length}</span>
          </div>
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Filtered:</span>
            <span className="ml-2 font-bold text-green-700">{filteredAssignments.length}</span>
          </div>
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Teachers:</span>
            <span className="ml-2 font-bold text-purple-700">
              {new Set(assignments.map((a) => a.teacherId)).size}
            </span>
          </div>
        </div>

        {/* Assignments Grid */}
        {filteredAssignments.length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-6xl mb-4">📭</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              {assignments.length === 0 ? "No Assignments Found" : "No Assignments Match"}
            </h3>
            <p className="text-gray-500">
              {assignments.length === 0 
                ? "No teacher assignments have been created yet." 
                : "No assignments match your search criteria."}
            </p>
            {assignments.length === 0 && (
              <button
                onClick={() => navigate("/assign-teacher")}
                className="mt-4 bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition"
              >
                + Create First Assignment
              </button>
            )}
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {filteredAssignments.map((assignment) => (
              <div
                key={assignment.id}
                className="bg-white rounded-xl shadow-md p-5 hover:shadow-xl transition duration-300 border-l-4 border-blue-500"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-gray-800">
                      {assignment.teacherName}
                    </h3>
                    <p className="text-sm text-gray-500">
                      Teacher ID: {assignment.teacherId?.substring(0, 8) || "N/A"}...
                    </p>
                  </div>
                  <div className="text-3xl">👨‍🏫</div>
                </div>

                <div className="mt-3 space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-500">📚</span>
                    <span className="text-sm font-medium text-gray-700">{assignment.subject}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-500">📋</span>
                    <span className="text-sm text-gray-600">{assignment.grade} - Section {assignment.section}</span>
                  </div>
                </div>

                {assignment.createdAt && (
                  <p className="text-xs text-gray-400 mt-3">
                    Created: {new Date(assignment.createdAt).toLocaleDateString()}
                  </p>
                )}

                <div className="mt-4 pt-3 border-t border-gray-100 flex gap-2">
                  <button
                    onClick={() => navigate(`/edit-teacher-assignment/${assignment.id}`)}
                    className="flex-1 bg-yellow-500 text-white px-3 py-2 rounded-lg hover:bg-yellow-600 transition font-medium text-sm"
                  >
                    ✏️ Edit
                  </button>
                  <button
                    onClick={() => deleteAssignment(
                      assignment.id, 
                      assignment.teacherName, 
                      assignment.grade, 
                      assignment.section, 
                      assignment.subject
                    )}
                    className="flex-1 bg-red-600 text-white px-3 py-2 rounded-lg hover:bg-red-700 transition font-medium text-sm"
                  >
                    🗑️ Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}