// src/pages/TeacherPerformance.jsx
import { useEffect, useState } from "react";
import { db, collection, getDocs } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";
import { SkeletonCard } from "../../components/LoadingSkeleton";

const PASS_THRESHOLD = 50; // a result counts as a pass at >= 50%

export default function TeacherPerformance() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [performance, setPerformance] = useState([]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [teachersSnap, resultsSnap] = await Promise.all([
        getDocs(collection(db, "teachers")),
        getDocs(collection(db, "results")),
      ]);
      const teachersData = teachersSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      const results = resultsSnap.docs.map((doc) => doc.data());

      const perfData = teachersData.map((teacher) => {
        // Results carry teacherId = the teacher's auth uid, which is also the
        // teachers doc id. Fall back to teacherName for legacy records.
        const teacherResults = results.filter(
          (r) =>
            r.teacherId === teacher.id ||
            (!r.teacherId && r.teacherName && r.teacherName === teacher.fullName)
        );

        // Weighted average: total points earned over total points possible,
        // skipping malformed records with no outOf.
        let totalScore = 0;
        let totalMax = 0;
        const gradable = teacherResults.filter((r) => (r.outOf || 0) > 0);
        gradable.forEach((r) => {
          totalScore += r.score || 0;
          totalMax += r.outOf;
        });
        const avgScore = totalMax > 0 ? Math.round((totalScore / totalMax) * 100) : 0;

        const passed = gradable.filter(
          (r) => ((r.score || 0) / r.outOf) * 100 >= PASS_THRESHOLD
        ).length;
        const passRate =
          gradable.length > 0 ? Math.round((passed / gradable.length) * 100) : 0;

        const studentsTaught = new Set(
          teacherResults.map((r) => r.studentId).filter(Boolean)
        ).size;

        return {
          ...teacher,
          totalResults: teacherResults.length,
          avgScore,
          passed,
          passRate,
          studentsTaught,
          hasData: gradable.length > 0,
        };
      });

      // Highest average first; teachers with no results sink to the bottom
      // instead of tying with genuinely low performers at 0%.
      perfData.sort((a, b) => {
        if (a.hasData !== b.hasData) return a.hasData ? -1 : 1;
        return b.avgScore - a.avgScore;
      });
      setPerformance(perfData);
    } catch (error) {
      console.error("Error fetching teacher performance:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const getScoreColor = (score) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-yellow-600";
    if (score >= 40) return "text-orange-600";
    return "text-red-600";
  };

  const getStatusBadge = (teacher) => {
    if (!teacher.hasData) {
      return { label: "📭 No Data", classes: "bg-gray-100 text-gray-600" };
    }
    if (teacher.avgScore >= 80) {
      return { label: "🌟 Excellent", classes: "bg-green-100 text-green-700" };
    }
    if (teacher.avgScore >= 60) {
      return { label: "👍 Good", classes: "bg-yellow-100 text-yellow-700" };
    }
    if (teacher.avgScore >= 40) {
      return { label: "📚 Satisfactory", classes: "bg-orange-100 text-orange-700" };
    }
    return { label: "📖 Needs Improvement", classes: "bg-red-100 text-red-700" };
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <button onClick={() => navigate(-1)} className="text-gray-600 hover:text-gray-800 transition">
            ← Back
          </button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              📊 Teacher Performance
            </h1>
            <p className="text-gray-600 mt-1">
              Monitor and evaluate teacher performance
            </p>
          </div>
          <div className="ml-auto">
            <span className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-sm font-medium">
              Principal
            </span>
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <SkeletonCard count={6} />
          </div>
        ) : performance.length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-6xl mb-4">📭</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No Data Available</h3>
            <p className="text-gray-500">No teacher performance data found.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {performance.map((teacher) => {
              const badge = getStatusBadge(teacher);
              return (
                <div key={teacher.id} className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-14 h-14 rounded-full bg-blue-100 flex items-center justify-center text-2xl text-blue-700 font-bold">
                      {teacher.firstName?.charAt(0) || "T"}
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-800">
                        {teacher.firstName} {teacher.fatherName}
                      </h3>
                      <p className="text-sm text-gray-500">{teacher.subject || "No subject"}</p>
                      <p className="text-xs text-gray-400">{teacher.teacherId}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 mb-4">
                    <div className="bg-gray-50 rounded-lg p-2 text-center">
                      <div className="text-lg font-bold text-blue-600">{teacher.totalResults}</div>
                      <div className="text-xs text-gray-500">Results</div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-2 text-center">
                      <div className="text-lg font-bold text-indigo-600">{teacher.studentsTaught}</div>
                      <div className="text-xs text-gray-500">Students</div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-2 text-center">
                      <div className={`text-lg font-bold ${teacher.hasData ? getScoreColor(teacher.passRate) : "text-gray-400"}`}>
                        {teacher.hasData ? `${teacher.passRate}%` : "—"}
                      </div>
                      <div className="text-xs text-gray-500">Pass Rate</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-sm text-gray-500">Average Score</span>
                      <div className={`text-2xl font-bold ${teacher.hasData ? getScoreColor(teacher.avgScore) : "text-gray-400"}`}>
                        {teacher.hasData ? `${teacher.avgScore}%` : "—"}
                      </div>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${badge.classes}`}>
                      {badge.label}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
