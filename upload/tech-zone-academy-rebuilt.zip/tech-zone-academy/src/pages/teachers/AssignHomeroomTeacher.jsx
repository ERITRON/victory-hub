import { useEffect, useState } from "react";
import { db, collection, getDocs, addDoc, query, where } from "../../supabase/supabase";
import { provisionGradeGroupChat } from "../../services/chatService";
import { useAuth } from "../../context/AuthContext";

export default function AssignHomeroomTeacher() {
  const { user } = useAuth();
  const [teachers, setTeachers] = useState([]);
  const [grades, setGrades] = useState([]);
  const [sections, setSections] = useState([]);
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const [formData, setFormData] = useState({
    teacherId: "",
    teacherName: "",
    grade: "",
    section: "",
  });

  const fetchAllData = async () => {
    setLoading(true);
    try {
      // Fetch teachers
      const teachersSnapshot = await getDocs(collection(db, "teachers"));
      const teachersData = teachersSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setTeachers(teachersData);

      // Fetch grades
      const gradesSnapshot = await getDocs(collection(db, "grades"));
      const gradesData = gradesSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setGrades(gradesData.sort((a, b) => a.name.localeCompare(b.name)));

      // Fetch sections
      const sectionsSnapshot = await getDocs(collection(db, "sections"));
      const sectionsData = sectionsSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSections(sectionsData.sort((a, b) => a.name.localeCompare(b.name)));

    } catch (error) {
      setErrorMessage("Error loading data: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    // If teacher is selected, update teacher name
    if (name === "teacherId") {
      const selectedTeacher = teachers.find((teacher) => teacher.id === value);
      if (selectedTeacher) {
        setFormData({
          ...formData,
          teacherId: value,
          teacherName: `${selectedTeacher.firstName} ${selectedTeacher.fatherName}`,
        });
      }
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const saveAssignment = async () => {
    setLoading(true);
    setErrorMessage("");
    setSuccessMessage("");

    const { teacherId, teacherName, grade, section } = formData;

    // Validation
    if (!teacherId) {
      setErrorMessage("Please select a teacher");
      setLoading(false);
      return;
    }
    if (!grade) {
      setErrorMessage("Please select a grade");
      setLoading(false);
      return;
    }
    if (!section) {
      setErrorMessage("Please select a section");
      setLoading(false);
      return;
    }

    try {
      // Check if homeroom already exists for this grade and section
      const q = query(
        collection(db, "homeroomAssignments"),
        where("grade", "==", grade),
        where("section", "==", section)
      );
      const existing = await getDocs(q);

      if (!existing.empty) {
        setErrorMessage(`A homeroom teacher is already assigned to ${grade} - ${section}`);
        setLoading(false);
        return;
      }

      await addDoc(collection(db, "homeroomAssignments"), {
        teacherId,
        teacherName,
        grade,
        section,
        createdAt: new Date().toISOString(),
      });

      const assignedTeacher = teachers.find((teacher) => teacher.id === teacherId);
      if (assignedTeacher?.userId) {
        await provisionGradeGroupChat(grade, section, assignedTeacher.userId, user.uid).catch((chatError) => {
          console.error("Grade group chat could not be set up:", chatError);
        });
      }

      setSuccessMessage(`✅ ${teacherName} assigned as homeroom teacher for ${grade} - ${section}`);

      // Reset form
      setFormData({
        teacherId: "",
        teacherName: "",
        grade: "",
        section: "",
      });

      // Auto-hide success message after 5 seconds
      setTimeout(() => setSuccessMessage(""), 5000);

    } catch (error) {
      setErrorMessage("Error saving assignment: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setLoading(false);
    }
  };

  const isFormValid = formData.teacherId && formData.grade && formData.section;

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
            🏫 Assign Homeroom Teacher
          </h1>
          <p className="text-gray-600 mt-1">
            Assign a homeroom teacher to a class
          </p>
        </div>

        {/* Messages */}
        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Form Card */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-6 sm:p-8">
            <div className="grid gap-5">
              {/* Teacher Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Teacher *
                </label>
                <select
                  name="teacherId"
                  value={formData.teacherId}
                  onChange={handleChange}
                  className={`w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white ${
                    formData.teacherId ? "border-green-500" : "border-gray-300"
                  }`}
                >
                  <option value="">Select Teacher</option>
                  {loading ? (
                    <option disabled>Loading teachers...</option>
                  ) : (
                    teachers.map((teacher) => (
                      <option key={teacher.id} value={teacher.id}>
                        {teacher.firstName} {teacher.fatherName} ({teacher.teacherId})
                      </option>
                    ))
                  )}
                </select>
                {formData.teacherName && (
                  <p className="text-sm text-green-600 mt-1">
                    Selected: {formData.teacherName}
                  </p>
                )}
              </div>

              {/* Grade Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Grade *
                </label>
                <select
                  name="grade"
                  value={formData.grade}
                  onChange={handleChange}
                  className={`w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white ${
                    formData.grade ? "border-green-500" : "border-gray-300"
                  }`}
                >
                  <option value="">Select Grade</option>
                  {grades.map((grade) => (
                    <option key={grade.id} value={grade.name}>
                      {grade.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Section Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Section *
                </label>
                <select
                  name="section"
                  value={formData.section}
                  onChange={handleChange}
                  className={`w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white ${
                    formData.section ? "border-green-500" : "border-gray-300"
                  }`}
                >
                  <option value="">Select Section</option>
                  {sections.map((section) => (
                    <option key={section.id} value={section.name}>
                      {section.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Summary Card */}
              {formData.teacherId && formData.grade && formData.section && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-2">
                  <h3 className="font-semibold text-blue-800 mb-2">Assignment Summary</h3>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="text-gray-600">Teacher:</span>
                      <span className="font-medium text-gray-800 block">{formData.teacherName}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Class:</span>
                      <span className="font-medium text-gray-800 block">{formData.grade} - {formData.section}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Submit Button */}
              <button
                onClick={saveAssignment}
                disabled={!isFormValid || loading}
                className={`w-full py-4 rounded-lg font-semibold text-white transition mt-4 ${
                  isFormValid && !loading
                    ? "bg-blue-700 hover:bg-blue-800 hover:shadow-lg"
                    : "bg-gray-400 cursor-not-allowed"
                }`}
              >
                {loading ? (
                  <span className="flex items-center justify-center gap-2">
                    <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Assigning...
                  </span>
                ) : (
                  "Assign Homeroom Teacher"
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}