import { useEffect, useMemo, useState } from "react";
import { collection, doc, getDoc, getDocs, query, where } from "../../supabase/supabase";
import { useAuth } from "../../context/AuthContext";
import { db } from "../../supabase/supabase";
import DashboardShell from "../../components/dashboard/DashboardShell";
import { SkeletonDashboard } from "../../components/LoadingSkeleton";
import { assignmentMatchesAttendance, attendanceSummary, classKey, formatPercent } from "../dashboardUtils";

export default function TeacherDashboard() {
  const { user } = useAuth();
  const [teacher, setTeacher] = useState(null);
  const [assignments, setAssignments] = useState([]);
  const [students, setStudents] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    Promise.all([
      getDoc(doc(db, "teachers", user.uid)),
      getDocs(query(collection(db, "teacherAssignments"), where("teacherId", "==", user.uid))),
      getDocs(collection(db, "students")),
      getDocs(collection(db, "attendance")),
    ]).then(([teacherDoc, assignmentSnap, studentSnap, attendanceSnap]) => {
      setTeacher(teacherDoc.exists() ? { id: teacherDoc.id, ...teacherDoc.data() } : null);
      setAssignments(assignmentSnap.docs.map((item) => ({ id: item.id, ...item.data() })));
      setStudents(studentSnap.docs.map((item) => ({ id: item.id, ...item.data() })));
      setAttendance(attendanceSnap.docs.map((item) => ({ id: item.id, ...item.data() })));
    }).catch((error) => console.error("Unable to load teacher dashboard", error)).finally(() => setLoading(false));
  }, [user]);

  const classKeys = useMemo(() => new Set(assignments.map(classKey)), [assignments]);
  const assignedStudents = useMemo(() => students.filter((student) => classKeys.has(classKey(student))), [classKeys, students]);
  const ownAttendance = useMemo(() => attendance.filter((record) => assignments.some((assignment) => assignmentMatchesAttendance(record, assignment))), [assignments, attendance]);
  const summary = useMemo(() => attendanceSummary(ownAttendance), [ownAttendance]);

  const statCards = [
    { label: "Assigned Classes", value: assignments.length, icon: "classroom", color: "text-blue-700", bgColor: "bg-blue-50", borderColor: "border-blue-200" },
    { label: "Assigned Students", value: assignedStudents.length, icon: "student", color: "text-indigo-700", bgColor: "bg-indigo-50", borderColor: "border-indigo-200" },
    { label: "Attendance Records", value: summary.total, icon: "attendance", color: "text-emerald-700", bgColor: "bg-emerald-50", borderColor: "border-emerald-200" },
    { label: "Attendance Rate", value: formatPercent(summary.rate), icon: "chart", color: "text-violet-700", bgColor: "bg-violet-50", borderColor: "border-violet-200" },
  ];

  const dashboardItems = [
    { icon: "classroom", title: "My Classes", description: `${assignments.length} assigned class${assignments.length === 1 ? "" : "es"}`, route: "/teacher-classes", color: "bg-blue-50 hover:bg-blue-100 border-blue-200", iconColor: "text-blue-700" },
    { icon: "student", title: "My Students", description: `${assignedStudents.length} students across assigned classes`, route: "/teacher-students", color: "bg-indigo-50 hover:bg-indigo-100 border-indigo-200", iconColor: "text-indigo-700" },
    { icon: "exam", title: "Add Result", description: "Enter student results and scores", route: "/add-result", color: "bg-emerald-50 hover:bg-emerald-100 border-emerald-200", iconColor: "text-emerald-700" },
    { icon: "result", title: "My Results", description: "View results entered for your classes", route: "/teacher-results", color: "bg-purple-50 hover:bg-purple-100 border-purple-200", iconColor: "text-purple-700" },
    { icon: "assignment", title: "Assignments", description: "Upload class assignments and files", route: "/teacher-assignments-upload", color: "bg-orange-50 hover:bg-orange-100 border-orange-200", iconColor: "text-orange-700" },
    { icon: "calendar", title: "My Schedule", description: "View your weekly schedule", route: "/teacher-schedule", color: "bg-rose-50 hover:bg-rose-100 border-rose-200", iconColor: "text-rose-700" },
    { icon: "message", title: "Messages", description: "Chat with parents and your homeroom class", route: "/chat", color: "bg-cyan-50 hover:bg-cyan-100 border-cyan-200", iconColor: "text-cyan-700" },
    { icon: "teacher", title: "My Profile", description: "View your teacher profile", route: "/teacher-profile", color: "bg-sky-50 hover:bg-sky-100 border-sky-200", iconColor: "text-sky-700" },
    { icon: "settings", title: "Security Settings", description: "Update password and security", route: "/profile", color: "bg-slate-50 hover:bg-slate-100 border-slate-200", iconColor: "text-slate-700" },
    { icon: "attendance", title: "Attendance Report", description: `${summary.total} records from your assigned classes`, route: "/teacher-attendance", color: "bg-violet-50 hover:bg-violet-100 border-violet-200", iconColor: "text-violet-700" },
  ];

  if (loading) return <div className="mx-auto min-h-screen max-w-7xl bg-slate-50 px-4 py-8"><SkeletonDashboard /></div>;

  return <DashboardShell icon="teacher" title="Teacher Dashboard" welcomeName={teacher?.fullName || teacher?.name || "Teacher"} subtitle={teacher?.teacherId || user?.email || ""} badgeLabel="Teacher" badgeColor="bg-blue-100 text-blue-700" stats={statCards} statsColumns="grid-cols-2 md:grid-cols-4" menuItems={dashboardItems} footerText="Tech Zone Academy - Teacher Dashboard" />;
}
