import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { db, collection, getDocs } from "../../supabase/supabase";

export default function TeacherManagement() {
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    totalTeachers: 0,
    totalAssignments: 0,
    totalHomeroom: 0,
    activeTeachers: 0,
  });
  const [loading, setLoading] = useState(true);

  const fetchStats = async () => {
    try {
      // Get all teachers
      const teachersSnap = await getDocs(collection(db, "teachers"));
      const teachers = teachersSnap.docs.map((doc) => doc.data());

      // Get teacher assignments
      const assignmentsSnap = await getDocs(collection(db, "teacherAssignments"));

      // Get homeroom assignments
      const homeroomSnap = await getDocs(collection(db, "homeroomAssignments"));

      // Calculate stats
      const activeTeachers = teachers.filter((t) => t.status === "active").length;

      setStats({
        totalTeachers: teachers.length,
        totalAssignments: assignmentsSnap.size,
        totalHomeroom: homeroomSnap.size,
        activeTeachers: activeTeachers,
      });
    } catch (error) {
      console.error("Error fetching stats:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  const menuItems = [
    {
      icon: "➕",
      title: "Add Teacher",
      description: "Register a new teacher with login account",
      route: "/add-teacher",
      color: "bg-blue-50 hover:bg-blue-100 border-blue-200",
      iconColor: "text-blue-700",
    },
    {
      icon: "📋",
      title: "Teachers List",
      description: "View, Edit and Delete teachers",
      route: "/teacher-list",
      color: "bg-green-50 hover:bg-green-100 border-green-200",
      iconColor: "text-green-700",
    },
    {
      icon: "📚",
      title: "Assign Teacher",
      description: "Assign a teacher to a class and subject",
      route: "/assign-teacher",
      color: "bg-purple-50 hover:bg-purple-100 border-purple-200",
      iconColor: "text-purple-700",
    },
    {
      icon: "📊",
      title: "Teacher Assignments",
      description: "View and manage teacher assignments",
      route: "/teacher-assignments",
      color: "bg-orange-50 hover:bg-orange-100 border-orange-200",
      iconColor: "text-orange-700",
    },
    {
      icon: "🏫",
      title: "Homeroom Teachers",
      description: "Assign homeroom teachers to classes",
      route: "/assign-homeroom-teacher",
      color: "bg-red-50 hover:bg-red-100 border-red-200",
      iconColor: "text-red-700",
    },
    {
      icon: "📋",
      title: "Homeroom Assignments",
      description: "View and manage homeroom assignments",
      route: "/homeroom-assignments",
      color: "bg-indigo-50 hover:bg-indigo-100 border-indigo-200",
      iconColor: "text-indigo-700",
    },
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading statistics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              👨‍🏫 Teacher Management
            </h1>
            <p className="text-gray-600 mt-1">
              Manage teachers, assignments, and homeroom classes
            </p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-blue-500">
            <div className="text-2xl font-bold text-blue-700">{stats.totalTeachers}</div>
            <div className="text-xs sm:text-sm text-gray-600">Total Teachers</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-green-500">
            <div className="text-2xl font-bold text-green-700">{stats.activeTeachers}</div>
            <div className="text-xs sm:text-sm text-gray-600">Active Teachers</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-purple-500">
            <div className="text-2xl font-bold text-purple-700">{stats.totalAssignments}</div>
            <div className="text-xs sm:text-sm text-gray-600">Assignments</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-orange-500">
            <div className="text-2xl font-bold text-orange-700">{stats.totalHomeroom}</div>
            <div className="text-xs sm:text-sm text-gray-600">Homeroom Classes</div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
          <button
            onClick={() => navigate("/add-teacher")}
            className="bg-blue-700 text-white px-4 py-3 rounded-lg hover:bg-blue-800 transition text-sm font-medium"
          >
            ➕ Add Teacher
          </button>
          <button
            onClick={() => navigate("/teacher-list")}
            className="bg-green-700 text-white px-4 py-3 rounded-lg hover:bg-green-800 transition text-sm font-medium"
          >
            📋 View All Teachers
          </button>
          <button
            onClick={() => navigate("/assign-teacher")}
            className="bg-purple-700 text-white px-4 py-3 rounded-lg hover:bg-purple-800 transition text-sm font-medium"
          >
            📚 Assign Teacher
          </button>
          <button
            onClick={() => navigate("/assign-homeroom-teacher")}
            className="bg-red-700 text-white px-4 py-3 rounded-lg hover:bg-red-800 transition text-sm font-medium"
          >
            🏫 Assign Homeroom
          </button>
        </div>

        {/* Menu Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {menuItems.map((item, index) => (
            <div
              key={index}
              onClick={() => navigate(item.route)}
              className={`
                ${item.color}
                border-2
                rounded-xl
                p-6
                cursor-pointer
                transition-all
                duration-300
                hover:shadow-xl
                hover:-translate-y-1
                hover:border-opacity-100
              `}
            >
              <div className="flex items-start gap-4">
                <div className={`text-4xl ${item.iconColor}`}>
                  {item.icon}
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-gray-800">
                    {item.title}
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {item.description}
                  </p>
                </div>
              </div>
              <div className="mt-3 flex justify-end">
                <span className="text-sm text-gray-400">→</span>
              </div>
            </div>
          ))}
        </div>

        {/* Quick Tips */}
        <div className="mt-8 bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-3">📌 Quick Tips</h3>
          <ul className="space-y-2 text-sm text-gray-600">
            <li className="flex items-start gap-2">
              <span className="text-blue-600">•</span>
              Use "Add Teacher" to create new teacher accounts with login credentials
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-600">•</span>
              Assign teachers to classes and subjects using "Assign Teacher"
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-600">•</span>
              Set homeroom teachers for each class using "Homeroom Teachers"
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-600">•</span>
              View all assignments in "Teacher Assignments" and "Homeroom Assignments"
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}