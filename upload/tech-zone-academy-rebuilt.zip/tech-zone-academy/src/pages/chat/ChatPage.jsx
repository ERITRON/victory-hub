// src/pages/chat/ChatPage.jsx
import { useEffect, useRef, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { db, collection, query, where, getDocs, getDoc, doc } from "../../supabase/supabase";
import { supabase } from "../../supabase/supabaseClient";
import { useAuth } from "../../context/AuthContext";
import {
  sendMessage,
  markConversationRead,
  setParticipantMuted,
  toggleAnnouncementOnly,
  pinMessage,
  softDeleteMessage,
  findOrCreateDirectConversation,
  getHomeroomTeacherForStudent,
} from "../../services/chatService";
import { useParentChildren } from "../../hooks/useParentChildren";
import SEO from "../../components/SEO";

const snap = (snapshot) => snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));

function conversationLabel(conversation, participants, myUserId, directory) {
  if (conversation.type === "grade_group") return conversation.title || `${conversation.grade} - Section ${conversation.section}`;
  const other = participants.find((p) => p.userId !== myUserId);
  return other ? directory.get(other.userId)?.name || "Conversation" : "Conversation";
}

export default function ChatPage() {
  const { user, role } = useAuth();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const activeConversationId = searchParams.get("c");

  const [conversations, setConversations] = useState([]);
  const [participantsByConversation, setParticipantsByConversation] = useState({});
  const [directory, setDirectory] = useState(new Map()); // userId -> { name }
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [messages, setMessages] = useState([]);
  const [messagesLoading, setMessagesLoading] = useState(false);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef(null);

  const { children: linkedChildren } = useParentChildren(role === "parent" ? user?.uid : null);
  const [homeroomTeachers, setHomeroomTeachers] = useState([]); // [{ studentName, userId, fullName }]
  const [startingChatWith, setStartingChatWith] = useState(null);

  useEffect(() => {
    if (role !== "parent" || linkedChildren.length === 0) return;
    let active = true;
    Promise.all(
      linkedChildren.map(async (child) => {
        const teacher = await getHomeroomTeacherForStudent(child);
        return teacher ? { studentName: `${child.firstName} ${child.fatherName}`, ...teacher } : null;
      })
    ).then((results) => {
      if (active) setHomeroomTeachers(results.filter(Boolean));
    });
    return () => { active = false; };
  }, [role, linkedChildren]);

  const startTeacherChat = async (teacherUserId) => {
    setStartingChatWith(teacherUserId);
    try {
      const conversationId = await findOrCreateDirectConversation(user.uid, teacherUserId);
      setSearchParams({ c: conversationId });
      // Refresh the conversation list so the new thread shows up.
      const myParticipation = snap(await getDocs(query(collection(db, "chatParticipants"), where("userId", "==", user.uid))));
      const conversationIds = myParticipation.map((p) => p.conversationId);
      const conversationDocs = await Promise.all(conversationIds.map((id) => getDoc(doc(db, "chatConversations", id))));
      setConversations(conversationDocs.filter((d) => d.exists()).map((d) => ({ id: d.id, ...d.data() })));
    } catch (startError) {
      alert("Could not start conversation: " + startError.message);
    } finally {
      setStartingChatWith(null);
    }
  };

  const teachersWithoutChat = homeroomTeachers.filter(
    (t) => !conversations.some((c) => c.type === "direct" && (participantsByConversation[c.id] || []).some((p) => p.userId === t.userId))
  );

  useEffect(() => {
    if (!user) return;
    let active = true;

    (async () => {
      setLoading(true);
      setError("");
      try {
        const myParticipation = snap(
          await getDocs(query(collection(db, "chatParticipants"), where("userId", "==", user.uid)))
        );
        const conversationIds = myParticipation.map((p) => p.conversationId);
        if (conversationIds.length === 0) {
          if (active) { setConversations([]); setLoading(false); }
          return;
        }

        const conversationDocs = await Promise.all(conversationIds.map((id) => getDoc(doc(db, "chatConversations", id))));
        const conversationRows = conversationDocs.filter((d) => d.exists()).map((d) => ({ id: d.id, ...d.data() }));

        const allParticipants = snap(
          await getDocs(query(collection(db, "chatParticipants"), where("conversationId", "in", conversationIds)))
        );
        const byConversation = {};
        allParticipants.forEach((p) => {
          byConversation[p.conversationId] = [...(byConversation[p.conversationId] || []), p];
        });

        const otherUserIds = [...new Set(allParticipants.map((p) => p.userId))];
        const userDocs = otherUserIds.length
          ? snap(await getDocs(query(collection(db, "users"), where("id", "in", otherUserIds))))
          : [];
        const dir = new Map(userDocs.map((u) => [u.id, { name: u.name || u.email || "User" }]));

        // Sort by most recent activity, computed from messages (not a
        // stored lastMessageAt field, since only the conversation head
        // has write access to chat_conversations under RLS).
        const recentMessages = conversationIds.length
          ? snap(await getDocs(query(collection(db, "chatMessages"), where("conversationId", "in", conversationIds))))
          : [];
        const latestByConversation = new Map();
        recentMessages.forEach((m) => {
          const current = latestByConversation.get(m.conversationId);
          if (!current || new Date(m.createdAt) > new Date(current)) latestByConversation.set(m.conversationId, m.createdAt);
        });
        conversationRows.sort((a, b) => {
          const aTime = latestByConversation.get(a.id) || a.createdAt || 0;
          const bTime = latestByConversation.get(b.id) || b.createdAt || 0;
          return new Date(bTime) - new Date(aTime);
        });

        if (!active) return;
        setConversations(conversationRows);
        setParticipantsByConversation(byConversation);
        setDirectory(dir);

        if (!activeConversationId && conversationRows.length > 0) {
          setSearchParams({ c: conversationRows[0].id });
        }
      } catch (loadError) {
        console.error("Unable to load conversations", loadError);
        if (active) setError("Conversations could not be loaded.");
      } finally {
        if (active) setLoading(false);
      }
    })();

    return () => { active = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  useEffect(() => {
    if (!activeConversationId || !user) return;
    let active = true;
    setMessagesLoading(true);

    getDocs(query(collection(db, "chatMessages"), where("conversationId", "==", activeConversationId)))
      .then((snapshot) => {
        if (!active) return;
        const rows = snap(snapshot).sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
        setMessages(rows);
        markConversationRead(activeConversationId, user.uid).catch(() => {});
      })
      .catch((loadError) => console.error("Unable to load messages", loadError))
      .finally(() => { if (active) setMessagesLoading(false); });

    const channel = supabase
      .channel(`chat-${activeConversationId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "chat_messages", filter: `conversation_id=eq.${activeConversationId}` },
        (payload) => {
          if (payload.eventType === "INSERT") {
            const row = payload.new;
            setMessages((prev) => [...prev, {
              id: row.id,
              conversationId: row.conversation_id,
              senderId: row.sender_id,
              body: row.body,
              attachmentUrl: row.attachment_url,
              attachmentName: row.attachment_name,
              pinned: row.pinned,
              createdAt: row.created_at,
              deletedAt: row.deleted_at,
            }]);
            markConversationRead(activeConversationId, user.uid).catch(() => {});
          } else if (payload.eventType === "UPDATE") {
            const row = payload.new;
            setMessages((prev) => prev.map((m) => (m.id === row.id ? { ...m, pinned: row.pinned, deletedAt: row.deleted_at } : m)));
          }
        }
      )
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, [activeConversationId, user]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  const activeConversation = conversations.find((c) => c.id === activeConversationId);
  const activeParticipants = participantsByConversation[activeConversationId] || [];
  const myParticipant = activeParticipants.find((p) => p.userId === user?.uid);
  const isHead = myParticipant?.role === "head" || role === "admin" || role === "vice_principal";
  const isMuted = !!myParticipant?.muted;
  const canPost = !isMuted && (!activeConversation?.announcementOnly || isHead);

  const handleSend = async () => {
    if (!draft.trim() || !activeConversationId || sending) return;
    setSending(true);
    try {
      await sendMessage(activeConversationId, user.uid, draft.trim());
      setDraft("");
    } catch (sendError) {
      alert("Message could not be sent: " + sendError.message);
    } finally {
      setSending(false);
    }
  };

  return (
    <>
      <SEO title="Messages" noindex />
      <main className="flex h-screen flex-col bg-slate-50">
        <header className="flex items-center gap-4 border-b border-slate-200 bg-white px-4 py-3">
          <button type="button" onClick={() => navigate(-1)} className="rounded-lg border border-slate-200 px-3 py-1.5 text-sm font-semibold text-slate-700">Back</button>
          <h1 className="text-lg font-bold text-slate-900">Messages</h1>
        </header>

        <div className="flex flex-1 overflow-hidden">
          <aside className="w-full max-w-xs shrink-0 overflow-y-auto border-r border-slate-200 bg-white">
            {role === "parent" && teachersWithoutChat.length > 0 && (
              <div className="border-b border-slate-200 bg-slate-50 p-3">
                <p className="mb-2 text-xs font-bold uppercase text-slate-500">Message a homeroom teacher</p>
                <div className="space-y-2">
                  {teachersWithoutChat.map((t) => (
                    <button
                      key={t.userId}
                      onClick={() => startTeacherChat(t.userId)}
                      disabled={startingChatWith === t.userId}
                      className="block w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-left text-sm hover:bg-blue-50 disabled:opacity-50"
                    >
                      <span className="font-semibold text-slate-800">{t.fullName || "Teacher"}</span>
                      <span className="block text-xs text-slate-500">{t.studentName}'s homeroom teacher</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
            {loading ? (
              <p className="p-4 text-sm text-slate-500">Loading…</p>
            ) : error ? (
              <p className="p-4 text-sm text-rose-600">{error}</p>
            ) : conversations.length === 0 ? (
              <p className="p-4 text-sm text-slate-500">No conversations yet.</p>
            ) : (
              conversations.map((c) => {
                const participants = participantsByConversation[c.id] || [];
                const label = conversationLabel(c, participants, user.uid, directory);
                const isActive = c.id === activeConversationId;
                return (
                  <button
                    key={c.id}
                    onClick={() => setSearchParams({ c: c.id })}
                    className={`block w-full border-b border-slate-100 px-4 py-3 text-left ${isActive ? "bg-blue-50" : "hover:bg-slate-50"}`}
                  >
                    <p className="truncate text-sm font-semibold text-slate-800">{label}</p>
                    <p className="mt-0.5 text-xs text-slate-500">{c.type === "grade_group" ? "Class chat" : "Direct message"}</p>
                  </button>
                );
              })
            )}
          </aside>

          <section className="flex flex-1 flex-col">
            {!activeConversation ? (
              <div className="flex flex-1 items-center justify-center text-sm text-slate-500">Select a conversation.</div>
            ) : (
              <>
                <div className="flex items-center justify-between border-b border-slate-200 bg-white px-4 py-3">
                  <div>
                    <p className="text-sm font-bold text-slate-900">{conversationLabel(activeConversation, activeParticipants, user.uid, directory)}</p>
                    {activeConversation.announcementOnly && <p className="text-xs text-amber-600">Announcement mode — only the class teacher can post</p>}
                  </div>
                  {isHead && activeConversation.type === "grade_group" && (
                    <button
                      onClick={() => toggleAnnouncementOnly(activeConversation.id, !activeConversation.announcementOnly).then(() =>
                        setConversations((prev) => prev.map((c) => (c.id === activeConversation.id ? { ...c, announcementOnly: !c.announcementOnly } : c)))
                      )}
                      className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                    >
                      {activeConversation.announcementOnly ? "Allow replies" : "Announcement mode"}
                    </button>
                  )}
                </div>

                <div className="flex-1 overflow-y-auto px-4 py-4">
                  {messagesLoading ? (
                    <p className="text-sm text-slate-500">Loading…</p>
                  ) : (
                    <div className="space-y-3">
                      {messages.filter((m) => !m.deletedAt).map((m) => {
                        const mine = m.senderId === user.uid;
                        return (
                          <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                            <div className={`max-w-[75%] rounded-2xl px-4 py-2 ${mine ? "bg-blue-700 text-white" : "bg-white border border-slate-200 text-slate-800"}`}>
                              {!mine && <p className="mb-0.5 text-xs font-semibold text-slate-500">{directory.get(m.senderId)?.name || "User"}</p>}
                              {m.pinned && <p className="mb-1 text-xs font-semibold uppercase text-amber-500">📌 Pinned</p>}
                              {m.body && <p className="whitespace-pre-wrap break-words text-sm">{m.body}</p>}
                              {m.attachmentUrl && (
                                <a href={m.attachmentUrl} target="_blank" rel="noopener noreferrer" className={`mt-1 block text-xs underline ${mine ? "text-blue-100" : "text-blue-700"}`}>
                                  {m.attachmentName || "Attachment"}
                                </a>
                              )}
                              <p className={`mt-1 text-[10px] ${mine ? "text-blue-100" : "text-slate-400"}`}>{new Date(m.createdAt).toLocaleString()}</p>
                              {isHead && (
                                <div className="mt-1 flex gap-2">
                                  <button onClick={() => pinMessage(m.id, !m.pinned)} className={`text-[10px] underline ${mine ? "text-blue-100" : "text-slate-400"}`}>{m.pinned ? "Unpin" : "Pin"}</button>
                                  <button onClick={() => softDeleteMessage(m.id).then(() => setMessages((prev) => prev.map((msg) => (msg.id === m.id ? { ...msg, deletedAt: new Date().toISOString() } : msg))))} className={`text-[10px] underline ${mine ? "text-blue-100" : "text-slate-400"}`}>Delete</button>
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                      <div ref={messagesEndRef} />
                    </div>
                  )}
                </div>

                <div className="border-t border-slate-200 bg-white p-3">
                  {!canPost ? (
                    <p className="text-center text-sm text-slate-500">{isMuted ? "You've been muted in this conversation." : "Only the class teacher can post here."}</p>
                  ) : (
                    <div className="flex gap-2">
                      <input
                        value={draft}
                        onChange={(e) => setDraft(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && (e.preventDefault(), handleSend())}
                        placeholder="Type a message…"
                        className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      <button onClick={handleSend} disabled={sending || !draft.trim()} className="rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-800 disabled:bg-gray-300">
                        Send
                      </button>
                    </div>
                  )}
                </div>

                {isHead && activeConversation.type === "grade_group" && (
                  <div className="border-t border-slate-200 bg-white px-4 py-3">
                    <p className="mb-2 text-xs font-bold uppercase text-slate-500">Participants ({activeParticipants.length})</p>
                    <div className="flex flex-wrap gap-2">
                      {activeParticipants.map((p) => (
                        <span key={p.id} className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-xs ${p.muted ? "border-rose-200 bg-rose-50 text-rose-700" : "border-slate-200 bg-slate-50 text-slate-700"}`}>
                          {directory.get(p.userId)?.name || "User"}{p.role === "head" && " 👑"}
                          {p.userId !== user.uid && (
                            <button onClick={() => setParticipantMuted(p.id, !p.muted).then(() =>
                              setParticipantsByConversation((prev) => ({
                                ...prev,
                                [activeConversation.id]: prev[activeConversation.id].map((row) => (row.id === p.id ? { ...row, muted: !row.muted } : row)),
                              }))
                            )} className="ml-1 underline">{p.muted ? "unmute" : "mute"}</button>
                          )}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </section>
        </div>
      </main>
    </>
  );
}
