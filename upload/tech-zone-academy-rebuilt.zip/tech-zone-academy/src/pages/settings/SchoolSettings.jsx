import { useState, useEffect } from "react";
import { db, collection, doc, getDocs, addDoc, deleteDoc, updateDoc } from "../../supabase/supabase";
import { useWebsiteSettings } from "../../context/WebsiteSettingsContext";

export default function SchoolSettings() {
  const { settings, loading: settingsLoading, updateSetting } = useWebsiteSettings();
  const [activeTab, setActiveTab] = useState("info");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");

  // School Info
  const [schoolInfo, setSchoolInfo] = useState({
    schoolName: "Tech Zone Academy",
    academicYear: "2026",
    phone: "",
    secondaryPhone: "",
    email: "",
    address: "",
    addressLine2: "",
    workingHours: "",
    saturdayHours: "",
    motto: "",
    principal: "",
    mapEmbedUrl: "",
  });

  // Grades
  const [grades, setGrades] = useState([]);
  const [newGrade, setNewGrade] = useState("");
  const [editingGrade, setEditingGrade] = useState(null);

  // Sections
  const [sections, setSections] = useState([]);
  const [newSection, setNewSection] = useState("");
  const [editingSection, setEditingSection] = useState(null);

  // Subjects
  const [subjects, setSubjects] = useState([]);
  const [newSubject, setNewSubject] = useState("");
  const [editingSubject, setEditingSubject] = useState(null);

  // Clear messages after 3 seconds
  useEffect(() => {
    if (success || error) {
      const timer = setTimeout(() => {
        setSuccess("");
        setError("");
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [success, error]);

  // ---- SCHOOL INFO ----
  useEffect(() => {
    if (settings?.schoolInfo) {
      setSchoolInfo((current) => ({ ...current, ...settings.schoolInfo }));
    }
  }, [settings?.schoolInfo]);

  const saveSchoolInfo = async () => {
    setLoading(true);
    setError("");
    setSuccess("");
    try {
      const saved = await updateSetting("schoolInfo", schoolInfo);
      if (!saved) throw new Error("School information could not be saved.");
      setSuccess("✅ School info saved successfully!");
    } catch (error) {
      setError("❌ Error saving: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  // ---- GRADES ----
  const loadGrades = async () => {
    try {
      const snapshot = await getDocs(collection(db, "grades"));
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setGrades(data.sort((a, b) => a.name.localeCompare(b.name)));
    } catch (error) {
      console.error("Error loading grades:", error);
    }
  };

  const addGrade = async () => {
    if (!newGrade.trim()) return;
    setLoading(true);
    setError("");
    setSuccess("");
    try {
      const exists = grades.some((g) => g.name === newGrade.trim());
      if (exists) {
        setError("⚠️ This grade already exists!");
        setLoading(false);
        return;
      }
      await addDoc(collection(db, "grades"), {
        name: newGrade.trim(),
        order: grades.length + 1,
        createdAt: new Date().toISOString(),
      });
      setNewGrade("");
      await loadGrades();
      setSuccess("✅ Grade added successfully!");
    } catch (error) {
      setError("❌ Error: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const updateGrade = async () => {
    if (!editingGrade || !editingGrade.name.trim()) return;
    setLoading(true);
    setError("");
    setSuccess("");
    try {
      await updateDoc(doc(db, "grades", editingGrade.id), {
        name: editingGrade.name.trim(),
      });
      setEditingGrade(null);
      await loadGrades();
      setSuccess("✅ Grade updated successfully!");
    } catch (error) {
      setError("❌ Error: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const deleteGrade = async (id) => {
    if (!window.confirm("Delete this grade? This action cannot be undone.")) return;
    setLoading(true);
    setError("");
    setSuccess("");
    try {
      await deleteDoc(doc(db, "grades", id));
      await loadGrades();
      setSuccess("✅ Grade deleted successfully!");
    } catch (error) {
      setError("❌ Error: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  // ---- SECTIONS ----
  const loadSections = async () => {
    try {
      const snapshot = await getDocs(collection(db, "sections"));
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSections(data.sort((a, b) => a.name.localeCompare(b.name)));
    } catch (error) {
      console.error("Error loading sections:", error);
    }
  };

  const addSection = async () => {
    if (!newSection.trim()) return;
    setLoading(true);
    setError("");
    setSuccess("");
    try {
      const exists = sections.some((s) => s.name === newSection.trim());
      if (exists) {
        setError("⚠️ This section already exists!");
        setLoading(false);
        return;
      }
      await addDoc(collection(db, "sections"), {
        name: newSection.trim().toUpperCase(),
        createdAt: new Date().toISOString(),
      });
      setNewSection("");
      await loadSections();
      setSuccess("✅ Section added successfully!");
    } catch (error) {
      setError("❌ Error: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const updateSection = async () => {
    if (!editingSection || !editingSection.name.trim()) return;
    setLoading(true);
    setError("");
    setSuccess("");
    try {
      await updateDoc(doc(db, "sections", editingSection.id), {
        name: editingSection.name.trim().toUpperCase(),
      });
      setEditingSection(null);
      await loadSections();
      setSuccess("✅ Section updated successfully!");
    } catch (error) {
      setError("❌ Error: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const deleteSection = async (id) => {
    if (!window.confirm("Delete this section? This action cannot be undone.")) return;
    setLoading(true);
    setError("");
    setSuccess("");
    try {
      await deleteDoc(doc(db, "sections", id));
      await loadSections();
      setSuccess("✅ Section deleted successfully!");
    } catch (error) {
      setError("❌ Error: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  // ---- SUBJECTS ----
  const loadSubjects = async () => {
    try {
      const snapshot = await getDocs(collection(db, "subjects"));
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSubjects(data.sort((a, b) => a.name.localeCompare(b.name)));
    } catch (error) {
      console.error("Error loading subjects:", error);
    }
  };

  // Load all settings
  useEffect(() => {
    loadGrades();
    loadSections();
    loadSubjects();
    // eslint-disable-next-line react-hooks/exhaustive-deps -- load helpers are stable; run once on mount
  }, []);

  const addSubject = async () => {
    if (!newSubject.trim()) return;
    setLoading(true);
    setError("");
    setSuccess("");
    try {
      const exists = subjects.some((s) => s.name === newSubject.trim());
      if (exists) {
        setError("⚠️ This subject already exists!");
        setLoading(false);
        return;
      }
      await addDoc(collection(db, "subjects"), {
        name: newSubject.trim(),
        createdAt: new Date().toISOString(),
      });
      setNewSubject("");
      await loadSubjects();
      setSuccess("✅ Subject added successfully!");
    } catch (error) {
      setError("❌ Error: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const updateSubject = async () => {
    if (!editingSubject || !editingSubject.name.trim()) return;
    setLoading(true);
    setError("");
    setSuccess("");
    try {
      await updateDoc(doc(db, "subjects", editingSubject.id), {
        name: editingSubject.name.trim(),
      });
      setEditingSubject(null);
      await loadSubjects();
      setSuccess("✅ Subject updated successfully!");
    } catch (error) {
      setError("❌ Error: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const deleteSubject = async (id) => {
    if (!window.confirm("Delete this subject? This action cannot be undone.")) return;
    setLoading(true);
    setError("");
    setSuccess("");
    try {
      await deleteDoc(doc(db, "subjects", id));
      await loadSubjects();
      setSuccess("✅ Subject deleted successfully!");
    } catch (error) {
      setError("❌ Error: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  // ---- RENDER TABS ----
  const renderTabContent = () => {
    switch (activeTab) {
      case "info":
        return renderSchoolInfo();
      case "grades":
        return renderGrades();
      case "sections":
        return renderSections();
      case "subjects":
        return renderSubjects();
      default:
        return null;
    }
  };

  // ---- TAB: SCHOOL INFO ----
  const renderSchoolInfo = () => (
    <div className="space-y-4">
      <h2 className="text-xl sm:text-2xl font-bold text-gray-800">🏫 School Information</h2>
      <p className="text-sm text-gray-500">
        These details are used across the hero, navigation, footer, contact page,
        and other public pages.
      </p>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">School Name</label>
          <input
            type="text"
            value={schoolInfo.schoolName}
            onChange={(e) => setSchoolInfo({ ...schoolInfo, schoolName: e.target.value })}
            className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Academic Year</label>
          <input
            type="text"
            value={schoolInfo.academicYear}
            onChange={(e) => setSchoolInfo({ ...schoolInfo, academicYear: e.target.value })}
            className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
          <input
            type="text"
            value={schoolInfo.phone}
            onChange={(e) => setSchoolInfo({ ...schoolInfo, phone: e.target.value })}
            className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Secondary Phone</label>
          <input
            type="text"
            value={schoolInfo.secondaryPhone}
            onChange={(e) => setSchoolInfo({ ...schoolInfo, secondaryPhone: e.target.value })}
            placeholder="Optional"
            className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
          <input
            type="email"
            value={schoolInfo.email}
            onChange={(e) => setSchoolInfo({ ...schoolInfo, email: e.target.value })}
            className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
          />
        </div>
        <div className="sm:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
          <input
            type="text"
            value={schoolInfo.address}
            onChange={(e) => setSchoolInfo({ ...schoolInfo, address: e.target.value })}
            className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
          />
        </div>
        <div className="sm:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">Additional Address</label>
          <input
            type="text"
            value={schoolInfo.addressLine2}
            onChange={(e) => setSchoolInfo({ ...schoolInfo, addressLine2: e.target.value })}
            placeholder="Sub-city, woreda, landmark, or P.O. box"
            className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Weekday Working Hours</label>
          <input
            type="text"
            value={schoolInfo.workingHours}
            onChange={(e) => setSchoolInfo({ ...schoolInfo, workingHours: e.target.value })}
            placeholder="Mon-Fri: 8:00 AM - 5:00 PM"
            className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Saturday Hours</label>
          <input
            type="text"
            value={schoolInfo.saturdayHours}
            onChange={(e) => setSchoolInfo({ ...schoolInfo, saturdayHours: e.target.value })}
            placeholder="Optional"
            className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
          />
        </div>
        <div className="sm:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">Motto</label>
          <input
            type="text"
            value={schoolInfo.motto}
            onChange={(e) => setSchoolInfo({ ...schoolInfo, motto: e.target.value })}
            placeholder="e.g., Building Bright Futures"
            className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Principal</label>
          <input
            type="text"
            value={schoolInfo.principal}
            onChange={(e) => setSchoolInfo({ ...schoolInfo, principal: e.target.value })}
            className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
          />
        </div>
        <div className="sm:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">Google Maps Embed URL</label>
          <input
            type="url"
            value={schoolInfo.mapEmbedUrl}
            onChange={(e) => setSchoolInfo({ ...schoolInfo, mapEmbedUrl: e.target.value })}
            placeholder="https://www.google.com/maps/embed?..."
            className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
          />
          <p className="mt-1 text-xs text-gray-500">
            Optional. Paste the URL from the src attribute of a Google Maps embed.
          </p>
        </div>
      </div>
      
      <button
        onClick={saveSchoolInfo}
        disabled={loading || settingsLoading}
        className="bg-blue-700 text-white px-6 py-2.5 rounded-lg hover:bg-blue-800 transition disabled:opacity-50"
      >
        {loading ? "Saving..." : "💾 Save School Info"}
      </button>
    </div>
  );

  // ---- TAB: GRADES ----
  const renderGrades = () => (
    <div className="space-y-4">
      <h2 className="text-xl sm:text-2xl font-bold text-gray-800">📚 Manage Grades</h2>
      <p className="text-sm text-gray-500">Add, edit, or remove grades</p>
      
      <div className="flex flex-col sm:flex-row gap-2">
        <input
          type="text"
          value={newGrade}
          onChange={(e) => setNewGrade(e.target.value)}
          placeholder="Enter grade name (e.g., Grade 5)"
          className="flex-1 border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
          onKeyPress={(e) => e.key === "Enter" && addGrade()}
        />
        <button
          onClick={addGrade}
          disabled={!newGrade.trim() || loading}
          className="bg-green-600 text-white px-6 py-2.5 rounded-lg hover:bg-green-700 transition disabled:opacity-50 whitespace-nowrap"
        >
          + Add Grade
        </button>
      </div>

      <div className="flex flex-wrap gap-2">
        {grades.length === 0 ? (
          <p className="text-gray-500 text-sm py-4">No grades added yet.</p>
        ) : (
          grades.map((grade) => (
            <div
              key={grade.id}
              className="bg-gray-50 border rounded-lg px-3 py-2 flex items-center gap-2"
            >
              {editingGrade?.id === grade.id ? (
                <input
                  type="text"
                  value={editingGrade.name}
                  onChange={(e) => setEditingGrade({ ...editingGrade, name: e.target.value })}
                  className="border rounded p-1 w-24 focus:ring-2 focus:ring-blue-500 outline-none"
                  onKeyPress={(e) => e.key === "Enter" && updateGrade()}
                />
              ) : (
                <span className="font-medium">{grade.name}</span>
              )}
              <div className="flex gap-1">
                {editingGrade?.id === grade.id ? (
                  <button
                    onClick={updateGrade}
                    className="text-green-600 hover:text-green-800 text-sm px-1"
                  >
                    ✓
                  </button>
                ) : (
                  <button
                    onClick={() => setEditingGrade(grade)}
                    className="text-blue-600 hover:text-blue-800 text-sm px-1"
                  >
                    ✏️
                  </button>
                )}
                <button
                  onClick={() => deleteGrade(grade.id)}
                  className="text-red-600 hover:text-red-800 text-sm px-1"
                >
                  ✕
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );

  // ---- TAB: SECTIONS ----
  const renderSections = () => (
    <div className="space-y-4">
      <h2 className="text-xl sm:text-2xl font-bold text-gray-800">📋 Manage Sections</h2>
      <p className="text-sm text-gray-500">Add, edit, or remove sections</p>
      
      <div className="flex flex-col sm:flex-row gap-2">
        <input
          type="text"
          value={newSection}
          onChange={(e) => setNewSection(e.target.value)}
          placeholder="Enter section (e.g., A, B, C)"
          className="flex-1 border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
          onKeyPress={(e) => e.key === "Enter" && addSection()}
        />
        <button
          onClick={addSection}
          disabled={!newSection.trim() || loading}
          className="bg-green-600 text-white px-6 py-2.5 rounded-lg hover:bg-green-700 transition disabled:opacity-50 whitespace-nowrap"
        >
          + Add Section
        </button>
      </div>

      <div className="flex flex-wrap gap-2">
        {sections.length === 0 ? (
          <p className="text-gray-500 text-sm py-4">No sections added yet.</p>
        ) : (
          sections.map((section) => (
            <div
              key={section.id}
              className="bg-gray-50 border rounded-lg px-3 py-2 flex items-center gap-2"
            >
              {editingSection?.id === section.id ? (
                <input
                  type="text"
                  value={editingSection.name}
                  onChange={(e) => setEditingSection({ ...editingSection, name: e.target.value })}
                  className="border rounded p-1 w-16 focus:ring-2 focus:ring-blue-500 outline-none"
                  onKeyPress={(e) => e.key === "Enter" && updateSection()}
                />
              ) : (
                <span className="font-medium text-lg">{section.name}</span>
              )}
              <div className="flex gap-1">
                {editingSection?.id === section.id ? (
                  <button
                    onClick={updateSection}
                    className="text-green-600 hover:text-green-800 text-sm px-1"
                  >
                    ✓
                  </button>
                ) : (
                  <button
                    onClick={() => setEditingSection(section)}
                    className="text-blue-600 hover:text-blue-800 text-sm px-1"
                  >
                    ✏️
                  </button>
                )}
                <button
                  onClick={() => deleteSection(section.id)}
                  className="text-red-600 hover:text-red-800 text-sm px-1"
                >
                  ✕
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );

  // ---- TAB: SUBJECTS ----
  const renderSubjects = () => (
    <div className="space-y-4">
      <h2 className="text-xl sm:text-2xl font-bold text-gray-800">📖 Manage Subjects</h2>
      <p className="text-sm text-gray-500">Add, edit, or remove subjects</p>
      
      <div className="flex flex-col sm:flex-row gap-2">
        <input
          type="text"
          value={newSubject}
          onChange={(e) => setNewSubject(e.target.value)}
          placeholder="Enter subject name"
          className="flex-1 border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
          onKeyPress={(e) => e.key === "Enter" && addSubject()}
        />
        <button
          onClick={addSubject}
          disabled={!newSubject.trim() || loading}
          className="bg-green-600 text-white px-6 py-2.5 rounded-lg hover:bg-green-700 transition disabled:opacity-50 whitespace-nowrap"
        >
          + Add Subject
        </button>
      </div>

      <div className="flex flex-wrap gap-2">
        {subjects.length === 0 ? (
          <p className="text-gray-500 text-sm py-4">No subjects added yet.</p>
        ) : (
          subjects.map((subject) => (
            <div
              key={subject.id}
              className="bg-gray-50 border rounded-lg px-3 py-2 flex items-center gap-2"
            >
              {editingSubject?.id === subject.id ? (
                <input
                  type="text"
                  value={editingSubject.name}
                  onChange={(e) => setEditingSubject({ ...editingSubject, name: e.target.value })}
                  className="border rounded p-1 w-24 focus:ring-2 focus:ring-blue-500 outline-none"
                  onKeyPress={(e) => e.key === "Enter" && updateSubject()}
                />
              ) : (
                <span className="font-medium">{subject.name}</span>
              )}
              <div className="flex gap-1">
                {editingSubject?.id === subject.id ? (
                  <button
                    onClick={updateSubject}
                    className="text-green-600 hover:text-green-800 text-sm px-1"
                  >
                    ✓
                  </button>
                ) : (
                  <button
                    onClick={() => setEditingSubject(subject)}
                    className="text-blue-600 hover:text-blue-800 text-sm px-1"
                  >
                    ✏️
                  </button>
                )}
                <button
                  onClick={() => deleteSubject(subject.id)}
                  className="text-red-600 hover:text-red-800 text-sm px-1"
                >
                  ✕
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );

  // ---- MAIN RENDER ----
  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
            ⚙️ School Settings
          </h1>
          <p className="text-gray-600 mt-1">
            Configure your school's grades, sections, subjects, and information
          </p>
        </div>

        {success && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {success}
          </div>
        )}

        {error && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {error}
          </div>
        )}

        {/* Tabs */}
        <div className="flex flex-wrap gap-1 border-b border-gray-200 mb-6">
          {[
            { id: "info", label: "🏫 School Info" },
            { id: "grades", label: "📚 Grades" },
            { id: "sections", label: "📋 Sections" },
            { id: "subjects", label: "📖 Subjects" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2.5 font-medium rounded-t-lg transition ${
                activeTab === tab.id
                  ? "bg-blue-700 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
}
