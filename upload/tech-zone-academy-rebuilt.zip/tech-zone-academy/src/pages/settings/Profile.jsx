// src/pages/Profile.jsx
import { useAuth } from "../../context/AuthContext";

export default function Profile() {
  const { user } = useAuth();
  
  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-white rounded-xl shadow-md p-6">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">👤 My Profile</h1>
        <div className="space-y-4">
          <div className="border-b pb-4">
            <label className="text-sm text-gray-500">Email</label>
            <p className="font-medium text-gray-800">{user?.email || "Not set"}</p>
          </div>
          <div className="border-b pb-4">
            <label className="text-sm text-gray-500">User ID</label>
            <p className="font-medium text-gray-800">{user?.uid || "Not set"}</p>
          </div>
          <div className="border-b pb-4">
            <label className="text-sm text-gray-500">Account Created</label>
            <p className="font-medium text-gray-800">
              {user?.metadata?.creationTime ? new Date(user.metadata.creationTime).toLocaleDateString() : "Not set"}
            </p>
          </div>
          <div>
            <label className="text-sm text-gray-500">Last Sign In</label>
            <p className="font-medium text-gray-800">
              {user?.metadata?.lastSignInTime ? new Date(user.metadata.lastSignInTime).toLocaleDateString() : "Not set"}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}