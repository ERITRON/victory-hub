// src/pages/Schedule.jsx
import { useAuth } from "../../context/AuthContext";
import { useEffect, useState } from "react";
import { db, doc, getDoc, collection, query, where, getDocs } from "../../supabase/supabase";
import { useNavigate, useSearchParams } from "react-router-dom";

export default function Schedule() {
  const { user, role } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const childId = searchParams.get('childId');
  
  const [, setUserData] = useState(null);
  const [schedules, setSchedules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");
  const [grade, setGrade] = useState("");
  const [section, setSection] = useState("");
  const [parentChildren, setParentChildren] = useState([]);
  const [selectedChildId, setSelectedChildId] = useState(childId);

  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

  useEffect(() => {
    if (user) {
      fetchUserData();
    }
  }, [user, childId]);

  async function fetchUserData() {
    try {
      if (role === "student") {
        const docRef = doc(db, "students", user.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setUserData(data);
          setGrade(data.grade);
          setSection(data.section);
          await fetchSchedule(data.grade, data.section);
        }
      } else if (role === "teacher") {
        const docRef = doc(db, "teachers", user.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setUserData(data);
          await fetchTeacherSchedule(user.uid);
        }
      } else if (role === "parent") {
        const docRef = doc(db, "users", user.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setUserData(data);
          setParentChildren(data.children || []);
          
          // If childId is provided, show that child's schedule
          if (childId) {
            const child = data.children?.find(c => c.studentId === childId);
            if (child) {
              setGrade(child.grade);
              setSection(child.section);
              await fetchSchedule(child.grade, child.section);
            } else {
              setErrorMessage("Child not found.");
            }
          } else if (data.children && data.children.length > 0) {
            // Show first child's schedule by default
            const child = data.children[0];
            setGrade(child.grade);
            setSection(child.section);
            await fetchSchedule(child.grade, child.section);
          }
        }
      } else {
        setErrorMessage("User data not found.");
      }
    } catch (error) {
      setErrorMessage("Error loading data: " + error.message);
    } finally {
      setLoading(false);
    }
  }

  const fetchSchedule = async (grade, section) => {
    try {
      const q = query(
        collection(db, "schedules"),
        where("grade", "==", grade),
        where("section", "==", section)
      );
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSchedules(data);
    } catch (error) {
      setErrorMessage("Error fetching schedule: " + error.message);
    }
  };

  const fetchTeacherSchedule = async (teacherId) => {
    try {
      const q = query(
        collection(db, "schedules"),
        where("teacherId", "==", teacherId)
      );
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSchedules(data);
      if (data.length > 0) {
        setGrade(data[0].grade);
        setSection(data[0].section);
      }
    } catch (error) {
      setErrorMessage("Error fetching schedule: " + error.message);
    }
  };

  const getScheduleMatrix = () => {
    const matrix = {};
    days.forEach((day) => {
      matrix[day] = schedules
        .filter((s) => s.day === day)
        .sort((a, b) => a.startTime.localeCompare(b.startTime));
    });
    return matrix;
  };

  const getPeriodTypeColor = (type) => {
    switch (type) {
      case "break": return "bg-green-50";
      case "lunch": return "bg-yellow-50";
      default: return "";
    }
  };

  const matrix = getScheduleMatrix();
  const times = [...new Set(schedules.map(s => s.startTime))].sort();

  // Handle child selection for parents
  const handleChildSelect = async (childId) => {
    setSelectedChildId(childId);
    const child = parentChildren.find(c => c.studentId === childId);
    if (child) {
      setGrade(child.grade);
      setSection(child.section);
      await fetchSchedule(child.grade, child.section);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading schedule...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <button onClick={() => navigate(-1)} className="text-gray-600 hover:text-gray-800 transition">
            ← Back
          </button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">📅 Class Schedule</h1>
            {role === "parent" ? (
              <p className="text-gray-600 mt-1">
                {grade && section ? `${grade} - Section ${section}` : "Select a child to view schedule"}
              </p>
            ) : role === "teacher" ? (
              <p className="text-gray-600 mt-1">Your teaching schedule</p>
            ) : (
              <p className="text-gray-600 mt-1">{grade && section ? `${grade} - Section ${section}` : ""}</p>
            )}
          </div>
        </div>

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Parent Child Selector */}
        {role === "parent" && parentChildren.length > 1 && (
          <div className="bg-white rounded-xl shadow-md p-4 mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">Select Child</label>
            <div className="flex flex-wrap gap-2">
              {parentChildren.map((child) => (
                <button
                  key={child.studentId}
                  onClick={() => handleChildSelect(child.studentId)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                    selectedChildId === child.studentId
                      ? "bg-blue-700 text-white"
                      : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                  }`}
                >
                  {child.studentName} ({child.grade} - {child.section})
                </button>
              ))}
            </div>
          </div>
        )}

        {schedules.length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-6xl mb-4">📭</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No Schedule Available</h3>
            <p className="text-gray-500">
              {role === "teacher" 
                ? "You haven't been assigned to any classes yet." 
                : role === "parent"
                ? "No schedule has been created for this child's class yet."
                : "No schedule has been created for this class yet."}
            </p>
          </div>
        ) : (
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-blue-700 text-white">
                    <th className="p-3 text-left border border-blue-800 min-w-[100px]">Time</th>
                    {days.map((day) => (
                      <th key={day} className="p-3 text-center border border-blue-800 min-w-[120px]">
                        {day}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {times.length === 0 ? (
                    <tr>
                      <td colSpan="6" className="p-4 text-center text-gray-500">No schedule entries found.</td>
                    </tr>
                  ) : (
                    times.map((time) => {
                      const endTime = schedules.find(s => s.startTime === time)?.endTime || "";
                      return (
                        <tr key={time} className="hover:bg-gray-50">
                          <td className="p-3 border border-gray-200 font-medium whitespace-nowrap">
                            {time} – {endTime}
                          </td>
                          {days.map((day) => {
                            const period = matrix[day]?.find(s => s.startTime === time);
                            if (!period) {
                              return <td key={day} className="p-3 border border-gray-200 text-center text-gray-400">–</td>;
                            }
                            const isBreak = period.periodType === "break";
                            const isLunch = period.periodType === "lunch";
                            
                            return (
                              <td key={day} className={`p-3 border border-gray-200 text-center ${getPeriodTypeColor(period.periodType)}`}>
                                {isBreak ? (
                                  <span className="font-medium text-green-600">🟢 Break</span>
                                ) : isLunch ? (
                                  <span className="font-medium text-yellow-600">🍽️ Lunch</span>
                                ) : (
                                  <>
                                    <div className="font-bold text-gray-800">{period.subject}</div>
                                    <div className="text-xs text-gray-500">{period.teacherName}</div>
                                    {period.room && <div className="text-xs text-gray-400">{period.room}</div>}
                                  </>
                                )}
                              </td>
                            );
                          })}
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Legend */}
            <div className="p-4 border-t border-gray-200 flex flex-wrap gap-4 text-sm">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded bg-blue-100 text-blue-700">📚 Class</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded bg-green-100 text-green-700">🟢 Break</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded bg-yellow-100 text-yellow-700">🍽️ Lunch</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}