// src/pages/WebsiteSettings.jsx
import { useState, useEffect } from "react";
import { useAuth } from "../../context/AuthContext";
import { useWebsiteSettings } from "../../context/WebsiteSettingsContext";
import { storage, ref, uploadBytes, getDownloadURL } from "../../supabase/supabase";

export default function WebsiteSettings() {
  const { role } = useAuth();
  const { settings, loading, updateSetting, updatePage, refresh } = useWebsiteSettings();
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [activeTab, setActiveTab] = useState("about");
  const [activePage, setActivePage] = useState("home");
  const [localSettings, setLocalSettings] = useState(settings);

  // Update local settings when global settings change
  useEffect(() => {
    setLocalSettings(settings);
  }, [settings]);

  // Image upload function
  const uploadImage = async (file, path) => {
    if (!file) return null;
    setUploading(true);
    try {
      const timestamp = Date.now();
      const fileName = `${timestamp}_${file.name}`;
      const storageRef = ref(storage, `website/${path}/${fileName}`);
      const snapshot = await uploadBytes(storageRef, file);
      const url = await getDownloadURL(snapshot.ref);
      return url;
    } catch (error) {
      console.error("Upload error:", error);
      setErrorMessage("Error uploading image: " + error.message);
      return null;
    } finally {
      setUploading(false);
    }
  };

  const handleImageUpload = async (e, field) => {
    const file = e.target.files[0];
    if (!file) return;
    
    const validTypes = ["image/jpeg", "image/png", "image/gif", "image/webp", "image/svg+xml"];
    if (!validTypes.includes(file.type)) {
      setErrorMessage("Please upload a valid image file (JPEG, PNG, GIF, WEBP, SVG)");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setErrorMessage("Image size must be less than 5MB");
      return;
    }

    const url = await uploadImage(file, field);
    if (url) {
      setLocalSettings(prev => ({ ...prev, [field]: url }));
      await updateSetting(field, url);
      setSuccessMessage(`✅ Image uploaded successfully!`);
      setTimeout(() => setSuccessMessage(""), 3000);
    }
  };

  const handleFieldChange = (sectionOrField, fieldOrValue, nestedValue) => {
    if (nestedValue !== undefined) {
      setLocalSettings((prev) => ({
        ...prev,
        [sectionOrField]: {
          ...(prev?.[sectionOrField] || {}),
          [fieldOrValue]: nestedValue,
        },
      }));
      return;
    }

    setLocalSettings((prev) => ({ ...prev, [sectionOrField]: fieldOrValue }));
  };

  const handleArrayItemChange = (arrayField, index, field, value) => {
    const items = [...(localSettings[arrayField] || [])];
    if (!items[index]) return;
    items[index] = { ...items[index], [field]: value };
    setLocalSettings(prev => ({ ...prev, [arrayField]: items }));
  };

  const addArrayItem = (arrayField, defaultItem) => {
    const items = [...(localSettings[arrayField] || [])];
    items.push({ ...defaultItem, id: Date.now().toString() });
    setLocalSettings(prev => ({ ...prev, [arrayField]: items }));
  };

  const removeArrayItem = (arrayField, index) => {
    const items = [...(localSettings[arrayField] || [])];
    items.splice(index, 1);
    setLocalSettings(prev => ({ ...prev, [arrayField]: items }));
  };

  const saveSection = async (sectionKey) => {
    setSaving(true);
    try {
      const data = localSettings[sectionKey];
      await updateSetting(sectionKey, data);
      setSuccessMessage(`✅ ${sectionKey.charAt(0).toUpperCase() + sectionKey.slice(1)} updated successfully!`);
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error saving: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setSaving(false);
    }
  };

  const saveAboutField = async (field, value) => {
    setSaving(true);
    try {
      await updateSetting(field, value);
      setSuccessMessage(`✅ About section updated successfully!`);
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error saving: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setSaving(false);
    }
  };

  // ============================================
  // RENDER ABOUT EDITOR
  // ============================================
  const renderAboutEditor = () => {
    const s = localSettings;
    return (
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-gray-800">📖 About Section</h3>
        <p className="text-sm text-gray-500">All text in the About section is fully editable below.</p>

        {/* HEADER */}
        <div className="bg-gray-50 rounded-lg p-4 border">
          <h4 className="font-semibold text-gray-700 mb-3">📌 Header</h4>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">About Label (e.g., "ABOUT US")</label>
            <input
              type="text"
              value={s?.aboutLabel || "ABOUT US"}
              onChange={(e) => {
                handleFieldChange("aboutLabel", e.target.value);
                saveAboutField("aboutLabel", e.target.value);
              }}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
        </div>

        {/* MAIN TITLE */}
        <div className="bg-gray-50 rounded-lg p-4 border">
          <h4 className="font-semibold text-gray-700 mb-3">📌 Main Title</h4>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
            <input
              type="text"
              value={s?.aboutTitle || "About Tech Zone Academy"}
              onChange={(e) => {
                handleFieldChange("aboutTitle", e.target.value);
                saveAboutField("aboutTitle", e.target.value);
              }}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
        </div>

        {/* SUBTITLE */}
        <div className="bg-gray-50 rounded-lg p-4 border">
          <h4 className="font-semibold text-gray-700 mb-3">📌 Subtitle (Full Page)</h4>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Subtitle</label>
            <input
              type="text"
              value={s?.aboutSubtitle || "Building Bright Futures Through Quality Education"}
              onChange={(e) => {
                handleFieldChange("aboutSubtitle", e.target.value);
                saveAboutField("aboutSubtitle", e.target.value);
              }}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
        </div>

        {/* DESCRIPTION */}
        <div className="bg-gray-50 rounded-lg p-4 border">
          <h4 className="font-semibold text-gray-700 mb-3">📌 Description</h4>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Description Line 1</label>
            <textarea
              value={s?.aboutDescription || "Tech Zone Academy is a premier educational institution dedicated to nurturing young minds with innovative teaching methods and a commitment to excellence."}
              onChange={(e) => {
                handleFieldChange("aboutDescription", e.target.value);
                saveAboutField("aboutDescription", e.target.value);
              }}
              rows="3"
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
          <div className="mt-3">
            <label className="block text-sm font-medium text-gray-700 mb-1">Description Line 2</label>
            <textarea
              value={s?.aboutDescription2 || "Our mission is to provide quality education that prepares students for the challenges of tomorrow."}
              onChange={(e) => {
                handleFieldChange("aboutDescription2", e.target.value);
                saveAboutField("aboutDescription2", e.target.value);
              }}
              rows="3"
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
        </div>

        {/* STATISTICS */}
        <div className="bg-gray-50 rounded-lg p-4 border">
          <h4 className="font-semibold text-gray-700 mb-3">📌 Statistics</h4>
          <p className="text-sm text-gray-500 mb-3">These stats appear below the description.</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Students Label</label>
              <input
                type="text"
                value={s?.aboutStudentsLabel || "Students"}
                onChange={(e) => {
                  handleFieldChange("aboutStudentsLabel", e.target.value);
                  saveAboutField("aboutStudentsLabel", e.target.value);
                }}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Students Value</label>
              <input
                type="text"
                value={s?.aboutStudentsValue || "500+"}
                onChange={(e) => {
                  handleFieldChange("aboutStudentsValue", e.target.value);
                  saveAboutField("aboutStudentsValue", e.target.value);
                }}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Teachers Label</label>
              <input
                type="text"
                value={s?.aboutTeachersLabel || "Teachers"}
                onChange={(e) => {
                  handleFieldChange("aboutTeachersLabel", e.target.value);
                  saveAboutField("aboutTeachersLabel", e.target.value);
                }}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Teachers Value</label>
              <input
                type="text"
                value={s?.aboutTeachersValue || "30+"}
                onChange={(e) => {
                  handleFieldChange("aboutTeachersValue", e.target.value);
                  saveAboutField("aboutTeachersValue", e.target.value);
                }}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Success Rate Label</label>
              <input
                type="text"
                value={s?.aboutSuccessLabel || "Success Rate"}
                onChange={(e) => {
                  handleFieldChange("aboutSuccessLabel", e.target.value);
                  saveAboutField("aboutSuccessLabel", e.target.value);
                }}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Success Rate Value</label>
              <input
                type="text"
                value={s?.aboutSuccessValue || "95%"}
                onChange={(e) => {
                  handleFieldChange("aboutSuccessValue", e.target.value);
                  saveAboutField("aboutSuccessValue", e.target.value);
                }}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Years Label</label>
              <input
                type="text"
                value={s?.aboutYearsLabel || "Years of Excellence"}
                onChange={(e) => {
                  handleFieldChange("aboutYearsLabel", e.target.value);
                  saveAboutField("aboutYearsLabel", e.target.value);
                }}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Years Value</label>
              <input
                type="text"
                value={s?.aboutYearsValue || "10+"}
                onChange={(e) => {
                  handleFieldChange("aboutYearsValue", e.target.value);
                  saveAboutField("aboutYearsValue", e.target.value);
                }}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
          </div>
        </div>

        {/* IMAGE */}
        <div className="bg-gray-50 rounded-lg p-4 border">
          <h4 className="font-semibold text-gray-700 mb-3">📌 Image</h4>
          <div className="flex gap-3">
            <input
              type="text"
              value={s?.aboutImage || ""}
              onChange={(e) => {
                handleFieldChange("aboutImage", e.target.value);
                saveAboutField("aboutImage", e.target.value);
              }}
              className="flex-1 border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="Image URL"
            />
            <label className="bg-gray-200 hover:bg-gray-300 px-4 py-3 rounded-lg cursor-pointer transition">
              📁 Upload
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => handleImageUpload(e, "aboutImage")}
              />
            </label>
          </div>
          {s?.aboutImage && (
            <div className="mt-2 h-32 w-full rounded-lg overflow-hidden bg-gray-200">
              <img src={s.aboutImage} alt="Preview" className="w-full h-full object-cover" />
            </div>
          )}
        </div>

        {/* BUTTON */}
        <div className="bg-gray-50 rounded-lg p-4 border">
          <h4 className="font-semibold text-gray-700 mb-3">📌 Button</h4>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Button Text</label>
              <input
                type="text"
                value={s?.aboutButtonText || "Learn More →"}
                onChange={(e) => {
                  handleFieldChange("aboutButtonText", e.target.value);
                  saveAboutField("aboutButtonText", e.target.value);
                }}
                className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Button Link</label>
              <input
                type="text"
                value={s?.aboutButtonLink || "/about"}
                onChange={(e) => {
                  handleFieldChange("aboutButtonLink", e.target.value);
                  saveAboutField("aboutButtonLink", e.target.value);
                }}
                className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
          </div>
        </div>

        {/* MISSION, VISION, VALUES */}
        <div className="bg-gray-50 rounded-lg p-4 border">
          <h4 className="font-semibold text-gray-700 mb-3">📌 Mission, Vision & Values</h4>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Mission Title</label>
            <input
              type="text"
              value={s?.aboutMissionTitle || "Our Mission"}
              onChange={(e) => {
                handleFieldChange("aboutMissionTitle", e.target.value);
                saveAboutField("aboutMissionTitle", e.target.value);
              }}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
          <div className="mt-3">
            <label className="block text-sm font-medium text-gray-700 mb-1">Mission Text</label>
            <textarea
              value={s?.aboutMission || "To provide quality education that nurtures intellectual curiosity, critical thinking, and character development."}
              onChange={(e) => {
                handleFieldChange("aboutMission", e.target.value);
                saveAboutField("aboutMission", e.target.value);
              }}
              rows="3"
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div className="mt-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Vision Title</label>
            <input
              type="text"
              value={s?.aboutVisionTitle || "Our Vision"}
              onChange={(e) => {
                handleFieldChange("aboutVisionTitle", e.target.value);
                saveAboutField("aboutVisionTitle", e.target.value);
              }}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
          <div className="mt-3">
            <label className="block text-sm font-medium text-gray-700 mb-1">Vision Text</label>
            <textarea
              value={s?.aboutVision || "To become a leading educational institution that empowers students with knowledge, skills, and values to excel."}
              onChange={(e) => {
                handleFieldChange("aboutVision", e.target.value);
                saveAboutField("aboutVision", e.target.value);
              }}
              rows="3"
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div className="mt-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Values Title</label>
            <input
              type="text"
              value={s?.aboutValuesTitle || "Core Values"}
              onChange={(e) => {
                handleFieldChange("aboutValuesTitle", e.target.value);
                saveAboutField("aboutValuesTitle", e.target.value);
              }}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
        </div>

        {/* CORE VALUES LIST */}
        <div className="bg-gray-50 rounded-lg p-4 border">
          <h4 className="font-semibold text-gray-700 mb-3">📌 Core Values List</h4>
          {(s?.aboutCoreValues || []).map((value, index) => (
            <div key={index} className="bg-white rounded-lg p-3 mb-2 border">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={value.icon || "🌟"}
                  onChange={(e) => {
                    handleArrayItemChange("aboutCoreValues", index, "icon", e.target.value);
                  }}
                  className="w-12 border rounded p-1 text-center"
                  placeholder="🌟"
                />
                <input
                  type="text"
                  value={value.title || ""}
                  onChange={(e) => {
                    handleArrayItemChange("aboutCoreValues", index, "title", e.target.value);
                  }}
                  className="flex-1 border rounded p-1"
                  placeholder="Title"
                />
                <input
                  type="text"
                  value={value.description || ""}
                  onChange={(e) => {
                    handleArrayItemChange("aboutCoreValues", index, "description", e.target.value);
                  }}
                  className="flex-1 border rounded p-1"
                  placeholder="Description"
                />
                <button
                  onClick={() => removeArrayItem("aboutCoreValues", index)}
                  className="text-red-500 hover:text-red-700 px-2"
                >
                  🗑️
                </button>
              </div>
            </div>
          ))}
          <button
            onClick={() => addArrayItem("aboutCoreValues", { icon: "🌟", title: "New Value", description: "Description" })}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition text-sm"
          >
            + Add Core Value
          </button>
          <button
            onClick={() => saveSection("aboutCoreValues")}
            disabled={saving}
            className="mt-3 w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-400 text-sm"
          >
            {saving ? "Saving..." : "💾 Save Core Values"}
          </button>
        </div>

        {/* FEATURES */}
        <div className="bg-gray-50 rounded-lg p-4 border">
          <h4 className="font-semibold text-gray-700 mb-3">📌 Features</h4>
          {(s?.aboutFeatures || []).map((feature, index) => (
            <div key={index} className="bg-white rounded-lg p-3 mb-2 border">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={feature.icon || "📌"}
                  onChange={(e) => {
                    handleArrayItemChange("aboutFeatures", index, "icon", e.target.value);
                  }}
                  className="w-12 border rounded p-1 text-center"
                  placeholder="📚"
                />
                <input
                  type="text"
                  value={feature.title || ""}
                  onChange={(e) => {
                    handleArrayItemChange("aboutFeatures", index, "title", e.target.value);
                  }}
                  className="flex-1 border rounded p-1"
                  placeholder="Title"
                />
                <input
                  type="text"
                  value={feature.description || ""}
                  onChange={(e) => {
                    handleArrayItemChange("aboutFeatures", index, "description", e.target.value);
                  }}
                  className="flex-1 border rounded p-1"
                  placeholder="Description"
                />
                <button
                  onClick={() => removeArrayItem("aboutFeatures", index)}
                  className="text-red-500 hover:text-red-700 px-2"
                >
                  🗑️
                </button>
              </div>
            </div>
          ))}
          <button
            onClick={() => addArrayItem("aboutFeatures", { icon: "📌", title: "New Feature", description: "Description" })}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition text-sm"
          >
            + Add Feature
          </button>
          <button
            onClick={() => saveSection("aboutFeatures")}
            disabled={saving}
            className="mt-3 w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-400 text-sm"
          >
            {saving ? "Saving..." : "💾 Save Features"}
          </button>
        </div>

        {/* TEAM MEMBERS */}
        <div className="bg-gray-50 rounded-lg p-4 border">
          <h4 className="font-semibold text-gray-700 mb-3">📌 Team Members</h4>
          {(s?.aboutTeamMembers || []).map((member, index) => (
            <div key={index} className="bg-white rounded-lg p-3 mb-2 border">
              <div className="grid grid-cols-3 gap-2">
                <input
                  type="text"
                  value={member.name || ""}
                  onChange={(e) => {
                    handleArrayItemChange("aboutTeamMembers", index, "name", e.target.value);
                  }}
                  className="border rounded p-1"
                  placeholder="Name"
                />
                <input
                  type="text"
                  value={member.role || ""}
                  onChange={(e) => {
                    handleArrayItemChange("aboutTeamMembers", index, "role", e.target.value);
                  }}
                  className="border rounded p-1"
                  placeholder="Role"
                />
                <input
                  type="text"
                  value={member.bio || ""}
                  onChange={(e) => {
                    handleArrayItemChange("aboutTeamMembers", index, "bio", e.target.value);
                  }}
                  className="border rounded p-1"
                  placeholder="Bio"
                />
              </div>
              <button
                onClick={() => removeArrayItem("aboutTeamMembers", index)}
                className="text-red-500 hover:text-red-700 text-sm mt-1"
              >
                🗑️ Remove
              </button>
            </div>
          ))}
          <button
            onClick={() => addArrayItem("aboutTeamMembers", { name: "New Member", role: "Role", bio: "Description" })}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition text-sm"
          >
            + Add Team Member
          </button>
          <button
            onClick={() => saveSection("aboutTeamMembers")}
            disabled={saving}
            className="mt-3 w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-400 text-sm"
          >
            {saving ? "Saving..." : "💾 Save Team Members"}
          </button>
        </div>

        {/* HISTORY TIMELINE */}
        <div className="bg-gray-50 rounded-lg p-4 border">
          <h4 className="font-semibold text-gray-700 mb-3">📌 History Timeline</h4>
          {(s?.aboutHistoryTimeline || []).map((item, index) => (
            <div key={index} className="bg-white rounded-lg p-3 mb-2 border">
              <div className="grid grid-cols-3 gap-2">
                <input
                  type="text"
                  value={item.year || ""}
                  onChange={(e) => {
                    handleArrayItemChange("aboutHistoryTimeline", index, "year", e.target.value);
                  }}
                  className="border rounded p-1"
                  placeholder="Year (e.g., 2020)"
                />
                <input
                  type="text"
                  value={item.title || ""}
                  onChange={(e) => {
                    handleArrayItemChange("aboutHistoryTimeline", index, "title", e.target.value);
                  }}
                  className="border rounded p-1"
                  placeholder="Title"
                />
                <input
                  type="text"
                  value={item.description || ""}
                  onChange={(e) => {
                    handleArrayItemChange("aboutHistoryTimeline", index, "description", e.target.value);
                  }}
                  className="border rounded p-1"
                  placeholder="Description"
                />
              </div>
              <button
                onClick={() => removeArrayItem("aboutHistoryTimeline", index)}
                className="text-red-500 hover:text-red-700 text-sm mt-1"
              >
                🗑️ Remove
              </button>
            </div>
          ))}
          <button
            onClick={() => addArrayItem("aboutHistoryTimeline", { year: "2024", title: "New Milestone", description: "Description" })}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition text-sm"
          >
            + Add Timeline Item
          </button>
          <button
            onClick={() => saveSection("aboutHistoryTimeline")}
            disabled={saving}
            className="mt-3 w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-400 text-sm"
          >
            {saving ? "Saving..." : "💾 Save History Timeline"}
          </button>
        </div>

        {/* CTA SECTION */}
        <div className="bg-gray-50 rounded-lg p-4 border">
          <h4 className="font-semibold text-gray-700 mb-3">📌 Call to Action (CTA) Section</h4>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">CTA Title</label>
            <input
              type="text"
              value={s?.aboutCtaTitle || "Ready to Join Us?"}
              onChange={(e) => {
                handleFieldChange("aboutCtaTitle", e.target.value);
                saveAboutField("aboutCtaTitle", e.target.value);
              }}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
          <div className="mt-3">
            <label className="block text-sm font-medium text-gray-700 mb-1">CTA Description</label>
            <textarea
              value={s?.aboutCtaDescription || "Give your child the best education. Enroll today at Tech Zone Academy."}
              onChange={(e) => {
                handleFieldChange("aboutCtaDescription", e.target.value);
                saveAboutField("aboutCtaDescription", e.target.value);
              }}
              rows="2"
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
          <div className="grid grid-cols-2 gap-4 mt-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Button 1 Text</label>
              <input
                type="text"
                value={s?.aboutCtaButton1Text || "Apply Now"}
                onChange={(e) => {
                  handleFieldChange("aboutCtaButton1Text", e.target.value);
                  saveAboutField("aboutCtaButton1Text", e.target.value);
                }}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Button 1 Link</label>
              <input
                type="text"
                value={s?.aboutCtaButton1Link || "/admissions"}
                onChange={(e) => {
                  handleFieldChange("aboutCtaButton1Link", e.target.value);
                  saveAboutField("aboutCtaButton1Link", e.target.value);
                }}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Button 2 Text</label>
              <input
                type="text"
                value={s?.aboutCtaButton2Text || "Contact Us"}
                onChange={(e) => {
                  handleFieldChange("aboutCtaButton2Text", e.target.value);
                  saveAboutField("aboutCtaButton2Text", e.target.value);
                }}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Button 2 Link</label>
              <input
                type="text"
                value={s?.aboutCtaButton2Link || "/contact"}
                onChange={(e) => {
                  handleFieldChange("aboutCtaButton2Link", e.target.value);
                  saveAboutField("aboutCtaButton2Link", e.target.value);
                }}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
          </div>
        </div>
      </div>
    );
  };

  // ============================================
  // RENDER HERO EDITOR
  // ============================================
  const renderHeroEditor = () => {
    const hero = localSettings?.hero || {};
    return (
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-gray-800">🎨 Hero Section</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">School Name</label>
            <input
              type="text"
              value={hero.schoolName || ""}
              onChange={(e) => handleFieldChange("hero", "schoolName", e.target.value)}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Tagline</label>
            <input
              type="text"
              value={hero.tagline || ""}
              onChange={(e) => handleFieldChange("hero", "tagline", e.target.value)}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
          <textarea
            value={hero.description || ""}
            onChange={(e) => handleFieldChange("hero", "description", e.target.value)}
            rows="3"
            className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Button Text</label>
            <input
              type="text"
              value={hero.buttonText || ""}
              onChange={(e) => handleFieldChange("hero", "buttonText", e.target.value)}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Button Link</label>
            <input
              type="text"
              value={hero.buttonLink || ""}
              onChange={(e) => handleFieldChange("hero", "buttonLink", e.target.value)}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Background Image</label>
          <div className="flex gap-3">
            <input
              type="text"
              value={hero.backgroundImage || ""}
              onChange={(e) => handleFieldChange("hero", "backgroundImage", e.target.value)}
              className="flex-1 border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="Image URL"
            />
            <label className="bg-gray-200 hover:bg-gray-300 px-4 py-3 rounded-lg cursor-pointer transition">
              📁 Upload
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => handleImageUpload(e, "hero", "backgroundImage")}
              />
            </label>
          </div>
          {hero.backgroundImage && (
            <div className="mt-2 h-40 w-full rounded-lg overflow-hidden bg-gray-200">
              <img src={hero.backgroundImage} alt="Preview" className="w-full h-full object-cover" />
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Overlay Color</label>
            <select
              value={hero.overlayColor || "from-blue-600 to-blue-800"}
              onChange={(e) => handleFieldChange("hero", "overlayColor", e.target.value)}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            >
              <option value="from-blue-600 to-blue-800">Blue</option>
              <option value="from-purple-600 to-purple-800">Purple</option>
              <option value="from-green-600 to-green-800">Green</option>
              <option value="from-red-600 to-red-800">Red</option>
              <option value="from-orange-600 to-orange-800">Orange</option>
              <option value="from-teal-600 to-teal-800">Teal</option>
              <option value="from-pink-600 to-pink-800">Pink</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Height</label>
            <select
              value={hero.height || "py-20"}
              onChange={(e) => handleFieldChange("hero", "height", e.target.value)}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            >
              <option value="py-12">Small</option>
              <option value="py-20">Medium</option>
              <option value="py-28">Large</option>
              <option value="py-36">Extra Large</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Alignment</label>
            <select
              value={hero.alignment || "center"}
              onChange={(e) => handleFieldChange("hero", "alignment", e.target.value)}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            >
              <option value="center">Center</option>
              <option value="left">Left</option>
              <option value="right">Right</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Animation</label>
            <select
              value={hero.animation || "fade-in"}
              onChange={(e) => handleFieldChange("hero", "animation", e.target.value)}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            >
              <option value="fade-in">Fade In</option>
              <option value="slide-up">Slide Up</option>
              <option value="slide-in">Slide In</option>
              <option value="zoom-in">Zoom In</option>
              <option value="none">None</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Overlay Opacity (%)</label>
            <input
              type="range"
              min="0"
              max="100"
              value={hero.overlayOpacity || "70"}
              onChange={(e) => handleFieldChange("hero", "overlayOpacity", e.target.value)}
              className="w-full"
            />
            <span className="text-sm text-gray-500">{hero.overlayOpacity || "70"}%</span>
          </div>
        </div>

        {/* Hero Cards */}
        <div className="border-t pt-4 mt-4">
          <h4 className="font-semibold text-gray-700 mb-3">Hero Cards</h4>
          {(hero.cards || []).map((card, index) => (
            <div key={card.id || index} className="bg-gray-50 rounded-lg p-3 mb-2 border">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={card.icon || ""}
                  onChange={(e) => handleArrayItemChange("hero", "cards", index, "icon", e.target.value)}
                  className="w-12 border rounded p-1 text-center"
                  placeholder="🔹"
                />
                <input
                  type="text"
                  value={card.title || ""}
                  onChange={(e) => handleArrayItemChange("hero", "cards", index, "title", e.target.value)}
                  className="flex-1 border rounded p-1"
                  placeholder="Card title"
                />
                <input
                  type="text"
                  value={card.description || ""}
                  onChange={(e) => handleArrayItemChange("hero", "cards", index, "description", e.target.value)}
                  className="flex-1 border rounded p-1"
                  placeholder="Description"
                />
                <button
                  onClick={() => removeArrayItem("hero", "cards", index)}
                  className="text-red-500 hover:text-red-700 px-2"
                >
                  🗑️
                </button>
              </div>
            </div>
          ))}
          <button
            onClick={() => addArrayItem("hero", "cards", { icon: "📌", title: "New Card", description: "Card description" })}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition text-sm"
          >
            + Add Card
          </button>
        </div>

        <button
          onClick={() => saveSection("hero")}
          disabled={saving || uploading}
          className="w-full bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition disabled:bg-gray-400"
        >
          {saving || uploading ? "Saving..." : "💾 Save Hero Section"}
        </button>
      </div>
    );
  };

  // ============================================
  // RENDER STATISTICS EDITOR
  // ============================================
  const renderStatsEditor = () => {
    const stats = localSettings?.statistics || {};
    const statKeys = ["students", "teachers", "parents", "grades", "years"];
    
    return (
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-gray-800">📊 Statistics</h3>

        <div className="flex items-center gap-3 mb-4">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={stats.enabled !== false}
              onChange={(e) => handleFieldChange("statistics", "enabled", e.target.checked)}
              className="w-4 h-4 text-blue-600"
            />
            <span className="text-sm font-medium text-gray-700">Enable Statistics</span>
          </label>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {statKeys.map((key) => {
            const stat = stats[key] || {};
            return (
              <div key={key} className="bg-gray-50 rounded-lg p-4 border">
                <h4 className="font-semibold text-gray-700 capitalize mb-3">
                  {key === "years" ? "⭐ Years of Excellence" : key}
                </h4>
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">Icon</label>
                    <input
                      type="text"
                      value={stat.icon || ""}
                      onChange={(e) => {
                        const newStats = { ...stats };
                        newStats[key] = { ...stat, icon: e.target.value };
                        setLocalSettings(prev => ({ ...prev, statistics: newStats }));
                      }}
                      className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">Label</label>
                    <input
                      type="text"
                      value={stat.label || ""}
                      onChange={(e) => {
                        const newStats = { ...stats };
                        newStats[key] = { ...stat, label: e.target.value };
                        setLocalSettings(prev => ({ ...prev, statistics: newStats }));
                      }}
                      className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">Value</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={stat.value || ""}
                        onChange={(e) => {
                          const newStats = { ...stats };
                          newStats[key] = { ...stat, value: e.target.value };
                          setLocalSettings(prev => ({ ...prev, statistics: newStats }));
                        }}
                        className="flex-1 border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                        placeholder={key === "years" ? "5+" : "0"}
                      />
                      {key !== "years" && (
                        <label className="flex items-center gap-1 text-xs text-gray-500 whitespace-nowrap">
                          <input
                            type="checkbox"
                            checked={stat.manual || false}
                            onChange={(e) => {
                              const newStats = { ...stats };
                              newStats[key] = { ...stat, manual: e.target.checked };
                              setLocalSettings(prev => ({ ...prev, statistics: newStats }));
                            }}
                            className="w-3 h-3"
                          />
                          Manual
                        </label>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <button
          onClick={() => saveSection("statistics")}
          disabled={saving}
          className="w-full bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition disabled:bg-gray-400"
        >
          {saving ? "Saving..." : "💾 Save Statistics"}
        </button>
      </div>
    );
  };

  // ============================================
  // RENDER NEWS EDITOR
  // ============================================
  const renderNewsEditor = () => {
    const news = localSettings?.newsSettings || {};
    return (
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-gray-800">📰 News Section</h3>
        
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={news.enabled !== false}
              onChange={(e) => handleFieldChange("newsSettings", "enabled", e.target.checked)}
              className="w-4 h-4 text-blue-600"
            />
            <span className="text-sm font-medium text-gray-700">Enable News Section</span>
          </label>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
          <input
            type="text"
            value={news.title || "Latest News"}
            onChange={(e) => handleFieldChange("newsSettings", "title", e.target.value)}
            className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Subtitle</label>
          <input
            type="text"
            value={news.subtitle || ""}
            onChange={(e) => handleFieldChange("newsSettings", "subtitle", e.target.value)}
            className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Number of Cards</label>
          <input
            type="number"
            value={news.cardCount || 6}
            onChange={(e) => handleFieldChange("newsSettings", "cardCount", parseInt(e.target.value) || 6)}
            className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            min="1"
            max="20"
          />
        </div>

        {/* Categories */}
        <div className="border-t pt-4 mt-4">
          <h4 className="font-semibold text-gray-700 mb-3">Categories</h4>
          {(news.categories || []).map((category, index) => (
            <div key={category.id || index} className="bg-gray-50 rounded-lg p-3 mb-2 border">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={category.emoji || "📌"}
                  onChange={(e) => handleArrayItemChange("newsSettings", "categories", index, "emoji", e.target.value)}
                  className="w-12 border rounded p-1 text-center"
                />
                <input
                  type="text"
                  value={category.name || ""}
                  onChange={(e) => handleArrayItemChange("newsSettings", "categories", index, "name", e.target.value)}
                  className="flex-1 border rounded p-1"
                  placeholder="Category name"
                />
                <select
                  value={category.color || "bg-gray-100 text-gray-700"}
                  onChange={(e) => handleArrayItemChange("newsSettings", "categories", index, "color", e.target.value)}
                  className="border rounded p-1"
                >
                  <option value="bg-blue-100 text-blue-700">Blue</option>
                  <option value="bg-purple-100 text-purple-700">Purple</option>
                  <option value="bg-green-100 text-green-700">Green</option>
                  <option value="bg-orange-100 text-orange-700">Orange</option>
                  <option value="bg-red-100 text-red-700">Red</option>
                  <option value="bg-yellow-100 text-yellow-700">Yellow</option>
                  <option value="bg-pink-100 text-pink-700">Pink</option>
                  <option value="bg-gray-100 text-gray-700">Gray</option>
                </select>
                <button
                  onClick={() => removeArrayItem("newsSettings", "categories", index)}
                  className="text-red-500 hover:text-red-700 px-2"
                >
                  🗑️
                </button>
              </div>
            </div>
          ))}
          <button
            onClick={() => addArrayItem("newsSettings", "categories", { id: Date.now().toString(), emoji: "📌", name: "New Category", color: "bg-gray-100 text-gray-700" })}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition text-sm"
          >
            + Add Category
          </button>
        </div>

        <button
          onClick={() => saveSection("newsSettings")}
          disabled={saving}
          className="w-full bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition disabled:bg-gray-400"
        >
          {saving ? "Saving..." : "💾 Save News Settings"}
        </button>
      </div>
    );
  };

  // ============================================
  // RENDER GALLERY EDITOR
  // ============================================
  const renderGalleryEditor = () => {
    const gallery = localSettings?.gallerySettings || {};
    return (
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-gray-800">🖼️ Gallery Section</h3>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
          <input
            type="text"
            value={gallery.title || "School Gallery"}
            onChange={(e) => handleFieldChange("gallerySettings", "title", e.target.value)}
            className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Subtitle</label>
          <input
            type="text"
            value={gallery.subtitle || ""}
            onChange={(e) => handleFieldChange("gallerySettings", "subtitle", e.target.value)}
            className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Layout</label>
          <select
            value={gallery.layout || "masonry"}
            onChange={(e) => handleFieldChange("gallerySettings", "layout", e.target.value)}
            className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
          >
            <option value="grid">Grid</option>
            <option value="masonry">Masonry</option>
            <option value="carousel">Carousel</option>
            <option value="slider">Slider</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Display Count</label>
          <input
            type="number"
            value={gallery.displayCount || 12}
            onChange={(e) => handleFieldChange("gallerySettings", "displayCount", parseInt(e.target.value) || 12)}
            className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            min="1"
            max="50"
          />
        </div>

        {/* Gallery Categories */}
        <div className="border-t pt-4 mt-4">
          <h4 className="font-semibold text-gray-700 mb-3">Gallery Categories</h4>
          {(gallery.categories || []).map((category, index) => (
            <div key={category.id || index} className="bg-gray-50 rounded-lg p-3 mb-2 border">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={category.emoji || "📌"}
                  onChange={(e) => handleArrayItemChange("gallerySettings", "categories", index, "emoji", e.target.value)}
                  className="w-12 border rounded p-1 text-center"
                />
                <input
                  type="text"
                  value={category.name || ""}
                  onChange={(e) => handleArrayItemChange("gallerySettings", "categories", index, "name", e.target.value)}
                  className="flex-1 border rounded p-1"
                  placeholder="Category name"
                />
                <button
                  onClick={() => removeArrayItem("gallerySettings", "categories", index)}
                  className="text-red-500 hover:text-red-700 px-2"
                >
                  🗑️
                </button>
              </div>
            </div>
          ))}
          <button
            onClick={() => addArrayItem("gallerySettings", "categories", { id: Date.now().toString(), emoji: "📌", name: "New Category" })}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition text-sm"
          >
            + Add Category
          </button>
        </div>

        <button
          onClick={() => saveSection("gallerySettings")}
          disabled={saving}
          className="w-full bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition disabled:bg-gray-400"
        >
          {saving ? "Saving..." : "💾 Save Gallery Settings"}
        </button>
      </div>
    );
  };

  // ============================================
  // RENDER EVENTS EDITOR
  // ============================================
  const renderEventsEditor = () => {
    const events = localSettings?.eventsSettings || {};
    return (
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-gray-800">📅 Events Section</h3>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
          <input
            type="text"
            value={events.title || "School Events"}
            onChange={(e) => handleFieldChange("eventsSettings", "title", e.target.value)}
            className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Subtitle</label>
          <input
            type="text"
            value={events.subtitle || ""}
            onChange={(e) => handleFieldChange("eventsSettings", "subtitle", e.target.value)}
            className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>

        {/* Event Categories */}
        <div className="border-t pt-4 mt-4">
          <h4 className="font-semibold text-gray-700 mb-3">Event Categories</h4>
          {(events.categories || []).map((category, index) => (
            <div key={category.id || index} className="bg-gray-50 rounded-lg p-3 mb-2 border">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={category.name || ""}
                  onChange={(e) => handleArrayItemChange("eventsSettings", "categories", index, "name", e.target.value)}
                  className="flex-1 border rounded p-1"
                  placeholder="Category name"
                />
                <select
                  value={category.color || "bg-gray-100 text-gray-700"}
                  onChange={(e) => handleArrayItemChange("eventsSettings", "categories", index, "color", e.target.value)}
                  className="border rounded p-1"
                >
                  <option value="bg-blue-100 text-blue-700">Blue</option>
                  <option value="bg-green-100 text-green-700">Green</option>
                  <option value="bg-purple-100 text-purple-700">Purple</option>
                  <option value="bg-red-100 text-red-700">Red</option>
                  <option value="bg-yellow-100 text-yellow-700">Yellow</option>
                  <option value="bg-orange-100 text-orange-700">Orange</option>
                </select>
                <button
                  onClick={() => removeArrayItem("eventsSettings", "categories", index)}
                  className="text-red-500 hover:text-red-700 px-2"
                >
                  🗑️
                </button>
              </div>
            </div>
          ))}
          <button
            onClick={() => addArrayItem("eventsSettings", "categories", { id: Date.now().toString(), name: "New Category", color: "bg-gray-100 text-gray-700" })}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition text-sm"
          >
            + Add Category
          </button>
        </div>

        <button
          onClick={() => saveSection("eventsSettings")}
          disabled={saving}
          className="w-full bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition disabled:bg-gray-400"
        >
          {saving ? "Saving..." : "💾 Save Events Settings"}
        </button>
      </div>
    );
  };

  // ============================================
  // RENDER FOOTER EDITOR
  // ============================================
  const renderFooterEditor = () => {
    const footer = localSettings?.footer || {};
    return (
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-gray-800">📋 Footer</h3>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
          <input
            type="text"
            value={footer.address || ""}
            onChange={(e) => handleFieldChange("footer", "address", e.target.value)}
            className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
            <input
              type="text"
              value={footer.phone || ""}
              onChange={(e) => handleFieldChange("footer", "phone", e.target.value)}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input
              type="text"
              value={footer.email || ""}
              onChange={(e) => handleFieldChange("footer", "email", e.target.value)}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Working Hours</label>
          <input
            type="text"
            value={footer.workingHours || ""}
            onChange={(e) => handleFieldChange("footer", "workingHours", e.target.value)}
            className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Copyright</label>
          <input
            type="text"
            value={footer.copyright || ""}
            onChange={(e) => handleFieldChange("footer", "copyright", e.target.value)}
            className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>

        <div>
          <h4 className="font-semibold text-gray-700 mb-3">Social Media</h4>
          <div className="grid grid-cols-2 gap-3">
            {Object.entries(footer.social || {}).map(([key, value]) => (
              <div key={key}>
                <label className="block text-xs text-gray-500 mb-1 capitalize">{key}</label>
                <input
                  type="text"
                  value={value || ""}
                  onChange={(e) => {
                    const newSocial = { ...footer.social, [key]: e.target.value };
                    setLocalSettings(prev => ({ ...prev, footer: { ...footer, social: newSocial } }));
                  }}
                  className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder={`https://${key}.com/...`}
                />
              </div>
            ))}
          </div>
        </div>

        <button
          onClick={() => saveSection("footer")}
          disabled={saving}
          className="w-full bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition disabled:bg-gray-400"
        >
          {saving ? "Saving..." : "💾 Save Footer"}
        </button>
      </div>
    );
  };

  // ============================================
  // RENDER NAVIGATION EDITOR
  // ============================================
  const renderNavEditor = () => {
    const nav = localSettings?.navigation || {};
    return (
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-gray-800">🧭 Navigation</h3>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Website Name</label>
          <input
            type="text"
            value={nav.websiteName || "Tech Zone Academy"}
            onChange={(e) => handleFieldChange("navigation", "websiteName", e.target.value)}
            className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Logo</label>
          <div className="flex gap-3">
            <input
              type="text"
              value={nav.logo || ""}
              onChange={(e) => handleFieldChange("navigation", "logo", e.target.value)}
              className="flex-1 border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="Logo URL"
            />
            <label className="bg-gray-200 hover:bg-gray-300 px-4 py-3 rounded-lg cursor-pointer transition">
              📁 Upload
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => handleImageUpload(e, "navigation", "logo")}
              />
            </label>
          </div>
          {nav.logo && (
            <div className="mt-2 h-16 w-16 rounded-lg overflow-hidden bg-gray-200">
              <img src={nav.logo} alt="Logo" className="w-full h-full object-cover" />
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Background Color</label>
            <select
              value={nav.backgroundColor || "from-blue-700 to-blue-800"}
              onChange={(e) => handleFieldChange("navigation", "backgroundColor", e.target.value)}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            >
              <option value="from-blue-700 to-blue-800">Blue</option>
              <option value="from-purple-700 to-purple-800">Purple</option>
              <option value="from-green-700 to-green-800">Green</option>
              <option value="from-red-700 to-red-800">Red</option>
              <option value="from-gray-800 to-gray-900">Dark</option>
              <option value="from-white to-gray-100">Light</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Text Color</label>
            <select
              value={nav.textColor || "text-white"}
              onChange={(e) => handleFieldChange("navigation", "textColor", e.target.value)}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            >
              <option value="text-white">White</option>
              <option value="text-gray-800">Dark</option>
              <option value="text-blue-700">Blue</option>
            </select>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={nav.sticky !== false}
              onChange={(e) => handleFieldChange("navigation", "sticky", e.target.checked)}
              className="w-4 h-4 text-blue-600"
            />
            <span className="text-sm font-medium text-gray-700">Sticky Navbar</span>
          </label>
        </div>

        <div>
          <h4 className="font-semibold text-gray-700 mb-3">Navigation Items</h4>
          {(nav.items || []).map((item, index) => (
            <div key={item.id || index} className="flex items-center gap-2 bg-gray-50 rounded-lg p-2 mb-2">
              <span className="text-gray-400 cursor-move">⠿</span>
              <input
                type="text"
                value={item.label || ""}
                onChange={(e) => handleArrayItemChange("navigation", "items", index, "label", e.target.value)}
                className="flex-1 border rounded p-1 text-sm"
                placeholder="Label"
              />
              <input
                type="text"
                value={item.path || ""}
                onChange={(e) => handleArrayItemChange("navigation", "items", index, "path", e.target.value)}
                className="flex-1 border rounded p-1 text-sm"
                placeholder="/path"
              />
              <label className="flex items-center gap-1 text-sm">
                <input
                  type="checkbox"
                  checked={item.enabled !== false}
                  onChange={(e) => handleArrayItemChange("navigation", "items", index, "enabled", e.target.checked)}
                  className="w-3 h-3"
                />
                Show
              </label>
              <button
                onClick={() => removeArrayItem("navigation", "items", index)}
                className="text-red-500 hover:text-red-700"
              >
                🗑️
              </button>
            </div>
          ))}
          <button
            onClick={() => addArrayItem("navigation", "items", { id: Date.now().toString(), label: "New Page", path: "/new-page", enabled: true })}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition text-sm"
          >
            + Add Menu Item
          </button>
        </div>

        <button
          onClick={() => saveSection("navigation")}
          disabled={saving}
          className="w-full bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition disabled:bg-gray-400"
        >
          {saving ? "Saving..." : "💾 Save Navigation"}
        </button>
      </div>
    );
  };

  // ============================================
  // RENDER THEME EDITOR
  // ============================================
  const renderThemeEditor = () => {
    const theme = localSettings?.theme || {};
    return (
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-gray-800">🎨 Theme & Colors</h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {Object.entries(theme).map(([key, value]) => (
            <div key={key}>
              <label className="block text-sm font-medium text-gray-700 mb-1 capitalize">
                {key.replace(/([A-Z])/g, ' $1').trim()}
              </label>
              {key.includes("Color") ? (
                <div className="flex gap-2">
                  <input
                    type="color"
                    value={value || "#1e40af"}
                    onChange={(e) => handleFieldChange("theme", key, e.target.value)}
                    className="h-10 w-16 border rounded cursor-pointer"
                  />
                  <input
                    type="text"
                    value={value || ""}
                    onChange={(e) => handleFieldChange("theme", key, e.target.value)}
                    className="flex-1 border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
              ) : (
                <input
                  type="text"
                  value={value || ""}
                  onChange={(e) => handleFieldChange("theme", key, e.target.value)}
                  className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                />
              )}
            </div>
          ))}
        </div>

        <button
          onClick={() => saveSection("theme")}
          disabled={saving}
          className="w-full bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition disabled:bg-gray-400"
        >
          {saving ? "Saving..." : "💾 Save Theme"}
        </button>
      </div>
    );
  };

  // ============================================
  // RENDER PAGES EDITOR
  // ============================================
  const renderPagesEditor = () => {
    const pages = localSettings?.pages || {};
    const currentPage = pages[activePage] || { sections: [] };
    const sections = currentPage.sections || [];

    const pageOptions = [
      { id: "home", label: "🏠 Home" },
      { id: "about", label: "📖 About" },
      { id: "admissions", label: "📝 Admissions" },
      { id: "student", label: "🎓 Student" },
      { id: "teacher", label: "👨‍🏫 Teacher" },
      { id: "parent", label: "👨‍👩‍👦 Parent" },
      { id: "news", label: "📰 News" },
      { id: "gallery", label: "🖼️ Gallery" },
      { id: "events", label: "📅 Events" },
      { id: "contact", label: "📞 Contact" },
    ];

    const addSectionToPage = () => {
      const newSection = {
        id: Date.now().toString(),
        type: "content",
        title: "",
        content: "",
        image: "",
        order: sections.length,
        enabled: true,
      };
      const newSections = [...sections, newSection];
      const newPage = { ...currentPage, sections: newSections };
      setLocalSettings(prev => ({
        ...prev,
        pages: { ...prev.pages, [activePage]: newPage }
      }));
    };

    const updatePageSection = (index, field, value) => {
      const newSections = [...sections];
      newSections[index] = { ...newSections[index], [field]: value };
      const newPage = { ...currentPage, sections: newSections };
      setLocalSettings(prev => ({
        ...prev,
        pages: { ...prev.pages, [activePage]: newPage }
      }));
    };

    const removePageSection = (index) => {
      const newSections = sections.filter((_, i) => i !== index);
      const newPage = { ...currentPage, sections: newSections };
      setLocalSettings(prev => ({
        ...prev,
        pages: { ...prev.pages, [activePage]: newPage }
      }));
    };

    const movePageSection = (index, direction) => {
      const newIndex = direction === "up" ? index - 1 : index + 1;
      if (newIndex < 0 || newIndex >= sections.length) return;
      const newSections = [...sections];
      [newSections[index], newSections[newIndex]] = [newSections[newIndex], newSections[index]];
      const newPage = { ...currentPage, sections: newSections };
      setLocalSettings(prev => ({
        ...prev,
        pages: { ...prev.pages, [activePage]: newPage }
      }));
    };

    const savePageContent = async () => {
      setSaving(true);
      try {
        const pageData = { sections };
        await updatePage(activePage, pageData);
        setSuccessMessage(`✅ ${activePage} page updated successfully!`);
        setTimeout(() => setSuccessMessage(""), 3000);
      } catch (error) {
        setErrorMessage("Error saving page: " + error.message);
        setTimeout(() => setErrorMessage(""), 3000);
      } finally {
        setSaving(false);
      }
    };

    return (
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-gray-800">📄 Page Content</h3>

        <div className="flex flex-wrap gap-2">
          {pageOptions.map((page) => (
            <button
              key={page.id}
              onClick={() => setActivePage(page.id)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                activePage === page.id
                  ? "bg-blue-700 text-white"
                  : "bg-gray-200 text-gray-700 hover:bg-gray-300"
              }`}
            >
              {page.label}
            </button>
          ))}
        </div>

        <div className="flex items-center justify-between">
          <h4 className="text-lg font-bold text-gray-800">
            {pageOptions.find(p => p.id === activePage)?.label} Page
          </h4>
          <button
            onClick={addSectionToPage}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition text-sm"
          >
            + Add Section
          </button>
        </div>

        {sections.length === 0 ? (
          <div className="bg-gray-50 rounded-lg p-8 text-center text-gray-500">
            No sections yet. Click "Add Section" to create content.
          </div>
        ) : (
          <div className="space-y-4">
            {sections.map((section, index) => (
              <div key={section.id} className="bg-gray-50 rounded-lg p-4 border">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium text-gray-600">
                    Section {index + 1}
                  </span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => movePageSection(index, "up")}
                      className="text-gray-500 hover:text-gray-700"
                      disabled={index === 0}
                    >
                      ↑
                    </button>
                    <button
                      onClick={() => movePageSection(index, "down")}
                      className="text-gray-500 hover:text-gray-700"
                      disabled={index === sections.length - 1}
                    >
                      ↓
                    </button>
                    <button
                      onClick={() => removePageSection(index)}
                      className="text-red-500 hover:text-red-700"
                    >
                      🗑️
                    </button>
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Section Type</label>
                    <select
                      value={section.type || "content"}
                      onChange={(e) => updatePageSection(index, "type", e.target.value)}
                      className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                    >
                      <option value="hero">Hero</option>
                      <option value="content">Content</option>
                      <option value="features">Features</option>
                      <option value="gallery">Gallery</option>
                      <option value="testimonials">Testimonials</option>
                      <option value="cta">Call to Action</option>
                      <option value="faq">FAQ</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Title</label>
                    <input
                      type="text"
                      value={section.title || ""}
                      onChange={(e) => updatePageSection(index, "title", e.target.value)}
                      className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Section title"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Content</label>
                    <textarea
                      value={section.content || ""}
                      onChange={(e) => updatePageSection(index, "content", e.target.value)}
                      rows="3"
                      className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Section content..."
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Image URL</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={section.image || ""}
                        onChange={(e) => updatePageSection(index, "image", e.target.value)}
                        className="flex-1 border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                        placeholder="Image URL"
                      />
                      <label className="bg-gray-200 hover:bg-gray-300 px-3 py-2 rounded-lg cursor-pointer transition text-sm">
                        📁
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={async (e) => {
                            const file = e.target.files[0];
                            if (file) {
                              const url = await uploadImage(file, `pages/${activePage}`);
                              if (url) {
                                updatePageSection(index, "image", url);
                              }
                            }
                          }}
                        />
                      </label>
                    </div>
                    {section.image && (
                      <div className="mt-2 h-20 w-full rounded-lg overflow-hidden bg-gray-200">
                        <img src={section.image} alt="Preview" className="w-full h-full object-cover" />
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-2 cursor-pointer text-sm">
                      <input
                        type="checkbox"
                        checked={section.enabled !== false}
                        onChange={(e) => updatePageSection(index, "enabled", e.target.checked)}
                        className="w-3 h-3"
                      />
                      Visible
                    </label>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        <button
          onClick={savePageContent}
          disabled={saving}
          className="w-full bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition disabled:bg-gray-400"
        >
          {saving ? "Saving..." : "💾 Save Page Content"}
        </button>
      </div>
    );
  };

  // ============================================
  // MAIN RENDER
  // ============================================
  if (role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">🚫</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h2>
          <p className="text-gray-600">You need admin privileges to access this page.</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading settings...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              ⚙️ Website Settings
            </h1>
            <p className="text-gray-600 mt-1">
              Full control over your school website - no coding required
            </p>
          </div>
          <div className="flex items-center gap-3">
            <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-medium">
              👑 Admin
            </span>
            <button
              onClick={() => window.open("/", "_blank")}
              className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition text-sm"
            >
              🔍 Preview
            </button>
            <button
              onClick={refresh}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm"
            >
              🔄 Refresh
            </button>
          </div>
        </div>

        {/* Messages */}
        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Tabs */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="border-b border-gray-200 overflow-x-auto">
            <div className="flex whitespace-nowrap">
              {[
                { id: "about", label: "📖 About" },
                { id: "hero", label: "🎨 Hero" },
                { id: "stats", label: "📊 Stats" },
                { id: "news", label: "📰 News" },
                { id: "gallery", label: "🖼️ Gallery" },
                { id: "events", label: "📅 Events" },
                { id: "footer", label: "📋 Footer" },
                { id: "nav", label: "🧭 Navigation" },
                { id: "theme", label: "🎨 Theme" },
                { id: "pages", label: "📄 Pages" },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-4 py-3 font-medium transition ${
                    activeTab === tab.id
                      ? "bg-blue-50 text-blue-700 border-b-2 border-blue-700"
                      : "text-gray-600 hover:text-gray-800 hover:bg-gray-50"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          <div className="p-6">
            {activeTab === "about" && renderAboutEditor()}
            {activeTab === "hero" && renderHeroEditor()}
            {activeTab === "stats" && renderStatsEditor()}
            {activeTab === "news" && renderNewsEditor()}
            {activeTab === "gallery" && renderGalleryEditor()}
            {activeTab === "events" && renderEventsEditor()}
            {activeTab === "footer" && renderFooterEditor()}
            {activeTab === "nav" && renderNavEditor()}
            {activeTab === "theme" && renderThemeEditor()}
            {activeTab === "pages" && renderPagesEditor()}
          </div>
        </div>
      </div>
    </div>
  );
}
