// src/pages/ProfileSettings.jsx
import { useState, useEffect, useRef } from "react";
import { useAuth } from "../../context/AuthContext";
import { useNavigate } from "react-router-dom";
import { db, doc, updateDoc, updatePassword, EmailAuthProvider, reauthenticateWithCredential, ref, storage, uploadBytes, getDownloadURL } from "../../supabase/supabase";

const MAX_AVATAR_SIZE = 3 * 1024 * 1024; // 3MB

export default function ProfileSettings() {
  const { user, role, userData, refreshUserData } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState("");
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const avatarInputRef = useRef(null);

  const [profileData, setProfileData] = useState({
    name: "",
    email: "",
    phone: "",
    role: "",
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const phoneRegex = /^(09\d{8}|07\d{8}|\+2519\d{8}|\+2517\d{8})$/;

  useEffect(() => {
    if (userData) {
      setProfileData({
        name: userData.name || userData.fullName || "",
        email: userData.email || user.email || "",
        phone: userData.phone || "",
        role: role || "",
      });
      setAvatarUrl(userData.avatarUrl || "");
    }
  }, [userData, user, role]);

  const handleAvatarSelect = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = ""; // allow re-selecting the same file later

    if (!file.type.startsWith("image/")) {
      setErrorMessage("Please choose an image file.");
      return;
    }
    if (file.size > MAX_AVATAR_SIZE) {
      setErrorMessage("Image must be under 3MB.");
      return;
    }

    setUploadingAvatar(true);
    setErrorMessage("");
    setSuccessMessage("");
    try {
      const extension = file.name.split(".").pop() || "jpg";
      const storageRef = ref(storage, `avatars/${user.uid}/avatar.${extension}`);
      const snapshot = await uploadBytes(storageRef, file);
      const url = await getDownloadURL(snapshot.ref);

      await updateDoc(doc(db, "users", user.uid), { avatarUrl: url });
      setAvatarUrl(url);
      await refreshUserData();
      setSuccessMessage("✅ Profile picture updated!");
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error uploading picture: " + error.message);
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleProfileChange = (e) => {
    const { name, value } = e.target;
    setProfileData((prev) => ({ ...prev, [name]: value }));
  };

  const handlePasswordChange = (e) => {
    const { name, value } = e.target;
    setPasswordData((prev) => ({ ...prev, [name]: value }));
  };

  const updatePhone = async () => {
    setLoading(true);
    setErrorMessage("");
    setSuccessMessage("");

    const { phone } = profileData;

    if (!phone) {
      setErrorMessage("Please enter a phone number");
      setLoading(false);
      return;
    }

    if (!phoneRegex.test(phone)) {
      setErrorMessage("Please enter a valid Ethiopian phone number");
      setLoading(false);
      return;
    }

    try {
      // Update in users collection
      await updateDoc(doc(db, "users", user.uid), {
        phone: phone,
        updatedAt: new Date().toISOString(),
      });

      // If user is a student, also update in students collection
      if (role === "student") {
        await updateDoc(doc(db, "students", user.uid), {
          phone: phone,
          updatedAt: new Date().toISOString(),
        });
      }

      // If user is a teacher, also update in teachers collection
      if (role === "teacher") {
        await updateDoc(doc(db, "teachers", user.uid), {
          phone: phone,
          updatedAt: new Date().toISOString(),
        });
      }

      setSuccessMessage("✅ Phone number updated successfully! You can now login with this phone number.");
      setTimeout(() => setSuccessMessage(""), 5000);
    } catch (error) {
      setErrorMessage("Error updating phone: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setLoading(false);
    }
  };

  const changePassword = async () => {
    setLoading(true);
    setErrorMessage("");
    setSuccessMessage("");

    const { currentPassword, newPassword, confirmPassword } = passwordData;

    if (!currentPassword || !newPassword || !confirmPassword) {
      setErrorMessage("Please fill in all password fields");
      setLoading(false);
      return;
    }

    if (newPassword.length < 6) {
      setErrorMessage("New password must be at least 6 characters");
      setLoading(false);
      return;
    }

    if (newPassword !== confirmPassword) {
      setErrorMessage("New passwords do not match");
      setLoading(false);
      return;
    }

    try {
      // Re-authenticate user
      const credential = EmailAuthProvider.credential(user.email, currentPassword);
      await reauthenticateWithCredential(user, credential);

      // Update password
      await updatePassword(user, newPassword);

      setSuccessMessage("✅ Password changed successfully!");
      setPasswordData({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
      setTimeout(() => setSuccessMessage(""), 5000);
    } catch (error) {
      if (error.code === "auth/wrong-password") {
        setErrorMessage("Current password is incorrect");
      } else if (error.code === "auth/too-many-requests") {
        setErrorMessage("Too many failed attempts. Please try again later.");
      } else {
        setErrorMessage("Error changing password: " + error.message);
      }
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setLoading(false);
    }
  };

  const getRoleBadge = () => {
    switch (role) {
      case "admin":
        return <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-medium">👑 Admin</span>;
      case "teacher":
        return <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">👨‍🏫 Teacher</span>;
      case "parent":
        return <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">👨‍👩‍👦 Parent</span>;
      case "student":
        return <span className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-sm font-medium">🎓 Student</span>;
      default:
        return <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium">User</span>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate(-1)}
              className="text-gray-600 hover:text-gray-800 transition"
            >
              ← Back
            </button>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
                ⚙️ Profile & Security
              </h1>
              <p className="text-gray-600 mt-1">
                Manage your profile information and security settings
              </p>
            </div>
          </div>
        </div>

        {/* Messages */}
        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Profile Card */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-6">
          <div className="p-6 sm:p-8">
            <div className="flex items-center gap-4 mb-6">
              <div className="relative group">
                {avatarUrl ? (
                  <img
                    src={avatarUrl}
                    alt="Profile"
                    className="w-16 h-16 rounded-full object-cover border-2 border-white shadow"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center text-2xl text-white font-bold">
                    {profileData.name?.charAt(0) || "U"}
                  </div>
                )}
                <button
                  type="button"
                  onClick={() => avatarInputRef.current?.click()}
                  disabled={uploadingAvatar}
                  title="Change profile picture"
                  className="absolute -bottom-1 -right-1 bg-blue-700 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs shadow hover:bg-blue-800 transition disabled:bg-gray-400"
                >
                  {uploadingAvatar ? "…" : "✎"}
                </button>
                <input
                  ref={avatarInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleAvatarSelect}
                />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-800">{profileData.name || "User"}</h2>
                <p className="text-sm text-gray-500">{profileData.email}</p>
                <div className="mt-1">{getRoleBadge()}</div>
              </div>
            </div>

            {/* Phone Number Section */}
            <div className="border-t border-gray-200 pt-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">
                📱 Phone Number (Login)
              </h3>
              <p className="text-sm text-gray-500 mb-3">
                Add your phone number to login using your phone number instead of email.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="flex-1">
                  <input
                    type="tel"
                    name="phone"
                    value={profileData.phone}
                    onChange={handleProfileChange}
                    placeholder="Enter phone number (e.g., 0912345678)"
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition"
                  />
                  <p className="text-xs text-gray-400 mt-1">
                    Format: 0912345678 or 0712345678 or +251912345678
                  </p>
                </div>
                <button
                  onClick={updatePhone}
                  disabled={loading}
                  className="bg-blue-700 text-white px-6 py-3 rounded-lg hover:bg-blue-800 transition disabled:bg-gray-400 whitespace-nowrap"
                >
                  {loading ? "Updating..." : "Update Phone"}
                </button>
              </div>
              {profileData.phone && (
                <div className="mt-2 text-sm text-green-600">
                  ✅ Current phone: {profileData.phone}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Change Password Card */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-6 sm:p-8">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">
              🔐 Change Password
            </h3>
            <p className="text-sm text-gray-500 mb-4">
              For security, we recommend changing your password regularly.
            </p>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Current Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    name="currentPassword"
                    value={passwordData.currentPassword}
                    onChange={handlePasswordChange}
                    placeholder="Enter your current password"
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition pr-12"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  >
                    {showPassword ? "🙈" : "👁️"}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  New Password
                </label>
                <div className="relative">
                  <input
                    type={showNewPassword ? "text" : "password"}
                    name="newPassword"
                    value={passwordData.newPassword}
                    onChange={handlePasswordChange}
                    placeholder="Enter new password (min 6 chars)"
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition pr-12"
                    minLength="6"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  >
                    {showNewPassword ? "🙈" : "👁️"}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Confirm New Password
                </label>
                <div className="relative">
                  <input
                    type={showConfirmPassword ? "text" : "password"}
                    name="confirmPassword"
                    value={passwordData.confirmPassword}
                    onChange={handlePasswordChange}
                    placeholder="Confirm new password"
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition pr-12"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  >
                    {showConfirmPassword ? "🙈" : "👁️"}
                  </button>
                </div>
              </div>

              {passwordData.newPassword && passwordData.confirmPassword && (
                <div className={`text-sm ${passwordData.newPassword === passwordData.confirmPassword ? "text-green-600" : "text-red-600"}`}>
                  {passwordData.newPassword === passwordData.confirmPassword
                    ? "✅ Passwords match"
                    : "❌ Passwords do not match"}
                </div>
              )}

              <button
                onClick={changePassword}
                disabled={
                  loading ||
                  !passwordData.currentPassword ||
                  !passwordData.newPassword ||
                  passwordData.newPassword !== passwordData.confirmPassword ||
                  passwordData.newPassword.length < 6
                }
                className={`w-full py-3 rounded-lg font-semibold text-white transition ${
                  loading ||
                  !passwordData.currentPassword ||
                  !passwordData.newPassword ||
                  passwordData.newPassword !== passwordData.confirmPassword ||
                  passwordData.newPassword.length < 6
                    ? "bg-gray-400 cursor-not-allowed"
                    : "bg-blue-700 hover:bg-blue-800 hover:shadow-lg"
                }`}
              >
                {loading ? "Changing Password..." : "Change Password"}
              </button>
            </div>
          </div>
        </div>

        {/* Info Footer */}
        <div className="mt-6 text-center text-xs text-gray-400">
          <p>🔒 Your password is encrypted and securely stored.</p>
          <p className="mt-1">You can login with either your email or phone number.</p>
        </div>
      </div>
    </div>
  );
}