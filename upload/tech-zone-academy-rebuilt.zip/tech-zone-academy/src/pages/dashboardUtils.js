export const firstValue = (item, keys, fallback = "") => {
  for (const key of keys) {
    if (item?.[key] !== undefined && item[key] !== null && item[key] !== "") return item[key];
  }
  return fallback;
};

export const asNumber = (value) => {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
};

export const studentId = (student) => String(firstValue(student, ["studentId", "studentID", "id", "uid"], ""));
export const studentName = (student) => {
  const fullName = firstValue(student, ["fullName", "studentName", "name"]);
  if (fullName) return String(fullName);
  return `${firstValue(student, ["firstName", "firstname"], "")} ${firstValue(student, ["fatherName", "lastName", "lastname"], "")}`.trim() || "Unnamed Student";
};
export const sortStudents = (students) => [...students].sort((a, b) => {
  const first = String(firstValue(a, ["firstName", "firstname"], studentName(a)));
  const second = String(firstValue(b, ["firstName", "firstname"], studentName(b)));
  return first.localeCompare(second, undefined, { sensitivity: "base" }) || studentName(a).localeCompare(studentName(b));
});
export const classKey = (item) => `${String(item?.grade || "").trim()}::${String(item?.section || "").trim()}`;
export const sameClass = (first, second) => classKey(first) === classKey(second);
export const assignmentMatchesAttendance = (record, assignment) => {
  if (!sameClass(record, assignment)) return false;
  const recordSubject = String(record?.subject || "").trim().toLowerCase();
  const assignmentSubject = String(assignment?.subject || "").trim().toLowerCase();
  return !recordSubject || !assignmentSubject || recordSubject === assignmentSubject;
};
export const resultPercentage = (result) => {
  const score = asNumber(firstValue(result, ["score", "marks", "marksObtained"], 0));
  const outOf = asNumber(firstValue(result, ["outOf", "maxScore", "totalMarks", "maxMarks"], 0));
  return outOf > 0 ? (score / outOf) * 100 : null;
};
export const toDate = (value) => {
  if (!value) return null;
  if (typeof value?.toDate === "function") return value.toDate();
  if (typeof value?.seconds === "number") return new Date(value.seconds * 1000);
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
};
export const recordDate = (item) => toDate(firstValue(item, ["date", "createdAt", "updatedAt", "timestamp"]));
export const formatPercent = (value) => value === null || value === undefined ? "No data" : `${new Intl.NumberFormat("en-US", { maximumFractionDigits: 1 }).format(value)}%`;
export const attendanceSummary = (records) => {
  const status = (value) => String(value || "").trim().toLowerCase();
  const total = records.length;
  const present = records.filter((item) => status(item.status) === "present").length;
  const absent = records.filter((item) => status(item.status) === "absent").length;
  const late = records.filter((item) => status(item.status) === "late").length;
  const excused = records.filter((item) => ["excused", "leave"].includes(status(item.status))).length;
  return { total, present, absent, late, excused, rate: total ? (present / total) * 100 : null };
};
export const assignmentDueDate = (assignment) => toDate(firstValue(assignment, ["dueDate", "deadline"]));
export const assignmentMatchesStudent = (assignment, student) => sameClass(assignment, student);
export const isSubmitted = (submission, assignment, student) => {
  const assignmentId = String(firstValue(submission, ["assignmentId", "assignmentID"], ""));
  const submissionStudentId = String(firstValue(submission, ["studentId", "studentID"], ""));
  return assignmentId === String(assignment.id) && submissionStudentId === studentId(student);
};
