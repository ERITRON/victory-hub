// src/pages/AdminProfile.jsx
import { useAuth } from "../../context/AuthContext";
import { useEffect, useState } from "react";
import { db, doc, getDoc } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";

export default function AdminProfile() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [adminData, setAdminData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      getDoc(doc(db, "users", user.uid))
        .then((doc) => {
          if (doc.exists()) {
            setAdminData(doc.data());
          }
        })
        .catch(console.error)
        .finally(() => setLoading(false));
    }
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading profile...</p>
        </div>
      </div>
    );
  }

  if (!adminData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <p className="text-gray-600">No admin data found.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button onClick={() => navigate(-1)} className="text-gray-600 hover:text-gray-800 transition">
            ← Back
          </button>
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">👑 Admin Profile</h1>
        </div>

        {/* Profile Card */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-purple-600 to-purple-800 px-6 py-8">
            <div className="flex items-center gap-6">
              <div className="w-24 h-24 rounded-full bg-white/20 flex items-center justify-center text-4xl text-white font-bold border-4 border-white">
                {adminData.name?.charAt(0) || "A"}
              </div>
              <div className="text-white">
                <h2 className="text-2xl font-bold">{adminData.name || "Admin"}</h2>
                <p className="text-purple-200">{adminData.email}</p>
                <span className="inline-block bg-purple-700 px-3 py-1 rounded-full text-sm font-medium mt-2">
                  👑 Admin
                </span>
              </div>
            </div>
          </div>

          <div className="p-6 space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Full Name</p>
                <p className="font-semibold text-gray-800">{adminData.name || "N/A"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Email</p>
                <p className="font-semibold text-gray-800">{adminData.email || "N/A"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Phone</p>
                <p className="font-semibold text-gray-800">{adminData.phone || "Not set"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Role</p>
                <p className="font-semibold text-gray-800 capitalize">{adminData.role || "Admin"}</p>
              </div>
            </div>

            <button
              onClick={() => navigate("/profile")}
              className="w-full bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition font-medium"
            >
              ⚙️ Edit Profile & Security
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}