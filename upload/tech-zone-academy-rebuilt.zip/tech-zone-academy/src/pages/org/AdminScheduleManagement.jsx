// src/pages/AdminScheduleManagement.jsx
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { db, collection, getDocs, addDoc, updateDoc, deleteDoc, doc, writeBatch } from "../../supabase/supabase";
import toast from "react-hot-toast";

export default function AdminScheduleManagement() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [schedules, setSchedules] = useState([]);
  const [grades, setGrades] = useState([]);
  const [sections, setSections] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [teacherAssignments, setTeacherAssignments] = useState([]);
  const [selectedClass, setSelectedClass] = useState(null);
  const [showTimetable, setShowTimetable] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const [formData, setFormData] = useState({
    grade: "",
    section: "",
    subject: "",
    teacherId: "",
    teacherName: "",
    day: "Monday",
    startTime: "",
    endTime: "",
    room: "",
    periodType: "class",
  });

  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
  const periodTypes = [
    { value: "class", label: "📚 Class" },
    { value: "break", label: "🟢 Break" },
    { value: "lunch", label: "🍽️ Lunch" },
  ];

  const refreshSchedules = async () => {
    const schedulesSnap = await getDocs(collection(db, "schedules"));
    const schedulesData = schedulesSnap.docs.map((scheduleDoc) => ({
      id: scheduleDoc.id,
      ...scheduleDoc.data(),
    }));
    setSchedules(schedulesData);
  };

  const fetchAllData = async () => {
    setLoading(true);
    try {
      const gradesSnap = await getDocs(collection(db, "grades"));
      const gradesData = gradesSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setGrades(gradesData.sort((a, b) => a.name.localeCompare(b.name)));

      const sectionsSnap = await getDocs(collection(db, "sections"));
      const sectionsData = sectionsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSections(sectionsData.sort((a, b) => a.name.localeCompare(b.name)));

      const subjectsSnap = await getDocs(collection(db, "subjects"));
      const subjectsData = subjectsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSubjects(subjectsData.sort((a, b) => a.name.localeCompare(b.name)));

      const teachersSnap = await getDocs(collection(db, "teachers"));
      const teachersData = teachersSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setTeachers(teachersData);

      const assignmentsSnap = await getDocs(collection(db, "teacherAssignments"));
      const assignmentsData = assignmentsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setTeacherAssignments(assignmentsData);

      const schedulesSnap = await getDocs(collection(db, "schedules"));
      const schedulesData = schedulesSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSchedules(schedulesData);

    } catch (error) {
      setErrorMessage("Error loading data: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
     
    fetchAllData();
  }, []);

  const findAssignedTeacher = (grade, section, subject) => {
    if (!grade || !section || !subject) return null;
    const assignment = teacherAssignments.find(
      (a) => a.grade === grade && a.section === section && a.subject === subject
    );
    if (assignment) {
      const teacher = teachers.find((t) => t.id === assignment.teacherId);
      return {
        teacherId: assignment.teacherId,
        teacherName: assignment.teacherName || teacher?.fullName || `${teacher?.firstName} ${teacher?.fatherName}` || "",
      };
    }
    return null;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));

    if (name === "subject" && value && formData.grade && formData.section) {
      const assigned = findAssignedTeacher(formData.grade, formData.section, value);
      if (assigned) {
        setFormData((prev) => ({
          ...prev,
          subject: value,
          teacherId: assigned.teacherId,
          teacherName: assigned.teacherName,
        }));
      } else {
        setFormData((prev) => ({
          ...prev,
          subject: value,
          teacherId: "",
          teacherName: "",
        }));
      }
    }

    if (name === "grade" || name === "section") {
      setFormData((prev) => ({
        ...prev,
        subject: "",
        teacherId: "",
        teacherName: "",
      }));
    }

    if (name === "teacherId") {
      const teacher = teachers.find((t) => t.id === value);
      if (teacher) {
        setFormData((prev) => ({
          ...prev,
          teacherId: value,
          teacherName: teacher.fullName || `${teacher.firstName} ${teacher.fatherName}`,
        }));
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMessage("");
    setSuccessMessage("");

    const { grade, section, subject, teacherId, teacherName, day, startTime, endTime, room, periodType } = formData;

    if (!grade || !section || !day || !startTime || !endTime) {
      setErrorMessage("Please fill all required fields.");
      setLoading(false);
      return;
    }

    if (periodType === "class" && (!subject || !teacherId)) {
      setErrorMessage("Subject and Teacher are required for class periods.");
      setLoading(false);
      return;
    }

    const conflict = schedules.find(
      (s) =>
        s.grade === grade &&
        s.section === section &&
        s.day === day &&
        s.startTime === startTime &&
        s.id !== editingId
    );

    if (conflict) {
      setErrorMessage(`Conflict: ${grade} - ${section} already has a class at ${startTime} on ${day}`);
      setLoading(false);
      return;
    }

    try {
      const scheduleData = {
        grade,
        section,
        subject: periodType === "class" ? subject : periodType,
        teacherId: periodType === "class" ? teacherId : "",
        teacherName: periodType === "class" ? teacherName : "",
        day,
        startTime,
        endTime,
        room: periodType === "class" ? room || `${grade}-${section}` : "",
        periodType,
        createdAt: new Date().toISOString(),
      };

      if (editingId) {
        await updateDoc(doc(db, "schedules", editingId), {
          ...scheduleData,
          updatedAt: new Date().toISOString(),
        });
        setSuccessMessage("✅ Schedule updated successfully!");
      } else {
        await addDoc(collection(db, "schedules"), scheduleData);
        setSuccessMessage("✅ Schedule created successfully!");
      }

      setFormData({
        grade: "",
        section: "",
        subject: "",
        teacherId: "",
        teacherName: "",
        day: "Monday",
        startTime: "",
        endTime: "",
        room: "",
        periodType: "class",
      });
      setEditingId(null);
      setShowEditModal(false);
      setEditingSchedule(null);
      fetchAllData();

      setTimeout(() => setSuccessMessage(""), 5000);

    } catch (error) {
      setErrorMessage("Error saving schedule: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  // ✅ Open edit modal for a schedule entry
  const openEditModal = (schedule) => {
    setEditingSchedule(schedule);
    setEditingId(schedule.id);
    setFormData({
      grade: schedule.grade || "",
      section: schedule.section || "",
      subject: schedule.subject || "",
      teacherId: schedule.teacherId || "",
      teacherName: schedule.teacherName || "",
      day: schedule.day || "Monday",
      startTime: schedule.startTime || "",
      endTime: schedule.endTime || "",
      room: schedule.room || "",
      periodType: schedule.periodType || "class",
    });
    setShowEditModal(true);
  };


  const closeEditModal = () => {
    setShowEditModal(false);
    setEditingId(null);
    setEditingSchedule(null);
    setFormData({
      grade: "",
      section: "",
      subject: "",
      teacherId: "",
      teacherName: "",
      day: "Monday",
      startTime: "",
      endTime: "",
      room: "",
      periodType: "class",
    });
  };

  const requestEntryDeletion = (schedule) => {
    setDeleteTarget({ type: "entry", schedule });
  };

  const requestClassDeletion = (grade, section, classSchedules) => {
    setDeleteTarget({ type: "class", grade, section, schedules: classSchedules });
  };

  const confirmDeletion = async () => {
    if (!deleteTarget || deleting) return;

    const schedulesToDelete = deleteTarget.type === "class"
      ? deleteTarget.schedules
      : [deleteTarget.schedule];
    const deletedIds = new Set(schedulesToDelete.map((schedule) => schedule.id));
    const previousSchedules = schedules;

    // Remove the entries immediately. The previous state is restored if the update fails.
    setSchedules((current) => current.filter((schedule) => !deletedIds.has(schedule.id)));
    setDeleting(true);

    try {
      if (deleteTarget.type === "class") {
        const batch = writeBatch(db);
        schedulesToDelete.forEach((schedule) => {
          batch.delete(doc(db, "schedules", schedule.id));
        });
        await batch.commit();
      } else {
        await deleteDoc(doc(db, "schedules", deleteTarget.schedule.id));
      }

      const deletedClass = deleteTarget.type === "class";
      setDeleteTarget(null);
      toast.success(deletedClass ? "Class schedule deleted" : "Schedule entry deleted");

      try {
        await refreshSchedules();
      } catch {
        toast.error("Schedule was deleted, but the latest data could not be refreshed");
      }
    } catch (error) {
      setSchedules(previousSchedules);
      toast.error(`Could not delete schedule: ${error.message}`);
    } finally {
      setDeleting(false);
    }
  };

  const getClassSchedules = (grade, section) => {
    return schedules
      .filter((s) => s.grade === grade && s.section === section)
      .sort((a, b) => {
        const dayOrder = days.indexOf(a.day) - days.indexOf(b.day);
        if (dayOrder !== 0) return dayOrder;
        return a.startTime.localeCompare(b.startTime);
      });
  };

  const getClassList = () => {
    const classMap = {};
    schedules.forEach((s) => {
      const key = `${s.grade}-${s.section}`;
      if (!classMap[key]) {
        classMap[key] = { grade: s.grade, section: s.section };
      }
    });
    return Object.values(classMap);
  };

  const getTimetableMatrix = (grade, section) => {
    const classSchedules = getClassSchedules(grade, section);
    const matrix = {};
    days.forEach((day) => {
      matrix[day] = classSchedules.filter((s) => s.day === day);
    });
    return matrix;
  };


  const getPeriodTypeColor = (type) => {
    switch (type) {
      case "break": return "bg-green-50";
      case "lunch": return "bg-yellow-50";
      default: return "";
    }
  };

  const classes = getClassList();

  if (loading && schedules.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading schedules...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <button onClick={() => navigate(-1)} className="text-gray-600 hover:text-gray-800 transition">
            ← Back
          </button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              📅 Schedule Management
            </h1>
            <p className="text-gray-600 mt-1">
              Create class schedules and view weekly timetables
            </p>
          </div>
        </div>

        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Add Schedule Form */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-8">
          <div className="p-6 sm:p-8">
            <h2 className="text-xl font-bold text-gray-800 mb-4">
              {editingId ? "✏️ Edit Schedule Entry" : "➕ Add Schedule Entry"}
            </h2>
            <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Grade *</label>
                <select
                  name="grade"
                  value={formData.grade}
                  onChange={handleChange}
                  className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
                  required
                >
                  <option value="">Select Grade</option>
                  {grades.map((grade) => (
                    <option key={grade.id} value={grade.name}>{grade.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Section *</label>
                <select
                  name="section"
                  value={formData.section}
                  onChange={handleChange}
                  className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
                  required
                >
                  <option value="">Select Section</option>
                  {sections.map((section) => (
                    <option key={section.id} value={section.name}>{section.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Day *</label>
                <select
                  name="day"
                  value={formData.day}
                  onChange={handleChange}
                  className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
                  required
                >
                  {days.map((day) => (
                    <option key={day} value={day}>{day}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Period Type</label>
                <select
                  name="periodType"
                  value={formData.periodType}
                  onChange={handleChange}
                  className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
                >
                  {periodTypes.map((type) => (
                    <option key={type.value} value={type.value}>{type.label}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Start Time *</label>
                <input
                  type="time"
                  name="startTime"
                  value={formData.startTime}
                  onChange={handleChange}
                  className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">End Time *</label>
                <input
                  type="time"
                  name="endTime"
                  value={formData.endTime}
                  onChange={handleChange}
                  className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
                  required
                />
              </div>

              {formData.periodType === "class" && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Subject *</label>
                    <select
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
                      required
                    >
                      <option value="">Select Subject</option>
                      {subjects.map((subject) => (
                        <option key={subject.id} value={subject.name}>{subject.name}</option>
                      ))}
                    </select>
                    {formData.subject && formData.teacherName ? (
                      <p className="text-xs text-green-600 mt-1">✅ Assigned: <strong>{formData.teacherName}</strong></p>
                    ) : formData.subject && !formData.teacherName ? (
                      <p className="text-xs text-yellow-600 mt-1">⚠️ No teacher assigned</p>
                    ) : null}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Teacher *</label>
                    <select
                      name="teacherId"
                      value={formData.teacherId}
                      onChange={handleChange}
                      className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
                      required
                    >
                      <option value="">Select Teacher</option>
                      {teachers.map((teacher) => (
                        <option key={teacher.id} value={teacher.id}>
                          {teacher.fullName || `${teacher.firstName} ${teacher.fatherName}`}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Room</label>
                    <input
                      type="text"
                      name="room"
                      value={formData.room}
                      onChange={handleChange}
                      placeholder="e.g., Room 101"
                      className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
                    />
                  </div>
                </>
              )}

              <div className="sm:col-span-2 lg:col-span-4 flex gap-3">
                <button
                  type="submit"
                  disabled={loading}
                  className="bg-blue-700 text-white px-6 py-2.5 rounded-lg hover:bg-blue-800 transition disabled:bg-gray-400"
                >
                  {loading ? "Saving..." : editingId ? "Update Schedule" : "Add Schedule"}
                </button>
                {editingId && (
                  <button
                    type="button"
                    onClick={closeEditModal}
                    className="bg-gray-200 text-gray-700 px-6 py-2.5 rounded-lg hover:bg-gray-300 transition"
                  >
                    Cancel
                  </button>
                )}
              </div>
            </form>
          </div>
        </div>

        {/* Class Cards Grid */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4">📋 Class Schedules</h2>
            
            {classes.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <div className="text-6xl mb-4">📭</div>
                <p>No schedules created yet. Add your first schedule above.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {classes.map((cls) => {
                  const classSchedules = getClassSchedules(cls.grade, cls.section);
                  const hasSchedules = classSchedules.length > 0;
                  
                  return (
                    <div
                      key={`${cls.grade}-${cls.section}`}
                      onClick={() => {
                        if (hasSchedules) {
                          setSelectedClass(cls);
                          setShowTimetable(true);
                        }
                      }}
                      className={`relative
                        border-2 rounded-xl p-6 cursor-pointer transition-all duration-300
                        ${hasSchedules 
                          ? "bg-white hover:shadow-xl hover:-translate-y-1 border-blue-200 hover:border-blue-500" 
                          : "bg-gray-50 border-gray-200 opacity-60 cursor-not-allowed"}
                      `}
                    >
                      <button
                        type="button"
                        onClick={(event) => {
                          event.stopPropagation();
                          requestClassDeletion(cls.grade, cls.section, classSchedules);
                        }}
                        className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-lg text-red-600 transition hover:bg-red-50 hover:text-red-700"
                        aria-label={`Delete schedule for ${cls.grade}, Section ${cls.section}`}
                        title="Delete class schedule"
                      >
                        <span aria-hidden="true">&#128465;</span>
                      </button>
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-xl font-bold text-gray-800">
                            {cls.grade}
                          </h3>
                          <p className="text-sm text-gray-500">Section {cls.section}</p>
                        </div>
                        <div className="mr-8 text-4xl">
                          {hasSchedules ? "📅" : "📭"}
                        </div>
                      </div>
                      <div className="mt-3 flex items-center justify-between">
                        <span className="text-sm text-gray-500">
                          {hasSchedules ? `${classSchedules.length} periods` : "No schedule"}
                        </span>
                        {hasSchedules && (
                          <span className="text-blue-600 text-sm font-medium">
                            View Timetable →
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Timetable Modal */}
        {showTimetable && selectedClass && (
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowTimetable(false)}
          >
            <div
              className="bg-white rounded-2xl max-w-5xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-800">
                    {selectedClass.grade} - Section {selectedClass.section}
                  </h2>
                  <p className="text-gray-500 text-sm">Weekly Timetable</p>
                </div>
                <button
                  onClick={() => setShowTimetable(false)}
                  className="text-gray-400 hover:text-gray-600 text-3xl"
                >
                  ✕
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-blue-700 text-white">
                      <th className="p-3 text-left border border-blue-800 min-w-[100px]">Time</th>
                      {days.map((day) => (
                        <th key={day} className="p-3 text-center border border-blue-800 min-w-[130px]">
                          {day}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {(() => {
                      const matrix = getTimetableMatrix(selectedClass.grade, selectedClass.section);
                      const times = [...new Set(
                        schedules
                          .filter(s => s.grade === selectedClass.grade && s.section === selectedClass.section)
                          .map(s => s.startTime)
                      )].sort();

                      if (times.length === 0) {
                        return (
                          <tr>
                            <td colSpan="6" className="p-4 text-center text-gray-500">
                              No schedule found for this class.
                            </td>
                          </tr>
                        );
                      }

                      return times.map((time) => {
                        const endTime = schedules.find(s => s.startTime === time && s.grade === selectedClass.grade && s.section === selectedClass.section)?.endTime || "";
                        return (
                          <tr key={time} className="hover:bg-gray-50">
                            <td className="p-3 border border-gray-200 font-medium whitespace-nowrap">
                              {time} – {endTime}
                            </td>
                            {days.map((day) => {
                              const period = matrix[day]?.find(s => s.startTime === time);
                              if (!period) {
                                return <td key={day} className="p-3 border border-gray-200 text-center text-gray-400">–</td>;
                              }
                              const isBreak = period.periodType === "break";
                              const isLunch = period.periodType === "lunch";
                              
                              return (
                                <td key={day} className={`p-3 border border-gray-200 text-center ${getPeriodTypeColor(period.periodType)}`}>
                                  {isBreak ? (
                                    <span className="font-medium text-green-600">🟢 Break</span>
                                  ) : isLunch ? (
                                    <span className="font-medium text-yellow-600">🍽️ Lunch</span>
                                  ) : (
                                    <div>
                                      <div className="font-bold text-gray-800">{period.subject}</div>
                                      <div className="text-xs text-gray-500">{period.teacherName}</div>
                                      <div className="text-xs text-gray-400">{period.room}</div>
                                      {/* ✅ Edit button on timetable period */}
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          // Close the timetable modal
                                          setShowTimetable(false);
                                          // Open edit modal for this schedule
                                          setTimeout(() => {
                                            openEditModal(period);
                                          }, 300);
                                        }}
                                        className="mt-1 text-xs text-blue-600 hover:text-blue-800"
                                      >
                                        ✏️ Edit
                                      </button>
                                    </div>
                                  )}
                                  <button
                                    type="button"
                                    onClick={(event) => {
                                      event.stopPropagation();
                                      requestEntryDeletion(period);
                                    }}
                                    className="mt-2 text-xs font-medium text-red-600 hover:text-red-800"
                                    aria-label={`Delete ${period.subject || period.periodType} on ${day} at ${period.startTime}`}
                                  >
                                    Delete
                                  </button>
                                </td>
                              );
                            })}
                          </tr>
                        );
                      });
                    })()}
                  </tbody>
                </table>
              </div>

              <div className="mt-4 flex flex-wrap gap-4 text-sm border-t border-gray-200 pt-4">
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded bg-blue-100 text-blue-700">📚 Class</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded bg-green-100 text-green-700">🟢 Break</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded bg-yellow-100 text-yellow-700">🍽️ Lunch</span>
                </div>
              </div>

              <button
                onClick={() => setShowTimetable(false)}
                className="w-full mt-6 bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition font-medium"
              >
                Close Timetable
              </button>
            </div>
          </div>
        )}

        {/* ✅ Edit Schedule Modal */}
        {deleteTarget && (
          <div
            className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
            onClick={() => !deleting && setDeleteTarget(null)}
          >
            <div
              role="alertdialog"
              aria-modal="true"
              aria-labelledby="delete-schedule-title"
              aria-describedby="delete-schedule-description"
              className="w-full max-w-md rounded-xl bg-white p-6 shadow-2xl"
              onClick={(event) => event.stopPropagation()}
            >
              <div className="flex items-start gap-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-red-100 text-xl text-red-700">
                  <span aria-hidden="true">&#128465;</span>
                </div>
                <div>
                  <h2 id="delete-schedule-title" className="text-lg font-bold text-gray-900">
                    {deleteTarget.type === "class" ? "Delete class schedule?" : "Delete schedule entry?"}
                  </h2>
                  <p id="delete-schedule-description" className="mt-2 text-sm leading-6 text-gray-600">
                    {deleteTarget.type === "class"
                      ? `This will permanently delete all ${deleteTarget.schedules.length} schedule entries for ${deleteTarget.grade}, Section ${deleteTarget.section}.`
                      : `This will permanently delete ${deleteTarget.schedule.subject || deleteTarget.schedule.periodType} on ${deleteTarget.schedule.day} at ${deleteTarget.schedule.startTime}.`}
                  </p>
                </div>
              </div>

              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  disabled={deleting}
                  onClick={() => setDeleteTarget(null)}
                  className="rounded-lg bg-gray-100 px-4 py-2.5 font-medium text-gray-700 transition hover:bg-gray-200 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={deleting}
                  onClick={confirmDeletion}
                  className="rounded-lg bg-red-600 px-4 py-2.5 font-medium text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:bg-red-300"
                >
                  {deleting ? "Deleting..." : "Delete"}
                </button>
              </div>
            </div>
          </div>
        )}

        {showEditModal && editingSchedule && (
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={closeEditModal}
          >
            <div
              className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-800">✏️ Edit Schedule Entry</h2>
                  <p className="text-gray-500 text-sm">
                    {editingSchedule.grade} - Section {editingSchedule.section} • {editingSchedule.day} • {editingSchedule.startTime} - {editingSchedule.endTime}
                  </p>
                </div>
                <button
                  onClick={closeEditModal}
                  className="text-gray-400 hover:text-gray-600 text-3xl"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Grade *</label>
                  <select
                    name="grade"
                    value={formData.grade}
                    onChange={handleChange}
                    className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
                    required
                  >
                    <option value="">Select Grade</option>
                    {grades.map((grade) => (
                      <option key={grade.id} value={grade.name}>{grade.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Section *</label>
                  <select
                    name="section"
                    value={formData.section}
                    onChange={handleChange}
                    className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
                    required
                  >
                    <option value="">Select Section</option>
                    {sections.map((section) => (
                      <option key={section.id} value={section.name}>{section.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Day *</label>
                  <select
                    name="day"
                    value={formData.day}
                    onChange={handleChange}
                    className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
                    required
                  >
                    {days.map((day) => (
                      <option key={day} value={day}>{day}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Period Type</label>
                  <select
                    name="periodType"
                    value={formData.periodType}
                    onChange={handleChange}
                    className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
                  >
                    {periodTypes.map((type) => (
                      <option key={type.value} value={type.value}>{type.label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Start Time *</label>
                  <input
                    type="time"
                    name="startTime"
                    value={formData.startTime}
                    onChange={handleChange}
                    className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">End Time *</label>
                  <input
                    type="time"
                    name="endTime"
                    value={formData.endTime}
                    onChange={handleChange}
                    className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
                    required
                  />
                </div>

                {formData.periodType === "class" && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Subject *</label>
                      <select
                        name="subject"
                        value={formData.subject}
                        onChange={handleChange}
                        className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
                        required
                      >
                        <option value="">Select Subject</option>
                        {subjects.map((subject) => (
                          <option key={subject.id} value={subject.name}>{subject.name}</option>
                        ))}
                      </select>
                      {formData.subject && formData.teacherName ? (
                        <p className="text-xs text-green-600 mt-1">✅ Assigned: <strong>{formData.teacherName}</strong></p>
                      ) : formData.subject && !formData.teacherName ? (
                        <p className="text-xs text-yellow-600 mt-1">⚠️ No teacher assigned</p>
                      ) : null}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Teacher *</label>
                      <select
                        name="teacherId"
                        value={formData.teacherId}
                        onChange={handleChange}
                        className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
                        required
                      >
                        <option value="">Select Teacher</option>
                        {teachers.map((teacher) => (
                          <option key={teacher.id} value={teacher.id}>
                            {teacher.fullName || `${teacher.firstName} ${teacher.fatherName}`}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Room</label>
                      <input
                        type="text"
                        name="room"
                        value={formData.room}
                        onChange={handleChange}
                        placeholder="e.g., Room 101"
                        className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
                      />
                    </div>
                  </>
                )}

                <div className="sm:col-span-2 flex gap-3 mt-4">
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition disabled:bg-gray-400 font-medium"
                  >
                    {loading ? "Updating..." : "💾 Update Schedule"}
                  </button>
                  <button
                    type="button"
                    onClick={closeEditModal}
                    className="px-6 py-3 rounded-lg bg-gray-200 text-gray-700 hover:bg-gray-300 transition font-medium"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
