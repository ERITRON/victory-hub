// src/pages/UserManagement.jsx
import { useState, useEffect } from "react";
import { useAuth } from "../../context/AuthContext";
import CreateUserModal from "../../components/CreateUserModal";

export default function UserManagement() {
  const { role, getVisibleUsers, updateUserStatus, deleteUser } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [filter, setFilter] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  const roleDisplay = {
    super_admin: "👑 Super Admin",
    owner: "🏢 Owner",
    admin: "👔 Admin",
    teacher: "👨‍🏫 Teacher",
    parent: "👨‍👩‍👦 Parent",
    student: "👨‍🎓 Student",
  };

  const statusColors = {
    active: "bg-green-100 text-green-700",
    inactive: "bg-red-100 text-red-700",
    pending: "bg-yellow-100 text-yellow-700",
    suspended: "bg-orange-100 text-orange-700",
    deleted: "bg-gray-100 text-gray-700",
  };

  useEffect(() => {
    loadUsers();
  }, []);

  async function loadUsers() {
    setLoading(true);
    try {
      const visibleUsers = await getVisibleUsers();
      setUsers(visibleUsers);
    } catch (error) {
      console.error("Error loading users:", error);
    } finally {
      setLoading(false);
    }
  }

  // Get creatable roles for the current user
  const getCreatableRoles = () => {
    switch (role) {
      case "super_admin":
        return ["owner"];
      case "owner":
        return ["admin"];
      case "admin":
        return ["teacher", "parent", "student"];
      default:
        return [];
    }
  };

  const handleStatusChange = async (uid, newStatus) => {
    if (window.confirm(`Change user status to ${newStatus}?`)) {
      const success = await updateUserStatus(uid, newStatus);
      if (success) {
        await loadUsers();
      }
    }
  };

  const handleDeleteUser = async (uid, userEmail) => {
    if (window.confirm(`Are you sure you want to delete ${userEmail}? This action cannot be undone.`)) {
      const success = await deleteUser(uid);
      if (success) {
        await loadUsers();
      }
    }
  };

  const filteredUsers = users.filter((u) => {
    if (!searchTerm) return true;
    const search = searchTerm.toLowerCase();
    return (
      u.email?.toLowerCase().includes(search) ||
      u.firstName?.toLowerCase().includes(search) ||
      u.lastName?.toLowerCase().includes(search) ||
      u.phone?.includes(search)
    );
  });

  // Get role filter options based on current user's role
  const getFilterOptions = () => {
    switch (role) {
      case "super_admin":
        return ["all", "owner", "admin", "teacher", "parent", "student"];
      case "owner":
        return ["all", "admin", "teacher", "parent", "student"];
      case "admin":
        return ["all", "teacher", "parent", "student"];
      default:
        return ["all"];
    }
  };

  const filterOptions = getFilterOptions();

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              👥 User Management
            </h1>
            <p className="text-gray-600 mt-1">
              {role === "super_admin" && "👑 Full access to all users"}
              {role === "owner" && "🏢 Manage admin accounts"}
              {role === "admin" && "👔 Manage teacher, parent, and student accounts"}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
              {roleDisplay[role] || role}
            </span>
            {getCreatableRoles().length > 0 && (
              <button
                onClick={() => setShowCreateModal(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition"
              >
                ➕ Add {getCreatableRoles().map(r => roleDisplay[r]).join(", ")}
              </button>
            )}
          </div>
        </div>

        {/* Hierarchy Info */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-gray-700">Role Hierarchy:</span>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-xs font-medium">👑 Super Admin</span>
              <span className="text-gray-400">→</span>
              <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-medium">🏢 Owner</span>
              <span className="text-gray-400">→</span>
              <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-xs font-medium">👔 Admin</span>
              <span className="text-gray-400">→</span>
                  <span className="text-gray-400">/</span>
              <span className="px-3 py-1 bg-orange-100 text-orange-700 rounded-full text-xs font-medium">👨‍🏫 Teacher</span>
              <span className="text-gray-400">/</span>
              <span className="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full text-xs font-medium">👨‍👩‍👦 Parent</span>
              <span className="text-gray-400">/</span>
              <span className="px-3 py-1 bg-pink-100 text-pink-700 rounded-full text-xs font-medium">👨‍🎓 Student</span>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <div className="flex flex-wrap gap-3">
            {filterOptions.map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-3 py-1 rounded-full text-sm font-medium transition ${
                  filter === f
                    ? "bg-blue-600 text-white"
                    : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                }`}
              >
                {f === "all" ? "All Users" : roleDisplay[f] || f}
              </button>
            ))}
          </div>

          <div className="mt-4">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="🔍 Search users by name, email, or phone..."
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
        </div>

        {/* Users Table */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">User</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Email</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Role</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Phone</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Status</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Created By</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan="7" className="px-4 py-8 text-center text-gray-500">
                      <div className="animate-pulse">Loading users...</div>
                    </td>
                  </tr>
                ) : filteredUsers.length === 0 ? (
                  <tr>
                    <td colSpan="7" className="px-4 py-8 text-center text-gray-500">
                      No users found
                    </td>
                  </tr>
                ) : (
                  filteredUsers.map((u) => (
                    <tr key={u.id} className="border-b hover:bg-gray-50 transition">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-bold">
                            {u.firstName?.[0] || u.email?.[0] || "U"}
                          </div>
                          <div>
                            <p className="font-medium text-gray-800">
                              {u.firstName || ""} {u.lastName || ""}
                            </p>
                            <p className="text-xs text-gray-500">
                              ID: {u.id.slice(0, 8)}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">{u.email}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          u.role === "super_admin" ? "bg-red-100 text-red-700" :
                          u.role === "owner" ? "bg-blue-100 text-blue-700" :
                          u.role === "admin" ? "bg-purple-100 text-purple-700" :
                                                    u.role === "teacher" ? "bg-orange-100 text-orange-700" :
                          u.role === "parent" ? "bg-yellow-100 text-yellow-700" :
                          "bg-pink-100 text-pink-700"
                        }`}>
                          {roleDisplay[u.role] || u.role}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">{u.phone || "—"}</td>
                      <td className="px-4 py-3 text-center">
                        <select
                          value={u.status || "active"}
                          onChange={(e) => handleStatusChange(u.id, e.target.value)}
                          className={`px-2 py-1 rounded-full text-xs font-medium border-0 focus:ring-2 focus:ring-blue-500 ${
                            statusColors[u.status] || statusColors.active
                          }`}
                        >
                          <option value="active">✅ Active</option>
                          <option value="inactive">❌ Inactive</option>
                          <option value="suspended">⛔ Suspended</option>
                          <option value="pending">⏳ Pending</option>
                        </select>
                      </td>
                      <td className="px-4 py-3 text-center text-sm text-gray-500">
                        {u.createdByRole ? roleDisplay[u.createdByRole] : "System"}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <div className="flex items-center justify-center gap-2">
                          {u.role !== "super_admin" && u.role !== role && (
                            <>
                              <button
                                onClick={() => {
                                  // Edit user logic
                                }}
                                className="text-blue-600 hover:text-blue-800 text-sm"
                                title="Edit User"
                              >
                                📝
                              </button>
                              <button
                                onClick={() => handleDeleteUser(u.id, u.email)}
                                className="text-red-600 hover:text-red-800 text-sm"
                                title="Delete User"
                              >
                                🗑️
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          <div className="px-4 py-3 border-t flex items-center justify-between">
            <p className="text-sm text-gray-500">
              Showing {filteredUsers.length} users
            </p>
            <div className="flex gap-2">
              <button className="px-3 py-1 border rounded hover:bg-gray-50 transition text-sm">
                Previous
              </button>
              <button className="px-3 py-1 bg-blue-600 text-white rounded text-sm">
                1
              </button>
              <button className="px-3 py-1 border rounded hover:bg-gray-50 transition text-sm">
                Next
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Create User Modal */}
      {showCreateModal && (
        <CreateUserModal
          onClose={() => setShowCreateModal(false)}
          onUserCreated={() => {
            loadUsers();
            setShowCreateModal(false);
          }}
        />
      )}
    </div>
  );
}