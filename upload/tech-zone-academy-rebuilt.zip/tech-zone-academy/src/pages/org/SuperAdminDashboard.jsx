// src/pages/SuperAdminDashboard.jsx
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import DashboardShell from "../../components/dashboard/DashboardShell";
import { getSuperAdminStats } from "../../services/statsService";

export default function SuperAdminDashboard() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [stats, setStats] = useState({
    totalOwners: 0,
    totalAdmins: 0,
    totalTeachers: 0,
    totalParents: 0,
    totalStudents: 0,
    totalUsers: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  async function fetchStats() {
    setLoading(true);
    try {
      const statsData = await getSuperAdminStats();
      setStats(statsData);
    } catch (error) {
      console.error("Error fetching stats:", error);
    } finally {
      setLoading(false);
    }
  }

  const dashboardItems = [
    {
      icon: "🏢",
      title: "Owner Management",
      description: "Create and manage school owners",
      route: "/owner-management",
      color: "bg-purple-50 hover:bg-purple-100 border-purple-200",
      iconColor: "text-purple-700",
    },
    {
      icon: "👤",
      title: "Profile Settings",
      description: "Update your super admin profile",
      route: "/profile",
      color: "bg-green-50 hover:bg-green-100 border-green-200",
      iconColor: "text-green-700",
    },
    {
      icon: "🔐",
      title: "Security Settings",
      description: "Manage security and permissions",
      route: "/settings",
      color: "bg-red-50 hover:bg-red-100 border-red-200",
      iconColor: "text-red-700",
    },
  ];

  const statCards = [
    { label: "Total Users", value: stats.totalUsers, icon: "👥", color: "text-blue-700", bgColor: "bg-blue-50" },
    { label: "Owners", value: stats.totalOwners, icon: "🏢", color: "text-purple-700", bgColor: "bg-purple-50" },
    { label: "Admins", value: stats.totalAdmins, icon: "👔", color: "text-indigo-700", bgColor: "bg-indigo-50" },
    { label: "Teachers", value: stats.totalTeachers, icon: "👨‍🏫", color: "text-orange-700", bgColor: "bg-orange-50" },
    { label: "Parents", value: stats.totalParents, icon: "👨‍👩‍👦", color: "text-yellow-700", bgColor: "bg-yellow-50" },
    { label: "Students", value: stats.totalStudents, icon: "🎓", color: "text-pink-700", bgColor: "bg-pink-50" },
  ];

  const handleLogout = async () => {
    try {
      await logout();
      navigate("/login");
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  return (
    <DashboardShell
      stickyHeader
      icon="👑"
      title="Super Admin Dashboard"
      welcomeName={user?.displayName || user?.email || "Super Admin"}
      subtitle="Role: Super Admin • Highest Access Level"
      badgeLabel="👑 Super Admin"
      badgeColor="bg-red-100 text-red-700"
      actions={[
        {
          label: "🏢 Manage Owners",
          onClick: () => navigate("/owner-management"),
          className: "bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm",
        },
        { label: "🚪 Logout", onClick: handleLogout },
      ]}
      stats={statCards}
      statsLoading={loading}
      statsColumns="grid-cols-2 md:grid-cols-3 lg:grid-cols-7"
      menuItems={dashboardItems}
      menuColumns="sm:grid-cols-2 lg:grid-cols-3"
    >
      {/* Role Hierarchy Info */}
      <div className="bg-white rounded-xl shadow-md p-4 mb-8">
        <h3 className="text-sm font-semibold text-gray-700 mb-3">
          📋 Role Creation Hierarchy
        </h3>
        <div className="flex flex-wrap items-center gap-2">
          <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-xs font-medium">👑 Super Admin</span>
          <span className="text-gray-400">→</span>
          <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-xs font-medium">🏢 Owner</span>
          <span className="text-gray-400">→</span>
          <span className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-xs font-medium">👔 Admin</span>
          <span className="text-gray-400">→</span>
          <span className="text-gray-400">/</span>
          <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-medium">👨‍🏫 Teacher</span>
          <span className="text-gray-400">/</span>
          <span className="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full text-xs font-medium">👨‍👩‍👦 Parent</span>
          <span className="text-gray-400">/</span>
          <span className="px-3 py-1 bg-orange-100 text-orange-700 rounded-full text-xs font-medium">🎓 Student</span>
        </div>
      </div>
    </DashboardShell>
  );
}