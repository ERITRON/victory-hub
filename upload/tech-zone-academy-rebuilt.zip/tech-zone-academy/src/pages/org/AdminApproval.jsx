import { useEffect, useState } from "react";
import { db, collection, getDocs, updateDoc, doc } from "../../supabase/supabase";

export default function AdminApproval() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [filter, setFilter] = useState("pending");

  useEffect(() => {
    loadUsers();
  }, []);

  async function loadUsers() {
    setLoading(true);
    try {
      const snapshot = await getDocs(collection(db, "users"));
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setUsers(data);
    } catch (error) {
      setErrorMessage("Failed to load users: " + error.message);
    } finally {
      setLoading(false);
    }
  }

  const approveUser = async (id, email) => {
    if (!window.confirm(`Approve user ${email}?`)) return;
    
    try {
      await updateDoc(doc(db, "users", id), {
        approved: true,
        status: "active",
      });
      setSuccessMessage(`✅ ${email} has been approved!`);
      setTimeout(() => setSuccessMessage(""), 3000);
      loadUsers();
    } catch (error) {
      setErrorMessage("Failed to approve user: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    }
  };

  const rejectUser = async (id, email) => {
    if (!window.confirm(`Reject user ${email}?`)) return;
    
    try {
      await updateDoc(doc(db, "users", id), {
        approved: false,
        status: "rejected",
      });
      setSuccessMessage(`❌ ${email} has been rejected.`);
      setTimeout(() => setSuccessMessage(""), 3000);
      loadUsers();
    } catch (error) {
      setErrorMessage("Failed to reject user: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    }
  };

  const getFilteredUsers = () => {
    if (filter === "pending") {
      return users.filter((user) => !user.approved && user.status !== "rejected");
    } else if (filter === "approved") {
      return users.filter((user) => user.approved && user.status === "active");
    } else if (filter === "rejected") {
      return users.filter((user) => user.status === "rejected");
    }
    return users;
  };

  const getRoleBadgeColor = (role) => {
    switch (role) {
      case "admin":
        return "bg-purple-100 text-purple-700";
      case "teacher":
        return "bg-blue-100 text-blue-700";
      case "student":
        return "bg-orange-100 text-orange-700";
      case "parent":
        return "bg-green-100 text-green-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  const getStatusBadge = (user) => {
    if (user.approved && user.status === "active") {
      return <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs font-medium">✅ Approved</span>;
    } else if (user.status === "rejected") {
      return <span className="bg-red-100 text-red-700 px-2 py-1 rounded-full text-xs font-medium">❌ Rejected</span>;
    } else {
      return <span className="bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full text-xs font-medium">⏳ Pending</span>;
    }
  };

  const pendingCount = users.filter((u) => !u.approved && u.status !== "rejected").length;
  const approvedCount = users.filter((u) => u.approved && u.status === "active").length;
  const rejectedCount = users.filter((u) => u.status === "rejected").length;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading users...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
                👥 Account Approval
              </h1>
              <p className="text-gray-600 mt-1">
                Manage and approve user accounts
              </p>
            </div>
            <button
              onClick={loadUsers}
              className="bg-blue-700 text-white px-4 py-2 rounded-lg hover:bg-blue-800 transition text-sm flex items-center gap-2"
            >
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
                <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h3.992v3.992m0-3.992-6.3 6.3a2.25 2.25 0 01-3.182 0l-3.7-3.7a2.25 2.25 0 010-3.182l6.3-6.3a2.25 2.25 0 013.182 0l3.7 3.7z" />
              </svg>
              Refresh
            </button>
          </div>
        </div>

        {/* Messages */}
        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Stats Cards */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-yellow-700">{pendingCount}</div>
            <div className="text-sm text-yellow-600">Pending</div>
          </div>
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-green-700">{approvedCount}</div>
            <div className="text-sm text-green-600">Approved</div>
          </div>
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-red-700">{rejectedCount}</div>
            <div className="text-sm text-red-600">Rejected</div>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap gap-2 mb-6">
          {["pending", "approved", "rejected", "all"].map((tab) => (
            <button
              key={tab}
              onClick={() => setFilter(tab)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                filter === tab
                  ? "bg-blue-700 text-white"
                  : "bg-gray-200 text-gray-700 hover:bg-gray-300"
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {/* Users List */}
        {getFilteredUsers().length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-6xl mb-4">📭</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No Users Found</h3>
            <p className="text-gray-500">There are no {filter} users to display.</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {getFilteredUsers().map((user) => (
              <div
                key={user.id}
                className="bg-white rounded-xl shadow-md p-4 sm:p-6 hover:shadow-lg transition"
              >
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  {/* User Info */}
                  <div className="flex-1">
                    <div className="flex items-center gap-3 flex-wrap">
                      <h3 className="text-lg font-bold text-gray-800">
                        {user.name || user.email}
                      </h3>
                      {getStatusBadge(user)}
                    </div>
                    
                    <p className="text-gray-600 text-sm mt-1">
                      {user.email}
                    </p>
                    
                    <div className="flex flex-wrap items-center gap-3 mt-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getRoleBadgeColor(user.role)}`}>
                        {user.role || "No role"}
                      </span>
                      {user.uid && (
                        <span className="text-xs text-gray-400">
                          UID: {user.uid.substring(0, 8)}...
                        </span>
                      )}
                      {user.createdAt && (
                        <span className="text-xs text-gray-400">
                          Created: {new Date(user.createdAt).toLocaleDateString()}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  {!user.approved && user.status !== "rejected" && (
                    <div className="flex gap-2">
                      <button
                        onClick={() => approveUser(user.id, user.email)}
                        className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition font-medium text-sm"
                      >
                        ✅ Approve
                      </button>
                      <button
                        onClick={() => rejectUser(user.id, user.email)}
                        className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition font-medium text-sm"
                      >
                        ❌ Reject
                      </button>
                    </div>
                  )}

                  {user.approved && user.status === "active" && (
                    <div className="flex gap-2">
                      <button
                        onClick={() => rejectUser(user.id, user.email)}
                        className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition font-medium text-sm"
                      >
                        Deactivate
                      </button>
                    </div>
                  )}

                  {user.status === "rejected" && (
                    <div className="flex gap-2">
                      <button
                        onClick={() => approveUser(user.id, user.email)}
                        className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition font-medium text-sm"
                      >
                        Reconsider
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}