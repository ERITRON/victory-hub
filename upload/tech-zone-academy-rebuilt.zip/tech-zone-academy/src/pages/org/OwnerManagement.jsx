// src/pages/OwnerManagement.jsx
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { db, collection, getDocs, query, where } from "../../supabase/supabase";

export default function OwnerManagement() {
  const navigate = useNavigate();
  const { role, createUserWithRole, updateUserStatus, deleteUser } = useAuth();
  const [owners, setOwners] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    firstName: "",
    lastName: "",
    phone: "",
    address: "",
  });
  const [formError, setFormError] = useState("");
  const [formSuccess, setFormSuccess] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const fetchOwners = async () => {
    setLoading(true);
    try {
      const q = query(collection(db, "users"), where("role", "==", "owner"));
      const snap = await getDocs(q);
      const ownersData = snap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setOwners(ownersData);
    } catch (error) {
      console.error("Error fetching owners:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (role === "super_admin") {
       
      fetchOwners();
    }
  }, [role]);

  const handleCreateOwner = async (e) => {
    e.preventDefault();
    setFormError("");
    setSubmitting(true);

    if (formData.password !== formData.confirmPassword) {
      setFormError("Passwords do not match");
      setSubmitting(false);
      return;
    }

    if (formData.password.length < 6) {
      setFormError("Password must be at least 6 characters");
      setSubmitting(false);
      return;
    }

    try {
      const additionalData = {
        firstName: formData.firstName,
        lastName: formData.lastName,
        phone: formData.phone,
        address: formData.address,
        email: formData.email,
        createdByRole: role,
      };

      await createUserWithRole(
        formData.email,
        formData.password,
        "owner",
        additionalData
      );

      setFormSuccess(true);
      setFormData({
        email: "",
        password: "",
        confirmPassword: "",
        firstName: "",
        lastName: "",
        phone: "",
        address: "",
      });
      
      setTimeout(() => {
        setFormSuccess(false);
        setShowCreateModal(false);
        fetchOwners();
      }, 2000);
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleStatusChange = async (ownerId, newStatus) => {
    if (window.confirm(`Change owner status to ${newStatus}?`)) {
      const success = await updateUserStatus(ownerId, newStatus);
      if (success) {
        await fetchOwners();
      }
    }
  };

  const handleDeleteOwner = async (ownerId, ownerEmail) => {
    if (window.confirm(`Are you sure you want to delete ${ownerEmail}? This action cannot be undone.`)) {
      const success = await deleteUser(ownerId);
      if (success) {
        await fetchOwners();
      }
    }
  };

  const filteredOwners = owners.filter((o) => {
    if (!searchTerm) return true;
    const search = searchTerm.toLowerCase();
    return (
      o.email?.toLowerCase().includes(search) ||
      o.firstName?.toLowerCase().includes(search) ||
      o.lastName?.toLowerCase().includes(search) ||
      o.phone?.includes(search)
    );
  });

  const statusColors = {
    active: "bg-green-100 text-green-700",
    inactive: "bg-red-100 text-red-700",
    pending: "bg-yellow-100 text-yellow-700",
    suspended: "bg-orange-100 text-orange-700",
  };

  if (role !== "super_admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">🚫</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h2>
          <p className="text-gray-600">Only Super Admin can access this page.</p>
          <button
            onClick={() => navigate("/super-admin/dashboard")}
            className="mt-4 bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              🏢 Owner Management
            </h1>
            <p className="text-gray-600 mt-1">
              Create and manage school owners
            </p>
            <p className="text-sm text-blue-600 mt-1">
              👑 Super Admin → Can create Owner accounts only
            </p>
          </div>
          <div className="flex items-center gap-3">
            <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-sm font-medium">
              👑 Super Admin
            </span>
            <button
              onClick={() => setShowCreateModal(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition"
            >
              ➕ Add Owner
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="🔍 Search owners by name, email, or phone..."
            className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>

        {/* Owners Table */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Owner</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Email</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Phone</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Status</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Created</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan="6" className="px-4 py-8 text-center text-gray-500">
                      <div className="animate-pulse">Loading owners...</div>
                    </td>
                  </tr>
                ) : filteredOwners.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="px-4 py-8 text-center text-gray-500">
                      No owners found. Click "Add Owner" to create one.
                    </td>
                  </tr>
                ) : (
                  filteredOwners.map((owner) => (
                    <tr key={owner.id} className="border-b hover:bg-gray-50 transition">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-700 font-bold">
                            {owner.firstName?.[0] || owner.email?.[0] || "O"}
                          </div>
                          <div>
                            <p className="font-medium text-gray-800">
                              {owner.firstName || ""} {owner.lastName || ""}
                            </p>
                            <p className="text-xs text-gray-500">
                              ID: {owner.id.slice(0, 8)}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">{owner.email}</td>
                      <td className="px-4 py-3 text-sm text-gray-600">{owner.phone || "—"}</td>
                      <td className="px-4 py-3 text-center">
                        <select
                          value={owner.status || "active"}
                          onChange={(e) => handleStatusChange(owner.id, e.target.value)}
                          className={`px-2 py-1 rounded-full text-xs font-medium border-0 focus:ring-2 focus:ring-blue-500 ${
                            statusColors[owner.status] || statusColors.active
                          }`}
                        >
                          <option value="active">✅ Active</option>
                          <option value="inactive">❌ Inactive</option>
                          <option value="suspended">⛔ Suspended</option>
                          <option value="pending">⏳ Pending</option>
                        </select>
                      </td>
                      <td className="px-4 py-3 text-center text-sm text-gray-500">
                        {owner.createdAt ? new Date(owner.createdAt).toLocaleDateString() : "—"}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => handleDeleteOwner(owner.id, owner.email)}
                            className="text-red-600 hover:text-red-800 text-sm"
                            title="Delete Owner"
                          >
                            🗑️
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          <div className="px-4 py-3 border-t flex items-center justify-between">
            <p className="text-sm text-gray-500">
              Showing {filteredOwners.length} owner{filteredOwners.length !== 1 ? "s" : ""}
            </p>
          </div>
        </div>
      </div>

      {/* Create Owner Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-gray-800">
                  🏢 Create New Owner
                </h3>
                <button
                  onClick={() => {
                    setShowCreateModal(false);
                    setFormError("");
                    setFormSuccess(false);
                  }}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ✕
                </button>
              </div>

              <div className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                <p className="text-sm text-blue-700">
                  👑 Super Admin → Creating Owner account
                </p>
                <p className="text-xs text-blue-600 mt-1">
                  Owners can create Admin accounts
                </p>
              </div>

              {formSuccess ? (
                <div className="text-center py-8">
                  <div className="text-6xl mb-4">✅</div>
                  <h4 className="text-xl font-bold text-green-600">Owner Created!</h4>
                  <p className="text-gray-500">The owner account has been created successfully.</p>
                </div>
              ) : (
                <form onSubmit={handleCreateOwner} className="space-y-4">
                  {formError && (
                    <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg text-sm">
                      {formError}
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="owner@school.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Password *
                    </label>
                    <input
                      type="password"
                      value={formData.password}
                      onChange={(e) =>
                        setFormData({ ...formData, password: e.target.value })
                      }
                      required
                      minLength="6"
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Min 6 characters"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Confirm Password *
                    </label>
                    <input
                      type="password"
                      value={formData.confirmPassword}
                      onChange={(e) =>
                        setFormData({ ...formData, confirmPassword: e.target.value })
                      }
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Confirm password"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        First Name
                      </label>
                      <input
                        type="text"
                        value={formData.firstName}
                        onChange={(e) =>
                          setFormData({ ...formData, firstName: e.target.value })
                        }
                        className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                        placeholder="First name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Last Name
                      </label>
                      <input
                        type="text"
                        value={formData.lastName}
                        onChange={(e) =>
                          setFormData({ ...formData, lastName: e.target.value })
                        }
                        className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                        placeholder="Last name"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData({ ...formData, phone: e.target.value })
                      }
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="+251 9XX XXX XXX"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Address
                    </label>
                    <input
                      type="text"
                      value={formData.address}
                      onChange={(e) =>
                        setFormData({ ...formData, address: e.target.value })
                      }
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Address"
                    />
                  </div>

                  <div className="flex gap-3 pt-4">
                    <button
                      type="button"
                      onClick={() => {
                        setShowCreateModal(false);
                        setFormError("");
                      }}
                      className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg hover:bg-gray-300 transition"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={submitting}
                      className="flex-1 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-400"
                    >
                      {submitting ? "Creating..." : "✅ Create Owner"}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}