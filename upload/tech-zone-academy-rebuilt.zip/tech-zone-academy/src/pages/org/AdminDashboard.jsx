// src/pages/AdminDashboard.jsx
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { useEffect, useState } from "react";
import DashboardShell from "../../components/dashboard/DashboardShell";
import { getSchoolWideStats, getUserCountByRole } from "../../services/statsService";

export default function AdminDashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [stats, setStats] = useState({
    students: 0,
    teachers: 0,
    totalParents: 0,
    pendingApprovals: 0,
  });
  const [loading, setLoading] = useState(true);

  async function fetchStats() {
    setLoading(true);
    try {
      const [schoolStats, totalParents] = await Promise.all([
        getSchoolWideStats(),
        // Actual parent count: users collection where role === "parent"
        getUserCountByRole("parent"),
      ]);
      setStats({ ...schoolStats, totalParents });
    } catch (error) {
      console.error("Error fetching stats:", error);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchStats();
  }, []);

  const dashboardItems = [
    // Profile & Settings
    {
      icon: "👑",
      title: "My Profile",
      description: "View your principal profile",
      route: "/admin-profile",
      color: "bg-purple-50 hover:bg-purple-100 border-purple-200",
      iconColor: "text-purple-700",
    },
    {
      icon: "🌐",
      title: "Website Settings",
      description: "Customize your school website without coding",
      route: "/website-settings",
      color: "bg-purple-50 hover:bg-purple-100 border-purple-200",
      iconColor: "text-purple-700",
    },
    
    // Management
    {
      icon: "📚",
      title: "Student Management",
      description: "Add, edit, and manage student records",
      route: "/student-management",
      color: "bg-blue-50 hover:bg-blue-100 border-blue-200",
      iconColor: "text-blue-700",
    },
    {
      icon: "👨‍🏫",
      title: "Teacher Management",
      description: "Manage teacher accounts and assignments",
      route: "/teacher-management",
      color: "bg-green-50 hover:bg-green-100 border-green-200",
      iconColor: "text-green-700",
    },
    {
      icon: "👨‍👩‍👦",
      title: "Parent Management",
      description: "Manage parent accounts and approvals",
      route: "/parent-management",
      color: "bg-purple-50 hover:bg-purple-100 border-purple-200",
      iconColor: "text-purple-700",
    },
    {
      icon: "👔",
      title: "Vice Principal Management",
      description: "Add and manage vice principals",
      route: "/vice-principal-management",
      color: "bg-purple-50 hover:bg-purple-100 border-purple-200",
      iconColor: "text-purple-700",
    },
    {
      icon: "📚",
      title: "Librarian Management",
      description: "Add and manage librarian accounts",
      route: "/librarian-management",
      color: "bg-indigo-50 hover:bg-indigo-100 border-indigo-200",
      iconColor: "text-indigo-700",
    },
    
    // Academic
    {
      icon: "📊",
      title: "Academic Overview",
      description: "View school-wide academic performance",
      route: "/academic-overview",
      color: "bg-indigo-50 hover:bg-indigo-100 border-indigo-200",
      iconColor: "text-indigo-700",
    },
    {
      icon: "📝",
      title: "Teacher Performance",
      description: "Monitor and evaluate teacher performance",
      route: "/teacher-performance",
      color: "bg-orange-50 hover:bg-orange-100 border-orange-200",
      iconColor: "text-orange-700",
    },
    {
      icon: "📋",
      title: "Student Discipline",
      description: "Track student behavior and discipline",
      route: "/discipline",
      color: "bg-red-50 hover:bg-red-100 border-red-200",
      iconColor: "text-red-700",
    },
    {
      icon: "👨‍🏫",
      title: "Teacher Attendance",
      description: "Monitor teacher attendance",
      route: "/teacher-attendance",
      color: "bg-orange-50 hover:bg-orange-100 border-orange-200",
      iconColor: "text-orange-700",
    },
    
    // CMS
    {
      icon: "📰",
      title: "News Management",
      description: "Create and manage news posts",
      route: "/admin/news",
      color: "bg-blue-50 hover:bg-blue-100 border-blue-200",
      iconColor: "text-blue-700",
    },
    {
      icon: "📄",
      title: "Student Documents",
      description: "Upload report cards and certificates",
      route: "/admin/documents",
      color: "bg-indigo-50 hover:bg-indigo-100 border-indigo-200",
      iconColor: "text-indigo-700",
    },
    {
      icon: "💬",
      title: "Messages",
      description: "View and moderate parent-teacher chats",
      route: "/chat",
      color: "bg-teal-50 hover:bg-teal-100 border-teal-200",
      iconColor: "text-teal-700",
    },
    {
      icon: "📅",
      title: "Academic Calendar",
      description: "Manage semesters, years, and promotion",
      route: "/admin/academic-calendar",
      color: "bg-amber-50 hover:bg-amber-100 border-amber-200",
      iconColor: "text-amber-700",
    },
    {
      icon: "🖼️",
      title: "Gallery Management",
      description: "Upload and manage images and albums",
      route: "/admin/gallery",
      color: "bg-purple-50 hover:bg-purple-100 border-purple-200",
      iconColor: "text-purple-700",
    },
    {
      icon: "📅",
      title: "Events Management",
      description: "Create and manage school events",
      route: "/admin/events",
      color: "bg-green-50 hover:bg-green-100 border-green-200",
      iconColor: "text-green-700",
    },
    {
      icon: "📝",
      title: "Admissions Management",
      description: "Manage admissions page content",
      route: "/admin/admissions",
      color: "bg-teal-50 hover:bg-teal-100 border-teal-200",
      iconColor: "text-teal-700",
    },
    
    // Attendance & Results
    {
      icon: "📊",
      title: "Attendance Reports",
      description: "View and manage attendance records",
      route: "/attendance-report",
      color: "bg-red-50 hover:bg-red-100 border-red-200",
      iconColor: "text-red-700",
    },
    {
      icon: "📝",
      title: "Results Management",
      description: "Manage student results and report cards",
      route: "/results-management",
      color: "bg-indigo-50 hover:bg-indigo-100 border-indigo-200",
      iconColor: "text-indigo-700",
    },
    
    // Approvals & Promotion
    {
      icon: "👥",
      title: "Account Approval",
      description: "Approve new user accounts",
      route: "/admin-approval",
      color: "bg-yellow-50 hover:bg-yellow-100 border-yellow-200",
      iconColor: "text-yellow-700",
    },
    {
      icon: "📈",
      title: "Promotion",
      description: "Promote students to next grade",
      route: "/promotion",
      color: "bg-teal-50 hover:bg-teal-100 border-teal-200",
      iconColor: "text-teal-700",
    },
    
    // Schedule & Settings
    {
      icon: "📅",
      title: "Schedule Management",
      description: "Create and manage class schedules",
      route: "/admin-schedule",
      color: "bg-indigo-50 hover:bg-indigo-100 border-indigo-200",
      iconColor: "text-indigo-700",
    },
    {
      icon: "⚙️",
      title: "School Settings",
      description: "Manage grades, sections, and subjects",
      route: "/settings",
      color: "bg-gray-50 hover:bg-gray-100 border-gray-200",
      iconColor: "text-gray-700",
    },
    
    // Security
    {
      icon: "🔐",
      title: "Security Settings",
      description: "Update your password and security",
      route: "/profile",
      color: "bg-blue-50 hover:bg-blue-100 border-blue-200",
      iconColor: "text-blue-700",
    },
  ];

  const statCards = [
    { 
      label: "Total Students", 
      value: stats.students, 
      color: "text-blue-700",
      icon: "👨‍🎓",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200",
    },
    { 
      label: "Total Teachers", 
      value: stats.teachers, 
      color: "text-green-700",
      icon: "👨‍🏫",
      bgColor: "bg-green-50",
      borderColor: "border-green-200",
    },
    {
      label: "Total Parents",
      value: stats.totalParents,
      color: "text-purple-700",
      icon: "👨‍👩‍👦",
      bgColor: "bg-purple-50",
      borderColor: "border-purple-200",
    },
    { 
      label: "Pending Approvals", 
      value: stats.pendingApprovals, 
      color: "text-yellow-700",
      icon: "⏳",
      bgColor: "bg-yellow-50",
      borderColor: "border-yellow-200",
    },
  ];

  return (
    <DashboardShell
      icon="👔"
      title="Principal Dashboard"
      welcomeName={user?.email || "Principal"}
      subtitle="Manage your school from one central location"
      badgeLabel="Principal"
      badgeColor="bg-blue-100 text-blue-700"
      onSettingsClick={() => navigate("/settings")}
      stats={statCards}
      statsLoading={loading}
      statsColumns="grid-cols-2 md:grid-cols-4"
      menuItems={dashboardItems}
      footerText="Tech Zone Academy - Principal Dashboard v2.0"
    />
  );
}
