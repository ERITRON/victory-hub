// src/pages/OwnerDashboard.jsx
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { db, collection, getDocs, query, where } from "../../supabase/supabase";

export default function OwnerDashboard() {
  const navigate = useNavigate();
  const { user, role, logout, createUserWithRole, updateUserStatus, deleteUser } = useAuth();

  const [loading, setLoading] = useState(true);

  // Admin Management State
  const [admins, setAdmins] = useState([]);
  const [showCreateAdminModal, setShowCreateAdminModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    firstName: "",
    lastName: "",
    phone: "",
    address: "",
  });
  const [formError, setFormError] = useState("");
  const [formSuccess, setFormSuccess] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // ============================================
  // FETCH DATA
  // ============================================

  const fetchAdmins = async () => {
    try {
      const q = query(collection(db, "users"), where("role", "==", "admin"));
      const snap = await getDocs(q);
      const adminsData = snap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setAdmins(adminsData);
    } catch (error) {
      console.error("Error fetching admins:", error);
    }
  };

  const loadAllData = async () => {
    setLoading(true);
    try {
      await fetchAdmins();
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (role === "owner" || role === "admin") {
      loadAllData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- loadAllData recreated each render; depend on role only to avoid refetch loop
  }, [role]);


  // ============================================
  // ADMIN MANAGEMENT FUNCTIONS
  // ============================================

  const handleCreateAdmin = async (e) => {
    e.preventDefault();
    setFormError("");
    setSubmitting(true);

    if (formData.password !== formData.confirmPassword) {
      setFormError("Passwords do not match");
      setSubmitting(false);
      return;
    }

    if (formData.password.length < 6) {
      setFormError("Password must be at least 6 characters");
      setSubmitting(false);
      return;
    }

    try {
      const additionalData = {
        firstName: formData.firstName,
        lastName: formData.lastName,
        phone: formData.phone,
        address: formData.address,
        email: formData.email,
        createdByRole: role,
        createdBy: user?.uid,
      };

      await createUserWithRole(
        formData.email,
        formData.password,
        "admin",
        additionalData
      );

      setFormSuccess(true);
      setFormData({
        email: "",
        password: "",
        confirmPassword: "",
        firstName: "",
        lastName: "",
        phone: "",
        address: "",
      });
      
      setTimeout(() => {
        setFormSuccess(false);
        setShowCreateAdminModal(false);
        fetchAdmins();
      }, 2000);
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleAdminStatusChange = async (adminId, newStatus) => {
    if (window.confirm(`Change admin status to ${newStatus}?`)) {
      const success = await updateUserStatus(adminId, newStatus);
      if (success) {
        await fetchAdmins();
      }
    }
  };

  const handleDeleteAdmin = async (adminId, adminEmail) => {
    if (window.confirm(`Are you sure you want to delete ${adminEmail}? This action cannot be undone.`)) {
      const success = await deleteUser(adminId);
      if (success) {
        await fetchAdmins();
      }
    }
  };

  const filteredAdmins = admins.filter((admin) => {
    if (!searchTerm) return true;
    const search = searchTerm.toLowerCase();
    return (
      admin.email?.toLowerCase().includes(search) ||
      admin.firstName?.toLowerCase().includes(search) ||
      admin.lastName?.toLowerCase().includes(search) ||
      admin.phone?.includes(search)
    );
  });

  const statusColors = {
    active: "bg-green-100 text-green-700",
    inactive: "bg-red-100 text-red-700",
    pending: "bg-yellow-100 text-yellow-700",
    suspended: "bg-orange-100 text-orange-700",
  };

  const handleLogout = async () => {
    try {
      await logout();
      navigate("/login");
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  // ============================================
  // ACCESS CHECK
  // ============================================

  if (role !== "admin" && role !== "owner") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">🚫</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h2>
          <p className="text-gray-600">You need owner/admin privileges to access this page.</p>
        </div>
      </div>
    );
  }

  // ============================================
  // RENDER
  // ============================================

  const isLoading = loading;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-800">
                {role === "owner" ? "🏢 Owner Dashboard" : "📊 Admin Dashboard"}
              </h1>
              <p className="text-sm text-gray-500">
                {role === "owner" ? "👑 Owner View" : "👔 Admin View"} • 
                Welcome back, {user?.displayName || user?.email || "Admin"}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={loadAllData}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm"
              >
                🔄 Refresh
              </button>
              {role === "owner" && (
                <button
                  onClick={() => setShowCreateAdminModal(true)}
                  className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition text-sm"
                >
                  ➕ Add Admin
                </button>
              )}
              <button
                onClick={handleLogout}
                className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition text-sm"
              >
                🚪 Logout
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Quick stat */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-xl shadow-md p-4">
            <p className="text-sm text-gray-500">Total Admins</p>
            <p className="text-2xl font-bold text-gray-800">{isLoading ? "…" : admins.length}</p>
          </div>
        </div>

        {/* ============================================
            ADMIN MANAGEMENT SECTION (Owner Only)
            ============================================ */}
        {role === "owner" && (
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="px-6 py-4 border-b bg-gray-50 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-gray-800">👥 Admin Management</h2>
                <p className="text-sm text-gray-500">
                  Create and manage admin accounts for your school
                </p>
              </div>
              <button
                onClick={() => setShowCreateAdminModal(true)}
                className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition text-sm whitespace-nowrap"
              >
                ➕ Add Admin
              </button>
            </div>

            {/* Search */}
            <div className="p-4 border-b">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="🔍 Search admins by name, email, or phone..."
                className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            {/* Admins Table */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Admin</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Email</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Phone</th>
                    <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Status</th>
                    <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Created</th>
                    <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {isLoading ? (
                    <tr>
                      <td colSpan="6" className="px-4 py-8 text-center text-gray-500">
                        <div className="animate-pulse">Loading admins...</div>
                      </td>
                    </tr>
                  ) : filteredAdmins.length === 0 ? (
                    <tr>
                      <td colSpan="6" className="px-4 py-8 text-center text-gray-500">
                        No admins found. Click "Add Admin" to create one.
                      </td>
                    </tr>
                  ) : (
                    filteredAdmins.map((admin) => (
                      <tr key={admin.id} className="border-b hover:bg-gray-50 transition">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold">
                              {admin.firstName?.[0] || admin.email?.[0] || "A"}
                            </div>
                            <div>
                              <p className="font-medium text-gray-800">
                                {admin.firstName || ""} {admin.lastName || ""}
                              </p>
                              <p className="text-xs text-gray-500">
                                ID: {admin.id.slice(0, 8)}
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-600">{admin.email}</td>
                        <td className="px-4 py-3 text-sm text-gray-600">{admin.phone || "—"}</td>
                        <td className="px-4 py-3 text-center">
                          <select
                            value={admin.status || "active"}
                            onChange={(e) => handleAdminStatusChange(admin.id, e.target.value)}
                            className={`px-2 py-1 rounded-full text-xs font-medium border-0 focus:ring-2 focus:ring-blue-500 ${
                              statusColors[admin.status] || statusColors.active
                            }`}
                          >
                            <option value="active">✅ Active</option>
                            <option value="inactive">❌ Inactive</option>
                            <option value="suspended">⛔ Suspended</option>
                            <option value="pending">⏳ Pending</option>
                          </select>
                        </td>
                        <td className="px-4 py-3 text-center text-sm text-gray-500">
                          {admin.createdAt ? new Date(admin.createdAt).toLocaleDateString() : "—"}
                        </td>
                        <td className="px-4 py-3 text-center">
                          <div className="flex items-center justify-center gap-2">
                            <button
                              onClick={() => handleDeleteAdmin(admin.id, admin.email)}
                              className="text-red-600 hover:text-red-800 text-sm"
                              title="Delete Admin"
                            >
                              🗑️
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            <div className="px-4 py-3 border-t flex items-center justify-between">
              <p className="text-sm text-gray-500">
                Showing {filteredAdmins.length} admin{filteredAdmins.length !== 1 ? "s" : ""}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* ============================================
          CREATE ADMIN MODAL (Owner Only)
          ============================================ */}
      {role === "owner" && showCreateAdminModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-gray-800">
                  👔 Create New Admin
                </h3>
                <button
                  onClick={() => {
                    setShowCreateAdminModal(false);
                    setFormError("");
                    setFormSuccess(false);
                  }}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ✕
                </button>
              </div>

              <div className="mb-4 p-3 bg-purple-50 rounded-lg border border-purple-200">
                <p className="text-sm text-purple-700">
                  🏢 Owner → Creating Admin account
                </p>
                <p className="text-xs text-purple-600 mt-1">
                  Admins can create Teacher, Parent, and Student accounts
                </p>
              </div>

              {formSuccess ? (
                <div className="text-center py-8">
                  <div className="text-6xl mb-4">✅</div>
                  <h4 className="text-xl font-bold text-green-600">Admin Created!</h4>
                  <p className="text-gray-500">The admin account has been created successfully.</p>
                </div>
              ) : (
                <form onSubmit={handleCreateAdmin} className="space-y-4">
                  {formError && (
                    <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg text-sm">
                      {formError}
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="admin@school.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Password *
                    </label>
                    <input
                      type="password"
                      value={formData.password}
                      onChange={(e) =>
                        setFormData({ ...formData, password: e.target.value })
                      }
                      required
                      minLength="6"
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Min 6 characters"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Confirm Password *
                    </label>
                    <input
                      type="password"
                      value={formData.confirmPassword}
                      onChange={(e) =>
                        setFormData({ ...formData, confirmPassword: e.target.value })
                      }
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Confirm password"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        First Name
                      </label>
                      <input
                        type="text"
                        value={formData.firstName}
                        onChange={(e) =>
                          setFormData({ ...formData, firstName: e.target.value })
                        }
                        className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                        placeholder="First name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Last Name
                      </label>
                      <input
                        type="text"
                        value={formData.lastName}
                        onChange={(e) =>
                          setFormData({ ...formData, lastName: e.target.value })
                        }
                        className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                        placeholder="Last name"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData({ ...formData, phone: e.target.value })
                      }
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="+251 9XX XXX XXX"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Address
                    </label>
                    <input
                      type="text"
                      value={formData.address}
                      onChange={(e) =>
                        setFormData({ ...formData, address: e.target.value })
                      }
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Address"
                    />
                  </div>

                  <div className="flex gap-3 pt-4">
                    <button
                      type="button"
                      onClick={() => {
                        setShowCreateAdminModal(false);
                        setFormError("");
                      }}
                      className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg hover:bg-gray-300 transition"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={submitting}
                      className="flex-1 bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 transition disabled:bg-gray-400"
                    >
                      {submitting ? "Creating..." : "✅ Create Admin"}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}