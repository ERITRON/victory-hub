// src/pages/vice-principal/TodaysSchedule.jsx
import { useEffect, useState } from "react";
import { db, collection, getDocs, query, where } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";

export default function TodaysSchedule() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [selectedDay, setSelectedDay] = useState(
    new Date().toLocaleDateString("en-US", { weekday: "long" })
  );
  const [selectedGrade, setSelectedGrade] = useState("");
  const [selectedSection, setSelectedSection] = useState("");
  const [grades, setGrades] = useState([]);
  const [sections, setSections] = useState([]);
  const [, setSchedule] = useState([]);
  const [allSchedules, setAllSchedules] = useState([]);
  const [filteredSchedules, setFilteredSchedules] = useState([]);

  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

  const applyFilters = (data) => {
    let filtered = data || allSchedules;
    if (selectedGrade) {
      filtered = filtered.filter((s) => s.grade === selectedGrade);
    }
    if (selectedSection) {
      filtered = filtered.filter((s) => s.section === selectedSection);
    }
    setFilteredSchedules(filtered);
    setSchedule(filtered);
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      // ✅ Fetch grades from your real data
      const gradesSnap = await getDocs(collection(db, "grades"));
      const gradesData = gradesSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setGrades(gradesData.sort((a, b) => a.name.localeCompare(b.name)));

      // ✅ Fetch sections from your real data
      const sectionsSnap = await getDocs(collection(db, "sections"));
      const sectionsData = sectionsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSections(sectionsData.sort((a, b) => a.name.localeCompare(b.name)));

      // ✅ Fetch schedule for selected day from your real data.
      // Sorted client-side: where + orderBy would need a composite index.
      const scheduleSnap = await getDocs(
        query(collection(db, "schedules"), where("day", "==", selectedDay))
      );
      const scheduleData = scheduleSnap.docs
        .map((doc) => ({ id: doc.id, ...doc.data() }))
        .sort((a, b) => (a.startTime || "").localeCompare(b.startTime || ""));
      setAllSchedules(scheduleData);

      // Set initial filters if available
      if (gradesData.length > 0 && !selectedGrade) {
        setSelectedGrade(gradesData[0].name);
      }
      if (sectionsData.length > 0 && !selectedSection) {
        setSelectedSection(sectionsData[0].name);
      }

      // Apply filters
      applyFilters(scheduleData);
    } catch (error) {
      console.error("Error fetching schedule:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedDay]);

  // Re-apply filters when selection changes
  useEffect(() => {
    if (allSchedules.length > 0) {
      applyFilters(allSchedules);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedGrade, selectedSection]);

  const getClassList = () => {
    const classMap = {};
    allSchedules.forEach((s) => {
      const key = `${s.grade}-${s.section}`;
      if (!classMap[key]) {
        classMap[key] = { grade: s.grade, section: s.section };
      }
    });
    return Object.values(classMap);
  };

  const getTimetableMatrix = () => {
    const matrix = {};
    const classList = getClassList();
    
    classList.forEach((cls) => {
      const key = `${cls.grade}-${cls.section}`;
      matrix[key] = allSchedules.filter(
        (s) => s.grade === cls.grade && s.section === cls.section
      );
    });
    
    return matrix;
  };

  const getPeriodTypeColor = (type) => {
    switch (type) {
      case "break": return "bg-green-50";
      case "lunch": return "bg-yellow-50";
      default: return "";
    }
  };

  const getPeriodTypeLabel = (type) => {
    switch (type) {
      case "break": return "🟢 Break";
      case "lunch": return "🍽️ Lunch";
      default: return "";
    }
  };

  // Get unique times
  const times = [...new Set(allSchedules.map(s => s.startTime))].sort();

  // Get unique subjects
  const uniqueSubjects = [...new Set(allSchedules.map(s => s.subject))].filter(Boolean);
  
  // Get unique teachers
  const uniqueTeachers = [...new Set(allSchedules.map(s => s.teacherName))].filter(Boolean);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading schedule...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <button onClick={() => navigate("/vice-principal/dashboard")} className="text-gray-600 hover:text-gray-800 transition">
            ← Back
          </button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              📅 Today's Schedule
            </h1>
            <p className="text-gray-600 mt-1">
              View all class schedules for the selected day
            </p>
          </div>
          <div className="ml-auto flex items-center gap-3">
            <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-medium">
              👔 Vice Principal
            </span>
          </div>
        </div>

        {/* Day Selector */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <div className="flex flex-wrap gap-2">
            {days.map((day) => (
              <button
                key={day}
                onClick={() => {
                  setSelectedDay(day);
                  if (grades.length > 0) setSelectedGrade(grades[0].name);
                  if (sections.length > 0) setSelectedSection(sections[0].name);
                }}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                  selectedDay === day
                    ? "bg-blue-700 text-white"
                    : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                }`}
              >
                {day}
              </button>
            ))}
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-blue-500">
            <div className="text-2xl font-bold text-blue-700">{allSchedules.length}</div>
            <div className="text-xs text-gray-600">Total Periods</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-green-500">
            <div className="text-2xl font-bold text-green-700">{getClassList().length}</div>
            <div className="text-xs text-gray-600">Classes</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-purple-500">
            <div className="text-2xl font-bold text-purple-700">{uniqueSubjects.length}</div>
            <div className="text-xs text-gray-600">Subjects</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-orange-500">
            <div className="text-2xl font-bold text-orange-700">{uniqueTeachers.length}</div>
            <div className="text-xs text-gray-600">Teachers</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-indigo-500">
            <div className="text-2xl font-bold text-indigo-700">
              {getClassList().filter(cls => {
                return allSchedules.some(s => s.grade === cls.grade && s.section === cls.section);
              }).length}
            </div>
            <div className="text-xs text-gray-600">Active Classes</div>
          </div>
        </div>

        {/* Filter Section */}
        {allSchedules.length > 0 && (
          <div className="bg-white rounded-xl shadow-md p-4 mb-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Filter by Grade</label>
                <select
                  value={selectedGrade}
                  onChange={(e) => setSelectedGrade(e.target.value)}
                  className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                >
                  <option value="">All Grades</option>
                  {grades.map((grade) => (
                    <option key={grade.id} value={grade.name}>
                      {grade.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Filter by Section</label>
                <select
                  value={selectedSection}
                  onChange={(e) => setSelectedSection(e.target.value)}
                  className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                >
                  <option value="">All Sections</option>
                  {sections.map((section) => (
                    <option key={section.id} value={section.name}>
                      {section.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex items-end">
                <button
                  onClick={() => {
                    setSelectedGrade("");
                    setSelectedSection("");
                  }}
                  className="w-full bg-gray-200 text-gray-700 px-4 py-2.5 rounded-lg hover:bg-gray-300 transition font-medium"
                >
                  Clear Filters
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Filtered Schedule Table */}
        {filteredSchedules.length > 0 && (
          <div className="bg-white rounded-xl shadow-md overflow-hidden mb-6">
            <div className="px-6 py-4 border-b bg-gray-50 flex justify-between items-center">
              <h3 className="text-lg font-bold text-gray-800">
                📋 Schedule for {selectedDay}
                {selectedGrade && <span className="ml-2 text-sm font-normal text-gray-500">• {selectedGrade}</span>}
                {selectedSection && <span className="text-sm font-normal text-gray-500">• Section {selectedSection}</span>}
              </h3>
              <span className="text-sm text-gray-500">
                {filteredSchedules.length} periods
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Time</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Grade</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Section</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Subject</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Teacher</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Room</th>
                    <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Type</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredSchedules.map((period, index) => {
                    const isBreak = period.periodType === "break";
                    const isLunch = period.periodType === "lunch";
                    
                    return (
                      <tr key={period.id || index} className={`border-b hover:bg-gray-50 transition ${getPeriodTypeColor(period.periodType)}`}>
                        <td className="px-4 py-3 text-sm text-gray-600 font-medium">
                          {period.startTime} - {period.endTime}
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-700 font-medium">
                          {period.grade || "N/A"}
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-600">
                          {period.section || "N/A"}
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-800 font-medium">
                          {isBreak || isLunch ? (
                            getPeriodTypeLabel(period.periodType)
                          ) : (
                            period.subject || "N/A"
                          )}
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-600">
                          {isBreak || isLunch ? (
                            "—"
                          ) : (
                            period.teacherName || "Not Assigned"
                          )}
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-500">
                          {isBreak || isLunch ? "—" : period.room || "N/A"}
                        </td>
                        <td className="px-4 py-3 text-center">
                          {isBreak ? (
                            <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700">🟢 Break</span>
                          ) : isLunch ? (
                            <span className="px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-700">🍽️ Lunch</span>
                          ) : (
                            <span className="px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-700">📚 Class</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <div className="px-4 py-3 border-t bg-gray-50 flex justify-between items-center">
              <p className="text-sm text-gray-500">
                Showing {filteredSchedules.length} of {allSchedules.length} periods
              </p>
              <div className="flex flex-wrap gap-2 text-sm">
                <span className="px-2 py-1 rounded bg-blue-100 text-blue-700">📚 Class</span>
                <span className="px-2 py-1 rounded bg-green-100 text-green-700">🟢 Break</span>
                <span className="px-2 py-1 rounded bg-yellow-100 text-yellow-700">🍽️ Lunch</span>
              </div>
            </div>
          </div>
        )}

        {/* Full Timetable Matrix */}
        {allSchedules.length > 0 && (
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="px-6 py-4 border-b bg-gray-50">
              <h3 className="text-lg font-bold text-gray-800">
                📋 Full Timetable - {selectedDay}
              </h3>
              <p className="text-xs text-gray-500">All classes and periods</p>
            </div>
            <div className="overflow-x-auto p-4">
              {getClassList().length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No schedule found for {selectedDay}
                </div>
              ) : (
                <table className="w-full border-collapse text-sm">
                  <thead>
                    <tr className="bg-blue-700 text-white">
                      <th className="p-3 text-left border border-blue-800 min-w-[100px]">Time</th>
                      {getClassList().map((cls) => (
                        <th key={`${cls.grade}-${cls.section}`} className="p-3 text-center border border-blue-800 min-w-[120px]">
                          {cls.grade}
                          <br />
                          <span className="text-xs font-normal">Sec {cls.section}</span>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {times.length === 0 ? (
                      <tr>
                        <td colSpan={getClassList().length + 1} className="p-4 text-center text-gray-500">
                          No schedule entries found.
                        </td>
                      </tr>
                    ) : (
                      times.map((time) => {
                        const endTime = allSchedules.find(s => s.startTime === time)?.endTime || "";
                        const matrix = getTimetableMatrix();
                        
                        return (
                          <tr key={time} className="hover:bg-gray-50">
                            <td className="p-3 border border-gray-200 font-medium whitespace-nowrap bg-gray-50">
                              {time} - {endTime}
                            </td>
                            {getClassList().map((cls) => {
                              const key = `${cls.grade}-${cls.section}`;
                              const period = matrix[key]?.find(s => s.startTime === time);
                              
                              if (!period) {
                                return <td key={key} className="p-3 border border-gray-200 text-center text-gray-300">—</td>;
                              }
                              
                              const isBreak = period.periodType === "break";
                              const isLunch = period.periodType === "lunch";
                              
                              return (
                                <td key={key} className={`p-3 border border-gray-200 text-center ${getPeriodTypeColor(period.periodType)}`}>
                                  {isBreak ? (
                                    <span className="font-medium text-green-600 text-xs">🟢 Break</span>
                                  ) : isLunch ? (
                                    <span className="font-medium text-yellow-600 text-xs">🍽️ Lunch</span>
                                  ) : (
                                    <>
                                      <div className="font-semibold text-gray-800 text-sm">{period.subject}</div>
                                      <div className="text-xs text-gray-500 truncate">{period.teacherName}</div>
                                      {period.room && <div className="text-xs text-gray-400">{period.room}</div>}
                                    </>
                                  )}
                                </td>
                              );
                            })}
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              )}
            </div>
            <div className="p-4 border-t border-gray-200 flex flex-wrap gap-4 text-sm">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded bg-blue-100 text-blue-700">📚 Class</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded bg-green-100 text-green-700">🟢 Break</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded bg-yellow-100 text-yellow-700">🍽️ Lunch</span>
              </div>
            </div>
          </div>
        )}

        {allSchedules.length === 0 && (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-6xl mb-4">📭</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No Schedule Found</h3>
            <p className="text-gray-500">
              No classes are scheduled for {selectedDay}. Please create schedules in the Schedule Management page.
            </p>
          </div>
        )}

        {/* Quick Actions */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6">
          <button
            onClick={() => navigate("/vice-principal/dashboard")}
            className="bg-gray-600 text-white p-4 rounded-xl hover:bg-gray-700 transition text-center"
          >
            <div className="text-2xl mb-1">👔</div>
            <div className="text-sm font-medium">Dashboard</div>
          </button>
          <button
            onClick={() => navigate("/vice-principal/operations")}
            className="bg-blue-600 text-white p-4 rounded-xl hover:bg-blue-700 transition text-center"
          >
            <div className="text-2xl mb-1">📋</div>
            <div className="text-sm font-medium">Daily Operations</div>
          </button>
          <button
            onClick={() => navigate("/vice-principal/classroom-monitoring")}
            className="bg-green-600 text-white p-4 rounded-xl hover:bg-green-700 transition text-center"
          >
            <div className="text-2xl mb-1">🏫</div>
            <div className="text-sm font-medium">Classrooms</div>
          </button>
          <button
            onClick={() => navigate("/discipline")}
            className="bg-red-600 text-white p-4 rounded-xl hover:bg-red-700 transition text-center"
          >
            <div className="text-2xl mb-1">📋</div>
            <div className="text-sm font-medium">Discipline</div>
          </button>
        </div>
      </div>
    </div>
  );
}