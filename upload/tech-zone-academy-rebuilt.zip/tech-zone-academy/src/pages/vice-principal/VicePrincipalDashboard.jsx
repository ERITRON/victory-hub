// src/pages/VicePrincipalDashboard.jsx
import { useEffect, useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { db, collection, getDocs, query, where, orderBy, doc, getDoc } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";
import DashboardShell from "../../components/dashboard/DashboardShell";
import { SkeletonDashboard } from "../../components/LoadingSkeleton";
import { getCollectionCount } from "../../services/statsService";

export default function VicePrincipalDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [vpData, setVpData] = useState(null);
  const [stats, setStats] = useState({
    totalStudents: 0,
    totalTeachers: 0,
    totalClasses: 0,
    presentToday: 0,
    absentToday: 0,
    lateToday: 0,
    disciplineCases: 0,
    pendingDiscipline: 0,
    todayEvents: 0,
  });
  const [recentDiscipline, setRecentDiscipline] = useState([]);
  const [todaySchedule, setTodaySchedule] = useState([]);
  const [teacherAttendance, setTeacherAttendance] = useState([]);

  const fetchVpData = async () => {
    try {
      if (user) {
        const userDoc = await getDoc(doc(db, "users", user.uid));
        if (userDoc.exists()) {
          setVpData(userDoc.data());
        }
        const vpDoc = await getDoc(doc(db, "vicePrincipals", user.uid));
        if (vpDoc.exists()) {
          setVpData(prev => ({ ...prev, ...vpDoc.data() }));
        }
      }
    } catch (error) {
      console.error("Error fetching VP data:", error);
    }
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch students / teachers counts via the shared, cached stats
      // service instead of separate getDocs() reads.
      const [totalStudents, totalTeachers] = await Promise.all([
        getCollectionCount("students"),
        getCollectionCount("teachers"),
      ]);

      // ✅ Fetch today's attendance from your real data
      const today = new Date().toISOString().split("T")[0];
      try {
        const attendanceSnap = await getDocs(
          query(collection(db, "attendance"), where("date", "==", today))
        );
        const attendanceData = attendanceSnap.docs.map((doc) => doc.data());
        
        const presentToday = attendanceData.filter((a) => a.status === "Present").length;
        const absentToday = attendanceData.filter((a) => a.status === "Absent").length;
        const lateToday = attendanceData.filter((a) => a.status === "Late").length;
        
        setStats(prev => ({ ...prev, presentToday, absentToday, lateToday }));
      } catch {
        console.log("No attendance data for today");
      }

      // ✅ Fetch discipline cases from your real data
      try {
        const disciplineSnap = await getDocs(
          query(collection(db, "discipline"), orderBy("date", "desc"))
        );
        const disciplineData = disciplineSnap.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        
        const disciplineCases = disciplineData.length;
        const pendingDiscipline = disciplineData.filter((d) => d.status === "active" || !d.status).length;
        
        setStats(prev => ({ ...prev, disciplineCases, pendingDiscipline }));
        setRecentDiscipline(disciplineData.slice(0, 5));
      } catch {
        console.log("No discipline data found");
      }

      // ✅ Fetch today's schedule + total classes from your real data.
      // Sorted client-side: where + orderBy would need a composite index.
      let totalClasses = 0;
      try {
        const dayOfWeek = new Date().toLocaleDateString("en-US", { weekday: "long" });
        const schedulesSnap = await getDocs(collection(db, "schedules"));
        const allSchedules = schedulesSnap.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));

        // Total classes = unique grade-section combinations in schedules
        totalClasses = new Set(
          allSchedules
            .filter((s) => s.grade || s.section)
            .map((s) => `${s.grade}-${s.section}`)
        ).size;

        const scheduleData = allSchedules
          .filter((s) => s.day === dayOfWeek)
          .sort((a, b) => (a.startTime || "").localeCompare(b.startTime || ""));
        setTodaySchedule(scheduleData.slice(0, 10));
      } catch {
        console.log("No schedule data found");
      }

      // ✅ Fetch today's events count from your real data
      try {
        const eventsSnap = await getDocs(
          query(collection(db, "events"), where("date", "==", today))
        );
        setStats((prev) => ({ ...prev, todayEvents: eventsSnap.size }));
      } catch {
        console.log("No events data found");
      }

      // ✅ Fetch teacher attendance from your real data
      try {
        const todayStr = new Date().toISOString().split("T")[0];
        const teacherAttSnap = await getDocs(
          query(collection(db, "teacherAttendance"), where("date", "==", todayStr))
        );
        const teacherAttData = teacherAttSnap.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setTeacherAttendance(teacherAttData.slice(0, 5));
      } catch {
        console.log("No teacher attendance data found");
      }

      setStats(prev => ({
        ...prev,
        totalStudents,
        totalTeachers,
        totalClasses,
      }));

    } catch (error) {
      console.error("Error fetching dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    fetchVpData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const dashboardItems = [
    {
      icon: "📋",
      title: "Daily Operations",
      description: "Manage daily school operations",
      route: "/vice-principal/operations",
      color: "bg-blue-50 hover:bg-blue-100 border-blue-200",
      iconColor: "text-blue-700",
    },
    {
      icon: "👨‍🎓",
      title: "Student Discipline",
      description: "Track and manage student behavior",
      route: "/discipline",
      color: "bg-red-50 hover:bg-red-100 border-red-200",
      iconColor: "text-red-700",
    },
    {
      icon: "👨‍🏫",
      title: "Teacher Attendance",
      description: "Monitor teacher attendance",
      route: "/vice-principal/teacher-attendance",
      color: "bg-orange-50 hover:bg-orange-100 border-orange-200",
      iconColor: "text-orange-700",
    },
    {
      icon: "🏫",
      title: "Classroom Monitoring",
      description: "Monitor classroom activities",
      route: "/vice-principal/classroom-monitoring",
      color: "bg-green-50 hover:bg-green-100 border-green-200",
      iconColor: "text-green-700",
    },
    {
      icon: "📊",
      title: "Attendance Reports",
      description: "View and analyze attendance data",
      route: "/attendance-report",
      color: "bg-purple-50 hover:bg-purple-100 border-purple-200",
      iconColor: "text-purple-700",
    },
    {
      icon: "📅",
      title: "Today's Schedule",
      description: "View today's class schedule",
      route: "/vice-principal/schedule",
      color: "bg-indigo-50 hover:bg-indigo-100 border-indigo-200",
      iconColor: "text-indigo-700",
    },
    {
      icon: "👤",
      title: "My Profile",
      description: "View your vice principal profile",
      route: "/vice-principal/profile",
      color: "bg-gray-50 hover:bg-gray-100 border-gray-200",
      iconColor: "text-gray-700",
    },
    {
      icon: "🔐",
      title: "Security Settings",
      description: "Update your security settings",
      route: "/profile",
      color: "bg-blue-50 hover:bg-blue-100 border-blue-200",
      iconColor: "text-blue-700",
    },
  ];

  const statCards = [
    {
      label: "Total Students",
      value: stats.totalStudents,
      icon: "👨‍🎓",
      color: "text-blue-700",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200",
    },
    {
      label: "Total Teachers",
      value: stats.totalTeachers,
      icon: "👨‍🏫",
      color: "text-green-700",
      bgColor: "bg-green-50",
      borderColor: "border-green-200",
    },
    {
      label: "Present Today",
      value: stats.presentToday,
      icon: "✅",
      color: "text-green-600",
      bgColor: "bg-green-50",
      borderColor: "border-green-200",
    },
    {
      label: "Absent Today",
      value: stats.absentToday,
      icon: "❌",
      color: "text-red-600",
      bgColor: "bg-red-50",
      borderColor: "border-red-200",
    },
    {
      label: "Late Today",
      value: stats.lateToday,
      icon: "⏰",
      color: "text-yellow-600",
      bgColor: "bg-yellow-50",
      borderColor: "border-yellow-200",
    },
    {
      label: "Discipline Cases",
      value: stats.disciplineCases,
      icon: "📋",
      color: "text-red-700",
      bgColor: "bg-red-50",
      borderColor: "border-red-200",
    },
    {
      label: "Total Classes",
      value: stats.totalClasses,
      icon: "🏫",
      color: "text-indigo-700",
      bgColor: "bg-indigo-50",
      borderColor: "border-indigo-200",
    },
    {
      label: "Today's Events",
      value: stats.todayEvents,
      icon: "📅",
      color: "text-purple-700",
      bgColor: "bg-purple-50",
      borderColor: "border-purple-200",
    },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto py-6 sm:py-8 px-4 sm:px-6 lg:px-8">
          <SkeletonDashboard />
        </div>
      </div>
    );
  }

  return (
    <DashboardShell
      icon="👔"
      title="Vice Principal Dashboard"
      welcomeName={vpData?.firstName || vpData?.name || user?.email || "Vice Principal"}
      subtitle="Manage daily operations, discipline, and attendance"
      subtitleSecondary={
        vpData?.department ? (
          <span className="inline-block mt-1 px-2 py-0.5 bg-purple-100 text-purple-700 rounded-full text-xs font-medium">
            📌 {vpData.department}
          </span>
        ) : undefined
      }
      badgeLabel="Vice Principal"
      badgeColor="bg-purple-100 text-purple-700"
      actions={[{ label: "🔄 Refresh", onClick: fetchData }]}
      stats={statCards}
      statsColumns="grid-cols-2 md:grid-cols-4"
      menuItems={dashboardItems}
      menuColumns="sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
      footerText="Tech Zone Academy - Vice Principal Dashboard v1.0"
    >
        {/* Today's Schedule Preview */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden mb-6">
          <div className="px-6 py-4 border-b bg-gray-50 flex justify-between items-center">
            <h3 className="text-lg font-bold text-gray-800">
              📅 Today's Schedule
            </h3>
            <button 
              onClick={() => navigate("/vice-principal/schedule")}
              className="text-sm text-blue-600 hover:text-blue-800"
            >
              View Full Schedule →
            </button>
          </div>
          <div className="overflow-x-auto">
            {todaySchedule.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                No schedule found for today.
              </div>
            ) : (
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Time</th>
                    <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Subject</th>
                    <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Teacher</th>
                    <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Class</th>
                  </tr>
                </thead>
                <tbody>
                  {todaySchedule.map((schedule, index) => (
                    <tr key={schedule.id || index} className="border-b hover:bg-gray-50 transition">
                      <td className="px-4 py-3 text-sm text-gray-600">
                        {schedule.startTime} - {schedule.endTime}
                      </td>
                      <td className="px-4 py-3 font-medium text-gray-800">
                        {schedule.subject || schedule.periodType || "N/A"}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">
                        {schedule.teacherName || "Not Assigned"}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">
                        {schedule.grade} - Section {schedule.section}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* Recent Discipline & Teacher Attendance */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Recent Discipline */}
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="px-6 py-4 border-b bg-gray-50 flex justify-between items-center">
              <h3 className="text-lg font-bold text-gray-800">
                📋 Recent Discipline Cases
              </h3>
              <span className="text-sm text-red-500 font-medium">
                {stats.pendingDiscipline} pending
              </span>
            </div>
            <div className="overflow-x-auto">
              {recentDiscipline.length === 0 ? (
                <div className="p-8 text-center text-gray-500">
                  No discipline cases found.
                </div>
              ) : (
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Student</th>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Type</th>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentDiscipline.map((item, index) => (
                      <tr key={item.id || index} className="border-b hover:bg-gray-50 transition">
                        <td className="px-4 py-3 font-medium text-gray-800">
                          {item.studentName || "Unknown"}
                        </td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            item.type === "warning" ? "bg-yellow-100 text-yellow-700" :
                            item.type === "detention" ? "bg-orange-100 text-orange-700" :
                            item.type === "suspension" ? "bg-red-100 text-red-700" :
                            item.type === "expulsion" ? "bg-red-200 text-red-800" :
                            "bg-green-100 text-green-700"
                          }`}>
                            {item.type || "Warning"}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            item.status === "active" || !item.status
                              ? "bg-yellow-100 text-yellow-700"
                              : "bg-green-100 text-green-700"
                          }`}>
                            {item.status === "active" || !item.status ? "⏳ Pending" : "✅ Resolved"}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>

          {/* Teacher Attendance */}
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="px-6 py-4 border-b bg-gray-50">
              <h3 className="text-lg font-bold text-gray-800">
                👨‍🏫 Teacher Attendance Today
              </h3>
            </div>
            <div className="overflow-x-auto">
              {teacherAttendance.length === 0 ? (
                <div className="p-8 text-center text-gray-500">
                  No teacher attendance recorded today.
                </div>
              ) : (
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Teacher</th>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Status</th>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    {teacherAttendance.map((item, index) => (
                      <tr key={item.id || index} className="border-b hover:bg-gray-50 transition">
                        <td className="px-4 py-3 font-medium text-gray-800">
                          {item.teacherName || "Unknown"}
                        </td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            item.status === "Present" ? "bg-green-100 text-green-700" :
                            item.status === "Late" ? "bg-yellow-100 text-yellow-700" :
                            "bg-red-100 text-red-700"
                          }`}>
                            {item.status || "Absent"}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-500">
                          {item.time || "N/A"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>

    </DashboardShell>
  );
}