import { useCallback, useEffect, useMemo, useState } from "react";
import {
  collection,
  deleteDoc,
  doc,
  getDocs,
  query,
  setDoc,
  updateDoc,
  where,
} from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";
import Icon from "../../components/Icon";
import { useAuth } from "../../context/AuthContext";
import { db } from "../../supabase/supabase";

const MANUAL_TASK_TYPES = [
  { title: "Staff Meeting", category: "meetings" },
  { title: "Parent Meeting", category: "meetings" },
  { title: "Student Counseling", category: "discipline" },
  { title: "Teacher Observation", category: "academic" },
  { title: "Classroom Visit", category: "academic" },
  { title: "Report Review", category: "administrative" },
  { title: "Event Planning", category: "administrative" },
  { title: "Emergency Drill", category: "administrative" },
  { title: "Staff Evaluation", category: "academic" },
  { title: "Student Discipline Hearing", category: "discipline" },
];

const PRIORITY_STYLES = {
  urgent: "bg-red-100 text-red-700 border-red-200",
  high: "bg-orange-100 text-orange-700 border-orange-200",
  normal: "bg-blue-100 text-blue-700 border-blue-200",
  low: "bg-gray-100 text-gray-600 border-gray-200",
};

const CATEGORY_STYLES = {
  attendance: "bg-teal-50 text-teal-700",
  discipline: "bg-red-50 text-red-700",
  academic: "bg-indigo-50 text-indigo-700",
  administrative: "bg-gray-100 text-gray-700",
  meetings: "bg-amber-50 text-amber-700",
};

const FILTERS = [
  { value: "all", label: "All tasks" },
  { value: "daily", label: "Daily" },
  { value: "weekly", label: "Weekly" },
  { value: "manual", label: "Manual" },
  { value: "completed", label: "Completed" },
];

function dateKey(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function addDays(date, days) {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

function startOfWeek(date) {
  return addDays(date, -((date.getDay() + 6) % 7));
}

function recordsOf(result) {
  return result.status === "fulfilled"
    ? result.value.docs.map((record) => ({ id: record.id, ...record.data() }))
    : [];
}

function createSystemTask({
  id,
  title,
  description,
  category,
  priority,
  dueDate,
  userId,
  cadence,
  relatedType,
  existing,
  now,
}) {
  return {
    id,
    title,
    description,
    category,
    priority,
    dueDate,
    completed: existing?.completed || false,
    completedAt: existing?.completedAt || null,
    userId,
    createdBy: "system",
    isSystemTask: true,
    cadence,
    createdAt: existing?.createdAt || now,
    updatedAt: now,
    relatedId: null,
    relatedType,
  };
}

function formatDueDate(value) {
  if (!value) return "No due date";
  return new Date(`${value}T00:00:00`).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export default function DailyOperations() {
  const { user } = useAuth();
  const userId = user?.uid;
  const navigate = useNavigate();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [savingIds, setSavingIds] = useState([]);
  const [filter, setFilter] = useState("all");
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [sourceWarnings, setSourceWarnings] = useState([]);
  const [today] = useState(() => dateKey());
  const [formData, setFormData] = useState({
    title: MANUAL_TASK_TYPES[0].title,
    description: "",
    category: MANUAL_TASK_TYPES[0].category,
    priority: "normal",
    dueDate: dateKey(),
  });

  const fetchTasks = useCallback(
    async ({ quiet = false } = {}) => {
      if (!userId) return;
      quiet ? setRefreshing(true) : setLoading(true);
      setErrorMessage("");

      const nowDate = new Date();
      const weekStart = startOfWeek(nowDate);
      const weekStartKey = dateKey(weekStart);
      const weekDueDate = dateKey(addDays(weekStart, 4));
      const dayName = nowDate.toLocaleDateString("en-US", { weekday: "long" });

      const reads = [
        getDocs(query(collection(db, "vpTasks"), where("userId", "==", userId))),
        getDocs(
          query(
            collection(db, "teacherAttendance"),
            where("date", ">=", weekStartKey),
            where("date", "<=", today)
          )
        ),
        getDocs(
          query(
            collection(db, "attendance"),
            where("date", ">=", weekStartKey),
            where("date", "<=", today)
          )
        ),
        getDocs(collection(db, "discipline")),
        getDocs(collection(db, "users")),
        getDocs(collection(db, "schedules")),
        getDocs(collection(db, "teachers")),
        getDocs(collection(db, "results")),
      ];

      try {
        const results = await Promise.allSettled(reads);
        if (results[0].status === "rejected") throw results[0].reason;

        const savedTasks = recordsOf(results[0]);
        const teacherAttendance = recordsOf(results[1]);
        const studentAttendance = recordsOf(results[2]);
        const discipline = recordsOf(results[3]);
        const users = recordsOf(results[4]);
        const schedules = recordsOf(results[5]);
        const teachers = recordsOf(results[6]);
        const resultsRecords = recordsOf(results[7]);
        const existingById = new Map(savedTasks.map((task) => [task.id, task]));
        const sourceNames = [
          "saved tasks",
          "teacher attendance",
          "student attendance",
          "discipline",
          "pending approvals",
          "schedules",
          "teachers",
          "student results",
        ];
        setSourceWarnings(
          results
            .map((result, index) => (result.status === "rejected" ? sourceNames[index] : null))
            .filter(Boolean)
        );

        const todayTeacherAttendance = teacherAttendance.filter((item) => item.date === today);
        const todayStudentAttendance = studentAttendance.filter((item) => item.date === today);
        const teacherExceptions = todayTeacherAttendance.filter((item) =>
          ["absent", "late"].includes(String(item.status || "").toLowerCase())
        ).length;
        const studentExceptions = todayStudentAttendance.filter((item) =>
          ["absent", "late"].includes(String(item.status || "").toLowerCase())
        ).length;
        const openDiscipline = discipline.filter(
          (item) => !item.status || ["active", "open", "pending"].includes(String(item.status).toLowerCase())
        );
        const pendingUsers = users.filter(
          (item) => !item.approved && item.status !== "rejected"
        );
        const todaySchedules = schedules.filter((item) => item.day === dayName);
        const now = new Date().toISOString();
        const dailyPrefix = `${userId}_daily_${today}`;
        const weeklyPrefix = `${userId}_weekly_${weekStartKey}`;

        const definitions = [
          {
            id: `${dailyPrefix}_teacher-attendance`,
            title: "Review Teacher Attendance",
            description: `${todayTeacherAttendance.length} teacher attendance records today; ${teacherExceptions} absent or late to follow up.`,
            category: "attendance",
            priority: "high",
            dueDate: today,
            cadence: "daily",
            relatedType: "teacherAttendance",
          },
          {
            id: `${dailyPrefix}_student-attendance`,
            title: "Review Student Attendance",
            description: `${todayStudentAttendance.length} student attendance records today; ${studentExceptions} absent or late entries need review.`,
            category: "attendance",
            priority: "high",
            dueDate: today,
            cadence: "daily",
            relatedType: "attendance",
          },
          {
            id: `${dailyPrefix}_discipline`,
            title: "Check Discipline Reports",
            description: `${openDiscipline.length} active or pending discipline record${openDiscipline.length === 1 ? "" : "s"} require attention.`,
            category: "discipline",
            priority: openDiscipline.length ? "urgent" : "normal",
            dueDate: today,
            cadence: "daily",
            relatedType: "discipline",
          },
          {
            id: `${dailyPrefix}_approvals`,
            title: "Review Pending Approvals",
            description: `${pendingUsers.length} user account${pendingUsers.length === 1 ? " is" : "s are"} waiting for approval.`,
            category: "administrative",
            priority: pendingUsers.length ? "high" : "normal",
            dueDate: today,
            cadence: "daily",
            relatedType: "users",
          },
          {
            id: `${dailyPrefix}_classrooms`,
            title: "Monitor Classrooms",
            description: `${todaySchedules.length} scheduled class${todaySchedules.length === 1 ? "" : "es"} to monitor today.`,
            category: "academic",
            priority: "normal",
            dueDate: today,
            cadence: "daily",
            relatedType: "schedule",
          },
          {
            id: `${weeklyPrefix}_attendance-report`,
            title: "Review Weekly Attendance Report",
            description: `Review ${studentAttendance.length} student and ${teacherAttendance.length} teacher attendance entries recorded this week.`,
            category: "attendance",
            priority: "high",
            dueDate: weekDueDate,
            cadence: "weekly",
            relatedType: "attendance",
          },
          {
            id: `${weeklyPrefix}_teacher-performance`,
            title: "Check Teacher Performance",
            description: `Review performance and attendance follow-up for ${teachers.length} teacher${teachers.length === 1 ? "" : "s"}.`,
            category: "academic",
            priority: "normal",
            dueDate: weekDueDate,
            cadence: "weekly",
            relatedType: "teachers",
          },
          {
            id: `${weeklyPrefix}_student-progress`,
            title: "Review Student Progress",
            description: `${resultsRecords.length} student result record${resultsRecords.length === 1 ? " is" : "s are"} available for progress review.`,
            category: "academic",
            priority: "normal",
            dueDate: weekDueDate,
            cadence: "weekly",
            relatedType: "results",
          },
          {
            id: `${weeklyPrefix}_discipline-records`,
            title: "Update Discipline Records",
            description: `Confirm actions and status updates for ${openDiscipline.length} open discipline record${openDiscipline.length === 1 ? "" : "s"}.`,
            category: "discipline",
            priority: openDiscipline.length ? "high" : "low",
            dueDate: weekDueDate,
            cadence: "weekly",
            relatedType: "discipline",
          },
        ];

        const systemTasks = definitions.map((definition) =>
          createSystemTask({
            ...definition,
            userId,
            existing: existingById.get(definition.id),
            now,
          })
        );

        await Promise.all(
          systemTasks.map((task) => setDoc(doc(db, "vpTasks", task.id), task, { merge: true }))
        );

        const currentSystemIds = new Set(systemTasks.map((task) => task.id));
        const manualAndHistory = savedTasks.filter((task) => !currentSystemIds.has(task.id));
        setTasks([...systemTasks, ...manualAndHistory]);
      } catch (error) {
        console.error("Error loading VP tasks:", error);
        setErrorMessage(`Unable to load VP tasks: ${error.message}`);
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [today, userId]
  );

  useEffect(() => {
    fetchTasks();
  }, [fetchTasks]);

  const filteredTasks = useMemo(() => {
    const visible = tasks.filter((task) => {
      if (filter === "completed") return task.completed;
      if (filter === "manual") return !task.isSystemTask && !task.completed;
      if (filter === "daily" || filter === "weekly") {
        return task.isSystemTask && task.cadence === filter && !task.completed;
      }
      return !task.completed;
    });

    const priorityRank = { urgent: 0, high: 1, normal: 2, low: 3 };
    return visible.sort((a, b) => {
      if ((a.dueDate || "") !== (b.dueDate || "")) {
        return (a.dueDate || "9999").localeCompare(b.dueDate || "9999");
      }
      return (priorityRank[a.priority] ?? 4) - (priorityRank[b.priority] ?? 4);
    });
  }, [filter, tasks]);

  const stats = useMemo(
    () => ({
      open: tasks.filter((task) => !task.completed).length,
      dueToday: tasks.filter((task) => !task.completed && task.dueDate === today).length,
      urgent: tasks.filter((task) => !task.completed && task.priority === "urgent").length,
      completed: tasks.filter((task) => task.completed).length,
    }),
    [tasks, today]
  );

  const toggleTaskComplete = async (task) => {
    const completed = !task.completed;
    setSavingIds((ids) => [...ids, task.id]);
    setErrorMessage("");
    setTasks((current) =>
      current.map((item) =>
        item.id === task.id
          ? { ...item, completed, completedAt: completed ? new Date().toISOString() : null }
          : item
      )
    );

    try {
      await updateDoc(doc(db, "vpTasks", task.id), {
        completed,
        completedAt: completed ? new Date().toISOString() : null,
        updatedAt: new Date().toISOString(),
      });
    } catch (error) {
      setTasks((current) => current.map((item) => (item.id === task.id ? task : item)));
      setErrorMessage(`Unable to update task: ${error.message}`);
    } finally {
      setSavingIds((ids) => ids.filter((id) => id !== task.id));
    }
  };

  const handleTaskTypeChange = (title) => {
    const taskType = MANUAL_TASK_TYPES.find((type) => type.title === title);
    setFormData((current) => ({
      ...current,
      title,
      category: taskType?.category || current.category,
    }));
  };

  const resetForm = () => {
    setFormData({
      title: MANUAL_TASK_TYPES[0].title,
      description: "",
      category: MANUAL_TASK_TYPES[0].category,
      priority: "normal",
      dueDate: dateKey(),
    });
  };

  const addManualTask = async (event) => {
    event.preventDefault();
    if (!formData.description.trim()) {
      setErrorMessage("Add a short description so the task has a clear outcome.");
      return;
    }

    setSubmitting(true);
    setErrorMessage("");
    try {
      const taskRef = doc(collection(db, "vpTasks"));
      const now = new Date().toISOString();
      const task = {
        id: taskRef.id,
        title: formData.title,
        description: formData.description.trim(),
        category: formData.category,
        priority: formData.priority,
        dueDate: formData.dueDate,
        completed: false,
        completedAt: null,
        userId,
        createdBy: userId,
        isSystemTask: false,
        cadence: "manual",
        createdAt: now,
        updatedAt: now,
        relatedId: null,
        relatedType: null,
      };
      await setDoc(taskRef, task);
      setTasks((current) => [...current, task]);
      setShowTaskModal(false);
      resetForm();
      setSuccessMessage("Task added to your operations queue.");
      window.setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage(`Unable to add task: ${error.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  const deleteManualTask = async (task) => {
    if (task.isSystemTask || !window.confirm(`Delete "${task.title}"?`)) return;
    setSavingIds((ids) => [...ids, task.id]);
    try {
      await deleteDoc(doc(db, "vpTasks", task.id));
      setTasks((current) => current.filter((item) => item.id !== task.id));
      setSuccessMessage("Task deleted.");
      window.setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage(`Unable to delete task: ${error.message}`);
    } finally {
      setSavingIds((ids) => ids.filter((id) => id !== task.id));
    }
  };

  const openRelatedArea = (task) => {
    const routes = {
      teacherAttendance: "/vice-principal/teacher-attendance",
      attendance: "/attendance-report",
      discipline: "/discipline",
      schedule: "/vice-principal/classroom-monitoring",
      teachers: "/vice-principal/teacher-attendance",
      results: "/results",
    };
    if (routes[task.relatedType]) navigate(routes[task.relatedType]);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto" />
          <p className="mt-4 text-gray-600">Preparing your operations queue...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-6 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <header className="flex flex-col gap-4 mb-6 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex items-start gap-3">
            <button
              type="button"
              onClick={() => navigate(-1)}
              className="mt-1 text-gray-600 hover:text-gray-900 transition"
              aria-label="Go back"
              title="Back"
            >
              Back
            </button>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">Daily Operations</h1>
              <p className="text-gray-600 mt-1">System priorities and VP-assigned work in one queue</p>
              <p className="text-sm text-gray-400 mt-1">
                {new Date(`${today}T00:00:00`).toLocaleDateString("en-US", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </p>
            </div>
          </div>
          <div className="flex gap-2 sm:justify-end">
            <button
              type="button"
              onClick={() => fetchTasks({ quiet: true })}
              disabled={refreshing}
              className="inline-flex min-h-10 items-center gap-2 border border-gray-300 bg-white px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-60"
            >
              <Icon name="refresh" spin={refreshing} aria-hidden="true" />
              Refresh
            </button>
            <button
              type="button"
              onClick={() => setShowTaskModal(true)}
              className="inline-flex min-h-10 items-center gap-2 bg-blue-700 px-4 py-2 rounded-md text-sm font-medium text-white hover:bg-blue-800"
            >
              <Icon name="add" aria-hidden="true" />
              Add task
            </button>
          </div>
        </header>

        {successMessage && (
          <div className="mb-4 flex items-center gap-2 border border-green-200 bg-green-50 px-4 py-3 rounded-md text-sm text-green-800" role="status">
            <Icon name="success" aria-hidden="true" />
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div className="mb-4 flex items-start gap-2 border border-red-200 bg-red-50 px-4 py-3 rounded-md text-sm text-red-800" role="alert">
            <Icon name="error" className="mt-0.5" aria-hidden="true" />
            {errorMessage}
          </div>
        )}
        {sourceWarnings.length > 0 && (
          <div className="mb-4 flex items-start gap-2 border border-amber-200 bg-amber-50 px-4 py-3 rounded-md text-sm text-amber-800">
            <Icon name="warning" className="mt-0.5" aria-hidden="true" />
            Live counts are unavailable for: {sourceWarnings.join(", ")}. Saved tasks are still available.
          </div>
        )}

        <section className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6" aria-label="Task summary">
          {[
            { label: "Open tasks", value: stats.open, color: "border-blue-600 text-blue-700" },
            { label: "Due today", value: stats.dueToday, color: "border-teal-600 text-teal-700" },
            { label: "Urgent", value: stats.urgent, color: "border-red-600 text-red-700" },
            { label: "Completed", value: stats.completed, color: "border-green-600 text-green-700" },
          ].map((item) => (
            <div key={item.label} className={`bg-white border-l-4 ${item.color} px-4 py-3 shadow-sm rounded-md`}>
              <div className="text-2xl font-bold">{item.value}</div>
              <div className="text-xs text-gray-600 mt-1">{item.label}</div>
            </div>
          ))}
        </section>

        <main className="bg-white border border-gray-200 shadow-sm rounded-md overflow-hidden">
          <div className="border-b border-gray-200 px-4 pt-4 sm:px-6">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
              <div className="pb-3">
                <h2 className="text-lg font-bold text-gray-900">VP task queue</h2>
                <p className="text-sm text-gray-500">{filteredTasks.length} task{filteredTasks.length === 1 ? "" : "s"} in this view</p>
              </div>
              <div className="flex gap-1 overflow-x-auto" role="tablist" aria-label="Task filters">
                {FILTERS.map((item) => (
                  <button
                    key={item.value}
                    type="button"
                    role="tab"
                    aria-selected={filter === item.value}
                    onClick={() => setFilter(item.value)}
                    className={`whitespace-nowrap border-b-2 px-3 py-3 text-sm font-medium transition ${
                      filter === item.value
                        ? "border-blue-700 text-blue-700"
                        : "border-transparent text-gray-500 hover:text-gray-800"
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {filteredTasks.length === 0 ? (
            <div className="py-16 px-4 text-center">
              <Icon name="success" size={36} className="text-green-500" aria-hidden="true" />
              <p className="mt-3 font-medium text-gray-800">No tasks in this view</p>
              <p className="mt-1 text-sm text-gray-500">Choose another filter or add a manual VP task.</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {filteredTasks.map((task) => {
                const saving = savingIds.includes(task.id);
                return (
                  <article key={task.id} className={`p-4 sm:px-6 transition ${task.completed ? "bg-green-50/40" : "hover:bg-gray-50"}`}>
                    <div className="flex items-start gap-3">
                      <button
                        type="button"
                        onClick={() => toggleTaskComplete(task)}
                        disabled={saving}
                        className={`mt-0.5 flex h-6 w-6 flex-shrink-0 items-center justify-center rounded border-2 transition ${
                          task.completed
                            ? "border-green-600 bg-green-600 text-white"
                            : "border-gray-300 bg-white text-transparent hover:border-blue-600"
                        } disabled:opacity-50`}
                        aria-label={task.completed ? `Reopen ${task.title}` : `Complete ${task.title}`}
                      >
                        <Icon name="success" size={13} aria-hidden="true" />
                      </button>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <h3 className={`font-semibold ${task.completed ? "text-gray-500 line-through" : "text-gray-900"}`}>
                            {task.title}
                          </h3>
                          <span className={`border px-2 py-0.5 rounded text-xs font-medium ${PRIORITY_STYLES[task.priority] || PRIORITY_STYLES.normal}`}>
                            {task.priority || "normal"}
                          </span>
                          <span className={`px-2 py-0.5 rounded text-xs font-medium ${CATEGORY_STYLES[task.category] || CATEGORY_STYLES.administrative}`}>
                            {task.category || "administrative"}
                          </span>
                          <span className="text-xs text-gray-400">
                            {task.isSystemTask ? `${task.cadence || "daily"} system task` : "manual task"}
                          </span>
                        </div>
                        <p className={`mt-1 text-sm leading-6 ${task.completed ? "text-gray-400" : "text-gray-600"}`}>
                          {task.description}
                        </p>
                        <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-gray-500">
                          <span className={task.dueDate < today && !task.completed ? "font-semibold text-red-700" : ""}>
                            Due {formatDueDate(task.dueDate)}
                          </span>
                          {task.completedAt && (
                            <span>Completed {new Date(task.completedAt).toLocaleString()}</span>
                          )}
                        </div>
                      </div>
                      <div className="flex flex-shrink-0 items-center gap-1">
                        {task.isSystemTask && task.relatedType !== "users" && (
                          <button
                            type="button"
                            onClick={() => openRelatedArea(task)}
                            className="px-2 py-1 text-xs font-medium text-blue-700 hover:bg-blue-50 rounded"
                          >
                            Review
                          </button>
                        )}
                        {!task.isSystemTask && (
                          <button
                            type="button"
                            onClick={() => deleteManualTask(task)}
                            disabled={saving}
                            className="flex h-8 w-8 items-center justify-center text-gray-400 hover:bg-red-50 hover:text-red-700 rounded disabled:opacity-50"
                            title="Delete task"
                            aria-label={`Delete ${task.title}`}
                          >
                            <Icon name="delete" aria-hidden="true" />
                          </button>
                        )}
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </main>
      </div>

      {showTaskModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" role="presentation">
          <div className="w-full max-w-xl max-h-[90vh] overflow-y-auto bg-white shadow-xl rounded-md" role="dialog" aria-modal="true" aria-labelledby="add-vp-task-title">
            <div className="flex items-center justify-between border-b border-gray-200 px-5 py-4">
              <div>
                <h2 id="add-vp-task-title" className="text-lg font-bold text-gray-900">Add VP task</h2>
                <p className="text-sm text-gray-500">Add a meeting, review, observation, or other operational duty.</p>
              </div>
              <button
                type="button"
                onClick={() => setShowTaskModal(false)}
                className="flex h-9 w-9 items-center justify-center text-gray-500 hover:bg-gray-100 rounded"
                title="Close"
                aria-label="Close task form"
              >
                <Icon name="close" aria-hidden="true" />
              </button>
            </div>
            <form onSubmit={addManualTask} className="space-y-4 p-5">
              <div>
                <label htmlFor="task-title" className="block text-sm font-medium text-gray-700 mb-1">Task type</label>
                <select
                  id="task-title"
                  value={formData.title}
                  onChange={(event) => handleTaskTypeChange(event.target.value)}
                  className="w-full border border-gray-300 bg-white p-2.5 rounded-md outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
                >
                  {MANUAL_TASK_TYPES.map((type) => (
                    <option key={type.title} value={type.title}>{type.title}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="task-description" className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  id="task-description"
                  rows="3"
                  required
                  value={formData.description}
                  onChange={(event) => setFormData((current) => ({ ...current, description: event.target.value }))}
                  placeholder="Purpose, people involved, and expected outcome"
                  className="w-full resize-y border border-gray-300 p-2.5 rounded-md outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
                />
              </div>
              <div className="grid gap-4 sm:grid-cols-3">
                <div>
                  <label htmlFor="task-category" className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                  <select
                    id="task-category"
                    value={formData.category}
                    onChange={(event) => setFormData((current) => ({ ...current, category: event.target.value }))}
                    className="w-full border border-gray-300 bg-white p-2.5 rounded-md outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
                  >
                    {Object.keys(CATEGORY_STYLES).map((category) => (
                      <option key={category} value={category}>{category}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="task-priority" className="block text-sm font-medium text-gray-700 mb-1">Priority</label>
                  <select
                    id="task-priority"
                    value={formData.priority}
                    onChange={(event) => setFormData((current) => ({ ...current, priority: event.target.value }))}
                    className="w-full border border-gray-300 bg-white p-2.5 rounded-md outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
                  >
                    {Object.keys(PRIORITY_STYLES).map((priority) => (
                      <option key={priority} value={priority}>{priority}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="task-due-date" className="block text-sm font-medium text-gray-700 mb-1">Due date</label>
                  <input
                    id="task-due-date"
                    type="date"
                    required
                    value={formData.dueDate}
                    onChange={(event) => setFormData((current) => ({ ...current, dueDate: event.target.value }))}
                    className="w-full border border-gray-300 p-2.5 rounded-md outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 border-t border-gray-100 pt-4">
                <button
                  type="button"
                  onClick={() => setShowTaskModal(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex items-center gap-2 bg-blue-700 px-4 py-2 text-sm font-medium text-white hover:bg-blue-800 rounded-md disabled:opacity-60"
                >
                  <Icon name="save" aria-hidden="true" />
                  {submitting ? "Adding..." : "Add task"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
