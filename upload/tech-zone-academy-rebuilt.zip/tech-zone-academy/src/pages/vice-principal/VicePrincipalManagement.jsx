// src/pages/VicePrincipalManagement.jsx
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { db, collection, getDocs, query, where, doc, updateDoc } from "../../supabase/supabase";

export default function VicePrincipalManagement() {
  const navigate = useNavigate();
  const { user, role, createUserWithRole, updateUserStatus, deleteUser } = useAuth();
  const [vicePrincipals, setVicePrincipals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    firstName: "",
    lastName: "",
    phone: "",
    address: "",
    employeeId: "",
    department: "",
  });
  const [formError, setFormError] = useState("");
  const [formSuccess, setFormSuccess] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [editingVicePrincipal, setEditingVicePrincipal] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);

  const departments = [
    "Academic Affairs",
    "Student Affairs",
    "Administration",
    "Finance",
    "Human Resources",
    "Operations",
  ];

  const fetchVicePrincipals = async () => {
    setLoading(true);
    try {
      const q = query(collection(db, "users"), where("role", "==", "vice_principal"));
      const snap = await getDocs(q);
      const data = snap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setVicePrincipals(data);
    } catch (error) {
      console.error("Error fetching vice principals:", error);
      setErrorMessage("Error loading vice principals: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (role === "admin") {
      fetchVicePrincipals();
    }
     
  }, [role]);

  const handleCreateVicePrincipal = async (e) => {
    e.preventDefault();
    setFormError("");
    setSubmitting(true);

    if (formData.password !== formData.confirmPassword) {
      setFormError("Passwords do not match");
      setSubmitting(false);
      return;
    }

    if (formData.password.length < 6) {
      setFormError("Password must be at least 6 characters");
      setSubmitting(false);
      return;
    }

    if (!formData.email) {
      setFormError("Email is required");
      setSubmitting(false);
      return;
    }

    if (!formData.firstName || !formData.lastName) {
      setFormError("First name and last name are required");
      setSubmitting(false);
      return;
    }

    try {
      const additionalData = {
        firstName: formData.firstName,
        lastName: formData.lastName,
        phone: formData.phone,
        address: formData.address,
        email: formData.email,
        employeeId: formData.employeeId || `VP-${Date.now().toString().slice(-6)}`,
        department: formData.department || "Academic Affairs",
        createdByRole: role,
        createdBy: user?.uid,
      };

      await createUserWithRole(
        formData.email,
        formData.password,
        "vice_principal",
        additionalData
      );

      setFormSuccess(true);
      setSuccessMessage("✅ Vice Principal created successfully!");
      setFormData({
        email: "",
        password: "",
        confirmPassword: "",
        firstName: "",
        lastName: "",
        phone: "",
        address: "",
        employeeId: "",
        department: "",
      });

      setTimeout(() => {
        setFormSuccess(false);
        setShowCreateModal(false);
        setSuccessMessage("");
        fetchVicePrincipals();
      }, 2000);
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleEditVicePrincipal = (vp) => {
    setEditingVicePrincipal(vp);
    setFormData({
      email: vp.email || "",
      password: "",
      confirmPassword: "",
      firstName: vp.firstName || "",
      lastName: vp.lastName || "",
      phone: vp.phone || "",
      address: vp.address || "",
      employeeId: vp.employeeId || "",
      department: vp.department || "Academic Affairs",
    });
    setShowEditModal(true);
    setFormError("");
  };

  const handleUpdateVicePrincipal = async (e) => {
    e.preventDefault();
    setFormError("");
    setSubmitting(true);

    if (!formData.firstName || !formData.lastName) {
      setFormError("First name and last name are required");
      setSubmitting(false);
      return;
    }

    try {
      const vpRef = doc(db, "users", editingVicePrincipal.id);
      await updateDoc(vpRef, {
        firstName: formData.firstName,
        lastName: formData.lastName,
        phone: formData.phone,
        address: formData.address,
        email: formData.email,
        employeeId: formData.employeeId,
        department: formData.department,
        updatedAt: new Date().toISOString(),
        updatedBy: user?.uid,
      });

      setSuccessMessage("✅ Vice Principal updated successfully!");
      setShowEditModal(false);
      setEditingVicePrincipal(null);
      setFormData({
        email: "",
        password: "",
        confirmPassword: "",
        firstName: "",
        lastName: "",
        phone: "",
        address: "",
        employeeId: "",
        department: "",
      });
      await fetchVicePrincipals();
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setFormError("Error updating vice principal: " + error.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleStatusChange = async (vpId, newStatus) => {
    if (window.confirm(`Change vice principal status to ${newStatus}?`)) {
      const success = await updateUserStatus(vpId, newStatus);
      if (success) {
        setSuccessMessage("✅ Status updated successfully!");
        await fetchVicePrincipals();
        setTimeout(() => setSuccessMessage(""), 3000);
      }
    }
  };

  const handleDeleteVicePrincipal = async (vpId, vpEmail) => {
    if (window.confirm(`Are you sure you want to delete ${vpEmail}? This action cannot be undone.`)) {
      const success = await deleteUser(vpId);
      if (success) {
        setSuccessMessage("✅ Vice Principal deleted successfully!");
        await fetchVicePrincipals();
        setTimeout(() => setSuccessMessage(""), 3000);
      }
    }
  };

  const filteredVicePrincipals = vicePrincipals.filter((vp) => {
    if (!searchTerm) return true;
    const search = searchTerm.toLowerCase();
    return (
      vp.email?.toLowerCase().includes(search) ||
      vp.firstName?.toLowerCase().includes(search) ||
      vp.lastName?.toLowerCase().includes(search) ||
      vp.phone?.includes(search) ||
      vp.employeeId?.toLowerCase().includes(search) ||
      vp.department?.toLowerCase().includes(search)
    );
  });

  const statusColors = {
    active: "bg-green-100 text-green-700",
    inactive: "bg-red-100 text-red-700",
    pending: "bg-yellow-100 text-yellow-700",
    suspended: "bg-orange-100 text-orange-700",
  };

  if (role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">🚫</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h2>
          <p className="text-gray-600">You need admin privileges to access this page.</p>
          <button
            onClick={() => navigate("/admin-dashboard")}
            className="mt-4 bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              👔 Vice Principal Management
            </h1>
            <p className="text-gray-600 mt-1">
              Manage vice principal accounts and permissions
            </p>
            <p className="text-sm text-purple-600 mt-1">
              👔 Principal → Managing Vice Principals
            </p>
          </div>
          <div className="flex items-center gap-3">
            <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-medium">
              👔 Vice Principals
            </span>
            <button
              onClick={() => {
                setEditingVicePrincipal(null);
                setFormData({
                  email: "",
                  password: "",
                  confirmPassword: "",
                  firstName: "",
                  lastName: "",
                  phone: "",
                  address: "",
                  employeeId: "",
                  department: "",
                });
                setFormError("");
                setFormSuccess(false);
                setShowCreateModal(true);
              }}
              className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition"
            >
              ➕ Add Vice Principal
            </button>
          </div>
        </div>

        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="🔍 Search vice principals by name, email, phone, or ID..."
            className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500 outline-none"
          />
        </div>

        <div className="flex flex-wrap gap-4 mb-6">
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Total Vice Principals:</span>
            <span className="ml-2 font-bold text-purple-700">{vicePrincipals.length}</span>
          </div>
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Active:</span>
            <span className="ml-2 font-bold text-green-700">
              {vicePrincipals.filter(vp => vp.status === "active" || !vp.status).length}
            </span>
          </div>
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Filtered:</span>
            <span className="ml-2 font-bold text-purple-700">{filteredVicePrincipals.length}</span>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Vice Principal</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Employee ID</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Department</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Email</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Phone</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Status</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan="7" className="px-4 py-8 text-center text-gray-500">
                      <div className="animate-pulse">Loading vice principals...</div>
                    </td>
                  </tr>
                ) : filteredVicePrincipals.length === 0 ? (
                  <tr>
                    <td colSpan="7" className="px-4 py-8 text-center text-gray-500">
                      No vice principals found. Click "Add Vice Principal" to create one.
                    </td>
                  </tr>
                ) : (
                  filteredVicePrincipals.map((vp) => (
                    <tr key={vp.id} className="border-b hover:bg-gray-50 transition">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-700 font-bold">
                            {vp.firstName?.charAt(0) || vp.email?.charAt(0) || "V"}
                          </div>
                          <div>
                            <p className="font-medium text-gray-800">
                              {vp.firstName || ""} {vp.lastName || ""}
                            </p>
                            <p className="text-xs text-gray-500">
                              ID: {vp.id.slice(0, 8)}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm font-medium text-gray-600">
                        {vp.employeeId || "---"}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">
                        <span className="px-2 py-1 rounded-full text-xs font-medium bg-purple-50 text-purple-700">
                          {vp.department || "Academic Affairs"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">{vp.email}</td>
                      <td className="px-4 py-3 text-sm text-gray-600">{vp.phone || "---"}</td>
                      <td className="px-4 py-3 text-center">
                        <select
                          value={vp.status || "active"}
                          onChange={(e) => handleStatusChange(vp.id, e.target.value)}
                          className={`px-2 py-1 rounded-full text-xs font-medium border-0 focus:ring-2 focus:ring-purple-500 ${
                            statusColors[vp.status] || statusColors.active
                          }`}
                        >
                          <option value="active">✅ Active</option>
                          <option value="inactive">❌ Inactive</option>
                          <option value="suspended">⛔ Suspended</option>
                          <option value="pending">⏳ Pending</option>
                        </select>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => handleEditVicePrincipal(vp)}
                            className="text-purple-600 hover:text-purple-800 text-sm"
                            title="Edit Vice Principal"
                          >
                            ✏️
                          </button>
                          <button
                            onClick={() => handleDeleteVicePrincipal(vp.id, vp.email)}
                            className="text-red-600 hover:text-red-800 text-sm"
                            title="Delete Vice Principal"
                          >
                            🗑️
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          <div className="px-4 py-3 border-t flex items-center justify-between">
            <p className="text-sm text-gray-500">
              Showing {filteredVicePrincipals.length} vice principal{filteredVicePrincipals.length !== 1 ? "s" : ""}
            </p>
          </div>
        </div>
      </div>

      {/* Create Vice Principal Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-gray-800">
                  👔 Create New Vice Principal
                </h3>
                <button
                  onClick={() => {
                    setShowCreateModal(false);
                    setFormError("");
                    setFormSuccess(false);
                  }}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ✕
                </button>
              </div>

              <div className="mb-4 p-3 bg-purple-50 rounded-lg border border-purple-200">
                <p className="text-sm text-purple-700">
                  👔 Principal → Creating Vice Principal account
                </p>
                <p className="text-xs text-purple-600 mt-1">
                  Vice Principals help manage daily operations, discipline, and attendance
                </p>
              </div>

              {formSuccess ? (
                <div className="text-center py-8">
                  <div className="text-6xl mb-4">✅</div>
                  <h4 className="text-xl font-bold text-green-600">Vice Principal Created!</h4>
                  <p className="text-gray-500">The vice principal account has been created successfully.</p>
                </div>
              ) : (
                <form onSubmit={handleCreateVicePrincipal} className="space-y-4">
                  {formError && (
                    <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg text-sm">
                      {formError}
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500 outline-none"
                      placeholder="vp@school.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Password *
                    </label>
                    <input
                      type="password"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      required
                      minLength="6"
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500 outline-none"
                      placeholder="Min 6 characters"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Confirm Password *
                    </label>
                    <input
                      type="password"
                      value={formData.confirmPassword}
                      onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500 outline-none"
                      placeholder="Confirm password"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        First Name *
                      </label>
                      <input
                        type="text"
                        value={formData.firstName}
                        onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                        required
                        className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500 outline-none"
                        placeholder="First name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Last Name *
                      </label>
                      <input
                        type="text"
                        value={formData.lastName}
                        onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                        required
                        className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500 outline-none"
                        placeholder="Last name"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500 outline-none"
                      placeholder="+251 9XX XXX XXX"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Employee ID (Optional)
                    </label>
                    <input
                      type="text"
                      value={formData.employeeId}
                      onChange={(e) => setFormData({ ...formData, employeeId: e.target.value })}
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500 outline-none"
                      placeholder="e.g., VP-001"
                    />
                    <p className="text-xs text-gray-400 mt-1">Auto-generated if left blank</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Department
                    </label>
                    <select
                      value={formData.department}
                      onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500 outline-none bg-white"
                    >
                      {departments.map(dept => (
                        <option key={dept} value={dept}>{dept}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Address
                    </label>
                    <input
                      type="text"
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500 outline-none"
                      placeholder="Address"
                    />
                  </div>

                  <div className="flex gap-3 pt-4">
                    <button
                      type="button"
                      onClick={() => {
                        setShowCreateModal(false);
                        setFormError("");
                      }}
                      className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg hover:bg-gray-300 transition"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={submitting}
                      className="flex-1 bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 transition disabled:bg-gray-400"
                    >
                      {submitting ? "Creating..." : "✅ Create Vice Principal"}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Edit Vice Principal Modal */}
      {showEditModal && editingVicePrincipal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-gray-800">
                  ✏️ Edit Vice Principal
                </h3>
                <button
                  onClick={() => {
                    setShowEditModal(false);
                    setEditingVicePrincipal(null);
                    setFormError("");
                  }}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ✕
                </button>
              </div>

              <div className="mb-4 p-3 bg-purple-50 rounded-lg border border-purple-200">
                <p className="text-sm text-purple-700">
                  Editing: <span className="font-semibold">{editingVicePrincipal.firstName || ""} {editingVicePrincipal.lastName || ""}</span>
                </p>
                <p className="text-xs text-purple-600 mt-1">
                  ID: {editingVicePrincipal.id.slice(0, 8)}
                </p>
              </div>

              <form onSubmit={handleUpdateVicePrincipal} className="space-y-4">
                {formError && (
                  <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg text-sm">
                    {formError}
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500 outline-none bg-gray-50"
                    placeholder="vp@school.com"
                    disabled
                  />
                  <p className="text-xs text-gray-400 mt-1">Email cannot be changed</p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      First Name *
                    </label>
                    <input
                      type="text"
                      value={formData.firstName}
                      onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500 outline-none"
                      placeholder="First name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Last Name *
                    </label>
                    <input
                      type="text"
                      value={formData.lastName}
                      onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500 outline-none"
                      placeholder="Last name"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500 outline-none"
                    placeholder="+251 9XX XXX XXX"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Employee ID
                  </label>
                  <input
                    type="text"
                    value={formData.employeeId}
                    onChange={(e) => setFormData({ ...formData, employeeId: e.target.value })}
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500 outline-none"
                    placeholder="VP-001"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Department
                  </label>
                  <select
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500 outline-none bg-white"
                  >
                    {departments.map(dept => (
                      <option key={dept} value={dept}>{dept}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Address
                  </label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500 outline-none"
                    placeholder="Address"
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex-1 bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 transition disabled:bg-gray-400"
                  >
                    {submitting ? "Updating..." : "💾 Update Vice Principal"}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowEditModal(false);
                      setEditingVicePrincipal(null);
                      setFormError("");
                    }}
                    className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg hover:bg-gray-300 transition"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}