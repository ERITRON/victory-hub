// src/pages/VicePrincipalProfile.jsx
import { useAuth } from "../../context/AuthContext";
import { useEffect, useState } from "react";
import { db, doc, getDoc } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";

export default function VicePrincipalProfile() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [vpData, setVpData] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchVpData = async () => {
    try {
      // Merge the users doc with the vicePrincipals doc (fetched in parallel)
      const [userDoc, vpDoc] = await Promise.all([
        getDoc(doc(db, "users", user.uid)),
        getDoc(doc(db, "vicePrincipals", user.uid)),
      ]);
      const merged = {
        ...(userDoc.exists() ? userDoc.data() : {}),
        ...(vpDoc.exists() ? vpDoc.data() : {}),
      };
      setVpData(Object.keys(merged).length > 0 ? merged : null);
    } catch (error) {
      console.error("Error fetching VP data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchVpData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading profile...</p>
        </div>
      </div>
    );
  }

  if (!vpData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <p className="text-gray-600">No profile data found.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <button onClick={() => navigate(-1)} className="text-gray-600 hover:text-gray-800 transition">
            ← Back
          </button>
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">👤 Vice Principal Profile</h1>
        </div>

        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-purple-600 to-purple-800 px-6 py-8">
            <div className="flex items-center gap-6">
              <div className="w-24 h-24 rounded-full bg-white/20 flex items-center justify-center text-4xl text-white font-bold border-4 border-white">
                {vpData.firstName?.charAt(0) || vpData.name?.charAt(0) || "V"}
              </div>
              <div className="text-white">
                <h2 className="text-2xl font-bold">
                  {vpData.firstName || ""} {vpData.lastName || ""}
                </h2>
                <p className="text-purple-200">{vpData.email}</p>
                <div className="flex flex-wrap gap-2 mt-2">
                  <span className="inline-block bg-purple-700 px-3 py-1 rounded-full text-sm font-medium">
                    👔 Vice Principal
                  </span>
                  {vpData.department && (
                    <span className="inline-block bg-purple-700 px-3 py-1 rounded-full text-sm font-medium">
                      📌 {vpData.department}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="p-6 space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Full Name</p>
                <p className="font-semibold text-gray-800">
                  {vpData.firstName || ""} {vpData.lastName || ""}
                </p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Email</p>
                <p className="font-semibold text-gray-800">{vpData.email || "N/A"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Phone</p>
                <p className="font-semibold text-gray-800">{vpData.phone || "Not set"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Employee ID</p>
                <p className="font-semibold text-gray-800">{vpData.employeeId || "Not set"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4 sm:col-span-2">
                <p className="text-sm text-gray-500">Department</p>
                <p className="font-semibold text-gray-800">{vpData.department || "Not set"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4 sm:col-span-2">
                <p className="text-sm text-gray-500">Address</p>
                <p className="font-semibold text-gray-800">{vpData.address || "Not set"}</p>
              </div>
            </div>

            <div className="flex gap-3 pt-4 border-t">
              <button
                onClick={() => navigate("/profile")}
                className="flex-1 bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition font-medium"
              >
                ⚙️ Security Settings
              </button>
              <button
                onClick={() => navigate("/vice-principal/dashboard")}
                className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg hover:bg-gray-300 transition font-medium"
              >
                ← Back to Dashboard
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}