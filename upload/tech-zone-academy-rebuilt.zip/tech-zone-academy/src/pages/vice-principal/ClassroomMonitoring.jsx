// src/pages/vice-principal/ClassroomMonitoring.jsx
import { useEffect, useState } from "react";
import { db, collection, getDocs, query, where } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";

export default function ClassroomMonitoring() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [selectedGrade, setSelectedGrade] = useState("");
  const [selectedSection, setSelectedSection] = useState("");
  const [grades, setGrades] = useState([]);
  const [sections, setSections] = useState([]);
  const [, setClasses] = useState([]);
  const [classDetails, setClassDetails] = useState(null);
  const [stats, setStats] = useState({
    totalClasses: 0,
    activeClasses: 0,
    totalStudents: 0,
    presentToday: 0,
    absentToday: 0,
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch grades
      const gradesSnap = await getDocs(collection(db, "grades"));
      const gradesData = gradesSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setGrades(gradesData.sort((a, b) => a.name.localeCompare(b.name)));

      // Fetch sections
      const sectionsSnap = await getDocs(collection(db, "sections"));
      const sectionsData = sectionsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSections(sectionsData.sort((a, b) => a.name.localeCompare(b.name)));

      if (gradesData.length > 0) {
        setSelectedGrade(gradesData[0].name);
      }
      if (sectionsData.length > 0) {
        setSelectedSection(sectionsData[0].name);
      }

      // Fetch all classes
      const studentsSnap = await getDocs(collection(db, "students"));
      const students = studentsSnap.docs.map((doc) => doc.data());
      
      const classMap = {};
      students.forEach((student) => {
        const key = `${student.grade}-${student.section}`;
        if (!classMap[key]) {
          classMap[key] = {
            grade: student.grade,
            section: student.section,
            students: [],
          };
        }
        classMap[key].students.push(student);
      });

      const classList = Object.values(classMap);
      setClasses(classList);
      setStats({
        totalClasses: classList.length,
        activeClasses: classList.filter(c => c.students.length > 0).length,
        totalStudents: students.length,
        presentToday: 0,
        absentToday: 0,
      });

      // Get today's attendance
      const today = new Date().toISOString().split("T")[0];
      const attendanceSnap = await getDocs(
        query(collection(db, "attendance"), where("date", "==", today))
      );
      const attendanceData = attendanceSnap.docs.map((doc) => doc.data());
      
      setStats(prev => ({
        ...prev,
        presentToday: attendanceData.filter(a => a.status === "Present").length,
        absentToday: attendanceData.filter(a => a.status === "Absent").length,
      }));
    } catch (error) {
      console.error("Error fetching classroom data:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchClassDetails = async () => {
    if (!selectedGrade || !selectedSection) return;
    
    try {
      const today = new Date().toLocaleDateString("en-US", { weekday: "long" });
      const todayStr = new Date().toISOString().split("T")[0];

      // All class-scoped reads in parallel. The schedule query avoids
      // orderBy (where + orderBy needs a composite index) — sorted below.
      const [studentsSnap, scheduleSnap, homeroomSnap, attendanceSnap] =
        await Promise.all([
          getDocs(
            query(
              collection(db, "students"),
              where("grade", "==", selectedGrade),
              where("section", "==", selectedSection)
            )
          ),
          getDocs(
            query(
              collection(db, "schedules"),
              where("grade", "==", selectedGrade),
              where("section", "==", selectedSection),
              where("day", "==", today)
            )
          ),
          getDocs(
            query(
              collection(db, "homeroomAssignments"),
              where("grade", "==", selectedGrade),
              where("section", "==", selectedSection)
            )
          ),
          getDocs(
            query(
              collection(db, "attendance"),
              where("grade", "==", selectedGrade),
              where("section", "==", selectedSection),
              where("date", "==", todayStr)
            )
          ),
        ]);

      const students = studentsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      const schedule = scheduleSnap.docs
        .map((doc) => ({ id: doc.id, ...doc.data() }))
        .sort((a, b) => (a.startTime || "").localeCompare(b.startTime || ""));
      let homeroomTeacher = null;
      homeroomSnap.forEach((doc) => {
        homeroomTeacher = doc.data();
      });
      const attendance = attendanceSnap.docs.map((doc) => doc.data());

      setClassDetails({
        students,
        schedule,
        homeroomTeacher,
        attendance,
        presentCount: attendance.filter(a => a.status === "Present").length,
        absentCount: attendance.filter(a => a.status === "Absent").length,
        lateCount: attendance.filter(a => a.status === "Late").length,
      });
    } catch (error) {
      console.error("Error fetching class details:", error);
    }
  };

  useEffect(() => {
     
    fetchData();
  }, []);

  useEffect(() => {
    if (selectedGrade && selectedSection) {
       
      fetchClassDetails();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedGrade, selectedSection]);

  const getStatusBadge = (status) => {
    const styles = {
      Present: "bg-green-100 text-green-700",
      Absent: "bg-red-100 text-red-700",
      Late: "bg-yellow-100 text-yellow-700",
      Excused: "bg-blue-100 text-blue-700",
    };
    return styles[status] || "bg-gray-100 text-gray-700";
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading classroom data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <button onClick={() => navigate(-1)} className="text-gray-600 hover:text-gray-800 transition">
            ← Back
          </button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              🏫 Classroom Monitoring
            </h1>
            <p className="text-gray-600 mt-1">
              Monitor classroom activities and student presence
            </p>
          </div>
          <div className="ml-auto">
            <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-medium">
              👔 Vice Principal
            </span>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-blue-500">
            <div className="text-2xl font-bold text-blue-700">{stats.totalClasses}</div>
            <div className="text-xs text-gray-600">Total Classes</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-green-500">
            <div className="text-2xl font-bold text-green-700">{stats.activeClasses}</div>
            <div className="text-xs text-gray-600">Active Classes</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-indigo-500">
            <div className="text-2xl font-bold text-indigo-700">{stats.totalStudents}</div>
            <div className="text-xs text-gray-600">Total Students</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-green-400">
            <div className="text-2xl font-bold text-green-600">{stats.presentToday}</div>
            <div className="text-xs text-gray-600">✅ Present Today</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-red-500">
            <div className="text-2xl font-bold text-red-600">{stats.absentToday}</div>
            <div className="text-xs text-gray-600">❌ Absent Today</div>
          </div>
        </div>

        {/* Class Selector */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Select Grade</label>
              <select
                value={selectedGrade}
                onChange={(e) => setSelectedGrade(e.target.value)}
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
              >
                {grades.map((grade) => (
                  <option key={grade.id} value={grade.name}>
                    {grade.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Select Section</label>
              <select
                value={selectedSection}
                onChange={(e) => setSelectedSection(e.target.value)}
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
              >
                {sections.map((section) => (
                  <option key={section.id} value={section.name}>
                    {section.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex items-end">
              <button
                onClick={fetchClassDetails}
                className="w-full bg-blue-700 text-white px-4 py-2.5 rounded-lg hover:bg-blue-800 transition"
              >
                🔍 View Class
              </button>
            </div>
          </div>
        </div>

        {/* Class Details */}
        {classDetails && selectedGrade && selectedSection && (
          <div className="space-y-6">
            {/* Class Info */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-bold text-gray-800">
                    {selectedGrade} - Section {selectedSection}
                  </h2>
                  {classDetails.homeroomTeacher && (
                    <p className="text-sm text-gray-600">
                      👨‍🏫 Homeroom Teacher: {classDetails.homeroomTeacher.teacherName || "Not Assigned"}
                    </p>
                  )}
                  <p className="text-sm text-gray-500">
                    Students: {classDetails.students.length}
                  </p>
                </div>
                <div className="flex gap-3">
                  <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                    ✅ Present: {classDetails.presentCount || 0}
                  </span>
                  <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-sm font-medium">
                    ❌ Absent: {classDetails.absentCount || 0}
                  </span>
                  <span className="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-sm font-medium">
                    ⏰ Late: {classDetails.lateCount || 0}
                  </span>
                </div>
              </div>
            </div>

            {/* Today's Schedule */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="px-6 py-4 border-b bg-gray-50">
                <h3 className="text-lg font-bold text-gray-800">📅 Today's Schedule</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Time</th>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Subject</th>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Teacher</th>
                    </tr>
                  </thead>
                  <tbody>
                    {classDetails.schedule.length === 0 ? (
                      <tr>
                        <td colSpan="3" className="px-4 py-8 text-center text-gray-500">
                          No schedule for today
                        </td>
                      </tr>
                    ) : (
                      classDetails.schedule.map((item) => (
                        <tr key={item.id} className="border-b hover:bg-gray-50 transition">
                          <td className="px-4 py-3 text-sm text-gray-600">
                            {item.startTime} - {item.endTime}
                          </td>
                          <td className="px-4 py-3 font-medium text-gray-800">{item.subject}</td>
                          <td className="px-4 py-3 text-sm text-gray-600">
                            {item.teacherName || "Not Assigned"}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Students List with Attendance */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="px-6 py-4 border-b bg-gray-50">
                <h3 className="text-lg font-bold text-gray-800">👨‍🎓 Students</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">#</th>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Student Name</th>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">ID</th>
                      <th className="px-4 py-2 text-center text-xs font-semibold text-gray-600">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {classDetails.students.length === 0 ? (
                      <tr>
                        <td colSpan="4" className="px-4 py-8 text-center text-gray-500">
                          No students in this class
                        </td>
                      </tr>
                    ) : (
                      classDetails.students.map((student, index) => {
                        const attendanceRecord = classDetails.attendance.find(
                          (a) => a.studentId === student.studentId
                        );
                        const status = attendanceRecord?.status || "Not Marked";
                        return (
                          <tr key={student.id} className="border-b hover:bg-gray-50 transition">
                            <td className="px-4 py-3 text-sm text-gray-500">{index + 1}</td>
                            <td className="px-4 py-3 font-medium text-gray-800">
                              {student.firstName} {student.fatherName}
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-600">{student.studentId}</td>
                            <td className="px-4 py-3 text-center">
                              {status === "Not Marked" ? (
                                <span className="px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-500">
                                  ⏳ Not Marked
                                </span>
                              ) : (
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(status)}`}>
                                  {status}
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}