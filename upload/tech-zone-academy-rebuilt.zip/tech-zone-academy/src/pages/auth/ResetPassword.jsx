// src/pages/ResetPassword.jsx
import { useState, useEffect } from "react";
import { useNavigate, useLocation, Link } from "react-router-dom";
import { auth, db, confirmPasswordReset, signInWithEmailAndPassword, signOut, verifyPasswordResetCode } from "../../supabase/supabase";
import { addDoc, collection, serverTimestamp } from "../../supabase/supabase";

export default function ResetPassword() {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [validCode, setValidCode] = useState(false);
  const [email, setEmail] = useState("");
  const navigate = useNavigate();
  const location = useLocation();

  // Get the reset code from URL
  const queryParams = new URLSearchParams(location.search);
  const oobCode = queryParams.get('oobCode');

  const verifyCode = async () => {
    try {
      const email = await verifyPasswordResetCode(auth, oobCode);
      setEmail(email);
      setValidCode(true);
    } catch {
      setErrorMessage("❌ This password reset link is invalid or has expired.");
    }
  };

  useEffect(() => {
    if (oobCode) {
       
      verifyCode();
    } else {
      setErrorMessage("❌ Invalid or missing password reset code.");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- verifyCode is a stable local function; only oobCode should retrigger
  }, [oobCode]);


  const handleResetPassword = async (e) => {
    e.preventDefault();
    setErrorMessage("");
    setSuccessMessage("");
    setLoading(true);

    if (password.length < 6) {
      setErrorMessage("⚠️ Password must be at least 6 characters.");
      setLoading(false);
      return;
    }

    if (password !== confirmPassword) {
      setErrorMessage("⚠️ Passwords do not match.");
      setLoading(false);
      return;
    }

    try {
      await confirmPasswordReset(auth, oobCode, password);
      try {
        const credential = await signInWithEmailAndPassword(auth, email, password);
        await addDoc(collection(db, "notificationEvents"), {
          type: "password_changed",
          title: "Password changed",
          message: "Your Tech Zone Academy password was changed successfully.",
          link: "/login",
          priority: "high",
          targetUserIds: [credential.user.uid],
          createdAt: serverTimestamp(),
        });
        await signOut(auth);
      } catch (notificationError) {
        console.error("Password changed notification could not be queued:", notificationError);
      }
      setSuccessMessage(
        "✅ Password reset successfully!\n\n" +
        "You can now login with your new password."
      );
      
      // Auto redirect after 3 seconds
      setTimeout(() => {
        navigate("/login");
      }, 3000);
      
    } catch (error) {
      if (error.code === "auth/expired-action-code") {
        setErrorMessage("❌ This password reset link has expired. Please request a new one.");
      } else if (error.code === "auth/invalid-action-code") {
        setErrorMessage("❌ Invalid password reset link. Please request a new one.");
      } else {
        setErrorMessage(`❌ ${error.message}`);
      }
    } finally {
      setLoading(false);
    }
  };

  if (!oobCode) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 p-4">
        <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">🔗</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Invalid Reset Link</h2>
          <p className="text-gray-600 mb-6">
            The password reset link is invalid or missing.
          </p>
          <Link
            to="/forgot-password"
            className="bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition font-medium inline-block"
          >
            Request New Link
          </Link>
        </div>
      </div>
    );
  }

  if (!validCode) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 p-4">
        <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Verifying your reset link...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="text-5xl mb-3">🔑</div>
          <h1 className="text-2xl font-bold text-gray-800">Reset Password</h1>
          <p className="text-gray-500 text-sm mt-1">
            {email ? `Reset password for ${email}` : "Create a new password"}
          </p>
        </div>

        {/* Success Message */}
        {successMessage && (
          <div className="mb-4 p-4 bg-green-50 border border-green-300 rounded-lg">
            <p className="text-green-700 text-sm whitespace-pre-line">{successMessage}</p>
            <p className="text-xs text-green-500 mt-2">⏳ Redirecting to login...</p>
          </div>
        )}

        {/* Error Message */}
        {errorMessage && (
          <div className="mb-4 p-4 bg-red-50 border border-red-300 rounded-lg">
            <p className="text-red-700 text-sm">{errorMessage}</p>
          </div>
        )}

        <form onSubmit={handleResetPassword} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              New Password
            </label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter new password (min 6 chars)"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition pr-12"
                minLength="6"
                required
                disabled={loading || !!successMessage}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
              >
                {showPassword ? "🙈" : "👁️"}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Confirm New Password
            </label>
            <input
              type={showPassword ? "text" : "password"}
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Confirm your new password"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
              required
              disabled={loading || !!successMessage}
            />
          </div>

          {password && confirmPassword && (
            <div className={`text-sm ${password === confirmPassword ? "text-green-600" : "text-red-600"}`}>
              {password === confirmPassword
                ? "✅ Passwords match"
                : "❌ Passwords do not match"}
            </div>
          )}

          <button
            type="submit"
            disabled={loading || !password || !confirmPassword || password !== confirmPassword || !!successMessage}
            className={`w-full py-3 rounded-lg font-semibold text-white transition ${
              loading || !password || !confirmPassword || password !== confirmPassword || !!successMessage
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-blue-700 hover:bg-blue-800 hover:shadow-lg"
            }`}
          >
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Resetting...
              </span>
            ) : (
              "Reset Password"
            )}
          </button>
        </form>

        {/* Back to Login */}
        <div className="mt-6 text-center">
          <Link
            to="/login"
            className="text-sm text-blue-600 hover:text-blue-800 transition font-medium"
          >
            ← Back to Login
          </Link>
        </div>
      </div>
    </div>
  );
}
