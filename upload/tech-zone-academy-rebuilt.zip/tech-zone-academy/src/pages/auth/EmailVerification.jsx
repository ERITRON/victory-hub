import { useCallback, useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { sendEmailVerification, auth } from "../../supabase/supabase";
import { useAuth } from "../../context/AuthContext";
import Icon from "../../components/Icon";

const CHECK_INTERVAL_MS = 5000;
const RESEND_COOLDOWN_SECONDS = 60;

const dashboardRoutes = {
  super_admin: "/super-admin/dashboard",
  owner: "/owner/dashboard",
  admin: "/admin-dashboard",
  vice_principal: "/vice-principal/dashboard",
  librarian: "/librarian/dashboard",
  teacher: "/teacher-dashboard",
  parent: "/parent-dashboard",
  student: "/student-dashboard",
};

export default function EmailVerification() {
  const navigate = useNavigate();
  const { user, role, loading } = useAuth();
  const [checking, setChecking] = useState(false);
  const [resending, setResending] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const [lastCheckedAt, setLastCheckedAt] = useState(null);
  const redirectedRef = useRef(false);

  const currentUser = auth.currentUser || user;
  const dashboardPath = dashboardRoutes[role] || "/";

  const redirectToDashboard = useCallback(() => {
    if (redirectedRef.current) return;
    redirectedRef.current = true;
    toast.success("Email verified. Redirecting to your dashboard...");
    navigate(dashboardPath, { replace: true });
  }, [dashboardPath, navigate]);

  const checkVerification = useCallback(
    async ({ manual = false } = {}) => {
      const activeUser = auth.currentUser || user;

      if (!activeUser) {
        if (manual) {
          toast.error("Please log in before checking verification status.");
        }
        navigate("/login", { replace: true });
        return false;
      }

      setChecking(true);
      try {
        await activeUser.reload();
        const refreshedUser = auth.currentUser || activeUser;
        const isVerified = refreshedUser.emailVerified;

        setLastCheckedAt(new Date());

        if (isVerified) {
          redirectToDashboard();
          return true;
        }

        if (manual) {
          toast("Your email is not verified yet. Please check your inbox.", {
            icon: "⏳",
          });
        }

        return false;
      } catch (error) {
        console.error("Email verification check failed:", error);
        if (manual) {
          toast.error("Could not check verification status. Try again.");
        }
        return false;
      } finally {
        setChecking(false);
      }
    },
    [navigate, redirectToDashboard, user]
  );

  useEffect(() => {
    if (loading) return undefined;

    if (!currentUser) {
      toast.error("Please log in to verify your email.");
      navigate("/login", { replace: true });
      return undefined;
    }

    if (currentUser.emailVerified) {
      redirectToDashboard();
      return undefined;
    }

    checkVerification();
    const intervalId = window.setInterval(() => {
      checkVerification();
    }, CHECK_INTERVAL_MS);

    return () => window.clearInterval(intervalId);
  }, [checkVerification, currentUser, loading, navigate, redirectToDashboard]);

  useEffect(() => {
    if (cooldown <= 0) return undefined;

    const timeoutId = window.setTimeout(() => {
      setCooldown((seconds) => Math.max(0, seconds - 1));
    }, 1000);

    return () => window.clearTimeout(timeoutId);
  }, [cooldown]);

  const handleResendEmail = async () => {
    const activeUser = auth.currentUser || user;

    if (!activeUser) {
      toast.error("Please log in before requesting another email.");
      navigate("/login", { replace: true });
      return;
    }

    if (cooldown > 0 || resending) return;

    setResending(true);
    try {
      await sendEmailVerification(activeUser);
      setCooldown(RESEND_COOLDOWN_SECONDS);
      toast.success("Verification email sent. Please check your inbox.");
    } catch (error) {
      console.error("Verification email resend failed:", error);

      if (error.code === "auth/too-many-requests") {
        toast.error("Too many requests. Please wait a moment before trying again.");
      } else {
        toast.error("Could not send verification email. Try again.");
      }
    } finally {
      setResending(false);
    }
  };

  const formattedLastCheckedAt = lastCheckedAt
    ? lastCheckedAt.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      })
    : "Not checked yet";

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 p-4">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading your verification status...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-purple-50 p-4">
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-blue-100 overflow-hidden">
        <div className="bg-blue-700 px-6 py-8 text-white text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-white/15 ring-1 ring-white/30">
            <Icon name="email" className="text-3xl" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold">Verify your email</h1>
          <p className="mt-2 text-sm text-blue-100">
            We need to confirm your email address before opening your dashboard.
          </p>
        </div>

        <div className="p-6 sm:p-8">
          <div className="rounded-xl border border-blue-100 bg-blue-50 p-4">
            <div className="flex items-start gap-3">
              <div className="mt-1 flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-blue-100 text-blue-700">
                <Icon name="info" />
              </div>
              <div>
                <p className="font-semibold text-gray-800">
                  Check the inbox for {currentUser?.email || "your email address"}.
                </p>
                <p className="mt-1 text-sm text-gray-600">
                  This page checks automatically every 5 seconds. Once your email is confirmed, you will be redirected.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-6 grid gap-3 sm:grid-cols-3">
            <div className="rounded-xl border border-gray-200 bg-gray-50 p-4">
              <div className="flex items-center gap-2 text-sm font-medium text-gray-500">
                <Icon name="pending" className="text-blue-700" />
                Status
              </div>
              <p className="mt-2 text-lg font-semibold text-gray-800">
                {currentUser?.emailVerified ? "Verified" : "Pending"}
              </p>
            </div>
            <div className="rounded-xl border border-gray-200 bg-gray-50 p-4">
              <div className="flex items-center gap-2 text-sm font-medium text-gray-500">
                <Icon name="refresh" className="text-blue-700" />
                Auto-check
              </div>
              <p className="mt-2 text-lg font-semibold text-gray-800">Every 5s</p>
            </div>
            <div className="rounded-xl border border-gray-200 bg-gray-50 p-4">
              <div className="flex items-center gap-2 text-sm font-medium text-gray-500">
                <Icon name="clock" className="text-blue-700" />
                Last check
              </div>
              <p className="mt-2 text-lg font-semibold text-gray-800">
                {formattedLastCheckedAt}
              </p>
            </div>
          </div>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <button
              type="button"
              onClick={() => checkVerification({ manual: true })}
              disabled={checking}
              className="flex-1 inline-flex items-center justify-center gap-2 rounded-lg bg-blue-700 px-4 py-3 text-sm font-semibold text-white transition hover:bg-blue-800 disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              <Icon name="success" />
              {checking ? "Checking..." : "I've verified, check again"}
            </button>

            <button
              type="button"
              onClick={handleResendEmail}
              disabled={resending || cooldown > 0}
              className="flex-1 inline-flex items-center justify-center gap-2 rounded-lg border border-blue-200 bg-white px-4 py-3 text-sm font-semibold text-blue-700 transition hover:bg-blue-50 disabled:border-gray-200 disabled:text-gray-400 disabled:cursor-not-allowed"
            >
              <Icon name="email" />
              {resending
                ? "Sending..."
                : cooldown > 0
                ? `Resend in ${cooldown}s`
                : "Resend email"}
            </button>
          </div>

          <div className="mt-6 rounded-xl border border-yellow-200 bg-yellow-50 p-4">
            <div className="flex items-start gap-3">
              <Icon name="warning" className="mt-1 text-yellow-600" />
              <div className="text-sm text-yellow-800">
                <p className="font-semibold">Still not seeing the email?</p>
                <p className="mt-1">
                  Check your spam folder, confirm you are logged in with the right account, or request another email after the cooldown finishes.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-6 text-center">
            <Link
              to="/login"
              className="text-sm font-medium text-blue-600 transition hover:text-blue-800"
            >
              Back to login
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
