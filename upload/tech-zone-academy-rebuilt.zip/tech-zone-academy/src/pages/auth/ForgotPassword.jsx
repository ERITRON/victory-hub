import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { resetPassword } from "../../supabase/auth";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const navigate = useNavigate();

  const handleResetPassword = async (e) => {
    e.preventDefault();
    setErrorMessage("");
    setSuccessMessage("");
    setLoading(true);

    if (!email) {
      setErrorMessage("⚠️ Please enter your email address.");
      setLoading(false);
      return;
    }

    try {
      await resetPassword(email);
      setSuccessMessage(
        `✅ Password reset email sent to ${email}.\n\n` +
        `Please check your inbox and follow the instructions to reset your password.`
      );
      setEmail("");
      
      // Auto redirect after 5 seconds
      setTimeout(() => {
        navigate("/login");
      }, 5000);
      
    } catch (error) {
      if (error.message.includes("No account found")) {
        setErrorMessage("❌ No account found with this email address.");
      } else if (error.message.includes("Invalid email")) {
        setErrorMessage("❌ Invalid email address format.");
      } else {
        setErrorMessage(`❌ ${error.message}`);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="text-5xl mb-3">🔐</div>
          <h1 className="text-2xl font-bold text-gray-800">Forgot Password</h1>
          <p className="text-gray-500 text-sm mt-1">
            Enter your email address and we'll send you a link to reset your password.
          </p>
        </div>

        {/* Success Message */}
        {successMessage && (
          <div className="mb-4 p-4 bg-green-50 border border-green-300 rounded-lg">
            <p className="text-green-700 text-sm whitespace-pre-line">{successMessage}</p>
            <p className="text-xs text-green-500 mt-2">⏳ Redirecting to login...</p>
          </div>
        )}

        {/* Error Message */}
        {errorMessage && (
          <div className="mb-4 p-4 bg-red-50 border border-red-300 rounded-lg">
            <p className="text-red-700 text-sm">{errorMessage}</p>
          </div>
        )}

        <form onSubmit={handleResetPassword} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Email Address
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your registered email"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
              required
              disabled={loading || !!successMessage}
            />
          </div>

          <button
            type="submit"
            disabled={loading || !email || !!successMessage}
            className={`w-full py-3 rounded-lg font-semibold text-white transition ${
              loading || !email || !!successMessage
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-blue-700 hover:bg-blue-800 hover:shadow-lg"
            }`}
          >
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Sending...
              </span>
            ) : (
              "Send Reset Link"
            )}
          </button>
        </form>

        {/* Back to Login */}
        <div className="mt-6 text-center">
          <Link
            to="/login"
            className="text-sm text-blue-600 hover:text-blue-800 transition font-medium"
          >
            ← Back to Login
          </Link>
        </div>

        {/* Info */}
        <div className="mt-4 text-center text-xs text-gray-400">
          <p>🔒 We'll send a password reset link to your email.</p>
          <p className="mt-1">Check your spam folder if you don't see the email.</p>
        </div>
      </div>
    </div>
  );
}