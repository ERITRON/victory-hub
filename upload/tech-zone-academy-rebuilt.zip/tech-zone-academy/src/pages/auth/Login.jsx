// src/pages/Login.jsx
import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { loginUser } from "../../supabase/auth";
import { db, doc, getDoc, collection, query, where, getDocs } from "../../supabase/supabase";

export default function Login() {
  const [userInput, setUserInput] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [selectedRole, setSelectedRole] = useState("");
  const [loginMethod, setLoginMethod] = useState("email");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const roles = [
    { id: "super_admin", label: "Super Owner", icon: "👑", color: "bg-red-100 border-red-500" },
    { id: "owner", label: "School Owner", icon: "🏢", color: "bg-purple-100 border-purple-500" },
    { id: "admin", label: "Principal", icon: "👔", color: "bg-indigo-100 border-indigo-500" },
    { id: "vice_principal", label: "Vice Principal", icon: "👔", color: "bg-purple-100 border-purple-500" },
    { id: "librarian", label: "Librarian", icon: "📚", color: "bg-indigo-100 border-indigo-500" },
    { id: "teacher", label: "Teacher", icon: "👨‍🏫", color: "bg-blue-100 border-blue-500" },
    { id: "parent", label: "Parent", icon: "👨‍👩‍👦", color: "bg-yellow-100 border-yellow-500" },
    { id: "student", label: "Student", icon: "🎓", color: "bg-orange-100 border-orange-500" },
  ];

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");

    if (!selectedRole) {
      setError("⚠️ Please select your role first!");
      return;
    }

    if (!userInput) {
      setError(`⚠️ Please enter your ${selectedRole === "student" ? "Student ID" : loginMethod === "email" ? "email" : "phone number"}!`);
      return;
    }

    if (!password) {
      setError("⚠️ Please enter your password!");
      return;
    }

    setLoading(true);

    try {
      let userEmail = "";

      if (selectedRole === "student") {
        const studentsQuery = query(
          collection(db, "students"),
          where("studentId", "==", userInput.toUpperCase())
        );
        const studentSnapshot = await getDocs(studentsQuery);

        if (studentSnapshot.empty) {
          setError("❌ Student ID not found. Please check and try again.");
          setLoading(false);
          return;
        }

        let studentData = {};
        studentSnapshot.forEach((doc) => {
          studentData = { id: doc.id, ...doc.data() };
        });

        userEmail = studentData.studentEmail || `${studentData.studentId.toLowerCase()}@student.techzone.com`;

        if (!studentData.userId) {
          setError("❌ No login account found for this student. Please contact admin.");
          setLoading(false);
          return;
        }
      } else {
        if (loginMethod === "phone") {
          const usersQuery = query(
            collection(db, "users"),
            where("phone", "==", userInput)
          );
          const userSnapshot = await getDocs(usersQuery);

          if (userSnapshot.empty) {
            setError("❌ Phone number not found. Please check and try again.");
            setLoading(false);
            return;
          }

          let userData = {};
          userSnapshot.forEach((doc) => {
            userData = { id: doc.id, ...doc.data() };
          });

          userEmail = userData.email;

          if (!userEmail) {
            setError("❌ No email found for this phone number. Please contact admin.");
            setLoading(false);
            return;
          }
        } else {
          userEmail = userInput;
        }
      }

      const userCredential = await loginUser(userEmail, password);
      const uid = userCredential.user.uid;

      if (selectedRole === "student") {
        const studentDoc = await getDoc(doc(db, "students", uid));
        if (!studentDoc.exists()) {
          setError("❌ Student account not found. Please contact admin.");
          setLoading(false);
          return;
        }
        navigate("/student-dashboard");
        setLoading(false);
        return;
      }

      const userDoc = await getDoc(doc(db, "users", uid));
      if (!userDoc.exists()) {
        setError("❌ User account not found. Please contact admin.");
        setLoading(false);
        return;
      }

      const userData = userDoc.data();
      const userRole = userData.role;

      if (userRole !== selectedRole) {
        setError(`❌ This account is registered as "${userRole}". Please select the correct role.`);
        setLoading(false);
        return;
      }

      if (userData.approved === false) {
        setError("⏳ Your account is pending approval.");
        setLoading(false);
        return;
      }

      if (userData.status === "inactive") {
        setError("❌ Your account has been deactivated.");
        setLoading(false);
        return;
      }

      switch (userRole) {
        case "super_admin": 
          navigate("/super-admin/dashboard"); 
          break;
        case "owner": 
          navigate("/owner/dashboard"); 
          break;
        case "admin": 
          navigate("/admin-dashboard"); 
          break;
        case "vice_principal": 
          navigate("/vice-principal/dashboard"); 
          break;
        case "librarian": 
          navigate("/librarian/dashboard"); 
          break;
        case "teacher": 
          navigate("/teacher-dashboard"); 
          break;
        case "parent": 
          navigate("/parent-dashboard"); 
          break;
        default: 
          navigate("/");
      }

    } catch (error) {
      console.error("Login error:", error);
      
      if (error.message.includes("Incorrect password") || 
          error.message.includes("Invalid email or password")) {
        setError("❌ Incorrect password. Please try again.");
      } else if (error.message.includes("No account found")) {
        setError(`❌ No account found with this ${selectedRole === "student" ? "Student ID" : loginMethod === "email" ? "email" : "phone number"}.`);
      } else if (error.message.includes("Network error")) {
        setError("❌ Network error. Please check your internet connection.");
      } else {
        setError(`❌ ${error.message}`);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full">
        <div className="text-center mb-8">
          <div className="text-4xl mb-2">🏫</div>
          <h1 className="text-2xl font-bold text-blue-700">Tech Zone Academy</h1>
          <p className="text-gray-500 text-sm">Login to your account</p>
        </div>

        {error && (
          <div className="mb-4 p-4 bg-red-50 border border-red-300 rounded-lg">
            <p className="text-red-700 text-sm font-medium">{error}</p>
          </div>
        )}

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">Select Your Role</label>
          <div className="grid grid-cols-2 gap-2">
            {roles.map((role) => (
              <button
                key={role.id}
                type="button"
                onClick={() => setSelectedRole(role.id)}
                className={`p-3 rounded-lg border-2 transition-all ${
                  selectedRole === role.id
                    ? `${role.color} border-2 border-opacity-100 shadow-md scale-105`
                    : "bg-gray-50 border-gray-200 hover:bg-gray-100"
                }`}
              >
                <div className="text-2xl">{role.icon}</div>
                <div className="text-sm font-medium">{role.label}</div>
              </button>
            ))}
          </div>
        </div>

        {selectedRole !== "student" && (
          <div className="flex gap-2 p-1 bg-gray-100 rounded-lg mb-4">
            <button
              type="button"
              onClick={() => setLoginMethod("email")}
              className={`flex-1 py-2 rounded-md text-sm font-medium transition ${
                loginMethod === "email"
                  ? "bg-white text-blue-700 shadow-sm"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              📧 Email
            </button>
            <button
              type="button"
              onClick={() => setLoginMethod("phone")}
              className={`flex-1 py-2 rounded-md text-sm font-medium transition ${
                loginMethod === "phone"
                  ? "bg-white text-blue-700 shadow-sm"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              📱 Phone
            </button>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {selectedRole === "student" ? "Student ID" : loginMethod === "email" ? "Email Address" : "Phone Number"}
            </label>
            <input
              type={selectedRole === "student" ? "text" : loginMethod === "email" ? "email" : "tel"}
              value={userInput}
              onChange={(e) => setUserInput(selectedRole === "student" ? e.target.value.toUpperCase() : e.target.value)}
              placeholder={
                selectedRole === "student"
                  ? "Enter Student ID (e.g., STU001)"
                  : loginMethod === "email"
                  ? "Enter your email"
                  : "Enter phone number (e.g., 0912345678)"
              }
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition pr-12"
                disabled={loading}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
              >
                {showPassword ? "🙈" : "👁️"}
              </button>
            </div>
          </div>

          <div className="text-right">
            <Link
              to="/forgot-password"
              className="text-xs text-blue-600 hover:text-blue-800 transition font-medium"
            >
              Forgot Password?
            </Link>
          </div>

          <button
            type="submit"
            disabled={loading || !selectedRole}
            className={`w-full py-3 rounded-lg font-semibold text-white transition ${
              loading || !selectedRole
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-blue-700 hover:bg-blue-800 hover:shadow-lg"
            }`}
          >
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Logging in...
              </span>
            ) : (
              "🔑 Login"
            )}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-xs text-gray-400">🔒 Secure login powered by Supabase</p>
          <p className="text-xs text-gray-400 mt-1">Contact admin if you have trouble logging in</p>
        </div>
      </div>
    </div>
  );
}