// src/pages/EditResult.jsx
import { useState, useEffect } from "react";
import { useAuth } from "../../context/AuthContext";
import { db, doc, getDoc, updateDoc, deleteDoc, collection, query, where, getDocs } from "../../supabase/supabase";
import { useNavigate, useParams } from "react-router-dom";

export default function EditResult() {
  const { resultId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [result, setResult] = useState(null);
  const [, setStudentInfo] = useState(null);
  
  // Form fields
  const [subject, setSubject] = useState("");
  const [assessment, setAssessment] = useState("");
  const [assessmentType, setAssessmentType] = useState("test");
  const [score, setScore] = useState("");
  const [maxScore, setMaxScore] = useState("");
  const [date, setDate] = useState("");
  const [remark, setRemark] = useState("");
  const [grade, setGrade] = useState("");
  const [section, setSection] = useState("");
  const [studentName, setStudentName] = useState("");

  // Assessment types
  const assessmentTypes = [
    { value: "test", label: "📝 Test" },
    { value: "class_activity", label: "📋 Class Activity" },
    { value: "assignment", label: "📄 Assignment" },
    { value: "exam", label: "📊 Exam" },
  ];

  const fetchResult = async () => {
    setLoading(true);
    setError("");
    try {
      // Get the result
      const resultDoc = await getDoc(doc(db, "results", resultId));
      if (!resultDoc.exists()) {
        setError("Result not found");
        setLoading(false);
        return;
      }

      const resultData = { id: resultDoc.id, ...resultDoc.data() };
      setResult(resultData);

      // Populate form fields
      setSubject(resultData.subject || "");
      setAssessment(resultData.assessment || "");
      setAssessmentType(resultData.assessmentType || "test");
      setScore(String(resultData.score || ""));
      setMaxScore(String(resultData.outOf || ""));
      setDate(resultData.date || "");
      setRemark(resultData.remark || "");
      setGrade(resultData.grade || "");
      setSection(resultData.section || "");
      setStudentName(resultData.studentName || "");

      // Fetch student info if studentId exists
      if (resultData.studentId) {
        const studentQuery = query(
          collection(db, "students"),
          where("studentId", "==", resultData.studentId)
        );
        const studentSnap = await getDocs(studentQuery);
        if (!studentSnap.empty) {
          studentSnap.forEach((doc) => {
            setStudentInfo({ id: doc.id, ...doc.data() });
          });
        }
      }

    } catch (error) {
      setError("Error loading result: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user && resultId) {
      fetchResult();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- fetchResult is a stable helper; re-fetch only when the user or resultId changes
  }, [user, resultId]);

  const validateScore = () => {
    if (!score || !maxScore) return true;
    const scoreNum = Number(score);
    const maxNum = Number(maxScore);
    if (scoreNum > maxNum) {
      setError(`Score (${scoreNum}) cannot be greater than max score (${maxNum})`);
      return false;
    }
    if (scoreNum < 0) {
      setError("Score cannot be negative");
      return false;
    }
    if (maxNum <= 0) {
      setError("Max score must be greater than 0");
      return false;
    }
    return true;
  };

  const handleScoreChange = (value) => {
    setScore(value);
    setError("");
    if (maxScore && value) {
      const scoreNum = Number(value);
      const maxNum = Number(maxScore);
      if (scoreNum > maxNum) {
        setError(`Score (${scoreNum}) cannot exceed max score (${maxNum})`);
      }
    }
  };

  const handleMaxScoreChange = (value) => {
    setMaxScore(value);
    setError("");
    if (score && value) {
      const scoreNum = Number(score);
      const maxNum = Number(value);
      if (scoreNum > maxNum) {
        setError(`Score (${scoreNum}) cannot exceed max score (${maxNum})`);
      }
    }
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    
    // Validate
    if (!validateScore()) {
      return;
    }

    setSaving(true);
    setError("");
    setSuccess("");

    try {
      await updateDoc(doc(db, "results", resultId), {
        subject: subject,
        assessment: assessment,
        assessmentType: assessmentType,
        score: Number(score),
        outOf: Number(maxScore),
        date: date,
        remark: remark || "",
        updatedAt: new Date().toISOString(),
        updatedBy: user.uid,
      });

      setSuccess("✅ Result updated successfully!");

      // Refresh the result data
      await fetchResult();

      // Scroll to top to show success message
      window.scrollTo({ top: 0, behavior: "smooth" });

    } catch (error) {
      setError("Error updating result: " + error.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm(`Are you sure you want to delete this result for ${studentName}?`)) {
      return;
    }

    setSaving(true);
    setError("");

    try {
      await deleteDoc(doc(db, "results", resultId));
      setSuccess("✅ Result deleted successfully!");
      
      // Navigate back after a short delay
      setTimeout(() => {
        navigate("/teacher-results");
      }, 1500);

    } catch (error) {
      setError("Error deleting result: " + error.message);
    } finally {
      setSaving(false);
    }
  };

  const getScoreColor = () => {
    if (!score || !maxScore) return "text-gray-600";
    const percentage = (Number(score) / Number(maxScore)) * 100;
    if (percentage >= 80) return "text-green-600";
    if (percentage >= 60) return "text-yellow-600";
    if (percentage >= 40) return "text-orange-600";
    return "text-red-600";
  };

  const getPercentage = () => {
    if (!score || !maxScore || Number(maxScore) === 0) return 0;
    return Math.round((Number(score) / Number(maxScore)) * 100);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading result...</p>
        </div>
      </div>
    );
  }

  if (error && !result) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">❌</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Error Loading Result</h2>
          <p className="text-gray-600">{error}</p>
          <button
            onClick={() => navigate("/teacher-results")}
            className="mt-4 bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition"
          >
            Back to Results
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => navigate("/teacher-results")}
            className="text-gray-600 hover:text-gray-800 transition p-2 hover:bg-gray-100 rounded-lg"
          >
            ← Back
          </button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              ✏️ Edit Result
            </h1>
            <p className="text-gray-600 text-sm mt-1">
              {studentName || "Student"} • {grade || ""} {section ? `- Section ${section}` : ""}
            </p>
          </div>
          <div className="ml-auto">
            <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
              👨‍🏫 Teacher
            </span>
          </div>
        </div>

        {/* Error/Success Messages */}
        {error && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            ❌ {error}
          </div>
        )}
        {success && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {success}
          </div>
        )}

        {/* Score Preview Card */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-medium text-gray-500">Current Score</h3>
              <div className="flex items-center gap-4 mt-1">
                <span className="text-3xl font-bold">{score || "—"}</span>
                <span className="text-gray-400 text-xl">/</span>
                <span className="text-3xl font-bold text-gray-600">{maxScore || "—"}</span>
              </div>
              <p className="text-sm text-gray-500 mt-1">
                {assessment || "No assessment"} • {assessmentType}
              </p>
            </div>
            <div className="text-right">
              <div className={`text-2xl font-bold ${getScoreColor()}`}>
                {getPercentage()}%
              </div>
              <div className="w-24 h-2 bg-gray-200 rounded-full mt-1 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    getPercentage() >= 80 ? "bg-green-500" :
                    getPercentage() >= 60 ? "bg-yellow-500" :
                    getPercentage() >= 40 ? "bg-orange-500" :
                    "bg-red-500"
                  }`}
                  style={{ width: `${Math.min(getPercentage(), 100)}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Edit Form */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <form onSubmit={handleUpdate}>
            {/* Student Info (Read-only) */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
              <div className="bg-gray-50 rounded-lg p-3">
                <label className="block text-xs font-medium text-gray-500">Student</label>
                <p className="font-medium text-gray-800 mt-1">{studentName || "N/A"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-3">
                <label className="block text-xs font-medium text-gray-500">Grade</label>
                <p className="font-medium text-gray-800 mt-1">{grade || "N/A"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-3">
                <label className="block text-xs font-medium text-gray-500">Section</label>
                <p className="font-medium text-gray-800 mt-1">{section || "N/A"}</p>
              </div>
            </div>

            {/* Editable Fields */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Subject *
                </label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Assessment Name *
                </label>
                <input
                  type="text"
                  value={assessment}
                  onChange={(e) => setAssessment(e.target.value)}
                  className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Assessment Type *
                </label>
                <select
                  value={assessmentType}
                  onChange={(e) => setAssessmentType(e.target.value)}
                  className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  {assessmentTypes.map((type) => (
                    <option key={type.value} value={type.value}>{type.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Date
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Score Section with Validation */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Score *
                </label>
                <input
                  type="number"
                  value={score}
                  onChange={(e) => handleScoreChange(e.target.value)}
                  className={`w-full border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none ${
                    score && maxScore && Number(score) > Number(maxScore) 
                      ? 'border-red-500 bg-red-50' 
                      : ''
                  }`}
                  min="0"
                  required
                />
                {score && maxScore && Number(score) > Number(maxScore) && (
                  <p className="text-xs text-red-500 mt-1">
                    Score cannot exceed {maxScore}
                  </p>
                )}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Max Score *
                </label>
                <input
                  type="number"
                  value={maxScore}
                  onChange={(e) => handleMaxScoreChange(e.target.value)}
                  className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  min="1"
                  required
                />
              </div>
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Remark (Optional)
              </label>
              <input
                type="text"
                value={remark}
                onChange={(e) => setRemark(e.target.value)}
                placeholder="e.g., Excellent work, Needs improvement, etc."
                className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-3">
              <button
                type="submit"
                disabled={saving || (score && maxScore && Number(score) > Number(maxScore))}
                className={`flex-1 py-3 rounded-lg text-white font-semibold transition ${
                  saving || (score && maxScore && Number(score) > Number(maxScore))
                    ? "bg-gray-400 cursor-not-allowed"
                    : "bg-blue-700 hover:bg-blue-800"
                }`}
              >
                {saving ? "Saving..." : "💾 Update Result"}
              </button>
              <button
                type="button"
                onClick={handleDelete}
                disabled={saving}
                className="px-6 py-3 rounded-lg bg-red-600 text-white font-semibold hover:bg-red-700 transition disabled:bg-gray-400"
              >
                🗑️ Delete
              </button>
              <button
                type="button"
                onClick={() => navigate("/teacher-results")}
                className="px-6 py-3 rounded-lg bg-gray-200 text-gray-700 font-semibold hover:bg-gray-300 transition"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>

        {/* Result History */}
        {result && (
          <div className="mt-6 bg-white rounded-xl shadow-md p-4">
            <h3 className="text-sm font-semibold text-gray-700 mb-2">📋 Result Details</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="bg-gray-50 rounded p-2">
                <span className="text-gray-500">Created</span>
                <p className="font-medium">{result.createdAt ? new Date(result.createdAt).toLocaleDateString() : "N/A"}</p>
              </div>
              <div className="bg-gray-50 rounded p-2">
                <span className="text-gray-500">Last Updated</span>
                <p className="font-medium">{result.updatedAt ? new Date(result.updatedAt).toLocaleDateString() : "N/A"}</p>
              </div>
              <div className="bg-gray-50 rounded p-2">
                <span className="text-gray-500">Result ID</span>
                <p className="font-medium text-xs truncate">{resultId}</p>
              </div>
              <div className="bg-gray-50 rounded p-2">
                <span className="text-gray-500">Status</span>
                <p className={`font-medium ${getPercentage() >= 50 ? "text-green-600" : "text-red-600"}`}>
                  {getPercentage() >= 50 ? "✅ Passing" : "❌ Needs Improvement"}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}