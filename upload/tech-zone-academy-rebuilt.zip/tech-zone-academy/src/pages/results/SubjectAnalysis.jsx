import { useEffect, useMemo, useState } from "react";
import { collection, getDocs } from "../../supabase/supabase";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import SEO from "../../components/SEO";
import { db } from "../../supabase/supabase";

const PASS_MARK = 50;
const INITIAL_FILTERS = { subject: "All", grade: "All", assessmentType: "All", assessmentName: "All" };
const numberValue = (value) => { const number = Number(value); return Number.isFinite(number) ? number : 0; };
const firstValue = (item, keys, fallback = "") => { for (const key of keys) if (item?.[key] !== undefined && item[key] !== null && item[key] !== "") return item[key]; return fallback; };
const getStudentId = (item) => String(firstValue(item, ["studentId", "studentID", "student_id", "uid", "id"], ""));
const getName = (student) => { const name = firstValue(student, ["fullName", "name", "studentName"]); return name ? String(name) : `${firstValue(student, ["firstName", "firstname"], "")} ${firstValue(student, ["fatherName", "lastName", "lastname"], "")}`.trim() || "Unnamed Student"; };
const getGrade = (item) => String(firstValue(item, ["grade", "class", "className"], ""));
const getSubject = (item) => String(firstValue(item, ["subject", "subjectName", "course"], "General"));
const getAssessmentType = (item) => String(firstValue(item, ["assessmentType", "examType", "type"], "General"));
const getAssessmentName = (item) => String(firstValue(item, ["assessment", "assessmentName", "examName"], getAssessmentType(item)));
const getScore = (item) => numberValue(firstValue(item, ["score", "marks", "marksObtained", "obtainedMarks"], 0));
const getMax = (item) => numberValue(firstValue(item, ["outOf", "maxScore", "maximumScore", "totalMarks", "maxMarks"], 100)) || 100;
const formatNumber = (value) => new Intl.NumberFormat("en-US", { maximumFractionDigits: 1 }).format(value);
const pct = (value) => `${formatNumber(value)}%`;

const normalizeResult = (item) => ({ ...item, studentId: getStudentId(item), grade: getGrade(item), subject: getSubject(item), assessmentType: getAssessmentType(item), assessmentName: getAssessmentName(item), score: getScore(item), maxScore: getMax(item) });
const percentage = (result) => result.maxScore ? (result.score / result.maxScore) * 100 : 0;
const gradeBand = (value) => value >= 90 ? "A" : value >= 80 ? "B" : value >= 70 ? "C" : value >= 60 ? "D" : "F";
const rangeFor = (value) => value >= 90 ? 0 : value >= 80 ? 1 : value >= 70 ? 2 : value >= 60 ? 3 : 4;

function StatCard({ title, value, subtitle, icon, tone }) {
  return <div className="relative overflow-hidden rounded-2xl border border-slate-100 bg-white p-5 shadow-sm"><div className={`absolute right-0 top-0 h-20 w-20 -translate-y-8 translate-x-8 rounded-full opacity-20 ${tone}`} /><div className="relative flex items-start justify-between gap-3"><div><p className="text-sm font-medium text-slate-500">{title}</p><p className="mt-2 text-2xl font-bold tracking-tight text-slate-900">{value}</p><p className="mt-1 text-xs text-slate-500">{subtitle}</p></div><span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-xl ${tone}`}>{icon}</span></div></div>;
}

function DistributionCard({ label, count, total, color }) {
  const share = total ? (count / total) * 100 : 0;
  return <div className="rounded-2xl border border-slate-100 bg-white p-4 shadow-sm"><div className="flex items-center justify-between gap-2"><span className="font-semibold text-slate-800">{label}</span><span className="text-lg font-bold text-slate-900">{count}</span></div><div className="mt-3 h-2 overflow-hidden rounded-full bg-slate-100"><div className={`h-full rounded-full ${color}`} style={{ width: `${share}%` }} /></div><p className="mt-2 text-xs text-slate-500">{pct(share)} of results</p></div>;
}

export default function SubjectAnalysis() {
  const [students, setStudents] = useState([]);
  const [results, setResults] = useState([]);
  const [filters, setFilters] = useState(INITIAL_FILTERS);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    Promise.all([getDocs(collection(db, "students")), getDocs(collection(db, "results"))]).then(([studentSnapshot, resultSnapshot]) => {
      if (!active) return;
      setStudents(studentSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
      setResults(resultSnapshot.docs.map((doc) => normalizeResult({ id: doc.id, ...doc.data() })));
    }).catch((fetchError) => { console.error("Unable to load subject analysis", fetchError); if (active) setError("Unable to load subject data. Check Firestore permissions and try again."); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  const studentMap = useMemo(() => new Map(students.flatMap((student) => [[getStudentId(student), student], [String(student.id), student]])), [students]);
  const options = useMemo(() => {
    const subjects = new Set(results.map((result) => result.subject));
    const grades = new Set(results.map((result) => result.grade));
    const types = new Set(results.map((result) => result.assessmentType));
    const names = new Set(results.map((result) => result.assessmentName));
    return { subjects: [...subjects].filter(Boolean).sort(), grades: [...grades].filter(Boolean).sort((a, b) => a.localeCompare(b, undefined, { numeric: true })), types: [...types].filter(Boolean).sort(), names: [...names].filter(Boolean).sort() };
  }, [results]);

  const assessmentNames = useMemo(() => [...new Set(results.filter((result) => (filters.subject === "All" || result.subject === filters.subject) && (filters.grade === "All" || result.grade === filters.grade) && (filters.assessmentType === "All" || result.assessmentType === filters.assessmentType)).map((result) => result.assessmentName))].filter(Boolean).sort(), [filters, results]);

  const filteredResults = useMemo(() => results.filter((result) => (filters.subject === "All" || result.subject === filters.subject) && (filters.grade === "All" || result.grade === filters.grade) && (filters.assessmentType === "All" || result.assessmentType === filters.assessmentType) && (filters.assessmentName === "All" || result.assessmentName === filters.assessmentName)), [filters, results]);

  const analysis = useMemo(() => {
    const totalResults = filteredResults.length;
    const percentages = filteredResults.map(percentage);
    const scoreDistribution = ["90-100%", "80-89%", "70-79%", "60-69%", "Below 60%"].map((label, index) => ({ label, count: percentages.filter((value) => rangeFor(value) === index).length, color: ["bg-emerald-500", "bg-blue-500", "bg-violet-500", "bg-amber-500", "bg-rose-500"][index] }));
    const gradeDistribution = ["A", "B", "C", "D", "F"].map((label) => ({ label, count: percentages.filter((value) => gradeBand(value) === label).length, color: { A: "bg-emerald-500", B: "bg-blue-500", C: "bg-violet-500", D: "bg-amber-500", F: "bg-rose-500" }[label] }));
    const groupedAssessments = new Map();
    const groupedGrades = new Map();
    const groupedStudents = new Map();
    filteredResults.forEach((result) => {
      const assessment = groupedAssessments.get(result.assessmentName) || { name: result.assessmentName, type: result.assessmentType, results: [] };
      assessment.results.push(result); groupedAssessments.set(result.assessmentName, assessment);
      const grade = groupedGrades.get(result.grade || "Unknown") || { grade: result.grade || "Unknown", results: [] };
      grade.results.push(result); groupedGrades.set(result.grade || "Unknown", grade);
      const student = groupedStudents.get(result.studentId) || { studentId: result.studentId, student: studentMap.get(result.studentId) || {}, grade: result.grade, totalScore: 0, totalMax: 0, count: 0 };
      student.totalScore += result.score; student.totalMax += result.maxScore; student.count += 1; groupedStudents.set(result.studentId, student);
    });
    // Headline stats are per-student: each student's cumulative percentage
    // across the filtered results, averaged and checked against PASS_MARK.
    const studentPercents = [...groupedStudents.entries()].filter(([id]) => id).map(([, entry]) => (entry.totalMax ? (entry.totalScore / entry.totalMax) * 100 : 0));
    const totalStudents = studentPercents.length;
    const averageScore = totalStudents ? studentPercents.reduce((sum, value) => sum + value, 0) / totalStudents : 0;
    const passRate = totalStudents ? (studentPercents.filter((value) => value >= PASS_MARK).length / totalStudents) * 100 : 0;
    const summarize = (items) => { const score = items.reduce((sum, result) => sum + result.score, 0); const max = items.reduce((sum, result) => sum + result.maxScore, 0); const values = items.map(percentage); return { average: max ? (score / max) * 100 : 0, passRate: items.length ? (values.filter((value) => value >= PASS_MARK).length / items.length) * 100 : 0, highest: values.length ? Math.max(...values) : 0, lowest: values.length ? Math.min(...values) : 0 }; };
    const assessmentBreakdown = [...groupedAssessments.values()].map((group) => ({ ...group, students: new Set(group.results.map((result) => result.studentId)).size, ...summarize(group.results) })).sort((a, b) => b.average - a.average);
    const gradePerformance = [...groupedGrades.values()].map((group) => ({ grade: group.grade, students: new Set(group.results.map((result) => result.studentId)).size, results: group.results.length, ...summarize(group.results) })).sort((a, b) => a.grade.localeCompare(b.grade, undefined, { numeric: true }));
    const topPerformers = [...groupedStudents.values()].map((student) => ({ ...student, name: getName(student.student), percentage: student.totalMax ? (student.totalScore / student.totalMax) * 100 : 0 })).sort((a, b) => b.percentage - a.percentage).slice(0, 10);
    return { totalResults, totalStudents, averageScore, passRate, highest: percentages.length ? Math.max(...percentages) : 0, lowest: percentages.length ? Math.min(...percentages) : 0, scoreDistribution, gradeDistribution, assessmentBreakdown, gradePerformance, topPerformers };
  }, [filteredResults, studentMap]);

  const exportRows = useMemo(() => analysis.assessmentBreakdown.map((row) => ({ Assessment: row.name, Type: row.type, Students: row.students, Average: pct(row.average), "Pass Rate": pct(row.passRate), Highest: pct(row.highest), Lowest: pct(row.lowest) })), [analysis.assessmentBreakdown]);
  const exportReport = (format) => {
    if (!filteredResults.length) return;
    if (format === "excel") { const workbook = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(exportRows), "Assessments"); XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(analysis.gradePerformance.map((row) => ({ Grade: row.grade, Students: row.students, Results: row.results, Average: pct(row.average), "Pass Rate": pct(row.passRate) }))), "Grades"); XLSX.writeFile(workbook, `subject-analysis-${new Date().toISOString().slice(0, 10)}.xlsx`); return; }
    const pdf = new jsPDF({ orientation: "landscape" }); pdf.setFontSize(18); pdf.text(`Subject Analysis${filters.subject !== "All" ? `: ${filters.subject}` : ""}`, 14, 16); pdf.setFontSize(9); pdf.setTextColor(100); pdf.text(`Generated ${new Date().toLocaleString()}`, 14, 23); autoTable(pdf, { startY: 29, head: [["Assessment", "Type", "Students", "Average", "Pass Rate", "Highest", "Lowest"]], body: exportRows.map((row) => Object.values(row)), headStyles: { fillColor: [15, 23, 42] }, styles: { fontSize: 9 } }); pdf.save(`subject-analysis-${new Date().toISOString().slice(0, 10)}.pdf`);
  };

  const updateFilter = (event) => { setFilters((current) => ({ ...current, [event.target.name]: event.target.value })); };
  const resetFilters = () => setFilters(INITIAL_FILTERS);
  const filterConfig = [{ key: "subject", label: "Subject", values: options.subjects }, { key: "grade", label: "Grade", values: options.grades }, { key: "assessmentType", label: "Assessment Type", values: options.types }, { key: "assessmentName", label: "Assessment Name", values: assessmentNames }];

  return <><SEO title="Subject Analysis" description="Detailed subject performance analysis and assessment insights." /><main className="min-h-screen bg-slate-50 px-4 py-6 sm:px-6 lg:px-8"><div className="mx-auto max-w-7xl">
    <header className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-indigo-950 to-violet-800 px-6 py-8 text-white shadow-xl sm:px-8"><div className="absolute -right-20 -top-24 h-72 w-72 rounded-full bg-cyan-400/20 blur-3xl" /><div className="relative flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between"><div><p className="mb-3 inline-flex rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-semibold tracking-wide text-indigo-100">ACADEMIC INSIGHTS</p><h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Subject Analysis</h1><p className="mt-3 max-w-2xl text-sm leading-6 text-indigo-100 sm:text-base">Understand achievement patterns, assessment outcomes, and grade-level performance.</p></div><div className="flex flex-wrap gap-3"><button type="button" onClick={() => exportReport("pdf")} disabled={!filteredResults.length} className="rounded-xl border border-white/20 bg-white/10 px-4 py-2.5 text-sm font-semibold hover:bg-white/20 disabled:opacity-50">📄 Export PDF</button><button type="button" onClick={() => exportReport("excel")} disabled={!filteredResults.length} className="rounded-xl bg-white px-4 py-2.5 text-sm font-semibold text-indigo-800 hover:bg-indigo-50 disabled:opacity-50">📊 Export Excel</button></div></div></header>
    <section className="mt-6 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5"><div className="mb-4 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between"><div><h2 className="font-bold text-slate-900">Analysis filters</h2><p className="text-sm text-slate-500">Choose a subject and assessment scope.</p></div><button type="button" onClick={resetFilters} className="self-start text-sm font-semibold text-indigo-600 hover:text-indigo-800 sm:self-auto">Reset filters</button></div><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{filterConfig.map(({ key, label, values }) => <label key={key}><span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">{label}</span><select name={key} value={filters[key]} onChange={updateFilter} className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-700 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"><option value="All">All {label}s</option>{values.map((value) => <option key={value} value={value}>{value}</option>)}</select></label>)}</div></section>
    {loading ? <div className="mt-6 animate-pulse space-y-6"><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{Array.from({ length: 6 }).map((_, index) => <div key={index} className="h-32 rounded-2xl bg-slate-200" />)}</div><div className="h-80 rounded-2xl bg-slate-200" /></div> : error ? <div className="mt-6 flex min-h-72 flex-col items-center justify-center rounded-2xl bg-white px-5 text-center shadow-sm"><span className="text-4xl">⚠</span><h2 className="mt-3 text-lg font-bold text-slate-800">Unable to load analysis</h2><p className="mt-2 max-w-md text-sm text-slate-500">{error}</p></div> : !filteredResults.length ? <div className="mt-6 flex min-h-72 flex-col items-center justify-center rounded-2xl bg-white px-5 text-center shadow-sm"><span className="text-5xl">📊</span><h2 className="mt-3 text-lg font-bold text-slate-800">No results found</h2><p className="mt-2 max-w-md text-sm text-slate-500">No results match the selected subject and filters.</p><button type="button" onClick={resetFilters} className="mt-5 rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700">Clear filters</button></div> : <>
      <section className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-3"><StatCard title="Total Results" value={formatNumber(analysis.totalResults)} subtitle="Recorded assessments" icon="📝" tone="bg-indigo-100 text-indigo-600" /><StatCard title="Total Students" value={formatNumber(analysis.totalStudents)} subtitle="Unique students" icon="👩‍🎓" tone="bg-cyan-100 text-cyan-600" /><StatCard title="Average Score" value={pct(analysis.averageScore)} subtitle="Average of student percentages" icon="📈" tone="bg-violet-100 text-violet-600" /><StatCard title="Pass Rate" value={pct(analysis.passRate)} subtitle={`Students at ${PASS_MARK}% or above`} icon="✓" tone="bg-emerald-100 text-emerald-600" /><StatCard title="Highest Score" value={pct(analysis.highest)} subtitle="Best percentage recorded" icon="⬆" tone="bg-amber-100 text-amber-600" /><StatCard title="Lowest Score" value={pct(analysis.lowest)} subtitle="Lowest percentage recorded" icon="⬇" tone="bg-rose-100 text-rose-600" /></section>
      <section className="mt-6 grid gap-6 lg:grid-cols-2"><div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><h2 className="text-lg font-bold text-slate-900">Score distribution</h2><p className="mt-1 text-sm text-slate-500">Results grouped by percentage band.</p><div className="mt-5 grid gap-3 sm:grid-cols-2">{analysis.scoreDistribution.map((item) => <DistributionCard key={item.label} {...item} total={analysis.totalResults} />)}</div></div><div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><h2 className="text-lg font-bold text-slate-900">Grade distribution</h2><p className="mt-1 text-sm text-slate-500">A to F performance bands across results.</p><div className="mt-5 grid gap-3 sm:grid-cols-2">{analysis.gradeDistribution.map((item) => <DistributionCard key={item.label} {...item} total={analysis.totalResults} />)}</div></div></section>
      <section className="mt-6 rounded-2xl border border-slate-200 bg-white shadow-sm"><div className="border-b border-slate-100 px-5 py-5"><h2 className="text-lg font-bold text-slate-900">Assessment breakdown</h2><p className="text-sm text-slate-500">Compare each assessment within the selected subject.</p></div><div className="overflow-x-auto"><table className="w-full min-w-[850px] text-left"><thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500"><tr>{["Assessment", "Type", "Students", "Average", "Pass Rate", "Highest", "Lowest"].map((heading) => <th key={heading} className="px-5 py-4 font-semibold">{heading}</th>)}</tr></thead><tbody className="divide-y divide-slate-100">{analysis.assessmentBreakdown.map((row) => <tr key={row.name} className="hover:bg-indigo-50/40"><td className="px-5 py-4 font-semibold text-slate-800">{row.name}</td><td className="px-5 py-4 text-sm text-slate-600">{row.type}</td><td className="px-5 py-4 text-sm text-slate-700">{row.students}</td><td className="px-5 py-4 text-sm font-semibold text-slate-800">{pct(row.average)}</td><td className="px-5 py-4 text-sm font-semibold text-emerald-700">{pct(row.passRate)}</td><td className="px-5 py-4 text-sm text-slate-700">{pct(row.highest)}</td><td className="px-5 py-4 text-sm text-slate-700">{pct(row.lowest)}</td></tr>)}</tbody></table></div></section>
      <section className="mt-6 rounded-2xl border border-slate-200 bg-white shadow-sm"><div className="border-b border-slate-100 px-5 py-5"><h2 className="text-lg font-bold text-slate-900">Performance by grade</h2><p className="text-sm text-slate-500">Compare results across grade levels.</p></div><div className="overflow-x-auto"><table className="w-full min-w-[700px] text-left"><thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500"><tr>{["Grade", "Students", "Results", "Average", "Pass Rate"].map((heading) => <th key={heading} className="px-5 py-4 font-semibold">{heading}</th>)}</tr></thead><tbody className="divide-y divide-slate-100">{analysis.gradePerformance.map((row) => <tr key={row.grade} className="hover:bg-indigo-50/40"><td className="px-5 py-4 font-bold text-slate-800">{row.grade}</td><td className="px-5 py-4 text-sm text-slate-700">{row.students}</td><td className="px-5 py-4 text-sm text-slate-700">{row.results}</td><td className="px-5 py-4 text-sm font-semibold text-slate-800">{pct(row.average)}</td><td className="px-5 py-4 text-sm font-semibold text-emerald-700">{pct(row.passRate)}</td></tr>)}</tbody></table></div></section>
      <section className="mt-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm"><div className="border-b border-slate-100 px-5 py-5"><h2 className="text-lg font-bold text-slate-900">Top 10 performers</h2><p className="text-sm text-slate-500">Students with the strongest cumulative performance in this subject.</p></div><div className="overflow-x-auto"><table className="w-full min-w-[650px] text-left"><thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500"><tr>{["Rank", "Student", "Grade", "Results", "Total Score", "Percentage"].map((heading) => <th key={heading} className="px-5 py-4 font-semibold">{heading}</th>)}</tr></thead><tbody className="divide-y divide-slate-100">{analysis.topPerformers.map((row, index) => <tr key={row.studentId} className="hover:bg-indigo-50/40"><td className="px-5 py-4 font-bold text-slate-700">{index + 1}</td><td className="px-5 py-4 font-semibold text-slate-800">{row.name}</td><td className="px-5 py-4 text-sm text-slate-600">{row.grade || "—"}</td><td className="px-5 py-4 text-sm text-slate-600">{row.count}</td><td className="px-5 py-4 text-sm text-slate-700">{formatNumber(row.totalScore)} / {formatNumber(row.totalMax)}</td><td className="px-5 py-4 text-sm font-bold text-indigo-700">{pct(row.percentage)}</td></tr>)}</tbody></table></div></section>
    </>}
  </div></main></>;
}
