import { useState } from "react";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";

const readValue = (item, key) =>
  String(key || "").split(".").reduce((value, part) => value?.[part], item);

const printable = (value) => {
  if (value === null || value === undefined) return "";
  if (value instanceof Date) return value.toLocaleString();
  if (typeof value === "object") return JSON.stringify(value);
  return String(value);
};

const safeFileName = (value) =>
  String(value || "report")
    .trim()
    .replace(/[<>:"/\\|?*]+/g, "-")
    .replace(/\s+/g, "-")
    .toLowerCase();

export default function ExportButtons({
  data = [],
  columns = [],
  title = "Report",
  subtitle = "",
  fileName = "report",
  metadata = [],
  disabled = false,
  className = "",
  onExportError,
}) {
  const [exporting, setExporting] = useState("");
  const headers = columns.map((column) => column.header || column.label || column.key);
  const rows = data.map((item) => columns.map((column) => {
    const value = column.value ? column.value(item) : readValue(item, column.key);
    return printable(column.format ? column.format(value, item) : value);
  }));
  const date = new Date().toISOString().slice(0, 10);
  const isDisabled = disabled || !data.length || !columns.length || Boolean(exporting);

  const runExport = async (type, callback) => {
    try {
      setExporting(type);
      await callback();
    } catch (error) {
      console.error(`Unable to export ${type}`, error);
      if (onExportError) onExportError(error, type);
      else window.alert(`Unable to export the ${type.toUpperCase()} report.`);
    } finally {
      setExporting("");
    }
  };

  const exportExcel = () => {
    const workbook = XLSX.utils.book_new();
    const sheetRows = [
      [title],
      ...(subtitle ? [[subtitle]] : []),
      ["Generated", new Date().toLocaleString()],
      ...metadata.filter((item) => item?.label).map((item) => [item.label, printable(item.value)]),
      [],
      headers,
      ...rows,
    ];
    const worksheet = XLSX.utils.aoa_to_sheet(sheetRows);
    worksheet["!cols"] = columns.map((column) => ({ wch: column.width || 18 }));
    XLSX.utils.book_append_sheet(workbook, worksheet, "Report");
    XLSX.writeFile(workbook, `${safeFileName(fileName)}-${date}.xlsx`);
  };

  const exportPdf = () => {
    const pdf = new jsPDF({ orientation: columns.length > 5 ? "landscape" : "portrait" });
    pdf.setFontSize(18);
    pdf.text(title, 14, 16);
    pdf.setFontSize(9);
    pdf.setTextColor(100);
    pdf.text(subtitle || `Generated ${new Date().toLocaleString()}`, 14, 23);
    autoTable(pdf, {
      startY: 29,
      head: [headers],
      body: rows,
      styles: { fontSize: 8, overflow: "linebreak" },
      headStyles: { fillColor: [15, 23, 42] },
    });
    pdf.save(`${safeFileName(fileName)}-${date}.pdf`);
  };

  return (
    <div className={`flex flex-wrap gap-3 ${className}`}>
      <button type="button" disabled={isDisabled} onClick={() => runExport("pdf", exportPdf)} className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50">
        <span aria-hidden="true">📄</span>{exporting === "pdf" ? "Exporting..." : "Export PDF"}
      </button>
      <button type="button" disabled={isDisabled} onClick={() => runExport("excel", exportExcel)} className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-50">
        <span aria-hidden="true">📊</span>{exporting === "excel" ? "Exporting..." : "Export Excel"}
      </button>
    </div>
  );
}
