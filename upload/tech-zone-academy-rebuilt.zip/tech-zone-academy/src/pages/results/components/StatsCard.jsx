const COLOR_STYLES = {
  indigo: "bg-indigo-100 text-indigo-700 ring-indigo-200",
  blue: "bg-blue-100 text-blue-700 ring-blue-200",
  cyan: "bg-cyan-100 text-cyan-700 ring-cyan-200",
  emerald: "bg-emerald-100 text-emerald-700 ring-emerald-200",
  amber: "bg-amber-100 text-amber-700 ring-amber-200",
  rose: "bg-rose-100 text-rose-700 ring-rose-200",
  violet: "bg-violet-100 text-violet-700 ring-violet-200",
  slate: "bg-slate-100 text-slate-700 ring-slate-200",
};

export default function StatsCard({
  icon,
  value = "0",
  label,
  color = "indigo",
  description,
  className = "",
}) {
  const colorStyle = COLOR_STYLES[color] || COLOR_STYLES.indigo;

  return (
    <article
      className={`relative overflow-hidden rounded-2xl border border-slate-100 bg-white p-5 shadow-sm ${className}`}
    >
      <div
        className={`absolute -right-7 -top-7 h-24 w-24 rounded-full opacity-40 ${colorStyle}`}
        aria-hidden="true"
      />
      <div className="relative flex items-start justify-between gap-4">
        <div className="min-w-0">
          <p className="text-sm font-medium text-slate-500">{label}</p>
          <p className="mt-2 truncate text-2xl font-bold tracking-tight text-slate-900">
            {value}
          </p>
          {description && (
            <p className="mt-1 text-xs leading-5 text-slate-500">{description}</p>
          )}
        </div>
        {icon && (
          <span
            className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-xl ring-1 ${colorStyle}`}
            aria-hidden="true"
          >
            {icon}
          </span>
        )}
      </div>
    </article>
  );
}
