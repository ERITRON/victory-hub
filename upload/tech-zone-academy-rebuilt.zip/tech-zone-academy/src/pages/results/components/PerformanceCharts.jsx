import { useEffect, useMemo, useRef, useState } from "react";

const COLORS = ["#4f46e5", "#0891b2", "#059669", "#d97706", "#e11d48", "#7c3aed"];

export default function PerformanceCharts({ data = [], type = "bar", title, height = 280, valueSuffix = "", className = "" }) {
  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  const [width, setWidth] = useState(0);
  const normalized = useMemo(() => data.map((item, index) => ({ label: String(item.label ?? item.name ?? ""), value: Number(item.value ?? item.count ?? 0) || 0, color: item.color || COLORS[index % COLORS.length] })), [data]);

  useEffect(() => {
    const update = () => setWidth(containerRef.current?.clientWidth || 0);
    update();
    const observer = new ResizeObserver(update);
    if (containerRef.current) observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !width) return;
    const ratio = window.devicePixelRatio || 1;
    canvas.width = width * ratio;
    canvas.height = height * ratio;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    const ctx = canvas.getContext("2d");
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.clearRect(0, 0, width, height);
    if (!normalized.length) { ctx.fillStyle = "#64748b"; ctx.font = "14px sans-serif"; ctx.textAlign = "center"; ctx.fillText("No chart data", width / 2, height / 2); return; }
    const max = Math.max(...normalized.map((item) => item.value), 1);
    if (type === "donut") {
      const total = normalized.reduce((sum, item) => sum + item.value, 0) || 1;
      let angle = -Math.PI / 2;
      normalized.forEach((item) => { const next = angle + (item.value / total) * Math.PI * 2; ctx.beginPath(); ctx.strokeStyle = item.color; ctx.lineWidth = 30; ctx.arc(width / 2, height / 2, Math.min(width, height) / 3, angle, next); ctx.stroke(); angle = next; });
      ctx.fillStyle = "#0f172a"; ctx.font = "bold 22px sans-serif"; ctx.textAlign = "center"; ctx.fillText(`${total}${valueSuffix}`, width / 2, height / 2 + 7); return;
    }
    const left = 42, top = 24, bottom = 46, chartWidth = width - left - 18, chartHeight = height - top - bottom;
    ctx.strokeStyle = "#e2e8f0"; ctx.lineWidth = 1;
    for (let step = 0; step <= 4; step += 1) { const y = top + chartHeight - chartHeight * step / 4; ctx.beginPath(); ctx.moveTo(left, y); ctx.lineTo(width - 18, y); ctx.stroke(); }
    const points = normalized.map((item, index) => ({ ...item, x: normalized.length === 1 ? left + chartWidth / 2 : left + chartWidth * index / (normalized.length - 1), y: top + chartHeight - item.value / max * chartHeight }));
    if (type === "line") { ctx.beginPath(); points.forEach((point, index) => index ? ctx.lineTo(point.x, point.y) : ctx.moveTo(point.x, point.y)); ctx.strokeStyle = "#4f46e5"; ctx.lineWidth = 3; ctx.stroke(); points.forEach((point) => { ctx.beginPath(); ctx.fillStyle = point.color; ctx.arc(point.x, point.y, 5, 0, Math.PI * 2); ctx.fill(); }); }
    else { const gap = chartWidth / normalized.length; const barWidth = Math.min(48, gap * 0.62); points.forEach((point) => { ctx.fillStyle = point.color; ctx.fillRect(point.x - barWidth / 2, point.y, barWidth, top + chartHeight - point.y); }); }
    ctx.fillStyle = "#64748b"; ctx.font = "10px sans-serif"; ctx.textAlign = "center"; points.forEach((point) => ctx.fillText(point.label.slice(0, 12), point.x, height - 18));
  }, [height, normalized, type, valueSuffix, width]);

  return <section className={`rounded-2xl border border-slate-200 bg-white p-5 shadow-sm ${className}`}>{title && <h3 className="mb-4 text-lg font-bold text-slate-900">{title}</h3>}<div ref={containerRef} className="w-full"><canvas ref={canvasRef} role="img" aria-label={title || "Performance chart"} /></div></section>;
}

export const PerformanceBarChart = (props) => <PerformanceCharts {...props} type="bar" />;
export const PerformanceLineChart = (props) => <PerformanceCharts {...props} type="line" />;
export const PerformanceDonutChart = (props) => <PerformanceCharts {...props} type="donut" />;
