const STATUS_VARIANTS = {
  success: "bg-emerald-100 text-emerald-700 ring-emerald-600/20",
  warning: "bg-amber-100 text-amber-700 ring-amber-600/20",
  danger: "bg-rose-100 text-rose-700 ring-rose-600/20",
  info: "bg-blue-100 text-blue-700 ring-blue-600/20",
  neutral: "bg-slate-100 text-slate-700 ring-slate-600/20",
};

const inferVariant = (status) => {
  const value = String(status || "").trim().toLowerCase();
  if (["pass", "passed", "success", "excellent", "complete", "completed", "active", "approved", "a"].includes(value)) return "success";
  if (["warning", "pending", "needs support", "needs improvement", "satisfactory", "c", "d"].includes(value)) return "warning";
  if (["fail", "failed", "danger", "rejected", "inactive", "below pass mark", "f"].includes(value)) return "danger";
  if (["good", "review", "in progress", "b"].includes(value)) return "info";
  return "neutral";
};

export default function StatusBadge({
  status,
  label,
  variant = "auto",
  showDot = false,
  className = "",
}) {
  const resolvedVariant = variant === "auto" ? inferVariant(status || label) : variant;
  const style = STATUS_VARIANTS[resolvedVariant] || STATUS_VARIANTS.neutral;

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ring-inset ${style} ${className}`}
    >
      {showDot && <span className="h-1.5 w-1.5 rounded-full bg-current" aria-hidden="true" />}
      {label || status || "Unknown"}
    </span>
  );
}
