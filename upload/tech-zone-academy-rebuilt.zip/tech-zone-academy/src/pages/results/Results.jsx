// src/pages/Results.jsx
import { useEffect, useState } from "react";
import { collection, getDocs, query, orderBy, db } from "../../supabase/supabase";

export default function Results() {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");
  const [filter, setFilter] = useState({
    subject: "",
    grade: "",
    assessment: "",
  });
  const [subjects, setSubjects] = useState([]);
  const [grades, setGrades] = useState([]);
  const [assessments, setAssessments] = useState([]);

  // Cumulative scoring: track total score and total max score per student
  const [studentCumulative, setStudentCumulative] = useState({});

  const fetchResults = async () => {
    setLoading(true);
    setErrorMessage("");

    try {
      const q = query(collection(db, "results"), orderBy("createdAt", "desc"));
      const querySnapshot = await getDocs(q);
      const data = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setResults(data);
      
      // Calculate cumulative scores per student
      const cumulative = {};
      data.forEach((result) => {
        const studentId = result.studentId || "unknown";
        if (!cumulative[studentId]) {
          cumulative[studentId] = {
            studentId: studentId,
            studentName: result.studentName || "Unknown",
            totalScore: 0,
            totalMaxScore: 0,
            count: 0,
            subjects: {},
          };
        }
        cumulative[studentId].totalScore += result.score || 0;
        cumulative[studentId].totalMaxScore += result.outOf || 0;
        cumulative[studentId].count++;
        
        const subject = result.subject || "Unknown";
        if (!cumulative[studentId].subjects[subject]) {
          cumulative[studentId].subjects[subject] = {
            totalScore: 0,
            totalMaxScore: 0,
            count: 0,
          };
        }
        cumulative[studentId].subjects[subject].totalScore += result.score || 0;
        cumulative[studentId].subjects[subject].totalMaxScore += result.outOf || 0;
        cumulative[studentId].subjects[subject].count++;
      });
      
      // Calculate percentages
      Object.keys(cumulative).forEach((key) => {
        const student = cumulative[key];
        student.percentage = student.totalMaxScore > 0 
          ? Math.round((student.totalScore / student.totalMaxScore) * 100) 
          : 0;
      });
      
      setStudentCumulative(cumulative);
      
    } catch (error) {
      setErrorMessage("Error loading results: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setLoading(false);
    }
  };

  const fetchFilters = async () => {
    try {
      const snapshot = await getDocs(collection(db, "results"));
      const uniqueSubjects = new Set();
      const uniqueGrades = new Set();
      const uniqueAssessments = new Set();

      snapshot.docs.forEach((doc) => {
        const data = doc.data();
        if (data.subject) uniqueSubjects.add(data.subject);
        if (data.grade) uniqueGrades.add(data.grade);
        if (data.assessment) uniqueAssessments.add(data.assessment);
      });

      setSubjects(Array.from(uniqueSubjects).sort());
      setGrades(Array.from(uniqueGrades).sort());
      setAssessments(Array.from(uniqueAssessments).sort());
    } catch (error) {
      console.error("Error fetching filters:", error);
    }
  };

  useEffect(() => {
    fetchResults();
    fetchFilters();
  }, []);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilter((prev) => ({ ...prev, [name]: value }));
  };

  const clearFilters = () => {
    setFilter({
      subject: "",
      grade: "",
      assessment: "",
    });
  };

  const filteredResults = results.filter((result) => {
    const matchSubject = filter.subject === "" || result.subject === filter.subject;
    const matchGrade = filter.grade === "" || result.grade === filter.grade;
    const matchAssessment = filter.assessment === "" || result.assessment === filter.assessment;
    return matchSubject && matchGrade && matchAssessment;
  });

  const getScoreColor = (score, outOf) => {
    const percentage = (score / outOf) * 100;
    if (percentage >= 80) return "text-green-600";
    if (percentage >= 60) return "text-yellow-600";
    if (percentage >= 40) return "text-orange-600";
    return "text-red-600";
  };

  const getScoreBadge = (score, outOf) => {
    const percentage = (score / outOf) * 100;
    if (percentage >= 80) return "bg-green-100 text-green-700";
    if (percentage >= 60) return "bg-yellow-100 text-yellow-700";
    if (percentage >= 40) return "bg-orange-100 text-orange-700";
    return "bg-red-100 text-red-700";
  };

  const getGradeLetter = (percentage) => {
    if (percentage >= 90) return "A";
    if (percentage >= 80) return "B";
    if (percentage >= 70) return "C";
    if (percentage >= 60) return "D";
    if (percentage >= 50) return "E";
    return "F";
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading results...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
                📊 Student Results
              </h1>
              <p className="text-gray-600 mt-1">
                View and analyze student academic performance
              </p>
            </div>
            <button
              onClick={fetchResults}
              className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition text-sm flex items-center gap-2"
            >
              🔄 Refresh
            </button>
          </div>
        </div>

        {/* Error Message */}
        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-md p-4 sm:p-6 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Subject
              </label>
              <select
                name="subject"
                value={filter.subject}
                onChange={handleFilterChange}
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
              >
                <option value="">All Subjects</option>
                {subjects.map((subject) => (
                  <option key={subject} value={subject}>{subject}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Grade
              </label>
              <select
                name="grade"
                value={filter.grade}
                onChange={handleFilterChange}
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
              >
                <option value="">All Grades</option>
                {grades.map((grade) => (
                  <option key={grade} value={grade}>{grade}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Assessment
              </label>
              <select
                name="assessment"
                value={filter.assessment}
                onChange={handleFilterChange}
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
              >
                <option value="">All Assessments</option>
                {assessments.map((assessment) => (
                  <option key={assessment} value={assessment}>{assessment}</option>
                ))}
              </select>
            </div>

            <div className="flex items-end">
              <button
                onClick={clearFilters}
                className="w-full bg-gray-200 text-gray-700 px-4 py-2.5 rounded-lg hover:bg-gray-300 transition font-medium"
              >
                Clear Filters
              </button>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="flex flex-wrap gap-4 mb-6">
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Total Results:</span>
            <span className="ml-2 font-bold text-blue-700">{results.length}</span>
          </div>
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Filtered:</span>
            <span className="ml-2 font-bold text-green-700">{filteredResults.length}</span>
          </div>
          {filteredResults.length > 0 && (
            <div className="bg-white rounded-lg shadow px-4 py-2">
              <span className="text-sm text-gray-600">Avg Score:</span>
              <span className="ml-2 font-bold text-purple-700">
                {(
                  filteredResults.reduce((acc, r) => acc + (r.score / r.outOf) * 100, 0) / 
                  filteredResults.length
                ).toFixed(1)}%
              </span>
            </div>
          )}
        </div>

        {/* Student Cumulative Summary */}
        {Object.keys(studentCumulative).length > 0 && (
          <div className="bg-white rounded-xl shadow-md p-4 mb-6">
            <h3 className="text-sm font-semibold text-gray-700 mb-3">📊 Student Cumulative Summary</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {Object.values(studentCumulative).slice(0, 6).map((student) => (
                <div key={student.studentId} className="bg-gray-50 rounded-lg p-3 flex justify-between items-center">
                  <span className="font-medium text-sm">{student.studentName || student.studentId}</span>
                  <div className="text-right">
                    <span className="text-sm font-bold">
                      {student.totalScore} / {student.totalMaxScore}
                    </span>
                    <span className={`ml-2 text-sm font-bold ${getScoreColor(student.totalScore, student.totalMaxScore || 1)}`}>
                      ({student.percentage}%)
                    </span>
                  </div>
                </div>
              ))}
            </div>
            {Object.keys(studentCumulative).length > 6 && (
              <p className="text-xs text-gray-400 mt-2 text-center">Showing 6 of {Object.keys(studentCumulative).length} students</p>
            )}
          </div>
        )}

        {/* Results Grid */}
        {filteredResults.length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-6xl mb-4">📭</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No Results Found</h3>
            <p className="text-gray-500">
              {results.length === 0 
                ? "No student results have been recorded yet." 
                : "No results match your search criteria."}
            </p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {filteredResults.map((result) => {
              const percentage = ((result.score / result.outOf) * 100).toFixed(1);
              return (
                <div
                  key={result.id}
                  className="bg-white rounded-xl shadow-md p-5 hover:shadow-xl transition duration-300 border-l-4"
                  style={{
                    borderColor: percentage >= 80 ? "#22c55e" : 
                                 percentage >= 60 ? "#eab308" : 
                                 percentage >= 40 ? "#f97316" : "#ef4444"
                  }}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-lg font-bold text-gray-800">
                        {result.subject || "Unknown Subject"}
                      </h3>
                      <p className="text-sm text-gray-500">
                        {result.studentName || result.studentId || "No ID"}
                      </p>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-sm font-bold ${getScoreBadge(result.score, result.outOf)}`}>
                      {getGradeLetter(percentage)}
                    </div>
                  </div>

                  <div className="mt-3 space-y-1">
                    <p className="text-sm text-gray-600">
                      <span className="font-medium">Assessment:</span> {result.assessment || "N/A"}
                    </p>
                    <p className="text-sm text-gray-600">
                      <span className="font-medium">Grade:</span> {result.grade || "N/A"}
                    </p>
                    <p className="text-sm text-gray-600">
                      <span className="font-medium">Section:</span> {result.section || "N/A"}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-gray-100">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-2xl font-bold">
                          {result.score}
                        </span>
                        <span className="text-gray-400 text-sm"> / {result.outOf}</span>
                      </div>
                      <div className={`text-right ${getScoreColor(result.score, result.outOf)}`}>
                        <div className="text-xl font-bold">{percentage}%</div>
                        <div className="text-xs text-gray-500">
                          {result.createdAt ? new Date(result.createdAt).toLocaleDateString() : "N/A"}
                        </div>
                      </div>
                    </div>
                    <div className="mt-2 w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                      <div 
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${Math.min(percentage, 100)}%`,
                          backgroundColor: percentage >= 80 ? "#22c55e" : 
                                         percentage >= 60 ? "#eab308" : 
                                         percentage >= 40 ? "#f97316" : "#ef4444"
                        }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}