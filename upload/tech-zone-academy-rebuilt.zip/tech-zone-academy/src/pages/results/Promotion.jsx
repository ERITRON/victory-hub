import { useState, useEffect } from "react";
import { db, collection, getDocs, query, where, updateDoc, doc } from "../../supabase/supabase";

export default function Promotion() {
  const [students, setStudents] = useState([]);
  const [grades, setGrades] = useState([]);
  const [sections, setSections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedGrade, setSelectedGrade] = useState("");
  const [selectedSection, setSelectedSection] = useState("");
  const [promotionGrade, setPromotionGrade] = useState("");
  const [promotionSection, setPromotionSection] = useState("");
  const [selectedStudents, setSelectedStudents] = useState([]);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const fetchData = async () => {
    try {
      const gradesSnap = await getDocs(collection(db, "grades"));
      const gradesData = gradesSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setGrades(gradesData.sort((a, b) => a.name.localeCompare(b.name)));

      const sectionsSnap = await getDocs(collection(db, "sections"));
      const sectionsData = sectionsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSections(sectionsData.sort((a, b) => a.name.localeCompare(b.name)));

      if (gradesData.length > 0) {
        setSelectedGrade(gradesData[0].name);
        setPromotionGrade(gradesData[0].name);
      }
      if (sectionsData.length > 0) {
        setSelectedSection(sectionsData[0].name);
        setPromotionSection(sectionsData[0].name);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const fetchStudents = async () => {
    setLoading(true);
    try {
      const q = query(
        collection(db, "students"),
        where("grade", "==", selectedGrade),
        where("section", "==", selectedSection)
      );
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setStudents(data.sort((a, b) => a.firstName.localeCompare(b.firstName)));
      setSelectedStudents([]);
    } catch (error) {
      setErrorMessage("Error loading students: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedGrade && selectedSection) {
      fetchStudents();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- fetchStudents is a stable helper; re-run only when the selection changes
  }, [selectedGrade, selectedSection]);

  const toggleStudent = (studentId) => {
    setSelectedStudents((prev) =>
      prev.includes(studentId)
        ? prev.filter((id) => id !== studentId)
        : [...prev, studentId]
    );
  };

  const selectAll = () => {
    if (selectedStudents.length === students.length) {
      setSelectedStudents([]);
    } else {
      setSelectedStudents(students.map((s) => s.id));
    }
  };

  const promoteStudents = async () => {
    if (selectedStudents.length === 0) {
      setErrorMessage("Please select at least one student to promote.");
      return;
    }

    if (!promotionGrade || !promotionSection) {
      setErrorMessage("Please select promotion grade and section.");
      return;
    }

    if (promotionGrade === selectedGrade && promotionSection === selectedSection) {
      setErrorMessage("Promotion grade/section must be different from current.");
      return;
    }

    if (!window.confirm(`Promote ${selectedStudents.length} student(s) to ${promotionGrade} - ${promotionSection}?`)) {
      return;
    }

    setLoading(true);
    try {
      for (const studentId of selectedStudents) {
        await updateDoc(doc(db, "students", studentId), {
          grade: promotionGrade,
          section: promotionSection,
          promotedAt: new Date().toISOString(),
        });
      }

      setSuccessMessage(`✅ ${selectedStudents.length} student(s) promoted successfully!`);
      setTimeout(() => setSuccessMessage(""), 5000);
      fetchStudents();
    } catch (error) {
      setErrorMessage("Error promoting students: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
            📈 Promote Students
          </h1>
          <p className="text-gray-600 mt-1">
            Promote students to the next grade and section
          </p>
        </div>

        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Current Class Selection */}
        <div className="bg-white rounded-xl shadow-md p-4 sm:p-6 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Current Grade
              </label>
              <select
                value={selectedGrade}
                onChange={(e) => setSelectedGrade(e.target.value)}
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
              >
                {grades.map((grade) => (
                  <option key={grade.id} value={grade.name}>
                    {grade.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Current Section
              </label>
              <select
                value={selectedSection}
                onChange={(e) => setSelectedSection(e.target.value)}
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
              >
                {sections.map((section) => (
                  <option key={section.id} value={section.name}>
                    {section.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Promotion Details */}
        <div className="bg-white rounded-xl shadow-md p-4 sm:p-6 mb-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4">Promote To</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                New Grade
              </label>
              <select
                value={promotionGrade}
                onChange={(e) => setPromotionGrade(e.target.value)}
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
              >
                {grades.map((grade) => (
                  <option key={grade.id} value={grade.name}>
                    {grade.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                New Section
              </label>
              <select
                value={promotionSection}
                onChange={(e) => setPromotionSection(e.target.value)}
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition bg-white"
              >
                {sections.map((section) => (
                  <option key={section.id} value={section.name}>
                    {section.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Students List */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="px-4 py-3 border-b flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="text-lg font-bold text-gray-800">
                Students ({students.length})
              </h3>
              <p className="text-sm text-gray-500">
                {selectedGrade} - Section {selectedSection}
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={selectAll}
                className="bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg hover:bg-gray-300 transition text-sm"
              >
                {selectedStudents.length === students.length ? "Deselect All" : "Select All"}
              </button>
              <button
                onClick={promoteStudents}
                disabled={selectedStudents.length === 0 || loading}
                className={`px-4 py-1.5 rounded-lg text-white font-medium text-sm transition ${
                  selectedStudents.length > 0 && !loading
                    ? "bg-blue-700 hover:bg-blue-800"
                    : "bg-gray-400 cursor-not-allowed"
                }`}
              >
                {loading ? "Promoting..." : `Promote (${selectedStudents.length})`}
              </button>
            </div>
          </div>

          {students.length === 0 ? (
            <div className="p-8 text-center text-gray-500">
              No students found in this class.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-4 py-3 w-10">
                      <input
                        type="checkbox"
                        checked={selectedStudents.length === students.length}
                        onChange={selectAll}
                        className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                    </th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">#</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Student Name</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">ID</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Current Class</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Promote To</th>
                  </tr>
                </thead>
                <tbody>
                  {students.map((student, index) => (
                    <tr key={student.id} className="border-b hover:bg-gray-50 transition">
                      <td className="px-4 py-3">
                        <input
                          type="checkbox"
                          checked={selectedStudents.includes(student.id)}
                          onChange={() => toggleStudent(student.id)}
                          className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-500">{index + 1}</td>
                      <td className="px-4 py-3 font-medium text-gray-800">
                        {student.firstName} {student.fatherName}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">{student.studentId}</td>
                      <td className="px-4 py-3 text-sm text-gray-600">
                        {student.grade} - {student.section}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">
                        {promotionGrade} - {promotionSection}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}