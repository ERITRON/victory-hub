import { Fragment, useEffect, useMemo, useState } from "react";
import { collection, getDocs } from "../../supabase/supabase";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import SEO from "../../components/SEO";
import { db } from "../../supabase/supabase";

const PASS_MARK = 50;
const INITIAL_FILTERS = { grade: "All", section: "All", subject: "All", assessmentType: "All" };

const firstValue = (item, keys, fallback = "") => {
  for (const key of keys) {
    if (item?.[key] !== undefined && item[key] !== null && item[key] !== "") return item[key];
  }
  return fallback;
};

const numberValue = (value) => {
  const result = Number(value);
  return Number.isFinite(result) ? result : 0;
};

const studentKey = (student) => String(firstValue(student, ["studentId", "id", "uid"], ""));
const studentName = (student) => {
  const name = firstValue(student, ["fullName", "name", "studentName"]);
  if (name) return String(name);
  return `${firstValue(student, ["firstName", "firstname"], "")} ${firstValue(student, ["fatherName", "lastName", "lastname"], "")}`.trim() || "Unnamed Student";
};
const gradeValue = (item) => String(firstValue(item, ["grade", "class", "className"], ""));
const sectionValue = (item) => String(firstValue(item, ["section", "stream", "classSection"], ""));
const subjectValue = (item) => String(firstValue(item, ["subject", "subjectName", "course"], "General"));
const assessmentValue = (item) => String(firstValue(item, ["assessmentType", "assessment", "examType", "type"], "General"));
const assessmentName = (item) => String(firstValue(item, ["assessment", "assessmentName", "examName"], assessmentValue(item)));
const scoreValue = (item) => numberValue(firstValue(item, ["score", "marks", "marksObtained", "obtainedMarks"], 0));
const maxValue = (item) => numberValue(firstValue(item, ["outOf", "maxScore", "maximumScore", "totalMarks", "maxMarks"], 100)) || 100;
const formatNumber = (value) => new Intl.NumberFormat("en-US", { maximumFractionDigits: 1 }).format(value);
const formatPercentage = (value) => `${formatNumber(value)}%`;
const normalizeResult = (result) => ({
  ...result,
  studentId: String(firstValue(result, ["studentId", "studentID", "student_id", "uid"], "")),
  grade: gradeValue(result),
  section: sectionValue(result),
  subject: subjectValue(result),
  assessmentType: assessmentValue(result),
  assessment: assessmentName(result),
  score: scoreValue(result),
  maxScore: maxValue(result),
});

const Medal = ({ rank }) => (rank <= 3 ? <span title={`${rank} place`}>{["", "🥇", "🥈", "🥉"][rank]}</span> : <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-slate-100 text-xs font-bold text-slate-600">{rank}</span>);

const ProgressBar = ({ value }) => {
  const percentage = Math.max(0, Math.min(100, Number(value) || 0));
  const color = percentage >= 75 ? "from-emerald-500 to-teal-500" : percentage >= PASS_MARK ? "from-blue-500 to-cyan-500" : "from-rose-500 to-orange-400";
  return <div className="flex min-w-[145px] items-center gap-3"><div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-200"><div className={`h-full rounded-full bg-gradient-to-r ${color}`} style={{ width: `${percentage}%` }} /></div><span className="w-12 text-right text-sm font-bold text-slate-700">{formatPercentage(percentage)}</span></div>;
};

const StatCard = ({ title, value, subtitle, icon, className }) => <div className="relative overflow-hidden rounded-2xl border border-slate-100 bg-white p-5 shadow-sm"><div className={`absolute right-0 top-0 h-20 w-20 -translate-y-7 translate-x-7 rounded-full opacity-20 ${className}`} /><div className="relative flex items-start justify-between gap-3"><div><p className="text-sm font-medium text-slate-500">{title}</p><p className="mt-2 max-w-[190px] truncate text-2xl font-bold tracking-tight text-slate-900">{value}</p><p className="mt-1 text-xs text-slate-500">{subtitle}</p></div><div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-xl ${className}`}>{icon}</div></div></div>;

export default function TopPerformers() {
  const [students, setStudents] = useState([]);
  const [results, setResults] = useState([]);
  const [filters, setFilters] = useState(INITIAL_FILTERS);
  const [expanded, setExpanded] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    Promise.all([getDocs(collection(db, "students")), getDocs(collection(db, "results"))])
      .then(([studentSnapshot, resultSnapshot]) => {
        if (!active) return;
        setStudents(studentSnapshot.docs.map((item) => ({ id: item.id, ...item.data() })));
        setResults(resultSnapshot.docs.map((item) => normalizeResult({ id: item.id, ...item.data() })));
      })
      .catch((fetchError) => {
        console.error("Unable to load top performers", fetchError);
        if (active) setError("Unable to load performance data. Check Firestore permissions and try again.");
      })
      .finally(() => active && setLoading(false));
    return () => { active = false; };
  }, []);

  const studentsByKey = useMemo(() => new Map(students.flatMap((student) => [[studentKey(student), student], [String(student.id), student]])), [students]);
  const options = useMemo(() => {
    const values = { grade: new Set(), section: new Set(), subject: new Set(), assessmentType: new Set() };
    students.forEach((student) => { if (gradeValue(student)) values.grade.add(gradeValue(student)); if (sectionValue(student)) values.section.add(sectionValue(student)); });
    results.forEach((result) => Object.keys(values).forEach((key) => values[key].add(result[key])));
    return Object.fromEntries(Object.entries(values).map(([key, set]) => [key, [...set].filter(Boolean).sort((a, b) => String(a).localeCompare(String(b), undefined, { numeric: true }))]));
  }, [results, students]);

  const leaderboard = useMemo(() => {
    const grouped = new Map();
    results.forEach((result) => {
      const student = studentsByKey.get(result.studentId) || {};
      const grade = result.grade || gradeValue(student);
      const section = result.section || sectionValue(student);
      if ((filters.grade !== "All" && grade !== filters.grade) || (filters.section !== "All" && section !== filters.section) || (filters.subject !== "All" && result.subject !== filters.subject) || (filters.assessmentType !== "All" && result.assessmentType !== filters.assessmentType)) return;
      if (!result.studentId) return;
      const current = grouped.get(result.studentId) || { studentId: result.studentId, student, grade, section, totalScore: 0, maximumScore: 0, subjects: new Map() };
      current.totalScore += result.score;
      current.maximumScore += result.maxScore;
      const subject = current.subjects.get(result.subject) || { name: result.subject, score: 0, maxScore: 0, assessments: [] };
      subject.score += result.score;
      subject.maxScore += result.maxScore;
      subject.assessments.push({ name: result.assessment, type: result.assessmentType, score: result.score, maxScore: result.maxScore });
      current.subjects.set(result.subject, subject);
      grouped.set(result.studentId, current);
    });
    return [...grouped.values()].map((entry) => ({ ...entry, studentName: studentName(entry.student), grade: entry.grade || "—", section: entry.section || "—", percentage: entry.maximumScore ? (entry.totalScore / entry.maximumScore) * 100 : 0, subjects: [...entry.subjects.values()].map((subject) => ({ ...subject, percentage: subject.maxScore ? (subject.score / subject.maxScore) * 100 : 0 })).sort((a, b) => b.percentage - a.percentage) })).sort((a, b) => b.percentage - a.percentage || b.totalScore - a.totalScore).map((entry, index) => ({ ...entry, rank: index + 1, status: entry.percentage >= PASS_MARK ? "Pass" : "Needs Support" }));
  }, [filters, results, studentsByKey]);

  const stats = useMemo(() => {
    const total = leaderboard.length;
    const average = total ? leaderboard.reduce((sum, student) => sum + student.percentage, 0) / total : 0;
    const passRate = total ? (leaderboard.filter((student) => student.percentage >= PASS_MARK).length / total) * 100 : 0;
    return { total, average, passRate, top: leaderboard[0] };
  }, [leaderboard]);

  const exportRows = useMemo(() => leaderboard.map((student) => ({ Rank: student.rank, "Student Name": student.studentName, Grade: student.grade, Section: student.section, "Total Score": `${formatNumber(student.totalScore)} / ${formatNumber(student.maximumScore)}`, Percentage: formatPercentage(student.percentage), Status: student.status })), [leaderboard]);

  const exportExcel = () => {
    if (!exportRows.length) return;
    const worksheet = XLSX.utils.json_to_sheet(exportRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Top Performers");
    XLSX.writeFile(workbook, `top-performers-${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const exportPdf = () => {
    if (!exportRows.length) return;
    const pdf = new jsPDF({ orientation: "landscape" });
    pdf.setFontSize(18);
    pdf.text("Top Performers Leaderboard", 14, 16);
    pdf.setFontSize(9);
    pdf.setTextColor(100);
    pdf.text(`Generated ${new Date().toLocaleString()}`, 14, 23);
    autoTable(pdf, { startY: 29, head: [Object.keys(exportRows[0])], body: exportRows.map((row) => Object.values(row)), styles: { fontSize: 9 }, headStyles: { fillColor: [15, 23, 42] } });
    pdf.save(`top-performers-${new Date().toISOString().slice(0, 10)}.pdf`);
  };

  const updateFilter = (event) => { setFilters((current) => ({ ...current, [event.target.name]: event.target.value })); setExpanded(null); };
  const resetFilters = () => { setFilters(INITIAL_FILTERS); setExpanded(null); };
  const filterConfig = [{ key: "grade", label: "Grade" }, { key: "section", label: "Section" }, { key: "subject", label: "Subject" }, { key: "assessmentType", label: "Assessment Type" }];

  return <>
    <SEO title="Top Performers" description="View cumulative student performance rankings and subject breakdowns." />
    <main className="min-h-screen bg-slate-50 px-4 py-6 sm:px-6 lg:px-8"><div className="mx-auto max-w-7xl">
      <header className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-indigo-950 to-violet-800 px-6 py-8 text-white shadow-xl sm:px-8"><div className="absolute -right-20 -top-24 h-72 w-72 rounded-full bg-cyan-400/20 blur-3xl" /><div className="relative flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between"><div><p className="mb-3 inline-flex rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-semibold tracking-wide text-indigo-100">ACADEMIC EXCELLENCE</p><h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Top Performers</h1><p className="mt-3 max-w-2xl text-sm leading-6 text-indigo-100 sm:text-base">Track student achievement and celebrate outstanding results.</p></div><div className="flex flex-wrap gap-3"><button type="button" onClick={exportPdf} disabled={!leaderboard.length} className="rounded-xl border border-white/20 bg-white/10 px-4 py-2.5 text-sm font-semibold hover:bg-white/20 disabled:opacity-50">📄 Export PDF</button><button type="button" onClick={exportExcel} disabled={!leaderboard.length} className="rounded-xl bg-white px-4 py-2.5 text-sm font-semibold text-indigo-800 hover:bg-indigo-50 disabled:opacity-50">📊 Export Excel</button></div></div></header>

      <section className="mt-6 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5"><div className="mb-4 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between"><div><h2 className="font-bold text-slate-900">Filter leaderboard</h2><p className="text-sm text-slate-500">Narrow results by class, subject, or assessment.</p></div><button type="button" onClick={resetFilters} className="self-start text-sm font-semibold text-indigo-600 hover:text-indigo-800 sm:self-auto">Reset filters</button></div><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{filterConfig.map(({ key, label }) => <label key={key} className="block"><span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">{label}</span><select name={key} value={filters[key]} onChange={updateFilter} className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-700 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"><option value="All">All {label}s</option>{options[key]?.map((option) => <option key={option} value={option}>{option}</option>)}</select></label>)}</div></section>

      <section className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4"><StatCard title="Total Students" value={loading ? "—" : formatNumber(stats.total)} subtitle="Students with recorded results" icon="👩‍🎓" className="bg-indigo-100 text-indigo-600" /><StatCard title="Average Score" value={loading ? "—" : formatPercentage(stats.average)} subtitle="Across current selection" icon="📈" className="bg-cyan-100 text-cyan-600" /><StatCard title="Pass Rate" value={loading ? "—" : formatPercentage(stats.passRate)} subtitle={`Students scoring ${PASS_MARK}% and above`} icon="✓" className="bg-emerald-100 text-emerald-600" /><StatCard title="Top Performer" value={loading ? "—" : stats.top?.studentName || "No data"} subtitle={stats.top ? `${formatPercentage(stats.top.percentage)} • ${stats.top.grade}` : "No matching results"} icon="🏆" className="bg-amber-100 text-amber-600" /></section>

      <section className="mt-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm"><div className="flex flex-col gap-1 border-b border-slate-100 px-5 py-5 sm:flex-row sm:items-center sm:justify-between"><div><h2 className="text-lg font-bold text-slate-900">Leaderboard</h2><p className="text-sm text-slate-500">Click a row to view the subject breakdown.</p></div>{!loading && <span className="text-sm font-medium text-slate-500">{leaderboard.length} student{leaderboard.length === 1 ? "" : "s"} found</span>}</div>
        {loading ? <div className="animate-pulse space-y-4 p-5">{Array.from({ length: 7 }).map((_, index) => <div key={index} className="h-12 rounded-xl bg-slate-100" />)}</div> : error ? <div className="flex min-h-72 flex-col items-center justify-center px-5 py-12 text-center"><div className="mb-4 text-4xl">⚠</div><h3 className="text-lg font-bold text-slate-800">Unable to load the leaderboard</h3><p className="mt-2 max-w-md text-sm text-slate-500">{error}</p></div> : !leaderboard.length ? <div className="flex min-h-72 flex-col items-center justify-center px-5 py-12 text-center"><div className="mb-4 text-5xl">📚</div><h3 className="text-lg font-bold text-slate-800">No results found</h3><p className="mt-2 max-w-md text-sm text-slate-500">No student results match the selected filters.</p><button type="button" onClick={resetFilters} className="mt-5 rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700">Clear filters</button></div> : <div className="overflow-x-auto"><table className="w-full min-w-[900px] text-left"><thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500"><tr>{["Rank", "Student Name", "Grade", "Section", "Total Score", "Percentage", "Status", ""].map((heading) => <th key={heading || "expand"} className="px-5 py-4 font-semibold">{heading}</th>)}</tr></thead><tbody className="divide-y divide-slate-100">{leaderboard.map((student) => <Fragment key={student.studentId}><tr onClick={() => setExpanded((current) => current === student.studentId ? null : student.studentId)} className="cursor-pointer transition hover:bg-indigo-50/50"><td className="px-5 py-4 text-lg"><Medal rank={student.rank} /></td><td className="px-5 py-4"><p className="font-semibold text-slate-800">{student.studentName}</p><p className="mt-0.5 text-xs text-slate-500">{student.subjects.length} subject{student.subjects.length === 1 ? "" : "s"} recorded</p></td><td className="px-5 py-4 text-sm font-medium text-slate-700">{student.grade}</td><td className="px-5 py-4 text-sm text-slate-600">{student.section}</td><td className="px-5 py-4 text-sm"><b>{formatNumber(student.totalScore)}</b> <span className="text-slate-400">/ {formatNumber(student.maximumScore)}</span></td><td className="px-5 py-4"><ProgressBar value={student.percentage} /></td><td className="px-5 py-4"><span className={`inline-flex rounded-full px-2.5 py-1 text-xs font-bold ${student.status === "Pass" ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"}`}>{student.status}</span></td><td className="px-5 py-4 text-right"><span className={`inline-flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 text-slate-500 transition ${expanded === student.studentId ? "rotate-180 bg-indigo-100 text-indigo-700" : ""}`}>↓</span></td></tr>{expanded === student.studentId && <tr><td colSpan="8" className="bg-slate-50 px-5 py-5"><div className="rounded-xl border border-indigo-100 bg-white p-4"><div className="mb-4 flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between"><div><h3 className="font-bold text-slate-800">Subject Breakdown</h3><p className="text-sm text-slate-500">{student.studentName}'s cumulative subject scores</p></div><span className="text-sm font-semibold text-indigo-600">Overall: {formatPercentage(student.percentage)}</span></div><div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">{student.subjects.map((subject) => <div key={subject.name} className="rounded-xl border border-slate-100 bg-slate-50 p-3.5"><div className="flex items-start justify-between gap-3"><div><p className="font-semibold text-slate-800">{subject.name}</p><p className="mt-1 text-xs text-slate-500">{formatNumber(subject.score)} / {formatNumber(subject.maxScore)}</p></div><span className="text-sm font-bold text-slate-700">{formatPercentage(subject.percentage)}</span></div><div className="mt-3"><ProgressBar value={subject.percentage} /></div>{subject.assessments.length > 1 && <p className="mt-3 border-t border-slate-200 pt-2 text-xs text-slate-500">{subject.assessments.map((assessment) => `${assessment.type}: ${formatNumber(assessment.score)}/${formatNumber(assessment.maxScore)}`).join(" • ")}</p>}</div>)}</div></div></td></tr>}</Fragment>)}</tbody></table></div>}
      </section>
    </div></main>
  </>;
}
