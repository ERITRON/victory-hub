// src/pages/results/ReportCards.jsx
import { useEffect, useMemo, useState } from "react";
import { db, collection, getDocs } from "../../supabase/supabase";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import toast from "react-hot-toast";
import SEO from "../../components/SEO";
import Icon from "../../components/Icon";
import { SkeletonCard } from "../../components/LoadingSkeleton";
import { useWebsiteSettings } from "../../context/WebsiteSettingsContext";

// 4.0-scale grading bands: percentage -> letter + grade points.
const GRADE_SCALE = [
  { min: 90, letter: "A+", points: 4.0 },
  { min: 85, letter: "A", points: 4.0 },
  { min: 80, letter: "A-", points: 3.75 },
  { min: 75, letter: "B+", points: 3.5 },
  { min: 70, letter: "B", points: 3.0 },
  { min: 65, letter: "C+", points: 2.5 },
  { min: 60, letter: "C", points: 2.0 },
  { min: 50, letter: "D", points: 1.0 },
  { min: 0, letter: "F", points: 0.0 },
];

const gradeFor = (pct) => GRADE_SCALE.find((g) => pct >= g.min) || GRADE_SCALE.at(-1);

// Auto-generated teacher comment: there is no comments collection in the
// data model, so the comment is derived from performance + attendance.
function buildComment(report) {
  const { average, attendancePct, hasAttendance, name } = report;
  const first = name.split(" ")[0];
  let academic;
  if (average >= 90) academic = `${first} has demonstrated outstanding academic performance this term.`;
  else if (average >= 80) academic = `${first} has shown excellent progress across subjects.`;
  else if (average >= 70) academic = `${first} is performing well, with room to aim even higher.`;
  else if (average >= 60) academic = `${first} shows satisfactory progress but should focus on consistent study habits.`;
  else if (average >= 50) academic = `${first} needs additional support and regular revision to improve results.`;
  else academic = `${first} requires close academic support; a parent-teacher meeting is recommended.`;

  let attendance = "";
  if (hasAttendance) {
    if (attendancePct >= 95) attendance = " Attendance has been exemplary.";
    else if (attendancePct >= 85) attendance = " Attendance is good.";
    else if (attendancePct >= 75) attendance = " Attendance needs improvement.";
    else attendance = " Poor attendance is affecting progress and must improve.";
  }
  return academic + attendance;
}

export default function ReportCards() {
  const { settings } = useWebsiteSettings();
  const schoolName = settings?.hero?.schoolName || "Tech Zone Academy";
  const tagline = settings?.hero?.tagline || "Building Bright Futures";
  const logo = settings?.navigation?.logo || "";
  const footer = settings?.footer || {};

  const [loading, setLoading] = useState(true);
  const [students, setStudents] = useState([]);
  const [results, setResults] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [grades, setGrades] = useState([]);
  const [sections, setSections] = useState([]);

  const [searchTerm, setSearchTerm] = useState("");
  const [gradeFilter, setGradeFilter] = useState("");
  const [sectionFilter, setSectionFilter] = useState("");
  const [selected, setSelected] = useState(null);
  const [exporting, setExporting] = useState(false);

  const fetchAllData = async () => {
    setLoading(true);
    try {
      const [studentsSnap, resultsSnap, attendanceSnap, gradesSnap, sectionsSnap] =
        await Promise.all([
          getDocs(collection(db, "students")),
          getDocs(collection(db, "results")),
          getDocs(collection(db, "attendance")),
          getDocs(collection(db, "grades")),
          getDocs(collection(db, "sections")),
        ]);
      setStudents(studentsSnap.docs.map((d) => ({ id: d.id, ...d.data() })));
      setResults(resultsSnap.docs.map((d) => d.data()));
      setAttendance(attendanceSnap.docs.map((d) => d.data()));
      setGrades(
        gradesSnap.docs
          .map((d) => ({ id: d.id, ...d.data() }))
          .sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }))
      );
      setSections(
        sectionsSnap.docs
          .map((d) => ({ id: d.id, ...d.data() }))
          .sort((a, b) => a.name.localeCompare(b.name))
      );
    } catch (error) {
      console.error("Error loading report card data:", error);
      toast.error("Failed to load report card data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  // One full report per student: subjects, GPA, attendance, rank, comment.
  const reports = useMemo(() => {
    const base = students.map((student) => {
      const sid = student.studentId || student.id;
      const own = results.filter((r) => r.studentId === sid && (r.outOf || 0) > 0);

      // Subject-wise totals
      const bySubject = {};
      own.forEach((r) => {
        const key = r.subject || "Other";
        if (!bySubject[key]) bySubject[key] = { score: 0, outOf: 0, count: 0 };
        bySubject[key].score += r.score || 0;
        bySubject[key].outOf += r.outOf;
        bySubject[key].count += 1;
      });
      const subjects = Object.entries(bySubject)
        .map(([subject, s]) => {
          const pct = (s.score / s.outOf) * 100;
          const g = gradeFor(pct);
          return {
            subject,
            count: s.count,
            score: s.score,
            outOf: s.outOf,
            pct: Math.round(pct * 10) / 10,
            letter: g.letter,
            points: g.points,
          };
        })
        .sort((a, b) => a.subject.localeCompare(b.subject));

      const totalScore = subjects.reduce((s, x) => s + x.score, 0);
      const totalOutOf = subjects.reduce((s, x) => s + x.outOf, 0);
      const average = totalOutOf > 0 ? Math.round((totalScore / totalOutOf) * 1000) / 10 : 0;
      const gpa =
        subjects.length > 0
          ? Math.round((subjects.reduce((s, x) => s + x.points, 0) / subjects.length) * 100) / 100
          : 0;

      const own_att = attendance.filter((a) => a.studentId === sid);
      const presentCount = own_att.filter(
        (a) => a.status === "Present" || a.status === "Late"
      ).length;
      const attendancePct =
        own_att.length > 0 ? Math.round((presentCount / own_att.length) * 100) : 0;

      return {
        id: student.id,
        sid,
        name: student.fullName || student.firstName || "Unnamed Student",
        gender: student.gender || "",
        grade: student.grade || "—",
        section: student.section || "—",
        subjects,
        average,
        gpa,
        overallGrade: gradeFor(average),
        attendancePct,
        hasAttendance: own_att.length > 0,
        hasResults: subjects.length > 0,
      };
    });

    // Class ranking: within each grade+section, by average (competition rank).
    const classes = {};
    base.forEach((r) => {
      if (!r.hasResults) return;
      const key = `${r.grade}|${r.section}`;
      (classes[key] = classes[key] || []).push(r);
    });
    Object.values(classes).forEach((cls) => {
      cls.sort((a, b) => b.average - a.average);
      cls.forEach((r, i) => {
        r.rank = i > 0 && cls[i - 1].average === r.average ? cls[i - 1].rank : i + 1;
        r.classSize = cls.length;
      });
    });

    return base.map((r) => ({ ...r, comment: buildComment(r) }));
  }, [students, results, attendance]);

  const filtered = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();
    return reports
      .filter((r) => {
        if (gradeFilter && r.grade !== gradeFilter) return false;
        if (sectionFilter && r.section !== sectionFilter) return false;
        if (term) {
          if (
            !r.name.toLowerCase().includes(term) &&
            !String(r.sid).toLowerCase().includes(term)
          )
            return false;
        }
        return true;
      })
      .sort((a, b) => (a.rank || Infinity) - (b.rank || Infinity) || a.name.localeCompare(b.name));
  }, [reports, searchTerm, gradeFilter, sectionFilter]);

  // ---------- PDF ----------

  // Draws one full report card onto the current jsPDF page.
  const drawReportPage = (doc, report) => {
    const pageW = doc.internal.pageSize.width;

    doc.setFillColor(29, 78, 216);
    doc.rect(0, 0, pageW, 30, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(18);
    doc.text(schoolName, pageW / 2, 13, { align: "center" });
    doc.setFontSize(10);
    doc.text(tagline, pageW / 2, 20, { align: "center" });
    doc.setFontSize(8);
    doc.text(
      [footer.address, footer.phone, footer.email].filter(Boolean).join("  •  "),
      pageW / 2,
      26,
      { align: "center" }
    );

    doc.setTextColor(11, 11, 11);
    doc.setFontSize(14);
    doc.text("STUDENT REPORT CARD", pageW / 2, 40, { align: "center" });
    doc.setFontSize(9);
    doc.setTextColor(82, 81, 78);
    doc.text(`Academic Year ${new Date().getFullYear()}`, pageW / 2, 46, { align: "center" });

    // Student info block
    doc.setTextColor(11, 11, 11);
    doc.setFontSize(10);
    const infoY = 56;
    doc.text(`Name: ${report.name}`, 14, infoY);
    doc.text(`Student ID: ${report.sid}`, 14, infoY + 6);
    doc.text(`Grade: ${report.grade}    Section: ${report.section}`, pageW / 2 + 10, infoY);
    doc.text(
      `Rank: ${report.rank ? `${report.rank} of ${report.classSize}` : "N/A"}`,
      pageW / 2 + 10,
      infoY + 6
    );

    autoTable(doc, {
      startY: infoY + 12,
      head: [["Subject", "Assessments", "Score", "Out Of", "Percentage", "Grade", "Points"]],
      body: report.subjects.map((s) => [
        s.subject,
        s.count,
        s.score,
        s.outOf,
        `${s.pct}%`,
        s.letter,
        s.points.toFixed(2),
      ]),
      theme: "grid",
      styles: { fontSize: 9 },
      headStyles: { fillColor: [29, 78, 216] },
    });

    const y = doc.lastAutoTable.finalY + 8;
    doc.setFontSize(10);
    doc.text(`Overall Average: ${report.average}%  (${report.overallGrade.letter})`, 14, y);
    doc.text(`Cumulative GPA: ${report.gpa.toFixed(2)} / 4.00`, 14, y + 6);
    doc.text(
      `Attendance: ${report.hasAttendance ? `${report.attendancePct}%` : "No records"}`,
      14,
      y + 12
    );

    doc.setFontSize(10);
    doc.text("Teacher's Comment:", 14, y + 22);
    doc.setFontSize(9);
    doc.setTextColor(82, 81, 78);
    doc.text(doc.splitTextToSize(report.comment, pageW - 28), 14, y + 28);

    // Signature lines
    const sigY = y + 52;
    doc.setDrawColor(150, 150, 150);
    doc.line(14, sigY, 74, sigY);
    doc.line(pageW - 74, sigY, pageW - 14, sigY);
    doc.setTextColor(82, 81, 78);
    doc.setFontSize(8);
    doc.text("Homeroom Teacher", 14, sigY + 4);
    doc.text("Principal", pageW - 74, sigY + 4);
    doc.text(`Generated: ${new Date().toLocaleDateString()}`, pageW / 2, sigY + 4, {
      align: "center",
    });
  };

  const handleExportPDF = (report) => {
    setExporting(true);
    try {
      const doc = new jsPDF("p", "mm", "a4");
      drawReportPage(doc, report);
      doc.save(`report-card-${report.sid}.pdf`);
      toast.success("Report card exported");
    } catch (error) {
      console.error("PDF export failed:", error);
      toast.error("PDF export failed");
    } finally {
      setExporting(false);
    }
  };

  // One PDF, one page per student in the currently selected class.
  const handleBulkExport = () => {
    if (!gradeFilter || !sectionFilter) {
      toast.error("Select a grade and section first");
      return;
    }
    const cls = filtered.filter((r) => r.hasResults);
    if (cls.length === 0) {
      toast.error("No students with results in this class");
      return;
    }
    setExporting(true);
    try {
      const doc = new jsPDF("p", "mm", "a4");
      cls.forEach((report, i) => {
        if (i > 0) doc.addPage();
        drawReportPage(doc, report);
      });
      doc.save(`report-cards-${gradeFilter}-${sectionFilter}.pdf`);
      toast.success(`${cls.length} report cards exported`);
    } catch (error) {
      console.error("Bulk export failed:", error);
      toast.error("Bulk export failed");
    } finally {
      setExporting(false);
    }
  };

  const handlePrint = () => window.print();

  const gpaColor = (gpa) => {
    if (gpa >= 3.5) return "text-green-700";
    if (gpa >= 2.5) return "text-yellow-700";
    if (gpa >= 1.5) return "text-orange-700";
    return "text-red-700";
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <SEO
        title="Report Cards"
        description="Generate and print student report cards"
        noindex
      />

      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 inline-flex items-center gap-3">
              <Icon name="result" className="text-blue-700" />
              Report Cards
            </h1>
            <p className="text-gray-600 mt-1">
              Generate, print, and export student report cards
            </p>
          </div>
          <button
            onClick={handleBulkExport}
            disabled={exporting || loading}
            className="inline-flex items-center gap-2 bg-blue-700 text-white px-4 py-2.5 rounded-lg hover:bg-blue-800 transition text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            title="Exports one PDF with a page per student in the selected class"
          >
            <Icon name="download" />
            Bulk Export Class PDF
          </button>
        </div>

        {/* Search + Filters */}
        <div className="bg-white rounded-xl shadow p-4 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                <Icon name="search" />
              </span>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by name or student ID..."
                className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm"
              />
            </div>
            <select
              value={gradeFilter}
              onChange={(e) => setGradeFilter(e.target.value)}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm bg-white"
            >
              <option value="">All Grades</option>
              {grades.map((g) => (
                <option key={g.id} value={g.name}>{g.name}</option>
              ))}
            </select>
            <select
              value={sectionFilter}
              onChange={(e) => setSectionFilter(e.target.value)}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm bg-white"
            >
              <option value="">All Sections</option>
              {sections.map((s) => (
                <option key={s.id} value={s.name}>{s.name}</option>
              ))}
            </select>
          </div>
          {(!gradeFilter || !sectionFilter) && (
            <p className="text-xs text-gray-400 mt-2">
              Tip: select both a grade and a section to enable bulk class export.
            </p>
          )}
        </div>

        {/* Student list */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <SkeletonCard count={6} />
          </div>
        ) : filtered.length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-gray-300 mb-3">
              <Icon name="search" size="3x" />
            </div>
            <h3 className="text-lg font-semibold text-gray-700">No students found</h3>
            <p className="text-sm text-gray-500 mt-1">Try adjusting your search or filters</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((report) => (
              <div
                key={report.id}
                onClick={() => setSelected(report)}
                className="bg-white border-2 border-gray-100 rounded-xl p-5 cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-blue-200"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 className="text-base font-bold text-gray-800 truncate">{report.name}</h3>
                    <p className="text-xs text-gray-500 mt-0.5">
                      {report.sid} • {report.grade} - Section {report.section}
                    </p>
                  </div>
                  {report.rank && (
                    <span className="shrink-0 text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200 rounded-full px-2.5 py-1">
                      #{report.rank} of {report.classSize}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-3 gap-2 mt-4 text-center">
                  <div className="bg-gray-50 rounded-lg py-2">
                    <div className={`text-lg font-bold ${report.hasResults ? gpaColor(report.gpa) : "text-gray-400"}`}>
                      {report.hasResults ? report.gpa.toFixed(2) : "—"}
                    </div>
                    <div className="text-[10px] text-gray-500">GPA</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg py-2">
                    <div className="text-lg font-bold text-gray-800">
                      {report.hasResults ? `${report.average}%` : "—"}
                    </div>
                    <div className="text-[10px] text-gray-500">Average</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg py-2">
                    <div className="text-lg font-bold text-gray-800">
                      {report.hasAttendance ? `${report.attendancePct}%` : "—"}
                    </div>
                    <div className="text-[10px] text-gray-500">Attendance</div>
                  </div>
                </div>

                <div className="mt-3 flex justify-end text-xs text-blue-600 font-medium">
                  View report card →
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Report Card Modal */}
      {selected && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 print:static print:block print:bg-white print:p-0"
          onClick={() => setSelected(null)}
        >
          <div
            className="report-print-area bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto print:max-h-none print:shadow-none print:rounded-none"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Branded header */}
            <div className="bg-gradient-to-r from-blue-700 to-blue-800 text-white px-8 py-6 rounded-t-2xl print:rounded-none">
              <div className="flex items-center justify-center gap-4">
                {logo && <img src={logo} alt="" className="h-12 w-12 object-contain bg-white rounded-full p-1" />}
                <div className="text-center">
                  <h2 className="text-2xl font-bold">{schoolName}</h2>
                  <p className="text-sm text-blue-100">{tagline}</p>
                </div>
              </div>
              <p className="text-center text-xs text-blue-200 mt-2">
                {[footer.address, footer.phone, footer.email].filter(Boolean).join("  •  ")}
              </p>
              <h3 className="text-center text-lg font-semibold mt-4 tracking-widest">
                STUDENT REPORT CARD
              </h3>
              <p className="text-center text-xs text-blue-200">
                Academic Year {new Date().getFullYear()}
              </p>
            </div>

            <div className="p-8">
              {/* Student info */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6 text-sm">
                <div>
                  <div className="text-xs text-gray-400">Student Name</div>
                  <div className="font-semibold text-gray-800">{selected.name}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-400">Student ID</div>
                  <div className="font-semibold text-gray-800">{selected.sid}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-400">Grade / Section</div>
                  <div className="font-semibold text-gray-800">
                    {selected.grade} - {selected.section}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-gray-400">Class Rank</div>
                  <div className="font-semibold text-amber-700">
                    {selected.rank ? `${selected.rank} of ${selected.classSize}` : "N/A"}
                  </div>
                </div>
              </div>

              {/* Subjects table */}
              {selected.subjects.length === 0 ? (
                <p className="text-sm text-gray-500 py-6 text-center">
                  No results recorded for this student yet.
                </p>
              ) : (
                <div className="overflow-x-auto border border-gray-200 rounded-lg mb-6">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Subject</th>
                        <th className="px-4 py-2 text-center text-xs font-semibold text-gray-600">Assessments</th>
                        <th className="px-4 py-2 text-center text-xs font-semibold text-gray-600">Score</th>
                        <th className="px-4 py-2 text-center text-xs font-semibold text-gray-600">%</th>
                        <th className="px-4 py-2 text-center text-xs font-semibold text-gray-600">Grade</th>
                        <th className="px-4 py-2 text-center text-xs font-semibold text-gray-600">Points</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selected.subjects.map((s) => (
                        <tr key={s.subject} className="border-b last:border-0">
                          <td className="px-4 py-2 font-medium text-gray-800">{s.subject}</td>
                          <td className="px-4 py-2 text-center text-gray-600">{s.count}</td>
                          <td className="px-4 py-2 text-center text-gray-600">
                            {s.score}/{s.outOf}
                          </td>
                          <td className="px-4 py-2 text-center font-semibold text-gray-800">
                            {s.pct}%
                          </td>
                          <td className="px-4 py-2 text-center">
                            <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                              s.points >= 3.5 ? "bg-green-100 text-green-700"
                              : s.points >= 2.0 ? "bg-yellow-100 text-yellow-700"
                              : s.points >= 1.0 ? "bg-orange-100 text-orange-700"
                              : "bg-red-100 text-red-700"
                            }`}>
                              {s.letter}
                            </span>
                          </td>
                          <td className="px-4 py-2 text-center text-gray-600">
                            {s.points.toFixed(2)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Summary row */}
              <div className="grid grid-cols-3 gap-4 mb-6 text-center">
                <div className="bg-blue-50 border border-blue-100 rounded-lg py-3">
                  <div className={`text-2xl font-bold ${gpaColor(selected.gpa)}`}>
                    {selected.hasResults ? selected.gpa.toFixed(2) : "—"}
                  </div>
                  <div className="text-xs text-gray-600">Cumulative GPA (4.00)</div>
                </div>
                <div className="bg-green-50 border border-green-100 rounded-lg py-3">
                  <div className="text-2xl font-bold text-gray-800">
                    {selected.hasResults
                      ? `${selected.average}% (${selected.overallGrade.letter})`
                      : "—"}
                  </div>
                  <div className="text-xs text-gray-600">Overall Average</div>
                </div>
                <div className="bg-purple-50 border border-purple-100 rounded-lg py-3">
                  <div className="text-2xl font-bold text-gray-800">
                    {selected.hasAttendance ? `${selected.attendancePct}%` : "—"}
                  </div>
                  <div className="text-xs text-gray-600">Attendance</div>
                </div>
              </div>

              {/* Teacher's comment */}
              <div className="border border-gray-200 rounded-lg p-4 mb-6">
                <div className="text-xs font-semibold text-gray-500 mb-1">
                  TEACHER'S COMMENT
                </div>
                <p className="text-sm text-gray-700 italic">{selected.comment}</p>
              </div>

              {/* Signatures */}
              <div className="flex justify-between items-end text-xs text-gray-500 pt-8">
                <div className="text-center">
                  <div className="border-t border-gray-300 w-40 mb-1" />
                  Homeroom Teacher
                </div>
                <div>Generated {new Date().toLocaleDateString()}</div>
                <div className="text-center">
                  <div className="border-t border-gray-300 w-40 mb-1" />
                  Principal
                </div>
              </div>

              {/* Actions (hidden when printing) */}
              <div className="flex gap-3 mt-8 pt-4 border-t print:hidden">
                <button
                  onClick={handlePrint}
                  className="flex-1 inline-flex items-center justify-center gap-2 bg-blue-700 text-white py-2.5 rounded-lg hover:bg-blue-800 transition text-sm font-medium"
                >
                  🖨️ Print
                </button>
                <button
                  onClick={() => handleExportPDF(selected)}
                  disabled={exporting}
                  className="flex-1 inline-flex items-center justify-center gap-2 bg-green-600 text-white py-2.5 rounded-lg hover:bg-green-700 transition text-sm font-medium disabled:opacity-50"
                >
                  <Icon name="download" /> Download PDF
                </button>
                <button
                  onClick={() => setSelected(null)}
                  className="px-6 py-2.5 rounded-lg bg-gray-200 text-gray-700 hover:bg-gray-300 transition text-sm font-medium"
                >
                  Close
                </button>
              </div>
            </div>
          </div>

          {/* Print isolation: only the open report card is printed. */}
          <style>{`
            @media print {
              body * { visibility: hidden; }
              .report-print-area, .report-print-area * { visibility: visible; }
              .report-print-area {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                max-height: none !important;
                overflow: visible !important;
              }
            }
          `}</style>
        </div>
      )}
    </div>
  );
}
