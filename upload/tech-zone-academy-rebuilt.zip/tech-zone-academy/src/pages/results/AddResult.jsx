// src/pages/AddResult.jsx
import { useState, useEffect } from "react";
import { useAuth } from "../../context/AuthContext";
import { db, collection, addDoc, getDocs, query, where, doc, getDoc, updateDoc } from "../../supabase/supabase";
import { useNavigate, useLocation } from "react-router-dom"; // ✅ Added useLocation

export default function AddResult() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation(); // ✅ For receiving edit data
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");

  // Teacher data
  const [teacherData, setTeacherData] = useState(null);
  const [assignedClasses, setAssignedClasses] = useState([]);
  const [students, setStudents] = useState([]);
  const [, setFilteredStudents] = useState([]);

  // Form fields
  const [selectedGrade, setSelectedGrade] = useState("");
  const [selectedSection, setSelectedSection] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("");
  const [selectedStudent, setSelectedStudent] = useState("");
  const [assessmentType, setAssessmentType] = useState("test");
  const [assessmentName, setAssessmentName] = useState("");
  const [score, setScore] = useState("");
  const [maxScore, setMaxScore] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [remark, setRemark] = useState("");
  const [studentName, setStudentName] = useState("");

  // Bulk entry
  const [bulkMode, setBulkMode] = useState(false);
  const [studentScores, setStudentScores] = useState({});

  // Edit mode
  const [editingResult, setEditingResult] = useState(null);
  const [isEditing, setIsEditing] = useState(false);

  // Assessment types
  const assessmentTypes = [
    { value: "test", label: "📝 Test" },
    { value: "class_activity", label: "📋 Class Activity" },
    { value: "assignment", label: "📄 Assignment" },
    { value: "exam", label: "📊 Exam" },
  ];

  // ✅ Check if we're in edit mode from navigation
  const fetchTeacherData = async () => {
    setLoading(true);
    try {
      const teacherDoc = await getDoc(doc(db, "teachers", user.uid));
      if (teacherDoc.exists()) {
        setTeacherData(teacherDoc.data());
      }

      const assignmentsQuery = query(
        collection(db, "teacherAssignments"),
        where("teacherId", "==", user.uid)
      );
      const assignmentsSnapshot = await getDocs(assignmentsQuery);
      const assignments = [];
      assignmentsSnapshot.forEach((doc) => {
        assignments.push({ id: doc.id, ...doc.data() });
      });
      setAssignedClasses(assignments);

      if (assignments.length > 0) {
        setSelectedGrade(assignments[0].grade);
        setSelectedSection(assignments[0].section);
        setSelectedSubject(assignments[0].subject);
      }

    } catch (error) {
      setError("Error loading data: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchStudents = async () => {
    try {
      const studentsQuery = query(
        collection(db, "students"),
        where("grade", "==", selectedGrade),
        where("section", "==", selectedSection)
      );
      const studentsSnap = await getDocs(studentsQuery);
      const studentsData = [];
      studentsSnap.forEach((doc) => {
        studentsData.push({ id: doc.id, ...doc.data() });
      });
      setStudents(studentsData.sort((a, b) => a.firstName.localeCompare(b.firstName)));
      setFilteredStudents(studentsData);
    } catch (error) {
      setError("Error loading students: " + error.message);
    }
  };

  // ✅ Fetch students for edit mode
  const fetchStudentsForEdit = async (grade, section) => {
    try {
      const studentsQuery = query(
        collection(db, "students"),
        where("grade", "==", grade),
        where("section", "==", section)
      );
      const studentsSnap = await getDocs(studentsQuery);
      const studentsData = [];
      studentsSnap.forEach((doc) => {
        studentsData.push({ id: doc.id, ...doc.data() });
      });
      setStudents(studentsData.sort((a, b) => a.firstName.localeCompare(b.firstName)));
      setFilteredStudents(studentsData);
    } catch (error) {
      setError("Error loading students: " + error.message);
    }
  };

  useEffect(() => {
    if (location.state?.editResult) {
      const result = location.state.editResult;
       
      setIsEditing(true);
      setEditingResult(result);
      setSelectedStudent(result.studentId);
      setStudentName(result.studentName);
      setSelectedGrade(result.grade);
      setSelectedSection(result.section);
      setSelectedSubject(result.subject);
      setAssessmentType(result.assessmentType || "test");
      setAssessmentName(result.assessment);
      setScore(String(result.score));
      setMaxScore(String(result.outOf));
      setDate(result.date || new Date().toISOString().split("T")[0]);
      setRemark(result.remark || "");
      setBulkMode(false);

      // Fetch students for this grade/section
      fetchStudentsForEdit(result.grade, result.section);
    }
     
  }, [location.state]);

  useEffect(() => {
    if (user && !location.state?.editResult) {
      fetchTeacherData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- run only when the authenticated user changes; helpers are stable
  }, [user]);

  useEffect(() => {
    if (selectedGrade && selectedSection && !location.state?.editResult) {
      fetchStudents();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- run only when the selected grade/section changes; helpers are stable
  }, [selectedGrade, selectedSection]);

  const handleStudentSelect = (studentId) => {
    setSelectedStudent(studentId);
    const student = students.find(s => s.studentId === studentId);
    if (student) {
      setStudentName(`${student.firstName} ${student.fatherName}`);
    }
  };

  // Validation function
  const validateScore = (scoreValue, maxScoreValue) => {
    if (!scoreValue || !maxScoreValue) return true;
    const scoreNum = Number(scoreValue);
    const maxNum = Number(maxScoreValue);
    if (scoreNum > maxNum) {
      setError(`Score (${scoreNum}) cannot be greater than max score (${maxNum})`);
      return false;
    }
    if (scoreNum < 0) {
      setError("Score cannot be negative");
      return false;
    }
    if (maxNum <= 0) {
      setError("Max score must be greater than 0");
      return false;
    }
    return true;
  };

  const handleScoreChange = (value) => {
    setScore(value);
    setError("");
    if (maxScore && value) {
      validateScore(value, maxScore);
    }
  };

  const handleMaxScoreChange = (value) => {
    setMaxScore(value);
    setError("");
    if (score && value) {
      validateScore(score, value);
    }
  };

  const handleBulkScoreChange = (studentId, value, type) => {
    setError("");
    const currentStudent = studentScores[studentId] || {};

    if (type === "score" && currentStudent.maxScore) {
      if (Number(value) > Number(currentStudent.maxScore)) {
        setError(`Score (${value}) cannot exceed max score (${currentStudent.maxScore}) for this student`);
        return;
      }
    }
    if (type === "maxScore" && currentStudent.score) {
      if (Number(currentStudent.score) > Number(value)) {
        setError(`Score (${currentStudent.score}) cannot exceed max score (${value}) for this student`);
        return;
      }
    }

    setStudentScores(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        [type]: value,
      },
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setSuccess("");

    try {
      if (!selectedStudent && !bulkMode) {
        setError("Please select a student");
        setLoading(false);
        return;
      }
      if (!selectedSubject) {
        setError("Please select a subject");
        setLoading(false);
        return;
      }
      if (!assessmentName.trim()) {
        setError("Please enter assessment name");
        setLoading(false);
        return;
      }

      if (bulkMode) {
        let hasError = false;
        for (const student of students) {
          const studentScore = studentScores[student.studentId]?.score;
          const studentMax = studentScores[student.studentId]?.maxScore || maxScore;
          if (studentScore && studentScore !== "") {
            if (Number(studentScore) > Number(studentMax)) {
              setError(`${student.firstName} ${student.fatherName}: Score (${studentScore}) cannot exceed max score (${studentMax})`);
              hasError = true;
              break;
            }
          }
        }
        if (hasError) {
          setLoading(false);
          return;
        }

        const bulkResults = [];
        for (const student of students) {
          const studentScore = studentScores[student.studentId]?.score || "";
          const studentMaxScore = studentScores[student.studentId]?.maxScore || maxScore;
          
          if (studentScore && studentScore !== "" && studentScore > 0) {
            await addDoc(collection(db, "results"), {
              studentId: student.studentId,
              studentName: `${student.firstName} ${student.fatherName}`,
              grade: selectedGrade,
              section: selectedSection,
              subject: selectedSubject,
              assessment: assessmentName,
              assessmentType: assessmentType,
              score: Number(studentScore),
              outOf: Number(studentMaxScore),
              date: date,
              remark: remark || "",
              teacherId: user.uid,
              teacherName: teacherData?.fullName || teacherData?.firstName || "",
              createdAt: new Date().toISOString(),
            });
            bulkResults.push(`${student.firstName} ${student.fatherName}`);
          }
        }
        setSuccess(`✅ Results saved for ${bulkResults.length} students successfully!`);
        setStudentScores({});
      } else {
        if (!validateScore(score, maxScore)) {
          setLoading(false);
          return;
        }

        if (isEditing && editingResult) {
          // ✅ Update existing result
          await updateDoc(doc(db, "results", editingResult.id), {
            score: Number(score),
            outOf: Number(maxScore),
            assessment: assessmentName,
            assessmentType: assessmentType,
            date: date,
            remark: remark || "",
            updatedAt: new Date().toISOString(),
          });
          setSuccess(`✅ Result updated for ${studentName} successfully!`);
          setIsEditing(false);
          setEditingResult(null);
          // Navigate back to teacher results after short delay
          setTimeout(() => {
            navigate("/teacher-results");
          }, 1500);
        } else {
          await addDoc(collection(db, "results"), {
            studentId: selectedStudent,
            studentName: studentName,
            grade: selectedGrade,
            section: selectedSection,
            subject: selectedSubject,
            assessment: assessmentName,
            assessmentType: assessmentType,
            score: Number(score),
            outOf: Number(maxScore),
            date: date,
            remark: remark || "",
            teacherId: user.uid,
            teacherName: teacherData?.fullName || teacherData?.firstName || "",
            createdAt: new Date().toISOString(),
          });
          setSuccess(`✅ Result saved for ${studentName} successfully!`);
        }

        if (!isEditing) {
          setAssessmentName("");
          setScore("");
          setMaxScore("");
          setRemark("");
        }
      }

    } catch (error) {
      setError("Error saving result: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  // ✅ Cancel edit
  const cancelEdit = () => {
    setIsEditing(false);
    setEditingResult(null);
    setAssessmentName("");
    setScore("");
    setMaxScore("");
    setRemark("");
    setError("");
    navigate("/teacher-results");
  };

  // Get unique subjects from assigned classes
  const uniqueSubjects = [...new Set(assignedClasses.map(a => a.subject))];
  const uniqueGrades = [...new Set(assignedClasses.map(a => a.grade))];
  const uniqueSections = [...new Set(assignedClasses.map(a => a.section))];

  if (loading && assignedClasses.length === 0 && !location.state?.editResult) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading your classes...</p>
        </div>
      </div>
    );
  }

  if (assignedClasses.length === 0 && !location.state?.editResult) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">📋</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">No Classes Assigned</h2>
          <p className="text-gray-600">You are not assigned to any classes yet.</p>
          <button
            onClick={() => navigate("/teacher-dashboard")}
            className="mt-4 bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              {isEditing ? "✏️ Edit Result" : "📝 Add Student Results"}
            </h1>
            <p className="text-gray-600 text-sm mt-1">
              {teacherData?.fullName || teacherData?.firstName || "Teacher"} • {assignedClasses.length} classes assigned
            </p>
          </div>
          <div className="flex items-center gap-3">
            <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
              👨‍🏫 Teacher
            </span>
            {isEditing && (
              <button
                onClick={cancelEdit}
                className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition text-sm"
              >
                Cancel Edit
              </button>
            )}
          </div>
        </div>

        {/* Error/Success Messages */}
        {error && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            ❌ {error}
          </div>
        )}
        {success && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {success}
          </div>
        )}

        {/* Warning */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4 text-sm text-yellow-700">
          ⚠️ Score cannot exceed Max Score. The Save button will be disabled if validation fails.
        </div>

        {/* Main Form */}
        <div id="result-form" className="bg-white rounded-xl shadow-md p-6">
          <form onSubmit={handleSubmit}>
            {/* Class Selection */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Grade *
                </label>
                <select
                  value={selectedGrade}
                  onChange={(e) => setSelectedGrade(e.target.value)}
                  className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                  disabled={isEditing}
                >
                  {isEditing ? (
                    <option value={selectedGrade}>{selectedGrade}</option>
                  ) : (
                    uniqueGrades.map((grade) => (
                      <option key={grade} value={grade}>{grade}</option>
                    ))
                  )}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Section *
                </label>
                <select
                  value={selectedSection}
                  onChange={(e) => setSelectedSection(e.target.value)}
                  className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                  disabled={isEditing}
                >
                  {isEditing ? (
                    <option value={selectedSection}>{selectedSection}</option>
                  ) : (
                    uniqueSections.map((section) => (
                      <option key={section} value={section}>{section}</option>
                    ))
                  )}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Subject *
                </label>
                <select
                  value={selectedSubject}
                  onChange={(e) => setSelectedSubject(e.target.value)}
                  className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                  disabled={isEditing}
                >
                  {isEditing ? (
                    <option value={selectedSubject}>{selectedSubject}</option>
                  ) : (
                    uniqueSubjects.map((subject) => (
                      <option key={subject} value={subject}>{subject}</option>
                    ))
                  )}
                </select>
              </div>
            </div>

            {/* Assessment Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Assessment Type *
                </label>
                <select
                  value={assessmentType}
                  onChange={(e) => setAssessmentType(e.target.value)}
                  className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  {assessmentTypes.map((type) => (
                    <option key={type.value} value={type.value}>{type.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Assessment Name *
                </label>
                <input
                  type="text"
                  value={assessmentName}
                  onChange={(e) => setAssessmentName(e.target.value)}
                  placeholder="e.g., Chapter 1 Test, Midterm, Project"
                  className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                />
              </div>
            </div>

            {/* Score & Date */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Score *
                </label>
                <input
                  type="number"
                  value={score}
                  onChange={(e) => handleScoreChange(e.target.value)}
                  placeholder="0"
                  className={`w-full border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none ${
                    score && maxScore && Number(score) > Number(maxScore) ? 'border-red-500 bg-red-50' : ''
                  }`}
                  min="0"
                  required
                />
                {score && maxScore && Number(score) > Number(maxScore) && (
                  <p className="text-xs text-red-500 mt-1">Score cannot exceed {maxScore}</p>
                )}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Max Score *
                </label>
                <input
                  type="number"
                  value={maxScore}
                  onChange={(e) => handleMaxScoreChange(e.target.value)}
                  placeholder="100"
                  className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  min="1"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Date
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Mode Toggle - Hide when editing */}
            {!isEditing && (
              <div className="flex items-center gap-4 mb-6 bg-gray-50 p-3 rounded-lg">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    checked={!bulkMode}
                    onChange={() => setBulkMode(false)}
                    className="w-4 h-4 text-blue-700"
                  />
                  <span className="text-sm font-medium text-gray-700">Single Entry</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    checked={bulkMode}
                    onChange={() => setBulkMode(true)}
                    className="w-4 h-4 text-blue-700"
                  />
                  <span className="text-sm font-medium text-gray-700">Bulk Entry</span>
                </label>
              </div>
            )}

            {/* Student Selection - Single Mode */}
            {!bulkMode && (
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Student *
                </label>
                <select
                  value={selectedStudent}
                  onChange={(e) => handleStudentSelect(e.target.value)}
                  className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                >
                  <option value="">Select a student</option>
                  {students.map((student) => (
                    <option key={student.id} value={student.studentId}>
                      {student.firstName} {student.fatherName}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Bulk Entry - Student Grid */}
            {bulkMode && !isEditing && (
              <div className="mb-6">
                <p className="text-sm text-gray-600 mb-3">
                  Enter scores for each student (leave blank to skip)
                </p>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-3 py-2 text-left text-xs font-semibold text-gray-600">#</th>
                        <th className="px-3 py-2 text-left text-xs font-semibold text-gray-600">Student</th>
                        <th className="px-3 py-2 text-center text-xs font-semibold text-gray-600">Score</th>
                        <th className="px-3 py-2 text-center text-xs font-semibold text-gray-600">Max Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      {students.map((student, index) => {
                        const sScore = studentScores[student.studentId]?.score || "";
                        const sMax = studentScores[student.studentId]?.maxScore || maxScore;
                        const hasError = sScore && sMax && Number(sScore) > Number(sMax);
                        return (
                          <tr key={student.id} className="border-b hover:bg-gray-50">
                            <td className="px-3 py-2 text-sm text-gray-500">{index + 1}</td>
                            <td className="px-3 py-2 font-medium text-gray-800">
                              {student.firstName} {student.fatherName}
                            </td>
                            <td className="px-3 py-2 text-center">
                              <input
                                type="number"
                                value={sScore}
                                onChange={(e) => handleBulkScoreChange(student.studentId, e.target.value, "score")}
                                placeholder="Score"
                                className={`w-20 border rounded p-1 text-center focus:ring-2 focus:ring-blue-500 outline-none ${
                                  hasError ? 'border-red-500 bg-red-50' : ''
                                }`}
                                min="0"
                              />
                            </td>
                            <td className="px-3 py-2 text-center">
                              <input
                                type="number"
                                value={sMax}
                                onChange={(e) => handleBulkScoreChange(student.studentId, e.target.value, "maxScore")}
                                placeholder="Max"
                                className="w-20 border rounded p-1 text-center focus:ring-2 focus:ring-blue-500 outline-none"
                                min="1"
                              />
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Remark */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Remark (Optional)
              </label>
              <input
                type="text"
                value={remark}
                onChange={(e) => setRemark(e.target.value)}
                placeholder="e.g., Excellent work, Needs improvement, etc."
                className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            {/* Submit Button */}
            {(() => {
              let isDisabled = loading;
              if (!bulkMode && !isEditing) {
                if (score && maxScore && Number(score) > Number(maxScore)) isDisabled = true;
                if (!selectedStudent || !assessmentName.trim() || !score || !maxScore) isDisabled = true;
              }
              if (isEditing) {
                if (score && maxScore && Number(score) > Number(maxScore)) isDisabled = true;
                if (!selectedStudent || !assessmentName.trim() || !score || !maxScore) isDisabled = true;
              }
              if (bulkMode && !isEditing) {
                let hasError = false;
                for (const student of students) {
                  const sScore = studentScores[student.studentId]?.score;
                  const sMax = studentScores[student.studentId]?.maxScore || maxScore;
                  if (sScore && sScore !== "" && Number(sScore) > Number(sMax)) {
                    hasError = true;
                    break;
                  }
                }
                if (hasError) isDisabled = true;
              }

              return (
                <button
                  type="submit"
                  disabled={isDisabled}
                  className={`w-full py-3 rounded-lg text-white font-semibold transition ${
                    isDisabled
                      ? "bg-gray-400 cursor-not-allowed"
                      : isEditing
                      ? "bg-yellow-600 hover:bg-yellow-700"
                      : "bg-blue-700 hover:bg-blue-800"
                  }`}
                >
                  {loading ? "Saving..." : isEditing ? "Update Result" : bulkMode ? "Save All Results" : "Save Result"}
                </button>
              );
            })()}
          </form>
        </div>
      </div>
    </div>
  );
}