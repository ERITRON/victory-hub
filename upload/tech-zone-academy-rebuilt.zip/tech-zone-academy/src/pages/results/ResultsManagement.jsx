import { useEffect, useState } from "react";
import { collection, getDocs } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";
import Icon from "../../components/Icon";
import { db } from "../../supabase/supabase";

const EMPTY_STATS = {
  totalResults: 0,
  totalSubjects: 0,
  totalStudents: 0,
  averageScore: 0,
  passRate: 0,
  topPerformer: null,
};

const RESULT_PAGES = [
  {
    icon: "result",
    title: "Student Report Cards",
    description: "View cumulative student report cards and subject results.",
    route: "/report-cards",
    iconClass: "bg-violet-100 text-violet-700",
    borderClass: "hover:border-violet-300",
  },
  {
    icon: "success",
    title: "Top Performers",
    description: "Rank students using cumulative assessment performance.",
    route: "/top-performers",
    iconClass: "bg-amber-100 text-amber-700",
    borderClass: "hover:border-amber-300",
  },
  {
    icon: "classroom",
    title: "Class Performance",
    description: "Compare student and subject outcomes by class.",
    route: "/class-performance",
    iconClass: "bg-emerald-100 text-emerald-700",
    borderClass: "hover:border-emerald-300",
  },
  {
    icon: "chart",
    title: "Subject Analysis",
    description: "Analyze score distribution and pass rates by subject.",
    route: "/subject-analysis",
    iconClass: "bg-blue-100 text-blue-700",
    borderClass: "hover:border-blue-300",
  },
];

function getPercentage(result) {
  const score = Number(result.score);
  const outOf = Number(result.outOf);

  if (!Number.isFinite(score) || !Number.isFinite(outOf) || outOf <= 0) {
    return null;
  }

  return Math.max(0, Math.min(100, (score / outOf) * 100));
}

function ResultsManagementSkeleton() {
  return (
    <div className="min-h-screen bg-gray-50 px-4 py-8 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl animate-pulse">
        <div className="h-8 w-64 rounded bg-gray-200" />
        <div className="mt-3 h-4 w-80 max-w-full rounded bg-gray-200" />

        <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-6">
          {Array.from({ length: 6 }).map((_, index) => (
            <div
              key={index}
              className="h-28 rounded-lg border border-gray-200 bg-white"
            />
          ))}
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, index) => (
            <div
              key={index}
              className="h-40 rounded-lg border border-gray-200 bg-white"
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export default function ResultsManagement() {
  const navigate = useNavigate();
  const [stats, setStats] = useState(EMPTY_STATS);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let isActive = true;

    const fetchStats = async () => {
      setLoading(true);
      setError(null);

      try {
        const snapshot = await getDocs(collection(db, "results"));
        const results = snapshot.docs.map((resultDoc) => resultDoc.data());
        const scoredResults = results
          .map((result) => ({
            ...result,
            percentage: getPercentage(result),
          }))
          .filter((result) => result.percentage !== null);
        const uniqueSubjects = new Set(
          results.map((result) => result.subject).filter(Boolean),
        );
        const uniqueStudents = new Set(
          results
            .map((result) => result.studentId || result.studentName)
            .filter(Boolean),
        );
        const studentTotals = scoredResults.reduce((totals, result) => {
          const studentKey =
            result.studentId || result.studentName || "unknown-student";

          if (!totals[studentKey]) {
            totals[studentKey] = {
              name: result.studentName || result.studentId || "Unknown student",
              totalScore: 0,
              totalMaximum: 0,
            };
          }

          totals[studentKey].totalScore += Number(result.score);
          totals[studentKey].totalMaximum += Number(result.outOf);
          return totals;
        }, {});
        // Headline stats use per-student cumulative percentages.
        const studentPercentages = Object.values(studentTotals).map(
          (student) =>
            student.totalMaximum > 0
              ? (student.totalScore / student.totalMaximum) * 100
              : 0,
        );
        const averageScore =
          studentPercentages.length > 0
            ? studentPercentages.reduce((sum, value) => sum + value, 0) /
              studentPercentages.length
            : 0;
        const passRate =
          studentPercentages.length > 0
            ? (studentPercentages.filter((value) => value >= 50).length /
                studentPercentages.length) *
              100
            : 0;
        const topPerformer =
          Object.values(studentTotals)
            .map((student) => ({
              ...student,
              percentage:
                student.totalMaximum > 0
                  ? Math.round(
                      (student.totalScore / student.totalMaximum) * 100,
                    )
                  : 0,
            }))
            .sort((a, b) => b.percentage - a.percentage)[0] || null;

        if (isActive) {
          setStats({
            totalResults: results.length,
            totalSubjects: uniqueSubjects.size,
            totalStudents: uniqueStudents.size,
            averageScore: Math.round(averageScore),
            passRate: Math.round(passRate),
            topPerformer,
          });
        }
      } catch (fetchError) {
        console.error("Error fetching result statistics:", fetchError);

        if (isActive) {
          setError(
            fetchError instanceof Error
              ? fetchError.message
              : "Unable to load result statistics",
          );
        }
      } finally {
        if (isActive) {
          setLoading(false);
        }
      }
    };

    fetchStats();
    return () => {
      isActive = false;
    };
  }, []);

  if (loading) {
    return <ResultsManagementSkeleton />;
  }

  const statCards = [
    {
      label: "Total Results",
      value: stats.totalResults,
      icon: "result",
      iconClass: "bg-blue-100 text-blue-700",
    },
    {
      label: "Total Subjects",
      value: stats.totalSubjects,
      icon: "subject",
      iconClass: "bg-emerald-100 text-emerald-700",
    },
    {
      label: "Total Students",
      value: stats.totalStudents,
      icon: "student",
      iconClass: "bg-violet-100 text-violet-700",
    },
    {
      label: "Average Score",
      value: `${stats.averageScore}%`,
      icon: "chart",
      iconClass: "bg-cyan-100 text-cyan-700",
    },
    {
      label: "Pass Rate",
      value: `${stats.passRate}%`,
      icon: "success",
      iconClass: "bg-amber-100 text-amber-700",
    },
    {
      label: "Top Performer",
      value: stats.topPerformer?.name || "No data",
      detail: stats.topPerformer
        ? `${stats.topPerformer.percentage}% cumulative`
        : "No scored results",
      icon: "star",
      iconClass: "bg-rose-100 text-rose-700",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 px-4 py-8 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-md bg-gray-900 text-white">
                <Icon name="result" aria-hidden="true" />
              </span>
              <div>
                <h1 className="text-2xl font-bold text-gray-950 sm:text-3xl">
                  Results Management
                </h1>
                <p className="mt-1 text-sm text-gray-500">
                  Review report cards and analyze academic performance.
                </p>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => navigate("/academic-overview")}
            className="inline-flex h-10 items-center justify-center gap-2 self-start rounded-md border border-gray-300 bg-white px-4 text-sm font-semibold text-gray-700 transition-colors hover:bg-gray-100 sm:self-auto"
          >
            <Icon name="dashboard" aria-hidden="true" />
            Academic Overview
          </button>
        </header>

        {error && (
          <div
            role="alert"
            className="mt-6 rounded-md border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
          >
            Result statistics could not be loaded: {error}
          </div>
        )}

        <section
          aria-label="Result statistics"
          className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-6"
        >
          {statCards.map((stat) => (
            <article
              key={stat.label}
              className="min-w-0 rounded-lg border border-gray-200 bg-white p-4 shadow-sm"
            >
              <span
                className={`flex h-9 w-9 items-center justify-center rounded-md ${stat.iconClass}`}
              >
                <Icon name={stat.icon} aria-hidden="true" />
              </span>
              <p
                className={`mt-3 break-words font-bold text-gray-950 ${
                  stat.label === "Top Performer"
                    ? "text-base leading-5"
                    : "text-2xl"
                }`}
              >
                {stat.value}
              </p>
              <p className="mt-1 text-xs font-medium text-gray-500">
                {stat.label}
              </p>
              {stat.detail && (
                <p className="mt-1 break-words text-[11px] text-gray-400">
                  {stat.detail}
                </p>
              )}
            </article>
          ))}
        </section>

        <section className="mt-8">
          <div className="mb-4">
            <h2 className="text-lg font-bold text-gray-900">
              Performance Reports
            </h2>
            <p className="mt-1 text-sm text-gray-500">
              Open a report to explore its filters and detailed analysis.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {RESULT_PAGES.map((item) => (
              <button
                key={item.route}
                type="button"
                onClick={() => navigate(item.route)}
                className={`flex min-h-44 flex-col rounded-lg border border-gray-200 bg-white p-5 text-left shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${item.borderClass}`}
              >
                <span
                  className={`flex h-11 w-11 items-center justify-center rounded-md text-lg ${item.iconClass}`}
                >
                  <Icon name={item.icon} aria-hidden="true" />
                </span>
                <span className="mt-4 text-base font-bold text-gray-900">
                  {item.title}
                </span>
                <span className="mt-2 flex-1 text-sm leading-5 text-gray-500">
                  {item.description}
                </span>
                <span className="mt-4 text-xs font-semibold text-blue-700">
                  Open report
                </span>
              </button>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
