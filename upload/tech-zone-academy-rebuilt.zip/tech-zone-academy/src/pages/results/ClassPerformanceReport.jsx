// src/pages/results/ClassPerformanceReport.jsx
import { Fragment, useEffect, useMemo, useState } from "react";
import { db, collection, getDocs } from "../../supabase/supabase";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import toast from "react-hot-toast";
import SEO from "../../components/SEO";
import Icon from "../../components/Icon";
import { SkeletonDashboard } from "../../components/LoadingSkeleton";

const SCHOOL_NAME = "Tech Zone Academy";

const ASSESSMENT_TYPES = [
  { value: "all", label: "All Types" },
  { value: "test", label: "📝 Test" },
  { value: "quiz", label: "❓ Quiz" },
  { value: "assignment", label: "📄 Assignment" },
  { value: "exam", label: "📊 Exam" },
];

// Performance bands (pass mark = 50%, consistent across all academic pages).
const BANDS = [
  { key: "excellent", label: "Excellent", range: "80% and above", min: 80, classes: "bg-green-50 border-green-200 text-green-700" },
  { key: "good", label: "Good", range: "60% – 79%", min: 60, classes: "bg-blue-50 border-blue-200 text-blue-700" },
  { key: "satisfactory", label: "Satisfactory", range: "50% – 59%", min: 50, classes: "bg-yellow-50 border-yellow-200 text-yellow-700" },
  { key: "needsImprovement", label: "Needs Improvement", range: "Below 50%", min: 0, classes: "bg-red-50 border-red-200 text-red-700" },
];

const bandFor = (pct) => BANDS.find((b) => pct >= b.min) || BANDS.at(-1);

const statusBadge = (pct) => {
  const band = bandFor(pct);
  const styles = {
    excellent: "bg-green-100 text-green-700",
    good: "bg-blue-100 text-blue-700",
    satisfactory: "bg-yellow-100 text-yellow-700",
    needsImprovement: "bg-red-100 text-red-700",
  };
  return { label: band.label, classes: styles[band.key] };
};

export default function ClassPerformanceReport() {
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [grades, setGrades] = useState([]);
  const [sections, setSections] = useState([]);
  const [students, setStudents] = useState([]);
  const [results, setResults] = useState([]);

  const [selectedGrade, setSelectedGrade] = useState("");
  const [selectedSection, setSelectedSection] = useState("");
  const [assessmentType, setAssessmentType] = useState("all");
  const [selectedAssessment, setSelectedAssessment] = useState("");
  const [expandedId, setExpandedId] = useState(null);

  const fetchAllData = async () => {
    setLoading(true);
    try {
      const [gradesSnap, sectionsSnap, studentsSnap, resultsSnap] = await Promise.all([
        getDocs(collection(db, "grades")),
        getDocs(collection(db, "sections")),
        getDocs(collection(db, "students")),
        getDocs(collection(db, "results")),
      ]);

      const gradesData = gradesSnap.docs
        .map((d) => ({ id: d.id, ...d.data() }))
        .sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
      const sectionsData = sectionsSnap.docs
        .map((d) => ({ id: d.id, ...d.data() }))
        .sort((a, b) => a.name.localeCompare(b.name));

      setGrades(gradesData);
      setSections(sectionsData);
      setStudents(studentsSnap.docs.map((d) => ({ id: d.id, ...d.data() })));
      setResults(resultsSnap.docs.map((d) => ({ id: d.id, ...d.data() })));

      if (gradesData.length > 0) setSelectedGrade(gradesData[0].name);
      if (sectionsData.length > 0) setSelectedSection(sectionsData[0].name);
    } catch (error) {
      console.error("Error loading class performance data:", error);
      toast.error("Failed to load class performance data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  // Students in the selected class.
  const classStudents = useMemo(
    () =>
      students.filter(
        (s) => s.grade === selectedGrade && s.section === selectedSection
      ),
    [students, selectedGrade, selectedSection]
  );

  // All gradable results belonging to those students (before type/name filters) —
  // used to derive the assessment-name dropdown options.
  const classResultsAll = useMemo(() => {
    const ids = new Set(classStudents.map((s) => s.studentId || s.id));
    return results.filter((r) => ids.has(r.studentId) && (r.outOf || 0) > 0);
  }, [results, classStudents]);

  const assessmentNames = useMemo(() => {
    const pool =
      assessmentType === "all"
        ? classResultsAll
        : classResultsAll.filter((r) => r.assessmentType === assessmentType);
    return [...new Set(pool.map((r) => r.assessment).filter(Boolean))].sort();
  }, [classResultsAll, assessmentType]);

  // Keep the assessment-name filter valid when type/class changes.
  useEffect(() => {
    setSelectedAssessment((prev) =>
      prev && !assessmentNames.includes(prev) ? "" : prev
    );
  }, [assessmentNames]);

  // Results after every filter.
  const classResults = useMemo(() => {
    let rows = classResultsAll;
    if (assessmentType !== "all") {
      rows = rows.filter((r) => r.assessmentType === assessmentType);
    }
    if (selectedAssessment) {
      rows = rows.filter((r) => r.assessment === selectedAssessment);
    }
    return rows;
  }, [classResultsAll, assessmentType, selectedAssessment]);

  // Per-student rows, ranked; plus class stats, distribution, subject table.
  const report = useMemo(() => {
    const rows = classStudents.map((student) => {
      const sid = student.studentId || student.id;
      const own = classResults.filter((r) => r.studentId === sid);
      const totalScore = own.reduce((s, r) => s + (r.score || 0), 0);
      const totalMax = own.reduce((s, r) => s + r.outOf, 0);
      const pct = totalMax > 0 ? Math.round((totalScore / totalMax) * 1000) / 10 : 0;
      return {
        id: student.id,
        sid,
        name: student.fullName || student.firstName || "Unnamed Student",
        totalScore,
        totalMax,
        pct,
        hasResults: own.length > 0,
        details: own
          .map((r) => ({
            id: r.id,
            subject: r.subject || "Other",
            assessment: r.assessment || "—",
            type: r.assessmentType || "—",
            score: r.score || 0,
            outOf: r.outOf,
            pct: Math.round(((r.score || 0) / r.outOf) * 1000) / 10,
            date: r.date || "",
          }))
          .sort(
            (a, b) =>
              a.subject.localeCompare(b.subject) ||
              a.assessment.localeCompare(b.assessment)
          ),
      };
    });

    // Rank students with results (competition ranking; ties share a rank).
    const ranked = rows
      .filter((r) => r.hasResults)
      .sort((a, b) => b.pct - a.pct);
    ranked.forEach((r, i) => {
      r.rank = i > 0 && ranked[i - 1].pct === r.pct ? ranked[i - 1].rank : i + 1;
    });

    // Class average = mean of each student's cumulative percentage.
    const classAverage =
      ranked.length > 0
        ? Math.round(
            (ranked.reduce((s, r) => s + r.pct, 0) / ranked.length) * 10
          ) / 10
        : 0;
    const passed = ranked.filter((r) => r.pct >= 50).length;
    const passRate = ranked.length > 0 ? Math.round((passed / ranked.length) * 100) : 0;

    const distribution = {
      excellent: ranked.filter((r) => r.pct >= 80).length,
      good: ranked.filter((r) => r.pct >= 60 && r.pct < 80).length,
      satisfactory: ranked.filter((r) => r.pct >= 50 && r.pct < 60).length,
      needsImprovement: ranked.filter((r) => r.pct < 50).length,
    };

    // Subject-wise table.
    const bySubject = {};
    classResults.forEach((r) => {
      const key = r.subject || "Other";
      if (!bySubject[key]) {
        bySubject[key] = { score: 0, outOf: 0, students: {}, count: 0 };
      }
      bySubject[key].score += r.score || 0;
      bySubject[key].outOf += r.outOf;
      bySubject[key].count += 1;
      const st = (bySubject[key].students[r.studentId] =
        bySubject[key].students[r.studentId] || { score: 0, outOf: 0 });
      st.score += r.score || 0;
      st.outOf += r.outOf;
    });
    const subjects = Object.entries(bySubject)
      .map(([subject, s]) => {
        const perStudent = Object.values(s.students).map(
          (st) => (st.score / st.outOf) * 100
        );
        return {
          subject,
          students: perStudent.length,
          average: Math.round((s.score / s.outOf) * 1000) / 10,
          highest: Math.round(Math.max(...perStudent) * 10) / 10,
          lowest: Math.round(Math.min(...perStudent) * 10) / 10,
          passRate: Math.round(
            (perStudent.filter((p) => p >= 50).length / perStudent.length) * 100
          ),
        };
      })
      .sort((a, b) => a.subject.localeCompare(b.subject));

    return {
      ranked,
      withoutResults: rows.filter((r) => !r.hasResults),
      totalStudents: classStudents.length,
      classAverage,
      passRate,
      needsImprovement: distribution.needsImprovement,
      highest: ranked.length > 0 ? ranked[0].pct : 0,
      lowest: ranked.length > 0 ? ranked[ranked.length - 1].pct : 0,
      distribution,
      subjects,
    };
  }, [classStudents, classResults]);

  const filterLabel = () => {
    const parts = [`${selectedGrade} - Section ${selectedSection}`];
    if (assessmentType !== "all") {
      parts.push(ASSESSMENT_TYPES.find((t) => t.value === assessmentType)?.label.replace(/^\S+\s/, "") || assessmentType);
    }
    if (selectedAssessment) parts.push(selectedAssessment);
    return parts.join(" · ");
  };

  // ---------- Export / Print ----------

  const handleExportPDF = () => {
    if (report.ranked.length === 0) {
      toast.error("No results to export");
      return;
    }
    setExporting(true);
    try {
      const doc = new jsPDF("p", "mm", "a4");
      doc.setFontSize(18);
      doc.text(SCHOOL_NAME, 14, 20);
      doc.setFontSize(13);
      doc.text(`Class Performance Report — ${filterLabel()}`, 14, 29);
      doc.setFontSize(9);
      doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 36);
      doc.setFontSize(10);
      doc.text(
        `Students: ${report.totalStudents}   Class Average: ${report.classAverage}%   Pass Rate: ${report.passRate}%   Highest: ${report.highest}%   Lowest: ${report.lowest}%`,
        14,
        44
      );

      autoTable(doc, {
        startY: 50,
        head: [["Subject", "Students", "Average %", "Highest %", "Lowest %", "Pass Rate %"]],
        body: report.subjects.map((s) => [
          s.subject, s.students, s.average, s.highest, s.lowest, s.passRate,
        ]),
        theme: "striped",
        styles: { fontSize: 8 },
        headStyles: { fillColor: [29, 78, 216] },
      });

      autoTable(doc, {
        startY: doc.lastAutoTable.finalY + 8,
        head: [["Rank", "Student", "ID", "Total Score", "Percentage", "Status"]],
        body: report.ranked.map((r) => [
          r.rank,
          r.name,
          r.sid,
          `${r.totalScore}/${r.totalMax}`,
          `${r.pct}%`,
          bandFor(r.pct).label,
        ]),
        theme: "striped",
        styles: { fontSize: 8 },
        headStyles: { fillColor: [29, 78, 216] },
      });

      doc.save(`class-performance-${selectedGrade}-${selectedSection}.pdf`);
      toast.success("PDF exported");
    } catch (error) {
      console.error("PDF export failed:", error);
      toast.error("PDF export failed");
    } finally {
      setExporting(false);
    }
  };

  const handleExportExcel = () => {
    if (report.ranked.length === 0) {
      toast.error("No results to export");
      return;
    }
    setExporting(true);
    try {
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(
        workbook,
        XLSX.utils.json_to_sheet(
          report.ranked.map((r) => ({
            Rank: r.rank,
            Student: r.name,
            "Student ID": r.sid,
            "Total Score": r.totalScore,
            "Out Of": r.totalMax,
            "Percentage": r.pct,
            Status: bandFor(r.pct).label,
          }))
        ),
        "Students"
      );
      XLSX.utils.book_append_sheet(
        workbook,
        XLSX.utils.json_to_sheet(
          report.subjects.map((s) => ({
            Subject: s.subject,
            Students: s.students,
            "Average %": s.average,
            "Highest %": s.highest,
            "Lowest %": s.lowest,
            "Pass Rate %": s.passRate,
          }))
        ),
        "Subjects"
      );
      XLSX.writeFile(
        workbook,
        `class-performance-${selectedGrade}-${selectedSection}.xlsx`
      );
      toast.success("Excel exported");
    } catch (error) {
      console.error("Excel export failed:", error);
      toast.error("Excel export failed");
    } finally {
      setExporting(false);
    }
  };

  const handlePrint = () => window.print();

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto py-6 sm:py-8 px-4 sm:px-6 lg:px-8">
          <SkeletonDashboard />
        </div>
      </div>
    );
  }

  const statCards = [
    { label: "Total Students", value: report.totalStudents, color: "text-blue-700", border: "border-blue-500" },
    { label: "Class Average", value: `${report.classAverage}%`, color: "text-indigo-700", border: "border-indigo-500" },
    { label: "Pass Rate", value: `${report.passRate}%`, color: "text-green-700", border: "border-green-500" },
    { label: "Needs Improvement", value: report.needsImprovement, color: "text-red-700", border: "border-red-500" },
    { label: "Highest Score", value: `${report.highest}%`, color: "text-emerald-700", border: "border-emerald-500" },
    { label: "Lowest Score", value: `${report.lowest}%`, color: "text-orange-700", border: "border-orange-500" },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-10">
      <SEO
        title="Class Performance Report"
        description="Performance report for a class: averages, rankings, and subject analysis"
        noindex
      />

      <div className="report-print-area">
        {/* Gradient header */}
        <div className="bg-gradient-to-r from-blue-700 via-blue-800 to-indigo-800 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <h1 className="text-2xl sm:text-3xl font-bold inline-flex items-center gap-3">
              <Icon name="chart" />
              Class Performance Report
            </h1>
            <p className="text-blue-100 mt-1 text-sm sm:text-base">{filterLabel()}</p>
            <p className="text-blue-200 text-xs mt-1">
              {SCHOOL_NAME} · Generated {new Date().toLocaleDateString()}
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-4">
          {/* Filters + actions */}
          <div className="bg-white rounded-xl shadow p-4 mb-6 print:hidden">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <select
                value={selectedGrade}
                onChange={(e) => setSelectedGrade(e.target.value)}
                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm bg-white"
              >
                {grades.map((g) => (
                  <option key={g.id} value={g.name}>{g.name}</option>
                ))}
              </select>
              <select
                value={selectedSection}
                onChange={(e) => setSelectedSection(e.target.value)}
                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm bg-white"
              >
                {sections.map((s) => (
                  <option key={s.id} value={s.name}>Section {s.name}</option>
                ))}
              </select>
              <select
                value={assessmentType}
                onChange={(e) => setAssessmentType(e.target.value)}
                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm bg-white"
              >
                {ASSESSMENT_TYPES.map((t) => (
                  <option key={t.value} value={t.value}>{t.label}</option>
                ))}
              </select>
              <select
                value={selectedAssessment}
                onChange={(e) => setSelectedAssessment(e.target.value)}
                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm bg-white"
              >
                <option value="">All Assessments</option>
                {assessmentNames.map((name) => (
                  <option key={name} value={name}>{name}</option>
                ))}
              </select>
            </div>
            <div className="flex flex-wrap gap-3 mt-4">
              <button
                onClick={handleExportPDF}
                disabled={exporting}
                className="inline-flex items-center gap-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition text-sm font-medium disabled:opacity-50"
              >
                <Icon name="download" /> Export PDF
              </button>
              <button
                onClick={handleExportExcel}
                disabled={exporting}
                className="inline-flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition text-sm font-medium disabled:opacity-50"
              >
                <Icon name="download" /> Export Excel
              </button>
              <button
                onClick={handlePrint}
                className="inline-flex items-center gap-2 bg-gray-700 text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition text-sm font-medium"
              >
                🖨️ Print Report
              </button>
            </div>
          </div>

          {classStudents.length === 0 ? (
            <div className="bg-white rounded-xl shadow p-12 text-center">
              <div className="text-6xl mb-4">📭</div>
              <h3 className="text-xl font-semibold text-gray-700 mb-2">No Students</h3>
              <p className="text-gray-500">
                No students found in {selectedGrade} - Section {selectedSection}.
              </p>
            </div>
          ) : report.ranked.length === 0 ? (
            <div className="bg-white rounded-xl shadow p-12 text-center">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-semibold text-gray-700 mb-2">No Results</h3>
              <p className="text-gray-500">
                No results match the selected filters for this class yet.
              </p>
            </div>
          ) : (
            <>
              {/* Stats cards */}
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
                {statCards.map((card) => (
                  <div
                    key={card.label}
                    className={`bg-white rounded-xl shadow p-4 text-center border-l-4 ${card.border}`}
                  >
                    <div className={`text-2xl font-bold ${card.color}`}>{card.value}</div>
                    <div className="text-xs text-gray-600">{card.label}</div>
                  </div>
                ))}
              </div>

              {/* Performance distribution */}
              <div className="bg-white rounded-xl shadow p-5 mb-6">
                <h2 className="text-base font-bold text-gray-800 mb-4">
                  Performance Distribution
                </h2>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  {BANDS.map((band) => (
                    <div
                      key={band.key}
                      className={`rounded-xl border-2 p-4 text-center ${band.classes}`}
                    >
                      <div className="text-3xl font-bold">
                        {report.distribution[band.key]}
                      </div>
                      <div className="text-sm font-medium mt-1">{band.label}</div>
                      <div className="text-xs opacity-75">{band.range}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Subject-wise performance */}
              <div className="bg-white rounded-xl shadow overflow-hidden mb-6">
                <div className="px-5 py-4 border-b">
                  <h2 className="text-base font-bold text-gray-800">
                    Subject-wise Performance
                  </h2>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Subject</th>
                        <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Students</th>
                        <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Average</th>
                        <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Highest</th>
                        <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Lowest</th>
                        <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Pass Rate</th>
                      </tr>
                    </thead>
                    <tbody>
                      {report.subjects.map((s) => (
                        <tr key={s.subject} className="border-b last:border-0 hover:bg-gray-50">
                          <td className="px-4 py-3 font-medium text-gray-800">{s.subject}</td>
                          <td className="px-4 py-3 text-center text-gray-600">{s.students}</td>
                          <td className="px-4 py-3 text-center font-semibold text-gray-800">{s.average}%</td>
                          <td className="px-4 py-3 text-center text-green-700">{s.highest}%</td>
                          <td className="px-4 py-3 text-center text-red-700">{s.lowest}%</td>
                          <td className="px-4 py-3 text-center">
                            <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                              s.passRate >= 80 ? "bg-green-100 text-green-700"
                              : s.passRate >= 50 ? "bg-yellow-100 text-yellow-700"
                              : "bg-red-100 text-red-700"
                            }`}>
                              {s.passRate}%
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Student performance table */}
              <div className="bg-white rounded-xl shadow overflow-hidden">
                <div className="px-5 py-4 border-b flex items-center justify-between">
                  <h2 className="text-base font-bold text-gray-800">Student Rankings</h2>
                  <span className="text-xs text-gray-400 print:hidden">
                    Click a row for the assessment breakdown
                  </span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600 w-16">Rank</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Student</th>
                        <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Total Score</th>
                        <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Percentage</th>
                        <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {report.ranked.map((r) => {
                        const badge = statusBadge(r.pct);
                        const expanded = expandedId === r.id;
                        return (
                          <Fragment key={r.id}>
                            <tr
                              onClick={() => setExpandedId(expanded ? null : r.id)}
                              className="border-b cursor-pointer hover:bg-blue-50/50 transition"
                            >
                              <td className="px-4 py-3 text-center">
                                <span className={`inline-flex items-center justify-center w-8 h-8 rounded-full text-xs font-bold ${
                                  r.rank === 1 ? "bg-amber-100 text-amber-700"
                                  : r.rank === 2 ? "bg-gray-200 text-gray-700"
                                  : r.rank === 3 ? "bg-orange-100 text-orange-700"
                                  : "bg-gray-50 text-gray-500"
                                }`}>
                                  {r.rank}
                                </span>
                              </td>
                              <td className="px-4 py-3">
                                <p className="font-medium text-gray-800">{r.name}</p>
                                <p className="text-xs text-gray-500">{r.sid}</p>
                              </td>
                              <td className="px-4 py-3 text-center text-gray-600">
                                {r.totalScore}/{r.totalMax}
                              </td>
                              <td className="px-4 py-3 text-center font-bold text-gray-800">
                                {r.pct}%
                              </td>
                              <td className="px-4 py-3 text-center">
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${badge.classes}`}>
                                  {badge.label}
                                </span>
                              </td>
                            </tr>
                            {expanded && (
                              <tr className="bg-gray-50 border-b">
                                <td colSpan="5" className="px-6 py-4">
                                  <div className="text-xs font-semibold text-gray-500 mb-2">
                                    ASSESSMENT BREAKDOWN — {r.name}
                                  </div>
                                  <div className="overflow-x-auto">
                                    <table className="w-full text-xs bg-white rounded-lg border border-gray-200">
                                      <thead className="bg-gray-100">
                                        <tr>
                                          <th className="px-3 py-2 text-left font-semibold text-gray-600">Subject</th>
                                          <th className="px-3 py-2 text-left font-semibold text-gray-600">Assessment</th>
                                          <th className="px-3 py-2 text-center font-semibold text-gray-600">Type</th>
                                          <th className="px-3 py-2 text-center font-semibold text-gray-600">Score</th>
                                          <th className="px-3 py-2 text-center font-semibold text-gray-600">%</th>
                                          <th className="px-3 py-2 text-center font-semibold text-gray-600">Date</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        {r.details.map((d) => (
                                          <tr key={d.id} className="border-t">
                                            <td className="px-3 py-2 text-gray-800">{d.subject}</td>
                                            <td className="px-3 py-2 text-gray-600">{d.assessment}</td>
                                            <td className="px-3 py-2 text-center text-gray-600 capitalize">{d.type}</td>
                                            <td className="px-3 py-2 text-center text-gray-600">{d.score}/{d.outOf}</td>
                                            <td className={`px-3 py-2 text-center font-semibold ${
                                              d.pct >= 50 ? "text-green-700" : "text-red-700"
                                            }`}>
                                              {d.pct}%
                                            </td>
                                            <td className="px-3 py-2 text-center text-gray-500">{d.date || "—"}</td>
                                          </tr>
                                        ))}
                                      </tbody>
                                    </table>
                                  </div>
                                </td>
                              </tr>
                            )}
                          </Fragment>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
                {report.withoutResults.length > 0 && (
                  <div className="px-5 py-3 border-t text-xs text-gray-500">
                    {report.withoutResults.length} student
                    {report.withoutResults.length > 1 ? "s" : ""} in this class
                    {report.withoutResults.length > 1 ? " have" : " has"} no results
                    matching the filters:{" "}
                    {report.withoutResults.map((r) => r.name).join(", ")}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Print isolation: print only the report area. */}
      <style>{`
        @media print {
          body * { visibility: hidden; }
          .report-print-area, .report-print-area * { visibility: visible; }
          .report-print-area { position: absolute; left: 0; top: 0; width: 100%; }
          .report-print-area .print\\:hidden { display: none !important; }
        }
      `}</style>
    </div>
  );
}