import { useEffect, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowLeft } from "@fortawesome/free-solid-svg-icons";
import { collection, doc, getDoc, getDocs } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";
import Icon from "../../components/Icon";
import { db } from "../../supabase/supabase";

const EMPTY_DATA = {
  schoolName: "Tech Zone Academy",
  academicYear: "",
  totalStudents: 0,
  totalTeachers: 0,
  totalSubjects: 0,
  totalGrades: 0,
  totalSections: 0,
  averageAttendance: 0,
  averageScore: 0,
  passRate: 0,
  totalResults: 0,
  studentsWithResults: 0,
  gradeDistribution: [],
  subjectPerformance: [],
  performanceDistribution: [],
  recentResults: [],
};

const PERFORMANCE_BANDS = [
  {
    key: "excellent",
    label: "Excellent",
    range: "80-100%",
    barClass: "bg-emerald-500",
    textClass: "text-emerald-700",
    matches: (score) => score >= 80,
  },
  {
    key: "good",
    label: "Good",
    range: "60-79%",
    barClass: "bg-blue-500",
    textClass: "text-blue-700",
    matches: (score) => score >= 60 && score < 80,
  },
  {
    key: "satisfactory",
    label: "Satisfactory",
    range: "50-59%",
    barClass: "bg-amber-500",
    textClass: "text-amber-700",
    matches: (score) => score >= 50 && score < 60,
  },
  {
    key: "needsImprovement",
    label: "Needs improvement",
    range: "Below 50%",
    barClass: "bg-red-500",
    textClass: "text-red-700",
    matches: (score) => score < 50,
  },
];

const QUICK_ACTIONS = [
  {
    label: "Results Management",
    description: "Review results and reports",
    icon: "result",
    route: "/results-management",
    iconClass: "bg-blue-100 text-blue-700",
  },
  {
    label: "Student Management",
    description: "Manage student records",
    icon: "student",
    route: "/student-management",
    iconClass: "bg-emerald-100 text-emerald-700",
  },
  {
    label: "Teacher Performance",
    description: "Review teaching outcomes",
    icon: "chart",
    route: "/teacher-performance",
    iconClass: "bg-violet-100 text-violet-700",
  },
  {
    label: "Attendance Reports",
    description: "Monitor school attendance",
    icon: "attendance",
    route: "/attendance-report",
    iconClass: "bg-amber-100 text-amber-700",
  },
  {
    label: "School Settings",
    description: "Manage grades and subjects",
    icon: "settings",
    route: "/settings",
    iconClass: "bg-gray-200 text-gray-700",
  },
];

function AnimatedCounter({ value, suffix = "" }) {
  const numericValue = Number.isFinite(Number(value)) ? Number(value) : 0;
  const [displayValue, setDisplayValue] = useState(0);

  useEffect(() => {
    const reducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;

    if (reducedMotion) {
      setDisplayValue(Math.round(numericValue));
      return undefined;
    }

    let animationFrame;
    const duration = 700;
    const startedAt = performance.now();

    const animate = (currentTime) => {
      const progress = Math.min((currentTime - startedAt) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplayValue(Math.round(numericValue * eased));

      if (progress < 1) {
        animationFrame = window.requestAnimationFrame(animate);
      }
    };

    animationFrame = window.requestAnimationFrame(animate);
    return () => window.cancelAnimationFrame(animationFrame);
  }, [numericValue]);

  return (
    <>
      {displayValue}
      {suffix}
    </>
  );
}

function AcademicOverviewSkeleton() {
  return (
    <div className="min-h-screen bg-gray-50 px-4 py-8 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl animate-pulse space-y-6">
        <div className="h-48 rounded-lg bg-gray-300" />
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-6">
          {Array.from({ length: 6 }).map((_, index) => (
            <div
              key={index}
              className="h-28 rounded-lg border border-gray-200 bg-white p-4"
            >
              <div className="h-9 w-9 rounded-md bg-gray-200" />
              <div className="mt-3 h-5 w-16 rounded bg-gray-200" />
              <div className="mt-2 h-3 w-24 rounded bg-gray-100" />
            </div>
          ))}
        </div>
        <div className="grid gap-6 lg:grid-cols-5">
          {Array.from({ length: 4 }).map((_, index) => (
            <div
              key={index}
              className={`h-80 rounded-lg border border-gray-200 bg-white ${
                index % 2 === 0 ? "lg:col-span-2" : "lg:col-span-3"
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function getPercentage(result) {
  const score = Number(result.score);
  const outOf = Number(result.outOf);

  if (!Number.isFinite(score) || !Number.isFinite(outOf) || outOf <= 0) {
    return null;
  }

  return Math.max(0, Math.min(100, (score / outOf) * 100));
}

function toDate(value) {
  if (!value) return null;
  if (value instanceof Date) return value;
  if (typeof value.toDate === "function") return value.toDate();
  if (typeof value.seconds === "number") return new Date(value.seconds * 1000);

  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function getResultTime(result) {
  return (
    toDate(result.createdAt || result.updatedAt || result.date)?.getTime() || 0
  );
}

function formatDate(result) {
  const date = toDate(result.date || result.createdAt);
  if (!date) return "Date unavailable";

  return new Intl.DateTimeFormat(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  }).format(date);
}

function getPerformanceStyle(score) {
  if (score >= 80) {
    return {
      barClass: "bg-emerald-500",
      badgeClass: "bg-emerald-100 text-emerald-700",
      textClass: "text-emerald-700",
    };
  }

  if (score >= 60) {
    return {
      barClass: "bg-blue-500",
      badgeClass: "bg-blue-100 text-blue-700",
      textClass: "text-blue-700",
    };
  }

  if (score >= 50) {
    return {
      barClass: "bg-amber-500",
      badgeClass: "bg-amber-100 text-amber-700",
      textClass: "text-amber-700",
    };
  }

  return {
    barClass: "bg-red-500",
    badgeClass: "bg-red-100 text-red-700",
    textClass: "text-red-700",
  };
}

function getInitials(name) {
  if (!name) return "ST";

  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase();
}

export default function AcademicOverview() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [data, setData] = useState(EMPTY_DATA);

  useEffect(() => {
    let isActive = true;

    const fetchData = async () => {
      setLoading(true);
      setError(null);

      try {
        const [
          studentsSnap,
          teachersSnap,
          subjectsSnap,
          gradesSnap,
          sectionsSnap,
          resultsSnap,
          attendanceSnap,
          schoolInfoSnap,
        ] = await Promise.all([
          getDocs(collection(db, "students")),
          getDocs(collection(db, "teachers")),
          getDocs(collection(db, "subjects")),
          getDocs(collection(db, "grades")),
          getDocs(collection(db, "sections")),
          getDocs(collection(db, "results")),
          getDocs(collection(db, "attendance")),
          getDoc(doc(db, "schoolSettings", "general")),
        ]);

        if (!isActive) return;

        const mapSnapshot = (snapshot) =>
          snapshot.docs.map((snapshotDoc) => ({
            id: snapshotDoc.id,
            ...snapshotDoc.data(),
          }));
        const students = mapSnapshot(studentsSnap);
        const teachers = mapSnapshot(teachersSnap);
        const subjects = mapSnapshot(subjectsSnap);
        const grades = mapSnapshot(gradesSnap);
        const sections = mapSnapshot(sectionsSnap);
        const results = mapSnapshot(resultsSnap);
        const attendance = mapSnapshot(attendanceSnap);
        const schoolInfo = schoolInfoSnap.exists()
          ? schoolInfoSnap.data()
          : {};

        const scoredResults = results
          .map((result) => ({
            ...result,
            percentage: getPercentage(result),
          }))
          .filter((result) => result.percentage !== null);

        // Per-student cumulative percentages drive the headline stats.
        const studentTotals = scoredResults.reduce((totals, result) => {
          const key = result.studentId || result.studentName || result.id;
          totals[key] ||= { score: 0, max: 0 };
          totals[key].score += Number(result.score);
          totals[key].max += Number(result.outOf);
          return totals;
        }, {});
        const studentPercentages = Object.values(studentTotals).map(
          (student) => (student.max > 0 ? (student.score / student.max) * 100 : 0),
        );
        const averageScore =
          studentPercentages.length > 0
            ? studentPercentages.reduce((sum, value) => sum + value, 0) /
              studentPercentages.length
            : 0;
        const passRate =
          studentPercentages.length > 0
            ? (studentPercentages.filter((value) => value >= 50).length /
                studentPercentages.length) *
              100
            : 0;
        const averageAttendance =
          attendance.length > 0
            ? (attendance.filter((record) => record.status === "Present")
                .length /
                attendance.length) *
              100
            : 0;

        const gradeCounts = students.reduce((counts, student) => {
          const grade = student.grade || "Unassigned";
          counts[grade] = (counts[grade] || 0) + 1;
          return counts;
        }, {});
        const gradeDistribution = Object.entries(gradeCounts)
          .map(([grade, count]) => ({ grade, count }))
          .sort((a, b) =>
            a.grade.localeCompare(b.grade, undefined, { numeric: true }),
          );

        const subjectTotals = scoredResults.reduce((totals, result) => {
          const subject = result.subject || "Unassigned";
          totals[subject] ||= { total: 0, count: 0 };
          totals[subject].total += result.percentage;
          totals[subject].count += 1;
          return totals;
        }, {});
        const subjectPerformance = Object.entries(subjectTotals)
          .map(([subject, values]) => ({
            subject,
            average: Math.round(values.total / values.count),
            resultCount: values.count,
          }))
          .sort((a, b) => b.average - a.average);
        const performanceDistribution = PERFORMANCE_BANDS.map((band) => {
          const count = studentPercentages.filter((value) =>
            band.matches(value),
          ).length;

          return {
            ...band,
            count,
            percentage:
              studentPercentages.length > 0
                ? Math.round((count / studentPercentages.length) * 100)
                : 0,
          };
        });

        const uniqueStudentSections = new Set(
          students
            .filter((student) => student.grade || student.section)
            .map(
              (student) =>
                `${student.grade || "Unassigned"}-${
                  student.section || "Unassigned"
                }`,
            ),
        );
        const fallbackYear = new Date().getFullYear();

        setData({
          schoolName: schoolInfo.schoolName || "Tech Zone Academy",
          academicYear:
            schoolInfo.academicYear || `${fallbackYear}/${fallbackYear + 1}`,
          totalStudents: students.length,
          totalTeachers: teachers.length,
          totalSubjects: subjects.length || subjectPerformance.length,
          totalGrades: grades.length || gradeDistribution.length,
          totalSections: sections.length || uniqueStudentSections.size,
          averageAttendance: Math.round(averageAttendance),
          averageScore: Math.round(averageScore),
          passRate: Math.round(passRate),
          totalResults: scoredResults.length,
          studentsWithResults: studentPercentages.length,
          gradeDistribution,
          subjectPerformance,
          performanceDistribution,
          recentResults: [...results]
            .sort((a, b) => getResultTime(b) - getResultTime(a))
            .slice(0, 8),
        });
      } catch (fetchError) {
        console.error("Error fetching academic data:", fetchError);
        if (isActive) {
          setError(
            fetchError instanceof Error
              ? fetchError.message
              : "Unable to load academic data",
          );
        }
      } finally {
        if (isActive) setLoading(false);
      }
    };

    fetchData();
    return () => {
      isActive = false;
    };
  }, [refreshKey]);

  if (loading) return <AcademicOverviewSkeleton />;

  const hasData =
    data.totalStudents > 0 ||
    data.totalTeachers > 0 ||
    data.totalSubjects > 0 ||
    data.totalGrades > 0 ||
    data.totalResults > 0;
  const maximumGradeCount = Math.max(
    1,
    ...data.gradeDistribution.map((item) => item.count),
  );
  const statCards = [
    {
      label: "Students",
      value: data.totalStudents,
      icon: "student",
      iconClass: "bg-blue-100 text-blue-700",
    },
    {
      label: "Teachers",
      value: data.totalTeachers,
      icon: "teacher",
      iconClass: "bg-emerald-100 text-emerald-700",
    },
    {
      label: "Subjects",
      value: data.totalSubjects,
      icon: "subject",
      iconClass: "bg-violet-100 text-violet-700",
    },
    {
      label: "Grades",
      value: data.totalGrades,
      icon: "school",
      iconClass: "bg-amber-100 text-amber-700",
    },
    {
      label: "Average score",
      value: data.averageScore,
      suffix: "%",
      icon: "chart",
      iconClass: "bg-cyan-100 text-cyan-700",
    },
    {
      label: "Pass rate",
      value: data.passRate,
      suffix: "%",
      icon: "success",
      iconClass: "bg-green-100 text-green-700",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 px-4 py-8 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <section className="overflow-hidden rounded-lg bg-gradient-to-r from-blue-900 via-indigo-800 to-emerald-700 text-white shadow-lg">
          <div className="px-5 py-6 sm:px-8 sm:py-8">
            <button
              type="button"
              onClick={() => navigate(-1)}
              className="mb-6 inline-flex h-10 items-center gap-2 rounded-md bg-white/10 px-3 text-sm font-semibold text-white transition-colors hover:bg-white/20 focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
            >
              <FontAwesomeIcon icon={faArrowLeft} aria-hidden="true" />
              Back
            </button>

            <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
              <div className="min-w-0">
                <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-md bg-white/15 text-xl">
                  <Icon name="graduation" aria-hidden="true" />
                </div>
                <p className="text-sm font-semibold text-emerald-100">
                  Academic Overview
                </p>
                <h1 className="mt-1 break-words text-2xl font-bold sm:text-3xl">
                  {data.schoolName}
                </h1>
                <p className="mt-2 max-w-2xl text-sm text-blue-100 sm:text-base">
                  School-wide performance, enrollment, and results insights.
                </p>
              </div>

              <div className="flex flex-wrap gap-3">
                <div className="rounded-md border border-white/20 bg-white/10 px-4 py-3">
                  <p className="text-xs font-medium text-blue-100">
                    Academic year
                  </p>
                  <p className="mt-0.5 text-base font-bold">
                    {data.academicYear}
                  </p>
                </div>
                <div className="rounded-md border border-white/20 bg-white/10 px-4 py-3">
                  <p className="text-xs font-medium text-blue-100">Sections</p>
                  <p className="mt-0.5 text-base font-bold">
                    {data.totalSections}
                  </p>
                </div>
                <div className="rounded-md border border-white/20 bg-white/10 px-4 py-3">
                  <p className="text-xs font-medium text-blue-100">
                    Attendance
                  </p>
                  <p className="mt-0.5 text-base font-bold">
                    {data.averageAttendance}%
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {error && (
          <div
            role="alert"
            className="flex flex-col gap-3 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 sm:flex-row sm:items-center sm:justify-between"
          >
            <span>Academic data could not be loaded: {error}</span>
            <button
              type="button"
              onClick={() => setRefreshKey((key) => key + 1)}
              className="inline-flex h-9 items-center justify-center gap-2 self-start rounded-md bg-red-700 px-3 font-semibold text-white hover:bg-red-800 sm:self-auto"
            >
              <Icon name="refresh" aria-hidden="true" />
              Retry
            </button>
          </div>
        )}

        {!error && !hasData ? (
          <section className="rounded-lg border border-dashed border-gray-300 bg-white px-6 py-16 text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-md bg-blue-100 text-xl text-blue-700">
              <Icon name="chart" aria-hidden="true" />
            </div>
            <h2 className="mt-4 text-lg font-bold text-gray-900">
              No academic data yet
            </h2>
            <p className="mx-auto mt-2 max-w-md text-sm text-gray-500">
              Add students, subjects, and results to begin building the
              school-wide academic overview.
            </p>
            <button
              type="button"
              onClick={() => navigate("/results-management")}
              className="mt-5 inline-flex h-10 items-center justify-center gap-2 rounded-md bg-blue-700 px-4 text-sm font-semibold text-white hover:bg-blue-800"
            >
              <Icon name="result" aria-hidden="true" />
              Open Results Management
            </button>
          </section>
        ) : (
          <>
            <section
              aria-label="Academic statistics"
              className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-6"
            >
              {statCards.map((stat) => (
                <article
                  key={stat.label}
                  className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm transition-shadow hover:shadow-md"
                >
                  <span
                    className={`flex h-9 w-9 items-center justify-center rounded-md ${stat.iconClass}`}
                  >
                    <Icon name={stat.icon} aria-hidden="true" />
                  </span>
                  <p className="mt-3 text-2xl font-bold text-gray-950">
                    <AnimatedCounter
                      value={stat.value}
                      suffix={stat.suffix}
                    />
                  </p>
                  <p className="mt-1 text-xs font-medium text-gray-500">
                    {stat.label}
                  </p>
                </article>
              ))}
            </section>

            <section className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
              <div className="mb-4 flex items-center gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-md bg-gray-900 text-white">
                  <Icon name="dashboard" aria-hidden="true" />
                </span>
                <div>
                  <h2 className="text-base font-bold text-gray-900">
                    Quick Actions
                  </h2>
                  <p className="text-xs text-gray-500">
                    Open frequently used academic tools.
                  </p>
                </div>
              </div>

              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
                {QUICK_ACTIONS.map((action) => (
                  <button
                    key={action.route}
                    type="button"
                    onClick={() => navigate(action.route)}
                    className="flex min-h-20 items-center gap-3 rounded-md border border-gray-200 bg-white px-3 py-3 text-left transition-colors hover:border-blue-300 hover:bg-blue-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
                  >
                    <span
                      className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-md ${action.iconClass}`}
                    >
                      <Icon name={action.icon} aria-hidden="true" />
                    </span>
                    <span className="min-w-0">
                      <span className="block break-words text-sm font-semibold text-gray-900">
                        {action.label}
                      </span>
                      <span className="mt-0.5 block text-xs leading-4 text-gray-500">
                        {action.description}
                      </span>
                    </span>
                  </button>
                ))}
              </div>
            </section>

            <div className="grid gap-6 lg:grid-cols-5">
              <section className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm lg:col-span-2">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <span className="flex h-9 w-9 items-center justify-center rounded-md bg-cyan-100 text-cyan-700">
                      <Icon name="chart" aria-hidden="true" />
                    </span>
                    <div>
                      <h2 className="text-base font-bold text-gray-900">
                        Performance Distribution
                      </h2>
                      <p className="text-xs text-gray-500">
                        {data.studentsWithResults} students · {data.totalResults} results
                      </p>
                    </div>
                  </div>
                  <span className="rounded-full bg-emerald-100 px-2.5 py-1 text-xs font-bold text-emerald-700">
                    {data.passRate}% pass
                  </span>
                </div>

                {data.totalResults === 0 ? (
                  <div className="flex h-64 flex-col items-center justify-center text-center">
                    <Icon
                      name="chart"
                      className="text-3xl text-gray-300"
                      aria-hidden="true"
                    />
                    <p className="mt-3 text-sm font-semibold text-gray-700">
                      No scored results
                    </p>
                    <p className="mt-1 text-xs text-gray-500">
                      Performance bands will appear after results are added.
                    </p>
                  </div>
                ) : (
                  <div className="mt-6 grid h-64 grid-cols-4 items-end gap-3">
                    {data.performanceDistribution.map((band) => (
                      <div
                        key={band.key}
                        className="flex h-full min-w-0 flex-col items-center justify-end"
                      >
                        <span
                          className={`mb-2 text-sm font-bold ${band.textClass}`}
                        >
                          {band.count}
                        </span>
                        <div className="flex h-40 w-full max-w-14 items-end rounded-md bg-gray-100 p-1">
                          <div
                            className={`w-full rounded-sm transition-[height] duration-700 ${band.barClass}`}
                            style={{
                              height: `${Math.max(band.percentage, 3)}%`,
                            }}
                            title={`${band.label}: ${band.count} results`}
                          />
                        </div>
                        <p className="mt-3 break-words text-center text-xs font-semibold text-gray-700">
                          {band.label}
                        </p>
                        <p className="mt-1 text-center text-[11px] text-gray-400">
                          {band.range}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </section>

              <section className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm lg:col-span-3">
                <div className="flex items-center gap-3">
                  <span className="flex h-9 w-9 items-center justify-center rounded-md bg-violet-100 text-violet-700">
                    <Icon name="subject" aria-hidden="true" />
                  </span>
                  <div>
                    <h2 className="text-base font-bold text-gray-900">
                      Subject Performance
                    </h2>
                    <p className="text-xs text-gray-500">
                      Average score by subject
                    </p>
                  </div>
                </div>

                {data.subjectPerformance.length === 0 ? (
                  <div className="flex h-64 flex-col items-center justify-center text-center">
                    <Icon
                      name="subject"
                      className="text-3xl text-gray-300"
                      aria-hidden="true"
                    />
                    <p className="mt-3 text-sm font-semibold text-gray-700">
                      No subject results
                    </p>
                    <p className="mt-1 text-xs text-gray-500">
                      Subject averages will appear here.
                    </p>
                  </div>
                ) : (
                  <div className="mt-6 max-h-80 space-y-4 overflow-y-auto pr-2">
                    {data.subjectPerformance.map((subject) => {
                      const style = getPerformanceStyle(subject.average);

                      return (
                        <div key={subject.subject}>
                          <div className="mb-2 flex items-center justify-between gap-3">
                            <div className="min-w-0">
                              <p className="break-words text-sm font-semibold text-gray-800">
                                {subject.subject}
                              </p>
                              <p className="text-xs text-gray-400">
                                {subject.resultCount} results
                              </p>
                            </div>
                            <span
                              className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-bold ${style.badgeClass}`}
                            >
                              {subject.average}%
                            </span>
                          </div>
                          <div className="h-2.5 overflow-hidden rounded-full bg-gray-100">
                            <div
                              className={`h-full rounded-full ${style.barClass}`}
                              style={{ width: `${subject.average}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </section>

              <section className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm lg:col-span-2">
                <div className="flex items-center gap-3">
                  <span className="flex h-9 w-9 items-center justify-center rounded-md bg-amber-100 text-amber-700">
                    <Icon name="school" aria-hidden="true" />
                  </span>
                  <div>
                    <h2 className="text-base font-bold text-gray-900">
                      Grade Distribution
                    </h2>
                    <p className="text-xs text-gray-500">
                      Students enrolled by grade
                    </p>
                  </div>
                </div>

                {data.gradeDistribution.length === 0 ? (
                  <div className="flex h-64 flex-col items-center justify-center text-center">
                    <Icon
                      name="school"
                      className="text-3xl text-gray-300"
                      aria-hidden="true"
                    />
                    <p className="mt-3 text-sm font-semibold text-gray-700">
                      No grade enrollment
                    </p>
                    <p className="mt-1 text-xs text-gray-500">
                      Grade indicators will appear after students are added.
                    </p>
                  </div>
                ) : (
                  <div className="mt-6 max-h-80 space-y-4 overflow-y-auto pr-2">
                    {data.gradeDistribution.map((item, index) => {
                      const enrollmentPercentage =
                        data.totalStudents > 0
                          ? Math.round((item.count / data.totalStudents) * 100)
                          : 0;
                      const width = Math.max(
                        5,
                        Math.round((item.count / maximumGradeCount) * 100),
                      );
                      const barClasses = [
                        "bg-blue-500",
                        "bg-emerald-500",
                        "bg-violet-500",
                        "bg-amber-500",
                        "bg-cyan-500",
                      ];

                      return (
                        <div key={item.grade}>
                          <div className="mb-2 flex items-center justify-between gap-3">
                            <span className="break-words text-sm font-semibold text-gray-800">
                              {item.grade}
                            </span>
                            <span className="shrink-0 text-xs font-medium text-gray-500">
                              {item.count} students · {enrollmentPercentage}%
                            </span>
                          </div>
                          <div className="h-2.5 overflow-hidden rounded-full bg-gray-100">
                            <div
                              className={`h-full rounded-full ${
                                barClasses[index % barClasses.length]
                              }`}
                              style={{ width: `${width}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </section>

              <section className="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm lg:col-span-3">
                <div className="flex items-center justify-between gap-3 border-b border-gray-200 px-5 py-4">
                  <div className="flex items-center gap-3">
                    <span className="flex h-9 w-9 items-center justify-center rounded-md bg-blue-100 text-blue-700">
                      <Icon name="clock" aria-hidden="true" />
                    </span>
                    <div>
                      <h2 className="text-base font-bold text-gray-900">
                        Recent Results
                      </h2>
                      <p className="text-xs text-gray-500">
                        Latest recorded assessments
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => navigate("/results-management")}
                    className="rounded-md px-3 py-2 text-xs font-semibold text-blue-700 hover:bg-blue-50"
                  >
                    View all
                  </button>
                </div>

                {data.recentResults.length === 0 ? (
                  <div className="flex h-64 flex-col items-center justify-center px-6 text-center">
                    <Icon
                      name="result"
                      className="text-3xl text-gray-300"
                      aria-hidden="true"
                    />
                    <p className="mt-3 text-sm font-semibold text-gray-700">
                      No recent results
                    </p>
                    <p className="mt-1 text-xs text-gray-500">
                      New assessment results will appear here.
                    </p>
                  </div>
                ) : (
                  <div className="divide-y divide-gray-100">
                    {data.recentResults.map((result) => {
                      const percentage = getPercentage(result);
                      const score = percentage === null ? 0 : Math.round(percentage);
                      const style = getPerformanceStyle(score);

                      return (
                        <article
                          key={result.id}
                          className="flex items-center gap-3 px-5 py-4 transition-colors hover:bg-gray-50"
                        >
                          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-gray-900 text-xs font-bold text-white">
                            {getInitials(result.studentName)}
                          </span>
                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                              <h3 className="break-words text-sm font-semibold text-gray-900">
                                {result.studentName || "Unknown student"}
                              </h3>
                              {result.grade && (
                                <span className="rounded-full bg-gray-100 px-2 py-0.5 text-[11px] font-medium text-gray-600">
                                  {result.grade}
                                </span>
                              )}
                            </div>
                            <p className="mt-1 break-words text-xs text-gray-500">
                              {result.subject || "Unassigned subject"}
                              {result.assessment
                                ? ` · ${result.assessment}`
                                : ""}
                            </p>
                            <p className="mt-1 text-[11px] text-gray-400">
                              {formatDate(result)}
                            </p>
                          </div>
                          <div className="shrink-0 text-right">
                            <span
                              className={`inline-flex rounded-full px-2.5 py-1 text-xs font-bold ${style.badgeClass}`}
                            >
                              {percentage === null ? "N/A" : `${score}%`}
                            </span>
                            <p
                              className={`mt-1 text-xs font-semibold ${style.textClass}`}
                            >
                              {result.score ?? "-"} / {result.outOf ?? "-"}
                            </p>
                          </div>
                        </article>
                      );
                    })}
                  </div>
                )}
              </section>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
