// src/pages/library/Members.jsx
import { useEffect, useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { db, collection, getDocs, addDoc, updateDoc, deleteDoc, doc, query, where } from "../../supabase/supabase";

export default function LibraryMembers() {
  const { user } = useAuth();
  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingMember, setEditingMember] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [students, setStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    memberId: "",
    type: "student",
    status: "active",
    borrowedCount: 0,
    notes: "",
    studentId: "",
  });

  const memberTypes = [
    { value: "student", label: "👨‍🎓 Student" },
    { value: "teacher", label: "👨‍🏫 Teacher" },
    { value: "staff", label: "👔 Staff" },
    { value: "parent", label: "👨‍👩‍👦 Parent" },
    { value: "other", label: "👤 Other" },
  ];

  const fetchMembers = async () => {
    setLoading(true);
    try {
      const snap = await getDocs(collection(db, "libraryMembers"));
      const data = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMembers(data.sort((a, b) => a.name?.localeCompare(b.name)));
    } catch (error) {
      setErrorMessage("Error loading members: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchStudents = async () => {
    try {
      const snap = await getDocs(collection(db, "students"));
      const data = snap.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setStudents(data.sort((a, b) => a.firstName?.localeCompare(b.firstName)));
    } catch (error) {
      console.error("Error fetching students:", error);
    }
  };

  useEffect(() => {
    fetchMembers();
    fetchStudents();
     
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleStudentSelect = (studentId) => {
    const student = students.find(s => s.studentId === studentId || s.id === studentId);
    if (student) {
      setSelectedStudent(student);
      setFormData(prev => ({
        ...prev,
        studentId: student.studentId,
        name: `${student.firstName} ${student.fatherName}`,
        email: student.email || student.parentEmail || `${student.studentId}@student.techzone.com`,
        phone: student.parentPhone || student.phone || "",
        address: student.address || "",
      }));
    }
  };

  const generateMemberId = () => {
    const prefix = "LIB";
    const year = new Date().getFullYear().toString().slice(-2);
    const random = String(Math.floor(Math.random() * 10000)).padStart(4, "0");
    return `${prefix}${year}${random}`;
  };

  const validateForm = () => {
    if (!formData.name.trim()) {
      setErrorMessage("Member name is required");
      return false;
    }
    
    // For student type, studentId is required
    if (formData.type === "student" && !formData.studentId) {
      setErrorMessage("Please select a student");
      return false;
    }
    
    // For non-student types, email is required
    if (formData.type !== "student") {
      if (!formData.email.trim()) {
        setErrorMessage("Email address is required");
        return false;
      }
      if (!formData.email.includes("@") || !formData.email.includes(".")) {
        setErrorMessage("Please enter a valid email address");
        return false;
      }
    }
    
    if (!formData.phone.trim()) {
      setErrorMessage("Phone number is required");
      return false;
    }
    if (formData.phone.replace(/\D/g, '').length < 10) {
      setErrorMessage("Please enter a valid phone number (minimum 10 digits)");
      return false;
    }
    
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMessage("");
    setSuccessMessage("");

    if (!validateForm()) {
      setLoading(false);
      return;
    }

    try {
      // Check if email already exists (only for non-student types)
      if (formData.type !== "student" && formData.email) {
        const emailQuery = query(
          collection(db, "libraryMembers"),
          where("email", "==", formData.email)
        );
        const emailSnap = await getDocs(emailQuery);
        
        if (!emailSnap.empty && !editingMember) {
          setErrorMessage("A member with this email already exists");
          setLoading(false);
          return;
        }
      }

      // Check if memberId already exists
      if (formData.memberId) {
        const idQuery = query(
          collection(db, "libraryMembers"),
          where("memberId", "==", formData.memberId)
        );
        const idSnap = await getDocs(idQuery);
        
        if (!idSnap.empty && !editingMember) {
          setErrorMessage("A member with this ID already exists");
          setLoading(false);
          return;
        }
      }

      const memberId = formData.memberId || generateMemberId();
      const memberData = {
        name: formData.name,
        email: formData.type === "student" ? `student_${formData.studentId}@library.techzone.com` : formData.email,
        phone: formData.phone,
        address: formData.address,
        memberId: memberId,
        type: formData.type,
        status: formData.status,
        borrowedCount: formData.borrowedCount || 0,
        notes: formData.notes,
        studentId: formData.type === "student" ? formData.studentId : "",
        updatedAt: new Date().toISOString(),
        updatedBy: user?.uid,
        updatedByName: user?.displayName || user?.email || "System",
        role: "library_member",
      };

      if (editingMember) {
        await updateDoc(doc(db, "libraryMembers", editingMember.id), memberData);
        setSuccessMessage("✅ Member updated successfully!");
      } else {
        memberData.createdAt = new Date().toISOString();
        memberData.createdBy = user?.uid;
        memberData.createdByName = user?.displayName || user?.email || "System";
        
        await addDoc(collection(db, "libraryMembers"), memberData);
        
        setSuccessMessage(
          `✅ Member added successfully!\n\n` +
          `🆔 Member ID: ${memberId}\n` +
          `📧 Email: ${memberData.email}\n` +
          (formData.type === "student" ? `👨‍🎓 Student ID: ${formData.studentId}\n` : "") +
          `\n📌 Member can use Member ID at the library`
        );
      }

      setShowModal(false);
      setEditingMember(null);
      setSelectedStudent(null);
      resetForm();
      await fetchMembers();
      setTimeout(() => setSuccessMessage(""), 5000);
    } catch (error) {
      setErrorMessage("Error saving member: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this member?")) return;
    try {
      const historyQuery = query(
        collection(db, "libraryHistory"),
        where("memberId", "==", id),
        where("status", "==", "active")
      );
      const historySnap = await getDocs(historyQuery);
      
      if (!historySnap.empty) {
        setErrorMessage("Cannot delete member with active borrowings. Please return all books first.");
        setTimeout(() => setErrorMessage(""), 3000);
        return;
      }

      await deleteDoc(doc(db, "libraryMembers", id));
      setSuccessMessage("✅ Member deleted successfully!");
      await fetchMembers();
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error deleting member: " + error.message);
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      email: "",
      phone: "",
      address: "",
      memberId: "",
      type: "student",
      status: "active",
      borrowedCount: 0,
      notes: "",
      studentId: "",
    });
    setSelectedStudent(null);
  };

  const filteredMembers = members.filter(member =>
    member.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.memberId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.phone?.includes(searchTerm) ||
    member.studentId?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getTypeBadge = (type) => {
    const styles = {
      student: "bg-blue-100 text-blue-700",
      teacher: "bg-purple-100 text-purple-700",
      staff: "bg-green-100 text-green-700",
      parent: "bg-yellow-100 text-yellow-700",
      other: "bg-gray-100 text-gray-700",
    };
    return styles[type] || "bg-gray-100 text-gray-700";
  };

  const getTypeIcon = (type) => {
    const icons = {
      student: "👨‍🎓",
      teacher: "👨‍🏫",
      staff: "👔",
      parent: "👨‍👩‍👦",
      other: "👤",
    };
    return icons[type] || "👤";
  };

  if (loading && members.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading members...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              👤 Library Members
            </h1>
            <p className="text-gray-600 mt-1">
              Manage library members (No login required)
            </p>
          </div>
          <button
            onClick={() => {
              setEditingMember(null);
              resetForm();
              setShowModal(true);
            }}
            className="bg-blue-700 text-white px-4 py-2 rounded-lg hover:bg-blue-800 transition"
          >
            ➕ Add Member
          </button>
        </div>

        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4 whitespace-pre-line">
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Search Members</label>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="🔍 Search by name, email, ID, phone, or student ID..."
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Total Members</label>
              <div className="text-2xl font-bold text-blue-700">{members.length}</div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Active Members</label>
              <div className="text-2xl font-bold text-green-700">
                {members.filter(m => m.status === "active" || !m.status).length}
              </div>
            </div>
          </div>
        </div>

        {/* Members Table */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Member</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Member ID</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Email / Student ID</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Type</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Phone</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Books</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Status</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredMembers.length === 0 ? (
                  <tr>
                    <td colSpan="8" className="px-4 py-8 text-center text-gray-500">
                      {members.length === 0 ? "No members found. Click 'Add Member' to create one." : "No members match your search."}
                    </td>
                  </tr>
                ) : (
                  filteredMembers.map((member) => (
                    <tr key={member.id} className="border-b hover:bg-gray-50 transition">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 text-sm font-bold">
                            {member.name?.charAt(0) || "?"}
                          </div>
                          <div>
                            <p className="font-medium text-gray-800">{member.name}</p>
                            <p className="text-xs text-gray-500">{member.address || "No address"}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-sm font-medium text-gray-600 bg-gray-100 px-2 py-1 rounded">
                          {member.memberId || "N/A"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">
                        {member.type === "student" ? (
                          <span className="text-blue-600 font-medium">
                            🆔 {member.studentId || member.email?.split('@')[0]?.replace('student_', '') || "N/A"}
                          </span>
                        ) : (
                          <a href={`mailto:${member.email}`} className="text-blue-600 hover:underline">
                            {member.email}
                          </a>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getTypeBadge(member.type)}`}>
                          {getTypeIcon(member.type)} {member.type || "student"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">{member.phone || "N/A"}</td>
                      <td className="px-4 py-3 text-center text-sm text-blue-600 font-medium">
                        {member.borrowedCount || 0}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          member.status === "active" || !member.status
                            ? "bg-green-100 text-green-700" 
                            : member.status === "inactive" 
                            ? "bg-red-100 text-red-700"
                            : "bg-yellow-100 text-yellow-700"
                        }`}>
                          {member.status || "active"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => {
                              setEditingMember(member);
                              setFormData({
                                name: member.name || "",
                                email: member.email || "",
                                phone: member.phone || "",
                                address: member.address || "",
                                memberId: member.memberId || "",
                                type: member.type || "student",
                                status: member.status || "active",
                                borrowedCount: member.borrowedCount || 0,
                                notes: member.notes || "",
                                studentId: member.studentId || "",
                              });
                              if (member.studentId) {
                                const student = students.find(s => s.studentId === member.studentId);
                                setSelectedStudent(student || null);
                              }
                              setShowModal(true);
                            }}
                            className="text-blue-600 hover:text-blue-800 text-sm p-1 hover:bg-blue-50 rounded"
                            title="Edit Member"
                          >
                            ✏️
                          </button>
                          <button
                            onClick={() => handleDelete(member.id)}
                            className="text-red-600 hover:text-red-800 text-sm p-1 hover:bg-red-50 rounded"
                            title="Delete Member"
                          >
                            🗑️
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          <div className="px-4 py-3 border-t flex items-center justify-between">
            <p className="text-sm text-gray-500">
              Showing {filteredMembers.length} of {members.length} members
            </p>
            <p className="text-sm text-gray-400">
              {members.filter(m => m.status === "active" || !m.status).length} active
            </p>
          </div>
        </div>
      </div>

      {/* Add/Edit Member Modal - Without Password */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800">
                  {editingMember ? "✏️ Edit Member" : "👤 Add New Member"}
                </h2>
                <button 
                  onClick={() => { 
                    setShowModal(false); 
                    setEditingMember(null); 
                    setSelectedStudent(null);
                    setErrorMessage("");
                  }} 
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ✕
                </button>
              </div>

              {editingMember && (
                <div className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-700">
                    Editing: <span className="font-semibold">{editingMember.name}</span>
                  </p>
                  <p className="text-xs text-blue-600">
                    Member ID: {editingMember.memberId || "Not set"} • 
                    {editingMember.type === "student" ? ` Student ID: ${editingMember.studentId}` : ` Email: ${editingMember.email}`}
                  </p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Member Type *
                    </label>
                    <select
                      name="type"
                      value={formData.type}
                      onChange={(e) => {
                        handleInputChange(e);
                        setSelectedStudent(null);
                        if (e.target.value !== "student") {
                          setFormData(prev => ({ ...prev, studentId: "" }));
                        }
                      }}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                    >
                      {memberTypes.map(type => (
                        <option key={type.value} value={type.value}>
                          {type.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Full name"
                    />
                  </div>
                </div>

                {/* Student Selection - Only show when type is student */}
                {formData.type === "student" && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Select Student *
                    </label>
                    <select
                      value={formData.studentId || ""}
                      onChange={(e) => handleStudentSelect(e.target.value)}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                    >
                      <option value="">Select a student...</option>
                      {students.map((student) => (
                        <option key={student.id || student.studentId} value={student.studentId}>
                          {student.firstName} {student.fatherName} ({student.studentId}) - {student.grade}
                        </option>
                      ))}
                    </select>
                    {selectedStudent && (
                      <div className="mt-2 p-2 bg-blue-50 rounded-lg border border-blue-200">
                        <p className="text-xs text-blue-700">
                          Selected: <span className="font-semibold">{selectedStudent.firstName} {selectedStudent.fatherName}</span>
                          <br />
                          Class: {selectedStudent.grade} - Section {selectedStudent.section}
                        </p>
                      </div>
                    )}
                  </div>
                )}

                {/* Email field - Only show for non-student types */}
                {formData.type !== "student" && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="email@example.com"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="+251 9XX XXX XXX"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Address
                  </label>
                  <input
                    type="text"
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="Address"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Member ID (Auto-generated if left blank)
                    </label>
                    <input
                      type="text"
                      name="memberId"
                      value={formData.memberId}
                      onChange={handleInputChange}
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="e.g., LIB240001"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Status
                    </label>
                    <select
                      name="status"
                      value={formData.status}
                      onChange={handleInputChange}
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                    >
                      <option value="active">✅ Active</option>
                      <option value="inactive">❌ Inactive</option>
                      <option value="suspended">⛔ Suspended</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Notes
                  </label>
                  <textarea
                    name="notes"
                    value={formData.notes}
                    onChange={handleInputChange}
                    rows="2"
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="Additional notes..."
                  />
                </div>

                <div className="flex gap-3 pt-4 border-t">
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition disabled:bg-gray-400 font-medium"
                  >
                    {loading ? "Saving..." : editingMember ? "💾 Update Member" : "✅ Add Member"}
                  </button>
                  <button
                    type="button"
                    onClick={() => { 
                      setShowModal(false); 
                      setEditingMember(null);
                      setSelectedStudent(null);
                      setErrorMessage("");
                    }}
                    className="px-6 py-3 rounded-lg bg-gray-200 text-gray-700 hover:bg-gray-300 transition font-medium"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}