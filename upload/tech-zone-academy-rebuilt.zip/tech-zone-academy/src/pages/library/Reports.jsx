// src/pages/library/Reports.jsx
import { useEffect, useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { db, collection, getDocs, query, orderBy } from "../../supabase/supabase";

export default function Reports() {
  useAuth();
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState({
    start: new Date(new Date().setDate(new Date().getDate() - 30)).toISOString().split("T")[0],
    end: new Date().toISOString().split("T")[0],
  });
  const [data, setData] = useState({
    overview: {
      totalBooks: 0,
      availableBooks: 0,
      borrowedBooks: 0,
      overdueBooks: 0,
      totalMembers: 0,
      activeMembers: 0,
      totalBorrows: 0,
      totalReturns: 0,
    },
    topBooks: [],
    topMembers: [],
    recentActivity: [],
  });

  const fetchReportData = async () => {
    setLoading(true);
    try {
      // Fetch books
      const booksSnap = await getDocs(collection(db, "libraryBooks"));
      const books = booksSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      
      const totalBooks = books.length;
      const availableBooks = books.filter(b => b.status === "available" || b.availableQuantity > 0).length;
      const borrowedBooks = books.filter(b => b.status === "borrowed").length;
      const overdueBooks = books.filter(b => b.status === "overdue").length;

      // Fetch members
      const membersSnap = await getDocs(collection(db, "libraryMembers"));
      const members = membersSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      const totalMembers = members.length;
      const activeMembers = members.filter(m => m.status === "active" || !m.status).length;

      // Fetch history with date range
      const startDate = new Date(dateRange.start);
      const endDate = new Date(dateRange.end);
      endDate.setHours(23, 59, 59, 999);

      const historySnap = await getDocs(
        query(collection(db, "libraryHistory"), orderBy("borrowedDate", "desc"))
      );
      const history = historySnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));

      // Filter by date range
      const filteredHistory = history.filter(h => {
        const hDate = new Date(h.borrowedDate);
        return hDate >= startDate && hDate <= endDate;
      });

      const totalBorrows = filteredHistory.filter(h => h.action === "borrowed").length;
      const totalReturns = filteredHistory.filter(h => h.action === "returned").length;

      // Top books (most borrowed)
      const bookCount = {};
      filteredHistory.forEach(h => {
        if (h.action === "borrowed" && h.bookTitle) {
          bookCount[h.bookTitle] = (bookCount[h.bookTitle] || 0) + 1;
        }
      });
      const topBooks = Object.entries(bookCount)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10)
        .map(([title, count]) => ({ title, count }));

      // Top members (most active)
      const memberCount = {};
      filteredHistory.forEach(h => {
        if (h.action === "borrowed" && h.memberName) {
          memberCount[h.memberName] = (memberCount[h.memberName] || 0) + 1;
        }
      });
      const topMembers = Object.entries(memberCount)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10)
        .map(([name, count]) => ({ name, count }));

      // Recent activity
      const recentActivity = filteredHistory.slice(0, 10);

      setData({
        overview: {
          totalBooks,
          availableBooks,
          borrowedBooks,
          overdueBooks,
          totalMembers,
          activeMembers,
          totalBorrows,
          totalReturns,
        },
        topBooks,
        topMembers,
        recentActivity,
      });
    } catch (error) {
      console.error("Error fetching report data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReportData();
    // fetchReportData is recreated each render; depend on dateRange only to avoid a refetch loop
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dateRange]);

  const exportReport = (format) => {
    // Simple export function - can be expanded
    const reportData = {
      generatedAt: new Date().toISOString(),
      dateRange: dateRange,
      ...data,
    };
    
    if (format === "json") {
      const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `library-report-${new Date().toISOString().split("T")[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } else {
      // CSV export
      const headers = ["Metric", "Value"];
      const rows = [
        ["Total Books", data.overview.totalBooks],
        ["Available Books", data.overview.availableBooks],
        ["Borrowed Books", data.overview.borrowedBooks],
        ["Overdue Books", data.overview.overdueBooks],
        ["Total Members", data.overview.totalMembers],
        ["Active Members", data.overview.activeMembers],
        ["Total Borrows", data.overview.totalBorrows],
        ["Total Returns", data.overview.totalReturns],
      ];
      
      const csvContent = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
      const blob = new Blob([csvContent], { type: "text/csv" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `library-report-${new Date().toISOString().split("T")[0]}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Generating report...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              📋 Library Reports
            </h1>
            <p className="text-gray-600 mt-1">
              Generate and view library statistics
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => exportReport("csv")}
              className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition text-sm"
            >
              📊 Export CSV
            </button>
            <button
              onClick={() => exportReport("json")}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm"
            >
              📄 Export JSON
            </button>
          </div>
        </div>

        {/* Date Range Filter */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
              <input
                type="date"
                value={dateRange.start}
                onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
              <input
                type="date"
                value={dateRange.end}
                onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div className="flex items-end">
              <button
                onClick={fetchReportData}
                className="w-full bg-blue-700 text-white px-4 py-2.5 rounded-lg hover:bg-blue-800 transition"
              >
                🔄 Generate Report
              </button>
            </div>
          </div>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-blue-500">
            <div className="text-2xl font-bold text-blue-700">{data.overview.totalBooks}</div>
            <div className="text-xs text-gray-600">Total Books</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-green-500">
            <div className="text-2xl font-bold text-green-700">{data.overview.availableBooks}</div>
            <div className="text-xs text-gray-600">Available</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-purple-500">
            <div className="text-2xl font-bold text-purple-700">{data.overview.totalMembers}</div>
            <div className="text-xs text-gray-600">Total Members</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-yellow-500">
            <div className="text-2xl font-bold text-yellow-700">{data.overview.totalBorrows}</div>
            <div className="text-xs text-gray-600">Total Borrows</div>
          </div>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          {/* Top Books */}
          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-lg font-bold text-gray-800 mb-4">🏆 Top 10 Books</h3>
            {data.topBooks.length === 0 ? (
              <p className="text-gray-500 text-center py-8">No data available</p>
            ) : (
              <div className="space-y-2">
                {data.topBooks.map((book, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <span className="text-sm font-bold text-gray-400 w-6">{index + 1}.</span>
                    <div className="flex-1">
                      <div className="flex justify-between text-sm">
                        <span className="font-medium text-gray-700 truncate">{book.title}</span>
                        <span className="text-blue-600 font-bold">{book.count}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 rounded-full h-2"
                          style={{ width: `${Math.min((book.count / data.topBooks[0]?.count) * 100, 100)}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Top Members */}
          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-lg font-bold text-gray-800 mb-4">👤 Top 10 Members</h3>
            {data.topMembers.length === 0 ? (
              <p className="text-gray-500 text-center py-8">No data available</p>
            ) : (
              <div className="space-y-2">
                {data.topMembers.map((member, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <span className="text-sm font-bold text-gray-400 w-6">{index + 1}.</span>
                    <div className="flex-1">
                      <div className="flex justify-between text-sm">
                        <span className="font-medium text-gray-700 truncate">{member.name}</span>
                        <span className="text-green-600 font-bold">{member.count}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-green-600 rounded-full h-2"
                          style={{ width: `${Math.min((member.count / data.topMembers[0]?.count) * 100, 100)}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="px-6 py-4 border-b">
            <h3 className="text-lg font-bold text-gray-800">🕐 Recent Activity</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Book</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Member</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Action</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Date</th>
                </tr>
              </thead>
              <tbody>
                {data.recentActivity.length === 0 ? (
                  <tr>
                    <td colSpan="4" className="px-4 py-8 text-center text-gray-500">
                      No recent activity
                    </td>
                  </tr>
                ) : (
                  data.recentActivity.map((record, index) => (
                    <tr key={record.id || index} className="border-b hover:bg-gray-50 transition">
                      <td className="px-4 py-3 font-medium text-gray-800">{record.bookTitle || "Unknown"}</td>
                      <td className="px-4 py-3 text-gray-600">{record.memberName || "Unknown"}</td>
                      <td className="px-4 py-3 text-center">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          record.action === "borrowed" 
                            ? "bg-purple-100 text-purple-700" 
                            : "bg-green-100 text-green-700"
                        }`}>
                          {record.action === "borrowed" ? "📖 Borrowed" : "🔄 Returned"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center text-sm text-gray-500">
                        {record.borrowedDate ? new Date(record.borrowedDate).toLocaleDateString() : "N/A"}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}