// src/pages/library/History.jsx
import { useEffect, useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { db, collection, getDocs, query, orderBy } from "../../supabase/supabase";

export default function History() {
  useAuth();
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [stats, setStats] = useState({
    total: 0,
    borrowed: 0,
    returned: 0,
    overdue: 0,
  });

  const fetchHistory = async () => {
    setLoading(true);
    try {
      const snap = await getDocs(
        query(collection(db, "libraryHistory"), orderBy("borrowedDate", "desc"))
      );
      const data = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setHistory(data);

      // Calculate stats
      const total = data.length;
      const borrowed = data.filter(h => h.action === "borrowed").length;
      const returned = data.filter(h => h.action === "returned").length;
      const overdue = data.filter(h => h.status === "overdue" || (h.status === "active" && new Date(h.dueDate) < new Date())).length;

      setStats({ total, borrowed, returned, overdue });
    } catch (error) {
      console.error("Error fetching history:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
     
  }, []);

  const filteredHistory = history.filter(record => {
    const matchSearch = 
      record.bookTitle?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.memberName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.memberId?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchType = filterType === "all" || record.action === filterType;
    const matchStatus = filterStatus === "all" || record.status === filterStatus;
    return matchSearch && matchType && matchStatus;
  });

  const getActionBadge = (action) => {
    return action === "borrowed" 
      ? "bg-purple-100 text-purple-700" 
      : "bg-green-100 text-green-700";
  };

  const getStatusBadge = (status, dueDate) => {
    if (status === "returned") return "bg-green-100 text-green-700";
    if (status === "overdue" || (status === "active" && new Date(dueDate) < new Date())) {
      return "bg-red-100 text-red-700";
    }
    return "bg-yellow-100 text-yellow-700";
  };

  const getStatusLabel = (status, dueDate) => {
    if (status === "returned") return "✅ Returned";
    if (status === "overdue" || (status === "active" && new Date(dueDate) < new Date())) {
      return "⚠️ Overdue";
    }
    return "📖 Active";
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading history...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              🕐 Library History
            </h1>
            <p className="text-gray-600 mt-1">
              View all borrowing and return history
            </p>
          </div>
          <button
            onClick={fetchHistory}
            className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition text-sm"
          >
            🔄 Refresh
          </button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-blue-500">
            <div className="text-2xl font-bold text-blue-700">{stats.total}</div>
            <div className="text-xs text-gray-600">Total Records</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-purple-500">
            <div className="text-2xl font-bold text-purple-700">{stats.borrowed}</div>
            <div className="text-xs text-gray-600">Borrowed</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-green-500">
            <div className="text-2xl font-bold text-green-700">{stats.returned}</div>
            <div className="text-xs text-gray-600">Returned</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-red-500">
            <div className="text-2xl font-bold text-red-700">{stats.overdue}</div>
            <div className="text-xs text-gray-600">Overdue</div>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Search</label>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="🔍 Search by book, member..."
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Action Type</label>
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
              >
                <option value="all">All Actions</option>
                <option value="borrowed">📖 Borrowed</option>
                <option value="returned">🔄 Returned</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
              >
                <option value="all">All Status</option>
                <option value="active">📖 Active</option>
                <option value="returned">✅ Returned</option>
                <option value="overdue">⚠️ Overdue</option>
              </select>
            </div>
          </div>
        </div>

        {/* History Table */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Book</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Member</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Action</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Borrowed</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Due Date</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Status</th>
                </tr>
              </thead>
              <tbody>
                {filteredHistory.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="px-4 py-8 text-center text-gray-500">
                      {history.length === 0 ? "No history records found." : "No records match your search."}
                    </td>
                  </tr>
                ) : (
                  filteredHistory.map((record) => (
                    <tr key={record.id} className="border-b hover:bg-gray-50 transition">
                      <td className="px-4 py-3">
                        <div>
                          <p className="font-medium text-gray-800">{record.bookTitle || "Unknown"}</p>
                          <p className="text-xs text-gray-500">ID: {record.bookId || "N/A"}</p>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div>
                          <p className="font-medium text-gray-800">{record.memberName || "Unknown"}</p>
                          <p className="text-xs text-gray-500">ID: {record.memberId || "N/A"}</p>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getActionBadge(record.action)}`}>
                          {record.action === "borrowed" ? "📖 Borrowed" : "🔄 Returned"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center text-sm text-gray-500">
                        {record.borrowedDate ? new Date(record.borrowedDate).toLocaleDateString() : "N/A"}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`text-sm font-medium ${
                          record.status === "returned" ? "text-gray-500" :
                          new Date(record.dueDate) < new Date() ? "text-red-600" : "text-gray-600"
                        }`}>
                          {record.dueDate ? new Date(record.dueDate).toLocaleDateString() : "N/A"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(record.status, record.dueDate)}`}>
                          {getStatusLabel(record.status, record.dueDate)}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          <div className="px-4 py-3 border-t flex items-center justify-between">
            <p className="text-sm text-gray-500">
              Showing {filteredHistory.length} of {history.length} records
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}