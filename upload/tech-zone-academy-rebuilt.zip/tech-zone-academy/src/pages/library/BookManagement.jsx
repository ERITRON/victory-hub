// src/pages/library/BookManagement.jsx
import { useEffect, useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { db, storage, collection, getDocs, addDoc, updateDoc, deleteDoc, doc, query, orderBy, ref, uploadBytes, getDownloadURL, deleteObject } from "../../supabase/supabase";

export default function BookManagement() {
  const { user } = useAuth();
  const [books, setBooks] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingBook, setEditingBook] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("");
  const [uploading, setUploading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [formData, setFormData] = useState({
    title: "",
    author: "",
    isbn: "",
    category: "",
    publisher: "",
    year: "",
    description: "",
    quantity: 1,
    availableQuantity: 1,
    location: "",
    coverImage: "",
    status: "available",
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch books
      const booksSnap = await getDocs(query(collection(db, "libraryBooks"), orderBy("title")));
      const booksData = booksSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setBooks(booksData);

      // Fetch categories
      const categoriesSnap = await getDocs(collection(db, "libraryCategories"));
      const categoriesData = categoriesSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setCategories(categoriesData.sort((a, b) => a.name.localeCompare(b.name)));
    } catch (error) {
      setErrorMessage("Error loading data: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
     
  }, []);

  const handleInputChange = (e) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === "number" ? parseInt(value) || 0 : value,
    }));
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      setErrorMessage("Image size must be less than 2MB");
      return;
    }

    setUploading(true);
    try {
      const timestamp = Date.now();
      const fileName = `${timestamp}_${file.name}`;
      const storageRef = ref(storage, `library/${fileName}`);
      const snapshot = await uploadBytes(storageRef, file);
      const url = await getDownloadURL(snapshot.ref);
      setFormData(prev => ({ ...prev, coverImage: url }));
      setSuccessMessage("✅ Image uploaded successfully!");
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error uploading image: " + error.message);
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMessage("");
    setSuccessMessage("");

    // Validate
    if (!formData.title.trim()) {
      setErrorMessage("Book title is required");
      setLoading(false);
      return;
    }
    if (!formData.author.trim()) {
      setErrorMessage("Author name is required");
      setLoading(false);
      return;
    }
    if (!formData.category) {
      setErrorMessage("Please select a category");
      setLoading(false);
      return;
    }
    if (formData.quantity < 1) {
      setErrorMessage("Quantity must be at least 1");
      setLoading(false);
      return;
    }

    try {
      const data = {
        ...formData,
        availableQuantity: formData.quantity,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        createdBy: user?.uid,
        createdByName: user?.displayName || user?.email || "System",
      };

      if (editingBook) {
        await updateDoc(doc(db, "libraryBooks", editingBook.id), data);
        setSuccessMessage("✅ Book updated successfully!");
      } else {
        await addDoc(collection(db, "libraryBooks"), data);
        setSuccessMessage("✅ Book added successfully!");
      }

      setShowModal(false);
      setEditingBook(null);
      resetForm();
      await fetchData();
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error saving book: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this book?")) return;
    try {
      const book = books.find(b => b.id === id);
      if (book?.coverImage) {
        try {
          const imageRef = ref(storage, book.coverImage);
          await deleteObject(imageRef);
        } catch {
          console.log("Image not found in storage");
        }
      }
      await deleteDoc(doc(db, "libraryBooks", id));
      setSuccessMessage("✅ Book deleted successfully!");
      await fetchData();
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error deleting book: " + error.message);
    }
  };

  const resetForm = () => {
    setFormData({
      title: "",
      author: "",
      isbn: "",
      category: "",
      publisher: "",
      year: "",
      description: "",
      quantity: 1,
      availableQuantity: 1,
      location: "",
      coverImage: "",
      status: "available",
    });
  };

  const filteredBooks = books.filter(book => {
    const matchSearch = book.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        book.author?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        book.isbn?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchCategory = filterCategory === "" || book.category === filterCategory;
    return matchSearch && matchCategory;
  });

  const getStatusBadge = (status) => {
    const styles = {
      available: "bg-green-100 text-green-700",
      borrowed: "bg-yellow-100 text-yellow-700",
      overdue: "bg-red-100 text-red-700",
      damaged: "bg-orange-100 text-orange-700",
      lost: "bg-gray-100 text-gray-700",
    };
    return styles[status] || "bg-gray-100 text-gray-700";
  };

  if (loading && books.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading books...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              📚 Book Management
            </h1>
            <p className="text-gray-600 mt-1">
              Add, edit, and manage library books
            </p>
          </div>
          <button
            onClick={() => {
              setEditingBook(null);
              resetForm();
              setShowModal(true);
            }}
            className="bg-blue-700 text-white px-4 py-2 rounded-lg hover:bg-blue-800 transition"
          >
            ➕ Add Book
          </button>
        </div>

        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Search and Filter */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Search Books</label>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="🔍 Search by title, author, or ISBN..."
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Filter by Category</label>
              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
              >
                <option value="">All Categories</option>
                {categories.map(cat => (
                  <option key={cat.id} value={cat.name}>{cat.name}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="flex flex-wrap gap-4 mb-6">
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Total Books:</span>
            <span className="ml-2 font-bold text-blue-700">{books.length}</span>
          </div>
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Available:</span>
            <span className="ml-2 font-bold text-green-700">
              {books.filter(b => b.status === "available" || b.availableQuantity > 0).length}
            </span>
          </div>
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Borrowed:</span>
            <span className="ml-2 font-bold text-yellow-700">
              {books.filter(b => b.status === "borrowed").length}
            </span>
          </div>
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Filtered:</span>
            <span className="ml-2 font-bold text-blue-700">{filteredBooks.length}</span>
          </div>
        </div>

        {/* Books Table */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Book</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Author</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Category</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Available</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Status</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredBooks.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="px-4 py-8 text-center text-gray-500">
                      No books found. Click "Add Book" to create one.
                    </td>
                  </tr>
                ) : (
                  filteredBooks.map((book) => (
                    <tr key={book.id} className="border-b hover:bg-gray-50 transition">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          {book.coverImage ? (
                            <img src={book.coverImage} alt={book.title} className="h-12 w-10 object-cover rounded" />
                          ) : (
                            <div className="h-12 w-10 bg-blue-100 rounded flex items-center justify-center text-xl">📖</div>
                          )}
                          <div>
                            <p className="font-medium text-gray-800">{book.title}</p>
                            <p className="text-xs text-gray-500">ISBN: {book.isbn || "N/A"}</p>
                            <p className="text-xs text-gray-400">{book.location || "No location"}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">{book.author || "N/A"}</td>
                      <td className="px-4 py-3 text-sm text-gray-600">{book.category || "Uncategorized"}</td>
                      <td className="px-4 py-3 text-center text-sm font-medium text-blue-600">
                        {book.availableQuantity || 0} / {book.quantity || 0}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(book.status)}`}>
                          {book.status || "available"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => {
                              setEditingBook(book);
                              setFormData(book);
                              setShowModal(true);
                            }}
                            className="text-blue-600 hover:text-blue-800 text-sm p-1 hover:bg-blue-50 rounded"
                            title="Edit Book"
                          >
                            ✏️
                          </button>
                          <button
                            onClick={() => handleDelete(book.id)}
                            className="text-red-600 hover:text-red-800 text-sm p-1 hover:bg-red-50 rounded"
                            title="Delete Book"
                          >
                            🗑️
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          <div className="px-4 py-3 border-t flex items-center justify-between">
            <p className="text-sm text-gray-500">
              Showing {filteredBooks.length} of {books.length} books
            </p>
          </div>
        </div>
      </div>

      {/* Add/Edit Book Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800">
                  {editingBook ? "✏️ Edit Book" : "📚 Add New Book"}
                </h2>
                <button 
                  onClick={() => { 
                    setShowModal(false); 
                    setEditingBook(null); 
                    setErrorMessage("");
                  }} 
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ✕
                </button>
              </div>

              {editingBook && (
                <div className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-700">
                    Editing: <span className="font-semibold">{editingBook.title}</span>
                  </p>
                  <p className="text-xs text-blue-600">
                    ISBN: {editingBook.isbn || "N/A"} • Added: {editingBook.createdAt ? new Date(editingBook.createdAt).toLocaleDateString() : "N/A"}
                  </p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Title *
                    </label>
                    <input
                      type="text"
                      name="title"
                      value={formData.title}
                      onChange={handleInputChange}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Book title"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Author *
                    </label>
                    <input
                      type="text"
                      name="author"
                      value={formData.author}
                      onChange={handleInputChange}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Author name"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      ISBN
                    </label>
                    <input
                      type="text"
                      name="isbn"
                      value={formData.isbn}
                      onChange={handleInputChange}
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="ISBN number"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Category *
                    </label>
                    <select
                      name="category"
                      value={formData.category}
                      onChange={handleInputChange}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                    >
                      <option value="">Select Category</option>
                      {categories.map(cat => (
                        <option key={cat.id} value={cat.name}>{cat.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Publisher
                    </label>
                    <input
                      type="text"
                      name="publisher"
                      value={formData.publisher}
                      onChange={handleInputChange}
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Publisher name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Year
                    </label>
                    <input
                      type="number"
                      name="year"
                      value={formData.year}
                      onChange={handleInputChange}
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Publication year"
                      min="1900"
                      max={new Date().getFullYear()}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    rows="3"
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="Book description..."
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Total Quantity *
                    </label>
                    <input
                      type="number"
                      name="quantity"
                      value={formData.quantity}
                      onChange={handleInputChange}
                      required
                      min="1"
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Location
                    </label>
                    <input
                      type="text"
                      name="location"
                      value={formData.location}
                      onChange={handleInputChange}
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Shelf location"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Cover Image
                  </label>
                  <div className="flex gap-3">
                    <input
                      type="text"
                      name="coverImage"
                      value={formData.coverImage}
                      onChange={handleInputChange}
                      className="flex-1 border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Image URL"
                    />
                    <label className="bg-gray-200 hover:bg-gray-300 px-4 py-3 rounded-lg cursor-pointer transition">
                      {uploading ? "⏳" : "📁"}
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleImageUpload}
                        disabled={uploading}
                      />
                    </label>
                  </div>
                  {formData.coverImage && (
                    <div className="mt-2 h-32 w-32 rounded-lg overflow-hidden bg-gray-200">
                      <img src={formData.coverImage} alt="Preview" className="w-full h-full object-cover" />
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Status
                  </label>
                  <select
                    name="status"
                    value={formData.status}
                    onChange={handleInputChange}
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                  >
                    <option value="available">✅ Available</option>
                    <option value="borrowed">📖 Borrowed</option>
                    <option value="damaged">⚠️ Damaged</option>
                    <option value="lost">❌ Lost</option>
                  </select>
                </div>

                <div className="flex gap-3 pt-4 border-t">
                  <button
                    type="submit"
                    disabled={loading || uploading}
                    className="flex-1 bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition disabled:bg-gray-400 font-medium"
                  >
                    {loading ? "Saving..." : editingBook ? "💾 Update Book" : "✅ Add Book"}
                  </button>
                  <button
                    type="button"
                    onClick={() => { 
                      setShowModal(false); 
                      setEditingBook(null);
                      setErrorMessage("");
                    }}
                    className="px-6 py-3 rounded-lg bg-gray-200 text-gray-700 hover:bg-gray-300 transition font-medium"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}