// src/pages/LibrarianManagement.jsx
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { db, collection, getDocs, query, where, doc, updateDoc, getDoc } from "../../supabase/supabase";

export default function LibrarianManagement() {
  const navigate = useNavigate();
  const { user, role, createUserWithRole, updateUserStatus, deleteUser } = useAuth();
  const [librarians, setLibrarians] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    firstName: "",
    lastName: "",
    phone: "",
    address: "",
    librarianId: "",
  });
  const [formError, setFormError] = useState("");
  const [formSuccess, setFormSuccess] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [editingLibrarian, setEditingLibrarian] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);

  const fetchLibrarians = async () => {
    setLoading(true);
    try {
      const q = query(collection(db, "users"), where("role", "==", "librarian"));
      const snap = await getDocs(q);
      const librariansData = snap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setLibrarians(librariansData);
    } catch (error) {
      console.error("Error fetching librarians:", error);
      setErrorMessage("Error loading librarians: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (role === "admin" || role === "owner" || role === "super_admin") {
      fetchLibrarians();
    }
     
  }, [role]);

  const handleCreateLibrarian = async (e) => {
    e.preventDefault();
    setFormError("");
    setSubmitting(true);

    if (formData.password !== formData.confirmPassword) {
      setFormError("Passwords do not match");
      setSubmitting(false);
      return;
    }

    if (formData.password.length < 6) {
      setFormError("Password must be at least 6 characters");
      setSubmitting(false);
      return;
    }

    if (!formData.email) {
      setFormError("Email is required");
      setSubmitting(false);
      return;
    }

    if (!formData.firstName || !formData.lastName) {
      setFormError("First name and last name are required");
      setSubmitting(false);
      return;
    }

    try {
      const additionalData = {
        firstName: formData.firstName,
        lastName: formData.lastName,
        phone: formData.phone,
        address: formData.address,
        email: formData.email,
        librarianId: formData.librarianId || `LIB-${Date.now().toString().slice(-6)}`,
        createdByRole: role,
        createdBy: user?.uid,
      };

      await createUserWithRole(
        formData.email,
        formData.password,
        "librarian",
        additionalData
      );

      setFormSuccess(true);
      setSuccessMessage("✅ Librarian created successfully!");
      setFormData({
        email: "",
        password: "",
        confirmPassword: "",
        firstName: "",
        lastName: "",
        phone: "",
        address: "",
        librarianId: "",
      });

      setTimeout(() => {
        setFormSuccess(false);
        setShowCreateModal(false);
        setSuccessMessage("");
        fetchLibrarians();
      }, 2000);
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleEditLibrarian = (librarian) => {
    setEditingLibrarian(librarian);
    setFormData({
      email: librarian.email || "",
      password: "",
      confirmPassword: "",
      firstName: librarian.firstName || "",
      lastName: librarian.lastName || "",
      phone: librarian.phone || "",
      address: librarian.address || "",
      librarianId: librarian.librarianId || "",
    });
    setShowEditModal(true);
    setFormError("");
  };

  const handleUpdateLibrarian = async (e) => {
    e.preventDefault();
    setFormError("");
    setSubmitting(true);

    if (!formData.firstName || !formData.lastName) {
      setFormError("First name and last name are required");
      setSubmitting(false);
      return;
    }

    try {
      const librarianRef = doc(db, "users", editingLibrarian.id);
      await updateDoc(librarianRef, {
        firstName: formData.firstName,
        lastName: formData.lastName,
        phone: formData.phone,
        address: formData.address,
        email: formData.email,
        librarianId: formData.librarianId,
        updatedAt: new Date().toISOString(),
        updatedBy: user?.uid,
      });

      // Also update the librarian's profile
      const profileRef = doc(db, "librarians", editingLibrarian.id);
      const profileSnap = await getDoc(profileRef);
      if (profileSnap.exists()) {
        await updateDoc(profileRef, {
          firstName: formData.firstName,
          lastName: formData.lastName,
          phone: formData.phone,
          address: formData.address,
          email: formData.email,
          librarianId: formData.librarianId,
          updatedAt: new Date().toISOString(),
        });
      }

      setSuccessMessage("✅ Librarian updated successfully!");
      setShowEditModal(false);
      setEditingLibrarian(null);
      setFormData({
        email: "",
        password: "",
        confirmPassword: "",
        firstName: "",
        lastName: "",
        phone: "",
        address: "",
        librarianId: "",
      });
      await fetchLibrarians();
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setFormError("Error updating librarian: " + error.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleStatusChange = async (librarianId, newStatus) => {
    if (window.confirm(`Change librarian status to ${newStatus}?`)) {
      const success = await updateUserStatus(librarianId, newStatus);
      if (success) {
        setSuccessMessage("✅ Status updated successfully!");
        await fetchLibrarians();
        setTimeout(() => setSuccessMessage(""), 3000);
      }
    }
  };

  const handleDeleteLibrarian = async (librarianId, librarianEmail) => {
    if (window.confirm(`Are you sure you want to delete ${librarianEmail}? This action cannot be undone.`)) {
      const success = await deleteUser(librarianId);
      if (success) {
        setSuccessMessage("✅ Librarian deleted successfully!");
        await fetchLibrarians();
        setTimeout(() => setSuccessMessage(""), 3000);
      }
    }
  };

  const filteredLibrarians = librarians.filter((librarian) => {
    if (!searchTerm) return true;
    const search = searchTerm.toLowerCase();
    return (
      librarian.email?.toLowerCase().includes(search) ||
      librarian.firstName?.toLowerCase().includes(search) ||
      librarian.lastName?.toLowerCase().includes(search) ||
      librarian.phone?.includes(search) ||
      librarian.librarianId?.toLowerCase().includes(search)
    );
  });

  const statusColors = {
    active: "bg-green-100 text-green-700",
    inactive: "bg-red-100 text-red-700",
    pending: "bg-yellow-100 text-yellow-700",
    suspended: "bg-orange-100 text-orange-700",
  };

  // Check if user has permission
  if (role !== "admin" && role !== "owner" && role !== "super_admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">🚫</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h2>
          <p className="text-gray-600">You need admin, owner, or super admin privileges to access this page.</p>
          <button
            onClick={() => navigate("/admin-dashboard")}
            className="mt-4 bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              📚 Librarian Management
            </h1>
            <p className="text-gray-600 mt-1">
              Manage librarian accounts and permissions
            </p>
            <p className="text-sm text-indigo-600 mt-1">
              {role === "admin" ? "👔 Principal → Managing Librarians" :
               role === "owner" ? "🏢 School Owner → Managing Librarians" :
               "👑 Super Admin → Managing Librarians"}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <span className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-sm font-medium">
              📚 Librarians
            </span>
            <button
              onClick={() => {
                setEditingLibrarian(null);
                setFormData({
                  email: "",
                  password: "",
                  confirmPassword: "",
                  firstName: "",
                  lastName: "",
                  phone: "",
                  address: "",
                  librarianId: "",
                });
                setFormError("");
                setFormSuccess(false);
                setShowCreateModal(true);
              }}
              className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition"
            >
              ➕ Add Librarian
            </button>
          </div>
        </div>

        {/* Messages */}
        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Search */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="🔍 Search librarians by name, email, phone, or ID..."
            className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        </div>

        {/* Stats */}
        <div className="flex flex-wrap gap-4 mb-6">
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Total Librarians:</span>
            <span className="ml-2 font-bold text-indigo-700">{librarians.length}</span>
          </div>
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Active:</span>
            <span className="ml-2 font-bold text-green-700">
              {librarians.filter(l => l.status === "active" || !l.status).length}
            </span>
          </div>
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Filtered:</span>
            <span className="ml-2 font-bold text-indigo-700">{filteredLibrarians.length}</span>
          </div>
        </div>

        {/* Librarians Table */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Librarian</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Librarian ID</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Email</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Phone</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Status</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Created</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan="7" className="px-4 py-8 text-center text-gray-500">
                      <div className="animate-pulse">Loading librarians...</div>
                    </td>
                  </tr>
                ) : filteredLibrarians.length === 0 ? (
                  <tr>
                    <td colSpan="7" className="px-4 py-8 text-center text-gray-500">
                      No librarians found. Click "Add Librarian" to create one.
                    </td>
                  </tr>
                ) : (
                  filteredLibrarians.map((librarian) => (
                    <tr key={librarian.id} className="border-b hover:bg-gray-50 transition">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold">
                            {librarian.firstName?.charAt(0) || librarian.email?.charAt(0) || "L"}
                          </div>
                          <div>
                            <p className="font-medium text-gray-800">
                              {librarian.firstName || ""} {librarian.lastName || ""}
                            </p>
                            <p className="text-xs text-gray-500">
                              ID: {librarian.id.slice(0, 8)}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm font-medium text-gray-600">
                        {librarian.librarianId || "---"}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">{librarian.email}</td>
                      <td className="px-4 py-3 text-sm text-gray-600">{librarian.phone || "---"}</td>
                      <td className="px-4 py-3 text-center">
                        <select
                          value={librarian.status || "active"}
                          onChange={(e) => handleStatusChange(librarian.id, e.target.value)}
                          className={`px-2 py-1 rounded-full text-xs font-medium border-0 focus:ring-2 focus:ring-indigo-500 ${
                            statusColors[librarian.status] || statusColors.active
                          }`}
                        >
                          <option value="active">✅ Active</option>
                          <option value="inactive">❌ Inactive</option>
                          <option value="suspended">⛔ Suspended</option>
                          <option value="pending">⏳ Pending</option>
                        </select>
                      </td>
                      <td className="px-4 py-3 text-center text-sm text-gray-500">
                        {librarian.createdAt ? new Date(librarian.createdAt).toLocaleDateString() : "---"}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => handleEditLibrarian(librarian)}
                            className="text-indigo-600 hover:text-indigo-800 text-sm"
                            title="Edit Librarian"
                          >
                            ✏️
                          </button>
                          <button
                            onClick={() => handleDeleteLibrarian(librarian.id, librarian.email)}
                            className="text-red-600 hover:text-red-800 text-sm"
                            title="Delete Librarian"
                          >
                            🗑️
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          <div className="px-4 py-3 border-t flex items-center justify-between">
            <p className="text-sm text-gray-500">
              Showing {filteredLibrarians.length} librarian{filteredLibrarians.length !== 1 ? "s" : ""}
            </p>
          </div>
        </div>
      </div>

      {/* ============================================
             CREATE LIBRARIAN MODAL
          ============================================ */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-gray-800">
                  📚 Create New Librarian
                </h3>
                <button
                  onClick={() => {
                    setShowCreateModal(false);
                    setFormError("");
                    setFormSuccess(false);
                  }}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ✕
                </button>
              </div>

              <div className="mb-4 p-3 bg-indigo-50 rounded-lg border border-indigo-200">
                <p className="text-sm text-indigo-700">
                  {role === "admin" ? "👔 Principal" : role === "owner" ? "🏢 School Owner" : "👑 Super Admin"} → Creating Librarian account
                </p>
                <p className="text-xs text-indigo-600 mt-1">
                  Librarians can manage books, members, and borrowing
                </p>
              </div>

              {formSuccess ? (
                <div className="text-center py-8">
                  <div className="text-6xl mb-4">✅</div>
                  <h4 className="text-xl font-bold text-green-600">Librarian Created!</h4>
                  <p className="text-gray-500">The librarian account has been created successfully.</p>
                </div>
              ) : (
                <form onSubmit={handleCreateLibrarian} className="space-y-4">
                  {formError && (
                    <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg text-sm">
                      {formError}
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                      placeholder="librarian@school.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Password *
                    </label>
                    <input
                      type="password"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      required
                      minLength="6"
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                      placeholder="Min 6 characters"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Confirm Password *
                    </label>
                    <input
                      type="password"
                      value={formData.confirmPassword}
                      onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                      placeholder="Confirm password"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        First Name *
                      </label>
                      <input
                        type="text"
                        value={formData.firstName}
                        onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                        required
                        className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                        placeholder="First name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Last Name *
                      </label>
                      <input
                        type="text"
                        value={formData.lastName}
                        onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                        required
                        className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                        placeholder="Last name"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                      placeholder="+251 9XX XXX XXX"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Librarian ID (Optional)
                    </label>
                    <input
                      type="text"
                      value={formData.librarianId}
                      onChange={(e) => setFormData({ ...formData, librarianId: e.target.value })}
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                      placeholder="e.g., LIB-001"
                    />
                    <p className="text-xs text-gray-400 mt-1">Auto-generated if left blank</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Address
                    </label>
                    <input
                      type="text"
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                      placeholder="Address"
                    />
                  </div>

                  <div className="flex gap-3 pt-4">
                    <button
                      type="button"
                      onClick={() => {
                        setShowCreateModal(false);
                        setFormError("");
                      }}
                      className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg hover:bg-gray-300 transition"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={submitting}
                      className="flex-1 bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition disabled:bg-gray-400"
                    >
                      {submitting ? "Creating..." : "✅ Create Librarian"}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ============================================
             EDIT LIBRARIAN MODAL
          ============================================ */}
      {showEditModal && editingLibrarian && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-gray-800">
                  ✏️ Edit Librarian
                </h3>
                <button
                  onClick={() => {
                    setShowEditModal(false);
                    setEditingLibrarian(null);
                    setFormError("");
                  }}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ✕
                </button>
              </div>

              <div className="mb-4 p-3 bg-indigo-50 rounded-lg border border-indigo-200">
                <p className="text-sm text-indigo-700">
                  Editing: {editingLibrarian.firstName || ""} {editingLibrarian.lastName || ""}
                </p>
                <p className="text-xs text-indigo-600 mt-1">
                  ID: {editingLibrarian.id.slice(0, 8)}
                </p>
              </div>

              <form onSubmit={handleUpdateLibrarian} className="space-y-4">
                {formError && (
                  <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg text-sm">
                    {formError}
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none bg-gray-50"
                    placeholder="librarian@school.com"
                    disabled
                  />
                  <p className="text-xs text-gray-400 mt-1">Email cannot be changed</p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      First Name *
                    </label>
                    <input
                      type="text"
                      value={formData.firstName}
                      onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                      placeholder="First name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Last Name *
                    </label>
                    <input
                      type="text"
                      value={formData.lastName}
                      onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                      placeholder="Last name"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="+251 9XX XXX XXX"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Librarian ID
                  </label>
                  <input
                    type="text"
                    value={formData.librarianId}
                    onChange={(e) => setFormData({ ...formData, librarianId: e.target.value })}
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="LIB-001"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Address
                  </label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="Address"
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex-1 bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition disabled:bg-gray-400"
                  >
                    {submitting ? "Updating..." : "💾 Update Librarian"}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowEditModal(false);
                      setEditingLibrarian(null);
                      setFormError("");
                    }}
                    className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg hover:bg-gray-300 transition"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}