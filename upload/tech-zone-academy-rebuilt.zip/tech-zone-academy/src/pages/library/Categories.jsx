// src/pages/library/Categories.jsx
import { useEffect, useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { db, collection, getDocs, addDoc, updateDoc, deleteDoc, doc, query, orderBy } from "../../supabase/supabase";

export default function Categories() {
  const { user } = useAuth();
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    color: "bg-blue-100 text-blue-700",
    icon: "📚",
  });

  const colorOptions = [
    { value: "bg-blue-100 text-blue-700", label: "Blue" },
    { value: "bg-green-100 text-green-700", label: "Green" },
    { value: "bg-purple-100 text-purple-700", label: "Purple" },
    { value: "bg-orange-100 text-orange-700", label: "Orange" },
    { value: "bg-red-100 text-red-700", label: "Red" },
    { value: "bg-yellow-100 text-yellow-700", label: "Yellow" },
    { value: "bg-pink-100 text-pink-700", label: "Pink" },
    { value: "bg-indigo-100 text-indigo-700", label: "Indigo" },
    { value: "bg-teal-100 text-teal-700", label: "Teal" },
    { value: "bg-gray-100 text-gray-700", label: "Gray" },
  ];

  const iconOptions = [
    "📚", "📖", "🔬", "📐", "🌍", "🎨", "🎵", "⚽", "💻", "📝", 
    "🧪", "📊", "🔢", "📓", "📕", "📗", "📘", "📙", "📔", "📒"
  ];

  const fetchCategories = async () => {
    setLoading(true);
    try {
      const snap = await getDocs(query(collection(db, "libraryCategories"), orderBy("name")));
      const data = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setCategories(data);
    } catch (error) {
      setErrorMessage("Error loading categories: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCategories();
     
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMessage("");
    setSuccessMessage("");

    if (!formData.name.trim()) {
      setErrorMessage("Category name is required");
      setLoading(false);
      return;
    }

    try {
      // Check if category name already exists
      const existingCategory = categories.find(
        c => c.name.toLowerCase() === formData.name.toLowerCase() && c.id !== editingCategory?.id
      );
      if (existingCategory) {
        setErrorMessage("A category with this name already exists");
        setLoading(false);
        return;
      }

      const data = {
        name: formData.name.trim(),
        description: formData.description.trim(),
        color: formData.color,
        icon: formData.icon,
        updatedAt: new Date().toISOString(),
        updatedBy: user?.uid,
        updatedByName: user?.displayName || user?.email || "System",
      };

      if (editingCategory) {
        await updateDoc(doc(db, "libraryCategories", editingCategory.id), data);
        setSuccessMessage("✅ Category updated successfully!");
      } else {
        data.createdAt = new Date().toISOString();
        data.createdBy = user?.uid;
        data.createdByName = user?.displayName || user?.email || "System";
        await addDoc(collection(db, "libraryCategories"), data);
        setSuccessMessage("✅ Category added successfully!");
      }

      setShowModal(false);
      setEditingCategory(null);
      resetForm();
      await fetchCategories();
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error saving category: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this category?")) return;
    try {
      // Check if category is used by any books
      const booksSnap = await getDocs(collection(db, "libraryBooks"));
      const books = booksSnap.docs.map(doc => doc.data());
      const categoryInUse = books.some(book => book.category === categories.find(c => c.id === id)?.name);
      
      if (categoryInUse) {
        setErrorMessage("Cannot delete category that is used by books. Please reassign books first.");
        setTimeout(() => setErrorMessage(""), 3000);
        return;
      }

      await deleteDoc(doc(db, "libraryCategories", id));
      setSuccessMessage("✅ Category deleted successfully!");
      await fetchCategories();
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error deleting category: " + error.message);
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      color: "bg-blue-100 text-blue-700",
      icon: "📚",
    });
  };

  const filteredCategories = categories.filter(category =>
    category.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    category.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading && categories.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading categories...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              📊 Book Categories
            </h1>
            <p className="text-gray-600 mt-1">
              Manage book categories and their colors
            </p>
          </div>
          <button
            onClick={() => {
              setEditingCategory(null);
              resetForm();
              setShowModal(true);
            }}
            className="bg-blue-700 text-white px-4 py-2 rounded-lg hover:bg-blue-800 transition"
          >
            ➕ Add Category
          </button>
        </div>

        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="🔍 Search categories..."
            className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredCategories.length === 0 ? (
            <div className="col-span-full bg-white rounded-xl shadow p-12 text-center">
              <div className="text-6xl mb-4">📭</div>
              <h3 className="text-xl font-semibold text-gray-700 mb-2">
                {categories.length === 0 ? "No Categories Found" : "No Categories Match"}
              </h3>
              <p className="text-gray-500">
                {categories.length === 0 ? "Click 'Add Category' to create one." : "No categories match your search."}
              </p>
            </div>
          ) : (
            filteredCategories.map((category) => (
              <div
                key={category.id}
                className={`${category.color} rounded-xl p-4 border-2 border-transparent hover:border-blue-400 transition-all duration-300`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="text-3xl mb-2">{category.icon || "📚"}</div>
                    <h3 className="font-bold text-gray-800">{category.name}</h3>
                    {category.description && (
                      <p className="text-sm text-gray-600 mt-1">{category.description}</p>
                    )}
                    <p className="text-xs text-gray-400 mt-2">
                      {category.createdAt ? new Date(category.createdAt).toLocaleDateString() : "N/A"}
                    </p>
                  </div>
                  <div className="flex gap-1">
                    <button
                      onClick={() => {
                        setEditingCategory(category);
                        setFormData({
                          name: category.name || "",
                          description: category.description || "",
                          color: category.color || "bg-blue-100 text-blue-700",
                          icon: category.icon || "📚",
                        });
                        setShowModal(true);
                      }}
                      className="text-gray-600 hover:text-blue-600 text-sm p-1 hover:bg-white/50 rounded transition"
                      title="Edit Category"
                    >
                      ✏️
                    </button>
                    <button
                      onClick={() => handleDelete(category.id)}
                      className="text-gray-600 hover:text-red-600 text-sm p-1 hover:bg-white/50 rounded transition"
                      title="Delete Category"
                    >
                      🗑️
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="mt-6 bg-white rounded-xl shadow p-4">
          <p className="text-sm text-gray-500">
            Showing {filteredCategories.length} of {categories.length} categories
          </p>
        </div>
      </div>

      {/* Add/Edit Category Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800">
                  {editingCategory ? "✏️ Edit Category" : "📊 Add New Category"}
                </h2>
                <button 
                  onClick={() => { 
                    setShowModal(false); 
                    setEditingCategory(null); 
                    setErrorMessage("");
                  }} 
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ✕
                </button>
              </div>

              {editingCategory && (
                <div className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-700">
                    Editing: <span className="font-semibold">{editingCategory.name}</span>
                  </p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Category Name *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="e.g., Fiction, Science, History"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <input
                    type="text"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="Category description"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Color Scheme
                  </label>
                  <select
                    name="color"
                    value={formData.color}
                    onChange={handleInputChange}
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                  >
                    {colorOptions.map(color => (
                      <option key={color.value} value={color.value}>
                        {color.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Icon
                  </label>
                  <div className="grid grid-cols-5 gap-2">
                    {iconOptions.map(icon => (
                      <button
                        key={icon}
                        type="button"
                        onClick={() => setFormData(prev => ({ ...prev, icon }))}
                        className={`p-2 rounded-lg text-2xl transition ${
                          formData.icon === icon
                            ? "bg-blue-100 border-2 border-blue-500"
                            : "bg-gray-50 hover:bg-gray-100 border-2 border-transparent"
                        }`}
                      >
                        {icon}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex gap-3 pt-4 border-t">
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition disabled:bg-gray-400 font-medium"
                  >
                    {loading ? "Saving..." : editingCategory ? "💾 Update Category" : "✅ Add Category"}
                  </button>
                  <button
                    type="button"
                    onClick={() => { 
                      setShowModal(false); 
                      setEditingCategory(null);
                      setErrorMessage("");
                    }}
                    className="px-6 py-3 rounded-lg bg-gray-200 text-gray-700 hover:bg-gray-300 transition font-medium"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}