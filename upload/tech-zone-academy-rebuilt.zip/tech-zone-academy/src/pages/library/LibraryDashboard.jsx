// src/pages/library/LibraryDashboard.jsx
import { useEffect, useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { db, collection, getDocs, query, where, orderBy, limit } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";

export default function LibraryDashboard() {
  useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalBooks: 0,
    availableBooks: 0,
    borrowedBooks: 0,
    overdueBooks: 0,
    totalMembers: 0,
    totalCategories: 0,
    pendingReturns: 0,
  });
  const [recentActivity, setRecentActivity] = useState([]);
  const [popularBooks, setPopularBooks] = useState([]);

  const fetchLibraryData = async () => {
    setLoading(true);
    try {
      const booksSnap = await getDocs(collection(db, "libraryBooks"));
      const books = booksSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));

      const totalBooks = books.length;
      const availableBooks = books.filter(b => b.status === "available").length;
      const borrowedBooks = books.filter(b => b.status === "borrowed").length;
      const overdueBooks = books.filter(b => b.status === "overdue").length;

      const categoriesSnap = await getDocs(collection(db, "libraryCategories"));
      const totalCategories = categoriesSnap.size;

      const membersSnap = await getDocs(collection(db, "libraryMembers"));
      const totalMembers = membersSnap.size;

      const pendingSnap = await getDocs(
        query(collection(db, "libraryHistory"), where("status", "==", "active"))
      );
      const pendingReturns = pendingSnap.size;

      const historySnap = await getDocs(
        query(collection(db, "libraryHistory"), orderBy("borrowedDate", "desc"), limit(10))
      );
      const history = historySnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));

      const borrowCount = {};
      history.forEach(record => {
        if (record.bookId) {
          borrowCount[record.bookId] = (borrowCount[record.bookId] || 0) + 1;
        }
      });
      const sortedBooks = Object.entries(borrowCount)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([bookId, count]) => {
          const book = books.find(b => b.id === bookId);
          return { ...book, borrowCount: count };
        });

      setStats({
        totalBooks,
        availableBooks,
        borrowedBooks,
        overdueBooks,
        totalMembers,
        totalCategories,
        pendingReturns,
      });
      setRecentActivity(history.slice(0, 5));
      setPopularBooks(sortedBooks);

    } catch (error) {
      console.error("Error fetching library data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLibraryData();
     
  }, []);

  const libraryItems = [
    {
      icon: "📚",
      title: "Book Management",
      description: "Add, edit, and manage books",
      route: "/library/books",
      color: "bg-blue-50 hover:bg-blue-100 border-blue-200",
      iconColor: "text-blue-700",
    },
    {
      icon: "👤",
      title: "Members",
      description: "Manage library members",
      route: "/library/members",
      color: "bg-green-50 hover:bg-green-100 border-green-200",
      iconColor: "text-green-700",
    },
    {
      icon: "📖",
      title: "Borrow/Return",
      description: "Process book borrow and returns",
      route: "/library/borrow",
      color: "bg-purple-50 hover:bg-purple-100 border-purple-200",
      iconColor: "text-purple-700",
    },
    {
      icon: "📊",
      title: "Categories",
      description: "Manage book categories",
      route: "/library/categories",
      color: "bg-orange-50 hover:bg-orange-100 border-orange-200",
      iconColor: "text-orange-700",
    },
    {
      icon: "🕐",
      title: "History",
      description: "View borrowing history",
      route: "/library/history",
      color: "bg-indigo-50 hover:bg-indigo-100 border-indigo-200",
      iconColor: "text-indigo-700",
    },
    {
      icon: "📋",
      title: "Reports",
      description: "Generate library reports",
      route: "/library/reports",
      color: "bg-red-50 hover:bg-red-100 border-red-200",
      iconColor: "text-red-700",
    },
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading library data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              📚 Library Dashboard
            </h1>
            <p className="text-gray-600 mt-1">
              Manage the school library
            </p>
          </div>
          <div className="flex items-center gap-3">
            <span className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-sm font-medium">
              📚 Librarian
            </span>
            <button
              onClick={fetchLibraryData}
              className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition text-sm"
            >
              🔄 Refresh
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-blue-500">
            <div className="text-2xl font-bold text-blue-700">{stats.totalBooks}</div>
            <div className="text-xs text-gray-600">Total Books</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-green-500">
            <div className="text-2xl font-bold text-green-700">{stats.availableBooks}</div>
            <div className="text-xs text-gray-600">Available</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-purple-500">
            <div className="text-2xl font-bold text-purple-700">{stats.borrowedBooks}</div>
            <div className="text-xs text-gray-600">Borrowed</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-red-500">
            <div className="text-2xl font-bold text-red-700">{stats.overdueBooks}</div>
            <div className="text-xs text-gray-600">Overdue</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-indigo-500">
            <div className="text-2xl font-bold text-indigo-700">{stats.totalMembers}</div>
            <div className="text-xs text-gray-600">Members</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-yellow-500">
            <div className="text-2xl font-bold text-yellow-700">{stats.pendingReturns}</div>
            <div className="text-xs text-gray-600">Pending Returns</div>
          </div>
        </div>

        {popularBooks.length > 0 && (
          <div className="bg-white rounded-xl shadow-md p-6 mb-8">
            <h3 className="text-lg font-bold text-gray-800 mb-4">🏆 Popular Books</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
              {popularBooks.map((book, index) => (
                <div key={book?.id || index} className="bg-gray-50 rounded-lg p-4 text-center">
                  <div className="text-3xl mb-2">📖</div>
                  <div className="font-medium text-gray-800 truncate">{book?.title || "Unknown"}</div>
                  <div className="text-sm text-gray-500">{book?.author || "Unknown Author"}</div>
                  <div className="text-xs text-blue-600 mt-1">
                    {book?.borrowCount || 0} borrows
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
          <div className="px-6 py-4 border-b">
            <h3 className="text-lg font-bold text-gray-800">🕐 Recent Activity</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Member</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Book</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Action</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Date</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Status</th>
                </tr>
              </thead>
              <tbody>
                {recentActivity.length === 0 ? (
                  <tr>
                    <td colSpan="5" className="px-4 py-8 text-center text-gray-500">
                      No recent activity
                    </td>
                  </tr>
                ) : (
                  recentActivity.map((record, index) => (
                    <tr key={record.id || index} className="border-b hover:bg-gray-50 transition">
                      <td className="px-4 py-3 font-medium text-gray-800">
                        {record.memberName || "Unknown"}
                      </td>
                      <td className="px-4 py-3 text-gray-600">{record.bookTitle || "Unknown"}</td>
                      <td className="px-4 py-3 text-center">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          record.action === "borrowed" 
                            ? "bg-purple-100 text-purple-700" 
                            : "bg-green-100 text-green-700"
                        }`}>
                          {record.action === "borrowed" ? "📖 Borrowed" : "🔄 Returned"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-500">
                        {record.borrowedDate ? new Date(record.borrowedDate).toLocaleDateString() : "N/A"}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          record.status === "returned" 
                            ? "bg-green-100 text-green-700" 
                            : record.status === "overdue" 
                            ? "bg-red-100 text-red-700" 
                            : "bg-yellow-100 text-yellow-700"
                        }`}>
                          {record.status || "Active"}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {libraryItems.map((item, index) => (
            <div
              key={index}
              onClick={() => navigate(item.route)}
              className={`
                ${item.color}
                border-2
                rounded-xl
                p-5
                cursor-pointer
                transition-all
                duration-300
                hover:shadow-xl
                hover:-translate-y-1
                hover:border-opacity-100
              `}
            >
              <div className="flex items-start gap-3">
                <div className={`text-3xl ${item.iconColor}`}>
                  {item.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm sm:text-base font-bold text-gray-800 truncate">
                    {item.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-gray-600 mt-1 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
              <div className="mt-3 flex justify-end">
                <span className="text-xs text-gray-400">→</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}