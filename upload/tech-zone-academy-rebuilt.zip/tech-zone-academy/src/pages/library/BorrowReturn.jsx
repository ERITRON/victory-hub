// src/pages/library/BorrowReturn.jsx
import { useEffect, useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { db, collection, getDocs, doc, query, where, orderBy, runTransaction } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";

export default function BorrowReturn() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [, setBooks] = useState([]);
  const [, setMembers] = useState([]);
  const [searchResults, setSearchResults] = useState([]);
  const [selectedBook, setSelectedBook] = useState(null);
  const [selectedMember, setSelectedMember] = useState(null);
  const [borrowRecords, setBorrowRecords] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchType, setSearchType] = useState("book"); // book or member
  const [dueDate, setDueDate] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const fetchData = async () => {
    try {
      const booksSnap = await getDocs(query(collection(db, "libraryBooks"), where("status", "==", "available")));
      const booksData = booksSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setBooks(booksData);

      const membersSnap = await getDocs(collection(db, "libraryMembers"));
      const membersData = membersSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMembers(membersData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const fetchBorrowRecords = async () => {
    try {
      const recordsSnap = await getDocs(
        query(collection(db, "libraryHistory"), orderBy("borrowedDate", "desc"))
      );
      const records = recordsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setBorrowRecords(records.filter(r => r.status !== "returned"));
    } catch (error) {
      console.error("Error fetching borrow records:", error);
    }
  };

  useEffect(() => {
    fetchData();
    fetchBorrowRecords();
     
  }, []);

  const handleSearch = async () => {
    if (!searchTerm.trim()) {
      setSearchResults([]);
      return;
    }

    setLoading(true);
    try {
      let results = [];
      if (searchType === "book") {
        const q = query(
          collection(db, "libraryBooks"),
          where("title", ">=", searchTerm),
          where("title", "<=", searchTerm + "\uf8ff")
        );
        const snap = await getDocs(q);
        results = snap.docs.map(doc => ({ id: doc.id, ...doc.data(), type: "book" }));
      } else {
        const q = query(
          collection(db, "libraryMembers"),
          where("name", ">=", searchTerm),
          where("name", "<=", searchTerm + "\uf8ff")
        );
        const snap = await getDocs(q);
        results = snap.docs.map(doc => ({ id: doc.id, ...doc.data(), type: "member" }));
      }
      setSearchResults(results);
    } catch (error) {
      setErrorMessage("Error searching: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSelect = (item) => {
    if (item.type === "book") {
      setSelectedBook(item);
      setSearchResults([]);
      setSearchTerm("");
    } else {
      setSelectedMember(item);
      setSearchResults([]);
      setSearchTerm("");
    }
  };

  const handleBorrow = async () => {
    if (!selectedBook || !selectedMember) {
      setErrorMessage("Please select both a book and a member");
      return;
    }

    if (!dueDate) {
      setErrorMessage("Please select a due date");
      return;
    }

    setLoading(true);
    setErrorMessage("");
    setSuccessMessage("");

    try {
      await runTransaction(db, async (transaction) => {
        const bookRef = doc(db, "libraryBooks", selectedBook.id);
        const bookSnap = await transaction.get(bookRef);
        
        if (!bookSnap.exists()) {
          throw new Error("Book not found");
        }

        const bookData = bookSnap.data();
        if (bookData.availableQuantity <= 0) {
          throw new Error("No copies available");
        }

        // Update book quantity
        transaction.update(bookRef, {
          availableQuantity: bookData.availableQuantity - 1,
          status: bookData.availableQuantity - 1 <= 0 ? "borrowed" : "available",
          updatedAt: new Date().toISOString(),
        });

        // Create borrow record
        const historyRef = doc(collection(db, "libraryHistory"));
        transaction.set(historyRef, {
          bookId: selectedBook.id,
          bookTitle: selectedBook.title,
          memberId: selectedMember.id,
          memberName: selectedMember.name,
          action: "borrowed",
          borrowedDate: new Date().toISOString(),
          dueDate: new Date(dueDate).toISOString(),
          status: "active",
          createdBy: user?.uid,
          createdAt: new Date().toISOString(),
        });
      });

      setSuccessMessage(`✅ Book "${selectedBook.title}" borrowed by ${selectedMember.name}`);
      setSelectedBook(null);
      setSelectedMember(null);
      setDueDate("");
      await fetchData();
      await fetchBorrowRecords();
    } catch (error) {
      setErrorMessage(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleReturn = async (record) => {
    if (!window.confirm(`Return "${record.bookTitle}"?`)) return;

    setLoading(true);
    try {
      await runTransaction(db, async (transaction) => {
        // Update book
        const bookRef = doc(db, "libraryBooks", record.bookId);
        const bookSnap = await transaction.get(bookRef);
        if (bookSnap.exists()) {
          const bookData = bookSnap.data();
          transaction.update(bookRef, {
            availableQuantity: (bookData.availableQuantity || 0) + 1,
            status: "available",
            updatedAt: new Date().toISOString(),
          });
        }

        // Update history record
        const historyRef = doc(db, "libraryHistory", record.id);
        transaction.update(historyRef, {
          action: "returned",
          returnedDate: new Date().toISOString(),
          status: "returned",
          updatedAt: new Date().toISOString(),
        });
      });

      setSuccessMessage(`✅ "${record.bookTitle}" returned successfully`);
      await fetchData();
      await fetchBorrowRecords();
    } catch (error) {
      setErrorMessage("Error returning book: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <button onClick={() => navigate(-1)} className="text-gray-600 hover:text-gray-800 transition">
            ← Back
          </button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              📖 Borrow / Return Books
            </h1>
            <p className="text-gray-600 mt-1">
              Process book borrowing and returns
            </p>
          </div>
        </div>

        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Search Section */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Search Type
              </label>
              <select
                value={searchType}
                onChange={(e) => {
                  setSearchType(e.target.value);
                  setSearchResults([]);
                }}
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
              >
                <option value="book">🔍 Search Books</option>
                <option value="member">👤 Search Members</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Search {searchType === "book" ? "Book" : "Member"}
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder={searchType === "book" ? "Enter book title..." : "Enter member name..."}
                  className="flex-1 border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
                  onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                />
                <button
                  onClick={handleSearch}
                  disabled={loading}
                  className="bg-blue-700 text-white px-4 py-2 rounded-lg hover:bg-blue-800 transition"
                >
                  {loading ? "..." : "🔍"}
                </button>
              </div>
            </div>
            <div className="flex items-end">
              <button
                onClick={() => {
                  setSearchResults([]);
                  setSearchTerm("");
                  setSelectedBook(null);
                  setSelectedMember(null);
                }}
                className="text-sm text-gray-500 hover:text-gray-700"
              >
                Clear Selection
              </button>
            </div>
          </div>

          {/* Search Results */}
          {searchResults.length > 0 && (
            <div className="mt-4 border-t pt-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {searchResults.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => handleSelect(item)}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer transition"
                  >
                    <div>
                      <div className="font-medium text-gray-800">
                        {item.type === "book" ? item.title : item.name}
                      </div>
                      <div className="text-sm text-gray-500">
                        {item.type === "book" 
                          ? `${item.author} • ${item.availableQuantity || 0} available`
                          : `${item.email || item.phone || ""}`
                        }
                      </div>
                    </div>
                    <div className="text-xs text-gray-400">
                      {item.type === "book" ? "📚" : "👤"}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Selected Items */}
          {(selectedBook || selectedMember) && (
            <div className="mt-4 border-t pt-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {selectedBook && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                    <div className="text-xs text-blue-600">Selected Book</div>
                    <div className="font-medium text-gray-800">{selectedBook.title}</div>
                    <div className="text-sm text-gray-500">{selectedBook.author}</div>
                  </div>
                )}
                {selectedMember && (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                    <div className="text-xs text-green-600">Selected Member</div>
                    <div className="font-medium text-gray-800">{selectedMember.name}</div>
                    <div className="text-sm text-gray-500">{selectedMember.email}</div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Borrow Form */}
        {selectedBook && selectedMember && (
          <div className="bg-white rounded-xl shadow-md p-6 mb-6">
            <h3 className="text-lg font-bold text-gray-800 mb-4">📝 Process Borrow</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Due Date *
                </label>
                <input
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  min={new Date().toISOString().split("T")[0]}
                  className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>
              <div className="flex items-end gap-3">
                <button
                  onClick={handleBorrow}
                  disabled={loading || !dueDate}
                  className="flex-1 bg-blue-700 text-white py-2.5 rounded-lg hover:bg-blue-800 transition disabled:bg-gray-400"
                >
                  {loading ? "Processing..." : "📖 Borrow Book"}
                </button>
                <button
                  onClick={() => {
                    setSelectedBook(null);
                    setSelectedMember(null);
                    setDueDate("");
                  }}
                  className="px-4 py-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Active Borrowings */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="px-6 py-4 border-b">
            <h3 className="text-lg font-bold text-gray-800">📋 Active Borrowings</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Book</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Member</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Borrowed Date</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Due Date</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Status</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Action</th>
                </tr>
              </thead>
              <tbody>
                {borrowRecords.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="px-4 py-8 text-center text-gray-500">
                      No active borrowings
                    </td>
                  </tr>
                ) : (
                  borrowRecords.map((record) => {
                    const isOverdue = new Date(record.dueDate) < new Date();
                    return (
                      <tr key={record.id} className="border-b hover:bg-gray-50 transition">
                        <td className="px-4 py-3 font-medium text-gray-800">
                          {record.bookTitle}
                        </td>
                        <td className="px-4 py-3 text-gray-600">{record.memberName}</td>
                        <td className="px-4 py-3 text-center text-sm text-gray-500">
                          {record.borrowedDate ? new Date(record.borrowedDate).toLocaleDateString() : "N/A"}
                        </td>
                        <td className="px-4 py-3 text-center">
                          <span className={`text-sm font-medium ${isOverdue ? "text-red-600" : "text-gray-600"}`}>
                            {record.dueDate ? new Date(record.dueDate).toLocaleDateString() : "N/A"}
                            {isOverdue && <span className="ml-1 text-red-600">⚠️</span>}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            isOverdue ? "bg-red-100 text-red-700" : "bg-yellow-100 text-yellow-700"
                          }`}>
                            {isOverdue ? "Overdue" : "Active"}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center">
                          <button
                            onClick={() => handleReturn(record)}
                            className="bg-green-600 text-white px-3 py-1 rounded-lg hover:bg-green-700 transition text-sm"
                          >
                            Return
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}