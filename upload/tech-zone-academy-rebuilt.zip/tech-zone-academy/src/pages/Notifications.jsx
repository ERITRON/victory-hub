import { useMemo, useState } from "react";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import Icon from "../components/Icon";
import SEO from "../components/SEO";
import { useAuth } from "../context/AuthContext";
import { useNotifications } from "../context/NotificationContext";
import {
  formatNotificationTime,
  getNotificationStyle,
  getRoleNotificationConfig,
  getRoleNotificationFilters,
} from "../services/notificationModel";

const priorityClass = {
  urgent: "border-red-200 bg-red-50 text-red-700",
  high: "border-amber-200 bg-amber-50 text-amber-800",
  normal: "border-gray-200 bg-gray-50 text-gray-600",
};

export default function Notifications() {
  const { user, role, loading: authLoading } = useAuth();
  const notificationState = useNotifications();
  const { notifications, unreadCount, loading, error, markAsRead, markAllAsRead, deleteNotification } = notificationState;
  const navigate = useNavigate();
  const location = useLocation();
  const [filter, setFilter] = useState("all");
  const [activeAction, setActiveAction] = useState(null);
  const [actionError, setActionError] = useState(null);

  const roleConfig = useMemo(() => getRoleNotificationConfig(role), [role]);
  const FILTERS = useMemo(
    () => [{ value: "all", label: "All" }, { value: "unread", label: "Unread" }, ...getRoleNotificationFilters(role)],
    [role]
  );

  const filtered = useMemo(() => notifications.filter((notification) => {
    if (filter === "all") return true;
    if (filter === "unread") return !notification.read;
    return notification.category === filter;
  }), [filter, notifications]);

  const counts = useMemo(() => notifications.reduce((result, notification) => {
    result[notification.category] = (result[notification.category] || 0) + 1;
    return result;
  }, {}), [notifications]);

  if (authLoading) return <LoadingView />;
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname }} />;

  const run = async (key, operation) => {
    setActiveAction(key);
    setActionError(null);
    try {
      await operation();
    } catch (operationError) {
      setActionError(operationError instanceof Error ? operationError.message : "The notification could not be updated.");
    } finally {
      setActiveAction(null);
    }
  };

  const openNotification = async (notification) => {
    if (!notification.read) await run(`read:${notification.id}`, () => markAsRead(notification.id));
    const target = notification.action || notification.link;
    if (!target) return;
    if (/^https?:\/\//i.test(target)) window.location.assign(target);
    else navigate(target.startsWith("/") ? target : `/${target}`);
  };

  return (
    <>
      <SEO title="Notifications" description="View and manage your Tech Zone Academy notifications." noindex />
      <main className="min-h-[75vh] bg-gray-50 px-4 py-8 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-5xl">
          <button type="button" onClick={() => navigate(-1)} className="mb-5 inline-flex items-center gap-2 rounded-md px-2 py-2 text-sm font-medium text-gray-600 hover:bg-gray-200 hover:text-gray-900">
            <span aria-hidden="true">&larr;</span> Back
          </button>

          <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <div className="flex flex-wrap items-center gap-3">
                <h1 className="text-2xl font-bold text-gray-950 sm:text-3xl">Notifications</h1>
                {unreadCount > 0 && <span className="rounded-full bg-blue-100 px-2.5 py-1 text-xs font-semibold text-blue-700">{unreadCount} unread</span>}
              </div>
              <p className="mt-1 text-sm text-gray-500">{roleConfig.subtitle}</p>
            </div>
            <button type="button" disabled={!unreadCount || activeAction === "all"} onClick={() => run("all", markAllAsRead)} className="inline-flex min-h-10 items-center justify-center gap-2 rounded-md bg-blue-700 px-4 text-sm font-semibold text-white hover:bg-blue-800 disabled:cursor-not-allowed disabled:bg-gray-300">
              <Icon name="success" size={15} aria-hidden="true" />
              {activeAction === "all" ? "Marking..." : "Mark all read"}
            </button>
          </div>

          <div className="mb-5 overflow-x-auto border-b border-gray-200" aria-label="Notification filters">
            <div className="flex min-w-max gap-1">
              {FILTERS.map((item) => {
                const count = item.value === "all" ? notifications.length : item.value === "unread" ? unreadCount : counts[item.value] || 0;
                return <button key={item.value} type="button" onClick={() => setFilter(item.value)} aria-pressed={filter === item.value} className={`border-b-2 px-3 py-3 text-sm font-semibold transition-colors ${filter === item.value ? "border-blue-700 text-blue-700" : "border-transparent text-gray-500 hover:text-gray-900"}`}>
                  {item.label} <span className="ml-1 text-xs font-medium">{count}</span>
                </button>;
              })}
            </div>
          </div>

          {(actionError || error) && <div role="alert" className="mb-4 rounded-md border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{actionError || error}</div>}

          {loading ? <LoadingPanel /> : filtered.length === 0 ? (
            <div className="border border-dashed border-gray-300 bg-white px-6 py-16 text-center">
              <Icon name="notification" size={32} className="text-gray-300" aria-hidden="true" />
              <h2 className="mt-4 text-lg font-semibold text-gray-900">{notifications.length ? "No matching notifications" : "No notifications"}</h2>
              <p className="mt-1 text-sm text-gray-500">{notifications.length ? "Choose another filter to see more updates." : roleConfig.emptyMessage}</p>
            </div>
          ) : (
            <div className="overflow-hidden border border-gray-200 bg-white shadow-sm">
              <div className="divide-y divide-gray-200">
                {filtered.map((notification) => {
                  const style = getNotificationStyle(notification);
                  const busy = activeAction?.endsWith(notification.id);
                  return (
                    <article key={notification.id} className={`relative flex gap-4 px-4 py-5 sm:px-6 ${notification.read ? "bg-white" : "bg-blue-50/50"}`}>
                      <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-md text-xl ${style.iconClass}`} aria-hidden="true">{style.icon}</span>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <h2 className={`break-words text-base ${notification.read ? "font-semibold text-gray-800" : "font-bold text-gray-950"}`}>{notification.title}</h2>
                              {!notification.read && <span className={`h-2.5 w-2.5 rounded-full ${style.dotClass}`} aria-label="Unread" />}
                              {notification.priority !== "normal" && <span className={`rounded border px-1.5 py-0.5 text-[10px] font-bold uppercase ${priorityClass[notification.priority]}`}>{notification.priority}</span>}
                            </div>
                            <p className="mt-1 break-words text-sm leading-6 text-gray-600">{notification.message}</p>
                            <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 text-xs text-gray-400">
                              <time>{formatNotificationTime(notification.createdAt)}</time>
                              <span className="capitalize">{notification.category}</span>
                              {notification.sender && <span>From {notification.sender}</span>}
                              {notification.channels.includes("email") && <span>Email sent</span>}
                            </div>
                          </div>
                          {(notification.link || notification.action) && <button type="button" disabled={busy} onClick={() => openNotification(notification)} className="shrink-0 self-start rounded-md bg-gray-900 px-3 py-2 text-xs font-semibold text-white hover:bg-black disabled:opacity-50">{notification.actionLabel || "View details"}</button>}
                        </div>
                        <div className="mt-4 flex flex-wrap gap-2">
                          {!notification.read && <button type="button" disabled={busy} onClick={() => run(`read:${notification.id}`, () => markAsRead(notification.id))} className="rounded-md border border-blue-200 bg-blue-50 px-3 py-2 text-xs font-semibold text-blue-700 hover:bg-blue-100 disabled:opacity-50">Mark as read</button>}
                          <button type="button" disabled={busy} onClick={() => window.confirm("Delete this notification?") && run(`delete:${notification.id}`, () => deleteNotification(notification.id))} className="inline-flex items-center gap-2 rounded-md border border-red-200 px-3 py-2 text-xs font-semibold text-red-600 hover:bg-red-50 disabled:opacity-50"><Icon name="delete" size={12} /> Delete</button>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </main>
    </>
  );
}

function LoadingView() {
  return <><SEO title="Notifications" noindex /><div className="min-h-[60vh] bg-gray-50 px-4 py-10"><LoadingPanel /></div></>;
}

function LoadingPanel() {
  return <div className="mx-auto flex min-h-48 max-w-5xl items-center justify-center border border-gray-200 bg-white text-sm text-gray-500" role="status">Loading notifications...</div>;
}
