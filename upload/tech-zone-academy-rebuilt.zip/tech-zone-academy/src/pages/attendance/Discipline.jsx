// src/pages/Discipline.jsx
import { useEffect, useMemo, useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { db, collection, getDocs, addDoc, updateDoc, doc, deleteDoc, query, orderBy } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";

export default function Discipline() {
  const { user, role } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [records, setRecords] = useState([]);
  const [students, setStudents] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingRecord, setEditingRecord] = useState(null);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [updatingStatusId, setUpdatingStatusId] = useState(null);
  const [formData, setFormData] = useState({
    studentId: "",
    studentName: "",
    grade: "",
    section: "",
    type: "warning",
    date: new Date().toISOString().split("T")[0],
    description: "",
    action: "",
    status: "active",
    reportedBy: "",
  });

  const disciplineTypes = [
    { value: "warning", label: "⚠️ Warning", color: "bg-yellow-100 text-yellow-700" },
    { value: "detention", label: "📝 Detention", color: "bg-orange-100 text-orange-700" },
    { value: "suspension", label: "⛔ Suspension", color: "bg-red-100 text-red-700" },
    { value: "expulsion", label: "🚫 Expulsion", color: "bg-red-200 text-red-800" },
    { value: "commendation", label: "🌟 Commendation", color: "bg-green-100 text-green-700" },
  ];

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch students
      const studentsSnap = await getDocs(collection(db, "students"));
      const studentsData = studentsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setStudents(studentsData);

      // Fetch discipline records
      const recordsSnap = await getDocs(
        query(collection(db, "discipline"), orderBy("date", "desc"))
      );
      const recordsData = recordsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setRecords(recordsData);
    } catch (error) {
      setErrorMessage("Error loading data: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {

    fetchData(); // async data fetch on mount
  }, []);

  // Manual refresh — refetches students and discipline records on demand.
  const handleRefresh = async () => {
    setErrorMessage("");
    await fetchData();
    setSuccessMessage("✅ Data refreshed");
    setTimeout(() => setSuccessMessage(""), 2000);
  };

  // Stats recalculate automatically whenever the records state changes —
  // add/edit/delete/status updates all flow through setRecords, so the
  // cards always reflect the current data without a manual trigger.
  const stats = useMemo(() => {
    const activeRecords = records.filter((r) => r.status === "active" || !r.status);
    const countType = (items, type) => items.filter((r) => r.type === type).length;
    const countSuspensions = (items) =>
      items.filter((r) => r.type === "suspension" || r.type === "expulsion").length;

    return {
      total: records.length,
      active: activeRecords.length,
      resolved: records.filter((r) => r.status === "resolved").length,
      closed: records.filter((r) => r.status === "closed").length,
      warnings: countType(activeRecords, "warning"),
      allWarnings: countType(records, "warning"),
      detentions: countType(activeRecords, "detention"),
      allDetentions: countType(records, "detention"),
      suspensions: countSuspensions(activeRecords),
      allSuspensions: countSuspensions(records),
      commendations: countType(activeRecords, "commendation"),
      allCommendations: countType(records, "commendation"),
    };
  }, [records]);

  // ✅ Check if user has access (Admin or Vice Principal)
  if (role !== "admin" && role !== "vice_principal") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">🚫</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h2>
          <p className="text-gray-600">You need admin or vice principal privileges to access this page.</p>
          <button
            onClick={() => navigate(role === "vice_principal" ? "/vice-principal/dashboard" : "/admin-dashboard")}
            className="mt-4 bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleStudentSelect = (studentId) => {
    const student = students.find((s) => s.id === studentId || s.studentId === studentId);
    if (student) {
      setFormData({
        ...formData,
        studentId: student.studentId || studentId,
        studentName: `${student.firstName} ${student.fatherName}`,
        grade: student.grade || "",
        section: student.section || "",
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMessage("");
    setSuccessMessage("");

    if (!formData.studentId) {
      setErrorMessage("Please select a student");
      setLoading(false);
      return;
    }

    if (!formData.description.trim()) {
      setErrorMessage("Please enter a description");
      setLoading(false);
      return;
    }

    try {
      const data = {
        ...formData,
        reportedBy: user?.email || user?.displayName || "System",
        reportedByRole: role,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      if (editingRecord) {
        await updateDoc(doc(db, "discipline", editingRecord.id), data);
        setSuccessMessage("✅ Record updated successfully!");
      } else {
        await addDoc(collection(db, "discipline"), data);
        setSuccessMessage("✅ Record added successfully!");
      }

      setShowModal(false);
      setEditingRecord(null);
      resetForm();
      await fetchData();
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error saving record: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this record?")) return;
    try {
      await deleteDoc(doc(db, "discipline", id));
      setSuccessMessage("✅ Record deleted successfully!");
      await fetchData();
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error deleting record: " + error.message);
    }
  };

  const handleStatusChange = async (id, newStatus) => {
    const previousRecord = records.find((record) => record.id === id);
    if (!previousRecord || (previousRecord.status || "active") === newStatus) return;

    setUpdatingStatusId(id);
    setErrorMessage("");
    setRecords((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status: newStatus } : r))
    );
    setEditingRecord((current) =>
      current?.id === id ? { ...current, status: newStatus } : current
    );
    if (editingRecord?.id === id) {
      setFormData((current) => ({ ...current, status: newStatus }));
    }
    try {
      const updatedAt = new Date().toISOString();
      await updateDoc(doc(db, "discipline", id), {
        status: newStatus,
        updatedAt,
        updatedBy: user?.uid,
        resolvedAt: newStatus === "resolved" ? updatedAt : null,
        closedAt: newStatus === "closed" ? updatedAt : null,
      });
      setSuccessMessage(`✅ Status updated to ${newStatus}`);
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage("Error updating status: " + error.message);
      setRecords((prev) =>
        prev.map((record) => (record.id === id ? previousRecord : record))
      );
      setEditingRecord((current) =>
        current?.id === id ? previousRecord : current
      );
      if (editingRecord?.id === id) {
        setFormData((current) => ({
          ...current,
          status: previousRecord.status || "active",
        }));
      }
    } finally {
      setUpdatingStatusId(null);
    }
  };

  const resetForm = () => {
    setFormData({
      studentId: "",
      studentName: "",
      grade: "",
      section: "",
      type: "warning",
      date: new Date().toISOString().split("T")[0],
      description: "",
      action: "",
      status: "active",
      reportedBy: "",
    });
  };

  const getTypeBadge = (type) => {
    const found = disciplineTypes.find((t) => t.value === type);
    return found ? found.color : "bg-gray-100 text-gray-700";
  };

  const getTypeIcon = (type) => {
    const found = disciplineTypes.find((t) => t.value === type);
    return found ? found.label.split(" ")[0] : "📌";
  };

  if (loading && records.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading discipline records...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              📋 Student Discipline
            </h1>
            <p className="text-gray-600 mt-1">
              Track and manage student behavior and disciplinary actions
            </p>
            {role === "vice_principal" && (
              <p className="text-sm text-purple-600 mt-1">
                👔 Vice Principal • Managing student discipline
              </p>
            )}
          </div>
          <div className="flex items-center gap-3">
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${
              role === "admin" ? "bg-blue-100 text-blue-700" : "bg-purple-100 text-purple-700"
            }`}>
              {role === "admin" ? "👔 Principal" : "👔 Vice Principal"}
            </span>
            <button
              onClick={handleRefresh}
              disabled={loading}
              className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition disabled:opacity-50"
              title="Reload records from the server"
            >
              🔄 Refresh
            </button>
            <button
              onClick={() => {
                setEditingRecord(null);
                resetForm();
                setShowModal(true);
              }}
              className="bg-red-700 text-white px-4 py-2 rounded-lg hover:bg-red-800 transition"
            >
              ➕ Add Record
            </button>
          </div>
        </div>

        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Stats — driven by the memoized `stats`, so every change to
            records (add / edit / delete / status change) updates them */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-blue-500">
            <div className="text-2xl font-bold text-blue-700">{stats.total}</div>
            <div className="text-xs text-gray-600">Total Records</div>
            <div className="text-[10px] text-gray-400 mt-0.5">
              {stats.active} active · {stats.resolved} resolved · {stats.closed} closed
            </div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 bg-yellow-50 border-yellow-500">
            <div className="text-2xl font-bold text-yellow-700">{stats.warnings}</div>
            <div className="text-xs text-gray-600">Active Warnings</div>
            <div className="mt-0.5 text-[10px] text-gray-400">{stats.allWarnings} total</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 bg-orange-50 border-orange-500">
            <div className="text-2xl font-bold text-orange-700">{stats.detentions}</div>
            <div className="text-xs text-gray-600">Active Detentions</div>
            <div className="mt-0.5 text-[10px] text-gray-400">{stats.allDetentions} total</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 bg-red-50 border-red-500">
            <div className="text-2xl font-bold text-red-700">{stats.suspensions}</div>
            <div className="text-xs text-gray-600">Active Suspensions</div>
            <div className="mt-0.5 text-[10px] text-gray-400">{stats.allSuspensions} total</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 bg-green-50 border-green-500">
            <div className="text-2xl font-bold text-green-700">{stats.commendations}</div>
            <div className="text-xs text-gray-600">Active Commendations</div>
            <div className="mt-0.5 text-[10px] text-gray-400">{stats.allCommendations} total</div>
          </div>
        </div>

        {/* Records Table */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Student</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Type</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Date</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Description</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Action</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Status</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {records.length === 0 ? (
                  <tr>
                    <td colSpan="7" className="px-4 py-8 text-center text-gray-500">
                      No discipline records found
                    </td>
                  </tr>
                ) : (
                  records.map((record) => (
                    <tr
                      key={record.id}
                      className={`border-b transition hover:bg-gray-50 ${
                        record.status === "resolved" || record.status === "closed"
                          ? "bg-gray-50/70 opacity-75"
                          : ""
                      }`}
                    >
                      <td className="px-4 py-3">
                        <div>
                          <p className="font-medium text-gray-800">{record.studentName}</p>
                          <p className="text-xs text-gray-500">{record.grade} - Section {record.section}</p>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getTypeBadge(record.type)}`}>
                          {getTypeIcon(record.type)} {record.type}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">{record.date}</td>
                      <td className="px-4 py-3 text-sm text-gray-600 max-w-xs truncate">
                        {record.description}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">{record.action || "—"}</td>
                      <td className="px-4 py-3 text-center">
                        <select
                          value={record.status || "active"}
                          onChange={(e) => handleStatusChange(record.id, e.target.value)}
                          disabled={updatingStatusId === record.id}
                          className={`px-2 py-1 rounded-full text-xs font-medium border-0 focus:ring-2 focus:ring-blue-500 ${
                            record.status === "resolved" || record.status === "closed"
                              ? "bg-green-100 text-green-700"
                              : "bg-yellow-100 text-yellow-700"
                          }`}
                        >
                          <option value="active">⏳ Active</option>
                          <option value="resolved">✅ Resolved</option>
                          <option value="closed">📌 Closed</option>
                        </select>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => {
                              setEditingRecord(record);
                              setFormData(record);
                              setShowModal(true);
                            }}
                            className="text-blue-600 hover:text-blue-800 text-sm"
                            title="Edit"
                          >
                            ✏️
                          </button>
                          <button
                            onClick={() => handleDelete(record.id)}
                            className="text-red-600 hover:text-red-800 text-sm"
                            title="Delete"
                          >
                            🗑️
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          <div className="px-4 py-3 border-t flex items-center justify-between">
            <p className="text-sm text-gray-500">
              Showing {records.length} records
            </p>
          </div>
        </div>
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800">
                  {editingRecord ? "✏️ Edit Record" : "➕ Add Discipline Record"}
                </h2>
                <button
                  onClick={() => {
                    setShowModal(false);
                    setEditingRecord(null);
                    setErrorMessage("");
                  }}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ✕
                </button>
              </div>

              {editingRecord && (
                <div className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-700">
                    Editing record for: <span className="font-semibold">{editingRecord.studentName}</span>
                  </p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Student *
                  </label>
                  <select
                    value={formData.studentId}
                    onChange={(e) => handleStudentSelect(e.target.value)}
                    required
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                  >
                    <option value="">Select Student</option>
                    {students.map((student) => (
                      <option key={student.id} value={student.studentId || student.id}>
                        {student.firstName} {student.fatherName} ({student.studentId}) - {student.grade}
                      </option>
                    ))}
                  </select>
                  {formData.studentName && (
                    <p className="text-xs text-green-600 mt-1">
                      Selected: {formData.studentName} • {formData.grade} - Section {formData.section}
                    </p>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Discipline Type *
                    </label>
                    <select
                      name="type"
                      value={formData.type}
                      onChange={handleInputChange}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                    >
                      {disciplineTypes.map((type) => (
                        <option key={type.value} value={type.value}>
                          {type.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Date *
                    </label>
                    <input
                      type="date"
                      name="date"
                      value={formData.date}
                      onChange={handleInputChange}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description *
                  </label>
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    rows="3"
                    required
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="Describe the incident..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Action Taken
                  </label>
                  <input
                    type="text"
                    name="action"
                    value={formData.action}
                    onChange={handleInputChange}
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="e.g., Meeting with parents, Counseling, etc."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Status
                  </label>
                  <select
                    name="status"
                    value={formData.status}
                    onChange={handleInputChange}
                    className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                  >
                    <option value="active">⏳ Active</option>
                    <option value="resolved">✅ Resolved</option>
                    <option value="closed">📌 Closed</option>
                  </select>
                </div>

                <div className="flex gap-3 pt-4 border-t">
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 bg-red-700 text-white py-3 rounded-lg hover:bg-red-800 transition disabled:bg-gray-400 font-medium"
                  >
                    {loading ? "Saving..." : editingRecord ? "💾 Update Record" : "✅ Add Record"}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowModal(false);
                      setEditingRecord(null);
                      setErrorMessage("");
                    }}
                    className="px-6 py-3 rounded-lg bg-gray-200 text-gray-700 hover:bg-gray-300 transition font-medium"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
