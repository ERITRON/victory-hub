// src/pages/Attendance.jsx
import { useEffect, useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { db, collection, getDocs, addDoc, query, where } from "../../supabase/supabase";

export default function Attendance() {
  const { user } = useAuth();
  const [homeroomClass, setHomeroomClass] = useState(null);
  const [students, setStudents] = useState([]);
  const [attendance, setAttendance] = useState({});
  const [remarks, setRemarks] = useState({});
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [isAttendanceTaken, setIsAttendanceTaken] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0]);
  const [summary, setSummary] = useState({
    total: 0,
    present: 0,
    absent: 0,
    late: 0,
    excused: 0,
  });

  const checkAttendanceTaken = async () => {
    try {
      const today = selectedDate;
      const attendanceQuery = query(
        collection(db, "attendance"),
        where("date", "==", today),
        where("grade", "==", homeroomClass?.grade),
        where("section", "==", homeroomClass?.section)
      );
      const attendanceSnap = await getDocs(attendanceQuery);
      setIsAttendanceTaken(attendanceSnap.size > 0);

      if (attendanceSnap.size > 0) {
        const existingAttendance = {};
        const existingRemarks = {};
        attendanceSnap.forEach((doc) => {
          const data = doc.data();
          existingAttendance[data.studentId] = data.status;
          existingRemarks[data.studentId] = data.remark || "";
        });
        setAttendance(existingAttendance);
        setRemarks(existingRemarks);
        updateSummary(existingAttendance);
      }
    } catch (error) {
      console.error("Error checking attendance:", error);
    }
  };

  const loadExistingAttendance = async () => {
    // Already handled in checkAttendanceTaken
  };

  const updateSummary = (attendanceData) => {
    const total = students.length;
    const present = Object.values(attendanceData).filter((s) => s === "Present").length;
    const absent = Object.values(attendanceData).filter((s) => s === "Absent").length;
    const late = Object.values(attendanceData).filter((s) => s === "Late").length;
    const excused = Object.values(attendanceData).filter((s) => s === "Excused").length;

    setSummary({ total, present, absent, late, excused });
  };

  const fetchHomeroomData = async () => {
    setLoading(true);
    try {
      const homeroomQuery = query(
        collection(db, "homeroomAssignments"),
        where("teacherId", "==", user.uid)
      );
      const homeroomSnapshot = await getDocs(homeroomQuery);

      if (homeroomSnapshot.empty) {
        setErrorMessage("You are not assigned as a homeroom teacher.");
        setLoading(false);
        return;
      }

      let homeroom = null;
      homeroomSnapshot.forEach((doc) => {
        homeroom = { id: doc.id, ...doc.data() };
      });
      setHomeroomClass(homeroom);

      const studentsQuery = query(
        collection(db, "students"),
        where("grade", "==", homeroom.grade),
        where("section", "==", homeroom.section)
      );
      const studentsSnap = await getDocs(studentsQuery);
      const studentsData = studentsSnap.docs.map((doc, index) => ({
        id: doc.id,
        rollNo: index + 1,
        ...doc.data(),
      }));
      setStudents(studentsData.sort((a, b) => a.firstName.localeCompare(b.firstName)));

      await checkAttendanceTaken();
      await loadExistingAttendance();

    } catch (error) {
      setErrorMessage("Error loading data: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
       
      fetchHomeroomData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- fetchHomeroomData is redefined each render; keying on user only avoids a refetch loop
  }, [user]);


  const handleAttendance = (studentId, status) => {
    const newAttendance = { ...attendance, [studentId]: status };
    setAttendance(newAttendance);
    updateSummary(newAttendance);
  };

  const handleRemark = (studentId, remark) => {
    setRemarks({ ...remarks, [studentId]: remark });
  };

  const saveAttendance = async () => {
    if (students.length === 0) {
      setErrorMessage("No students found in your homeroom class.");
      return;
    }

    setSubmitting(true);
    setErrorMessage("");
    setSuccessMessage("");

    try {
      const today = new Date(selectedDate);
      const date = selectedDate;
      const day = today.toLocaleDateString("en-US", { weekday: "long" });
      const month = today.toLocaleDateString("en-US", { month: "long" });
      const year = today.getFullYear();

      const attendanceQuery = query(
        collection(db, "attendance"),
        where("date", "==", date),
        where("grade", "==", homeroomClass.grade),
        where("section", "==", homeroomClass.section)
      );
      const existingAttendance = await getDocs(attendanceQuery);

      if (!existingAttendance.empty) {
        setErrorMessage(`Attendance for ${homeroomClass.grade} - ${homeroomClass.section} has already been taken on ${date}!`);
        setSubmitting(false);
        return;
      }

      const batchPromises = students.map((student) => {
        const status = attendance[student.id] || "Absent";
        const remark = remarks[student.id] || "";
        return addDoc(collection(db, "attendance"), {
          studentId: student.studentId,
          studentName: `${student.firstName} ${student.fatherName}`,
          grade: student.grade,
          section: student.section,
          status,
          remark,
          date,
          day,
          month,
          year,
          recordedAt: new Date().toISOString(),
        });
      });

      await Promise.all(batchPromises);

      setSuccessMessage(
        `✅ Attendance Saved Successfully!\n` +
        `Present: ${summary.present} | Absent: ${summary.absent} | Late: ${summary.late} | Excused: ${summary.excused}`
      );
      setIsAttendanceTaken(true);
      setTimeout(() => setSuccessMessage(""), 5000);

    } catch (error) {
      setErrorMessage("Error saving attendance: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading homeroom data...</p>
        </div>
      </div>
    );
  }

  if (!homeroomClass) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">📋</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">No Homeroom Class</h2>
          <p className="text-gray-600">You are not assigned as a homeroom teacher.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
                📋 Daily Attendance Register
              </h1>
              <p className="text-gray-600 mt-1">
                {homeroomClass.grade} - Section {homeroomClass.section}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="border rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
              />
              <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
                {isAttendanceTaken ? "✅ Taken" : "⏳ Pending"}
              </span>
            </div>
          </div>
        </div>

        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4 whitespace-pre-line">
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Summary Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 mb-6">
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-blue-500">
            <div className="text-2xl font-bold text-blue-700">{summary.total}</div>
            <div className="text-xs sm:text-sm text-gray-600">Total Students</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-green-500">
            <div className="text-2xl font-bold text-green-700">{summary.present}</div>
            <div className="text-xs sm:text-sm text-gray-600">✅ Present</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-red-500">
            <div className="text-2xl font-bold text-red-700">{summary.absent}</div>
            <div className="text-xs sm:text-sm text-gray-600">❌ Absent</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-yellow-500">
            <div className="text-2xl font-bold text-yellow-700">{summary.late}</div>
            <div className="text-xs sm:text-sm text-gray-600">⏰ Late</div>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-blue-500">
            <div className="text-2xl font-bold text-blue-700">{summary.excused}</div>
            <div className="text-xs sm:text-sm text-gray-600">📝 Excused</div>
          </div>
        </div>

        {/* Attendance Table */}
        {students.length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-6xl mb-4">📭</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No Students Found</h3>
            <p className="text-gray-500">No students are enrolled in {homeroomClass.grade} - {homeroomClass.section}</p>
          </div>
        ) : (
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">No</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Student ID</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Student Name</th>
                    <th className="px-4 py-3 text-center text-sm font-semibold text-gray-600">✅ Present</th>
                    <th className="px-4 py-3 text-center text-sm font-semibold text-gray-600">❌ Absent</th>
                    <th className="px-4 py-3 text-center text-sm font-semibold text-gray-600">⏰ Late</th>
                    <th className="px-4 py-3 text-center text-sm font-semibold text-gray-600">📝 Excused</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Remark</th>
                  </tr>
                </thead>
                <tbody>
                  {students.map((student, index) => (
                    <tr key={student.id} className="border-b hover:bg-gray-50 transition">
                      <td className="px-4 py-3 text-sm text-gray-500">{index + 1}</td>
                      <td className="px-4 py-3 text-sm text-gray-500">{student.studentId}</td>
                      <td className="px-4 py-3 font-medium text-gray-800">
                        {student.firstName} {student.fatherName}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <button
                          onClick={() => handleAttendance(student.id, "Present")}
                          disabled={isAttendanceTaken}
                          className={`w-8 h-8 rounded-full transition ${
                            attendance[student.id] === "Present"
                              ? "bg-green-600 text-white"
                              : "border-2 border-gray-300 hover:border-green-500"
                          } ${isAttendanceTaken ? "opacity-50 cursor-not-allowed" : ""}`}
                        >
                          {attendance[student.id] === "Present" && "✓"}
                        </button>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <button
                          onClick={() => handleAttendance(student.id, "Absent")}
                          disabled={isAttendanceTaken}
                          className={`w-8 h-8 rounded-full transition ${
                            attendance[student.id] === "Absent"
                              ? "bg-red-600 text-white"
                              : "border-2 border-gray-300 hover:border-red-500"
                          } ${isAttendanceTaken ? "opacity-50 cursor-not-allowed" : ""}`}
                        >
                          {attendance[student.id] === "Absent" && "✕"}
                        </button>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <button
                          onClick={() => handleAttendance(student.id, "Late")}
                          disabled={isAttendanceTaken}
                          className={`w-8 h-8 rounded-full transition ${
                            attendance[student.id] === "Late"
                              ? "bg-yellow-600 text-white"
                              : "border-2 border-gray-300 hover:border-yellow-500"
                          } ${isAttendanceTaken ? "opacity-50 cursor-not-allowed" : ""}`}
                        >
                          {attendance[student.id] === "Late" && "⏰"}
                        </button>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <button
                          onClick={() => handleAttendance(student.id, "Excused")}
                          disabled={isAttendanceTaken}
                          className={`w-8 h-8 rounded-full transition ${
                            attendance[student.id] === "Excused"
                              ? "bg-blue-600 text-white"
                              : "border-2 border-gray-300 hover:border-blue-500"
                          } ${isAttendanceTaken ? "opacity-50 cursor-not-allowed" : ""}`}
                        >
                          {attendance[student.id] === "Excused" && "📝"}
                        </button>
                      </td>
                      <td className="px-4 py-3">
                        <input
                          type="text"
                          value={remarks[student.id] || ""}
                          onChange={(e) => handleRemark(student.id, e.target.value)}
                          placeholder="Remark"
                          disabled={isAttendanceTaken}
                          className="w-full border rounded px-2 py-1 text-sm focus:ring-2 focus:ring-blue-500 outline-none disabled:bg-gray-100"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {!isAttendanceTaken && (
              <div className="p-4 bg-gray-50 border-t flex flex-wrap items-center justify-between gap-3">
                <div>
                  <span className="text-sm text-gray-600">
                    {Object.keys(attendance).length} of {students.length} students marked
                  </span>
                  {Object.keys(attendance).length < students.length && (
                    <p className="text-xs text-yellow-600 mt-1">
                      ⚠️ {students.length - Object.keys(attendance).length} student(s) not marked. They will be marked as Absent.
                    </p>
                  )}
                </div>
                <button
                  onClick={saveAttendance}
                  disabled={submitting || Object.keys(attendance).length === 0}
                  className={`px-8 py-3 rounded-lg font-semibold text-white transition ${
                    submitting || Object.keys(attendance).length === 0
                      ? "bg-gray-400 cursor-not-allowed"
                      : "bg-blue-700 hover:bg-blue-800 hover:shadow-lg"
                  }`}
                >
                  {submitting ? "Saving..." : `💾 Save Attendance`}
                </button>
              </div>
            )}

            {isAttendanceTaken && (
              <div className="p-4 bg-yellow-50 border-t text-center">
                <p className="text-yellow-700 font-medium">
                  ✅ Attendance for {selectedDate} has already been recorded.
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}