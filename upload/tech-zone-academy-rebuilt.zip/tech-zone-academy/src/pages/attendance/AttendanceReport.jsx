// src/pages/AttendanceReport.jsx
import { useEffect, useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { useAttendance } from "../../context/AttendanceContext";
import { db, collection, getDocs, query, orderBy } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";

export default function AttendanceReport() {
  const { user, role } = useAuth();
  const navigate = useNavigate();
  const {
    attendanceData,
    setAttendanceData,
    loading,
    setLoading,
    calculatePercentage,
    getAttendanceStatus,
  } = useAttendance();

  const [viewType, setViewType] = useState("weekly");
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0]);
  const [selectedGrade, setSelectedGrade] = useState("");
  const [selectedSection, setSelectedSection] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("");
  const [grades, setGrades] = useState([]);
  const [sections, setSections] = useState([]);
  const [, setStudents] = useState([]);
  const [displayRecords, setDisplayRecords] = useState([]);
  const [summary, setSummary] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [expandedStudent, setExpandedStudent] = useState(null);

  const fetchAllData = async () => {
    setLoading(true);
    try {
      const snapshot = await getDocs(
        query(collection(db, "attendance"), orderBy("date", "desc"))
      );
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setAttendanceData(data);

      const gradesSnap = await getDocs(collection(db, "grades"));
      const gradesData = gradesSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setGrades(gradesData.sort((a, b) => a.name.localeCompare(b.name)));

      const sectionsSnap = await getDocs(collection(db, "sections"));
      const sectionsData = sectionsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSections(sectionsData.sort((a, b) => a.name.localeCompare(b.name)));

      const studentsSnap = await getDocs(collection(db, "students"));
      const studentsData = studentsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setStudents(studentsData.sort((a, b) => a.firstName.localeCompare(b.firstName)));
    } catch (error) {
      setErrorMessage("Error loading data: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const updateDisplayData = () => {
    let records = [...attendanceData];

    if (viewType === "daily") {
      records = records.filter((a) => a.date === selectedDate);
    } else if (viewType === "weekly") {
      const date = new Date(selectedDate);
      const start = new Date(date);
      start.setDate(date.getDate() - date.getDay());
      const end = new Date(start);
      end.setDate(start.getDate() + 6);
      records = records.filter((a) => {
        const d = new Date(a.date);
        return d >= start && d <= end;
      });
    } else if (viewType === "monthly") {
      const date = new Date(selectedDate);
      records = records.filter((a) => {
        const d = new Date(a.date);
        return d.getMonth() === date.getMonth() && d.getFullYear() === date.getFullYear();
      });
    } else if (viewType === "yearly") {
      const year = new Date(selectedDate).getFullYear();
      records = records.filter((a) => new Date(a.date).getFullYear() === year);
    }

    if (selectedGrade) {
      records = records.filter((r) => r.grade === selectedGrade);
    }
    if (selectedSection) {
      records = records.filter((r) => r.section === selectedSection);
    }
    if (selectedStatus) {
      records = records.filter((r) => r.status === selectedStatus);
    }

    setDisplayRecords(records);

    const total = records.length;
    const present = records.filter((r) => r.status === "Present").length;
    const absent = records.filter((r) => r.status === "Absent").length;
    const late = records.filter((r) => r.status === "Late").length;
    const excused = records.filter((r) => r.status === "Excused").length;
    const percentage = calculatePercentage(present, total);
    const status = getAttendanceStatus(percentage);

    setSummary({ total, present, absent, late, excused, percentage, status });
  };

  useEffect(() => {
    if (user) {
       
      fetchAllData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- fetchAllData is redefined each render; keying on user only avoids a refetch loop
  }, [user]);

  useEffect(() => {
    if (attendanceData.length > 0) {
       
      updateDisplayData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- updateDisplayData is redefined each render; the filter inputs are the real dependencies
  }, [attendanceData, viewType, selectedDate, selectedGrade, selectedSection, selectedStatus]);

  // ✅ Check if user has access (Admin or Vice Principal)
  if (role !== "admin" && role !== "vice_principal") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">🚫</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h2>
          <p className="text-gray-600">You need admin or vice principal privileges to access this page.</p>
          <button
            onClick={() => navigate(role === "vice_principal" ? "/vice-principal/dashboard" : "/admin-dashboard")}
            className="mt-4 bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const getStatusBadge = (status) => {
    const styles = {
      Present: "bg-green-100 text-green-700 border-green-200",
      Absent: "bg-red-100 text-red-700 border-red-200",
      Late: "bg-yellow-100 text-yellow-700 border-yellow-200",
      Excused: "bg-blue-100 text-blue-700 border-blue-200",
    };
    return styles[status] || "bg-gray-100 text-gray-700 border-gray-200";
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case "Present": return "✅";
      case "Absent": return "❌";
      case "Late": return "⏰";
      case "Excused": return "📝";
      default: return "---";
    }
  };

  const getDayName = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", { weekday: "long" });
  };

  const getDateRangeLabel = () => {
    const date = new Date(selectedDate);
    if (viewType === "daily") {
      return date.toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
    } else if (viewType === "weekly") {
      const start = new Date(date);
      start.setDate(date.getDate() - date.getDay());
      const end = new Date(start);
      end.setDate(start.getDate() + 6);
      return `${start.toLocaleDateString()} - ${end.toLocaleDateString()}`;
    } else if (viewType === "monthly") {
      return date.toLocaleDateString("en-US", { month: "long", year: "numeric" });
    } else {
      return date.getFullYear().toString();
    }
  };

  const getGroupedRecords = () => {
    const grouped = {};
    displayRecords.forEach((record) => {
      const key = record.studentId || record.studentName;
      if (!grouped[key]) {
        grouped[key] = {
          studentId: record.studentId,
          studentName: record.studentName,
          grade: record.grade,
          section: record.section,
          records: [],
        };
      }
      grouped[key].records.push(record);
    });
    return Object.values(grouped).sort((a, b) => a.studentName.localeCompare(b.studentName));
  };

  const groupedStudents = getGroupedRecords();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading attendance data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-6 sm:py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <button onClick={() => navigate(-1)} className="text-gray-600 hover:text-gray-800 transition">
            ← Back
          </button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              📊 Attendance Reports
            </h1>
            <p className="text-gray-600 text-sm mt-1">
              {getDateRangeLabel()} • {viewType.charAt(0).toUpperCase() + viewType.slice(1)} View
            </p>
            {role === "vice_principal" && (
              <p className="text-xs text-purple-600 mt-1">
                👔 Vice Principal • Viewing attendance data
              </p>
            )}
          </div>
          <div className="ml-auto">
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${
              role === "admin" ? "bg-blue-100 text-blue-700" : "bg-purple-100 text-purple-700"
            }`}>
              {role === "admin" ? "👔 Principal" : "👔 Vice Principal"}
            </span>
          </div>
        </div>

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Controls */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">View Type</label>
              <select
                value={viewType}
                onChange={(e) => setViewType(e.target.value)}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none bg-white"
              >
                <option value="daily">📅 Daily</option>
                <option value="weekly">📆 Weekly</option>
                <option value="monthly">📊 Monthly</option>
                <option value="yearly">📈 Yearly</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Date</label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Grade</label>
              <select
                value={selectedGrade}
                onChange={(e) => setSelectedGrade(e.target.value)}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none bg-white"
              >
                <option value="">All Grades</option>
                {grades.map((g) => (
                  <option key={g.id} value={g.name}>{g.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Section</label>
              <select
                value={selectedSection}
                onChange={(e) => setSelectedSection(e.target.value)}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none bg-white"
              >
                <option value="">All Sections</option>
                {sections.map((s) => (
                  <option key={s.id} value={s.name}>{s.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Status Filter</label>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none bg-white"
              >
                <option value="">All Statuses</option>
                <option value="Present">✅ Present</option>
                <option value="Absent">❌ Absent</option>
                <option value="Late">⏰ Late</option>
                <option value="Excused">📝 Excused</option>
              </select>
            </div>
          </div>
        </div>

        {/* Summary Cards */}
        {summary && (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 mb-6">
              <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-blue-500">
                <div className="text-xl sm:text-2xl font-bold text-blue-700">{summary.total}</div>
                <div className="text-[10px] sm:text-xs text-gray-600">Total Records</div>
              </div>
              <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-green-500">
                <div className="text-xl sm:text-2xl font-bold text-green-700">{summary.present}</div>
                <div className="text-[10px] sm:text-xs text-gray-600">✅ Present</div>
              </div>
              <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-red-500">
                <div className="text-xl sm:text-2xl font-bold text-red-700">{summary.absent}</div>
                <div className="text-[10px] sm:text-xs text-gray-600">❌ Absent</div>
              </div>
              <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-yellow-500">
                <div className="text-xl sm:text-2xl font-bold text-yellow-700">{summary.late}</div>
                <div className="text-[10px] sm:text-xs text-gray-600">⏰ Late</div>
              </div>
              <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-purple-500">
                <div className="text-xl sm:text-2xl font-bold text-purple-700">{summary.excused}</div>
                <div className="text-[10px] sm:text-xs text-gray-600">📝 Excused</div>
              </div>
              <div className={`bg-white rounded-xl shadow p-4 text-center border-l-4 ${summary.percentage >= 90 ? 'border-green-500' : summary.percentage >= 75 ? 'border-yellow-500' : 'border-red-500'}`}>
                <div className={`text-xl sm:text-2xl font-bold ${summary.percentage >= 90 ? 'text-green-700' : summary.percentage >= 75 ? 'text-yellow-700' : 'text-red-700'}`}>
                  {summary.percentage}%
                </div>
                <div className="text-[10px] sm:text-xs text-gray-600">Attendance Rate</div>
              </div>
            </div>

            {/* Status Card */}
            {summary.total > 0 && (
              <div className="bg-white rounded-xl shadow-md p-4 mb-6 flex items-center gap-3 border-l-4 border-purple-500">
                <div className="text-2xl">{summary.status.icon}</div>
                <div>
                  <div className="font-semibold text-gray-800">Attendance Status</div>
                  <div className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${summary.status.color}`}>
                    {summary.status.label}
                  </div>
                  <span className="text-xs text-gray-500 ml-2">
                    ({summary.present} out of {summary.total} days present)
                  </span>
                </div>
              </div>
            )}
          </>
        )}

        {/* Student Cards - Grouped by Student */}
        {groupedStudents.length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-6xl mb-4">📭</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No Records Found</h3>
            <p className="text-gray-500">No attendance records match the current filters.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {groupedStudents.map((student, index) => {
              const studentRecords = student.records;
              const total = studentRecords.length;
              const present = studentRecords.filter(r => r.status === "Present").length;
              const absent = studentRecords.filter(r => r.status === "Absent").length;
              const late = studentRecords.filter(r => r.status === "Late").length;
              const excused = studentRecords.filter(r => r.status === "Excused").length;
              const percentage = total > 0 ? Math.round((present / total) * 100) : 0;
              const status = getAttendanceStatus(percentage);
              const isExpanded = expandedStudent === student.studentId;

              return (
                <div
                  key={student.studentId || index}
                  className={`bg-white rounded-xl shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg cursor-pointer ${
                    isExpanded ? 'ring-2 ring-blue-500 shadow-xl' : ''
                  }`}
                  onClick={() => setExpandedStudent(isExpanded ? null : student.studentId)}
                >
                  {/* Card Header */}
                  <div className="p-4 border-b bg-gradient-to-r from-gray-50 to-white">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-bold text-sm">
                          {index + 1}
                        </div>
                        <div>
                          <h4 className="font-semibold text-gray-800">
                            {student.studentName}
                          </h4>
                          <div className="flex items-center gap-2 text-xs text-gray-500">
                            <span className="bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">{student.grade}</span>
                            <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Section {student.section}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${status.color}`}>
                          {status.icon} {status.label}
                        </span>
                        <svg
                          className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${
                            isExpanded ? 'rotate-180' : ''
                          }`}
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                      </div>
                    </div>
                  </div>

                  {/* Card Stats */}
                  <div className="grid grid-cols-5 gap-1 p-3 bg-gray-50">
                    <div className="text-center">
                      <div className="text-sm font-bold text-blue-600">{total}</div>
                      <div className="text-[10px] text-gray-500">Total</div>
                    </div>
                    <div className="text-center">
                      <div className="text-sm font-bold text-green-600">{present}</div>
                      <div className="text-[10px] text-gray-500">✅</div>
                    </div>
                    <div className="text-center">
                      <div className="text-sm font-bold text-red-600">{absent}</div>
                      <div className="text-[10px] text-gray-500">❌</div>
                    </div>
                    <div className="text-center">
                      <div className="text-sm font-bold text-yellow-600">{late}</div>
                      <div className="text-[10px] text-gray-500">⏰</div>
                    </div>
                    <div className="text-center">
                      <div className="text-sm font-bold text-purple-600">{excused}</div>
                      <div className="text-[10px] text-gray-500">📝</div>
                    </div>
                  </div>

                  {/* Expanded Content - Shows all records for this student */}
                  {isExpanded && (
                    <div className="p-4 border-t bg-white">
                      <div className="mb-3 flex items-center justify-between">
                        <h5 className="text-sm font-semibold text-gray-700">📋 All Records</h5>
                        <span className="text-xs text-gray-500">
                          {studentRecords.length} records
                        </span>
                      </div>
                      {studentRecords.length === 0 ? (
                        <div className="text-center py-4 text-gray-500 text-sm">
                          No attendance records found.
                        </div>
                      ) : (
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead className="bg-gray-50">
                              <tr>
                                <th className="px-2 py-1 text-left text-xs font-semibold text-gray-600">#</th>
                                <th className="px-2 py-1 text-left text-xs font-semibold text-gray-600">Date</th>
                                <th className="px-2 py-1 text-left text-xs font-semibold text-gray-600">Day</th>
                                <th className="px-2 py-1 text-center text-xs font-semibold text-gray-600">Status</th>
                                <th className="px-2 py-1 text-left text-xs font-semibold text-gray-600">Remark</th>
                              </tr>
                            </thead>
                            <tbody>
                              {studentRecords.map((record, idx) => (
                                <tr key={record.id || idx} className="border-b hover:bg-gray-50">
                                  <td className="px-2 py-1 text-xs text-gray-500">{idx + 1}</td>
                                  <td className="px-2 py-1 text-xs text-gray-600">{record.date}</td>
                                  <td className="px-2 py-1 text-xs text-gray-600">{getDayName(record.date)}</td>
                                  <td className="px-2 py-1 text-center">
                                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusBadge(record.status)}`}>
                                      {getStatusIcon(record.status)} {record.status}
                                    </span>
                                  </td>
                                  <td className="px-2 py-1 text-xs text-gray-500">{record.remark || "---"}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                      <div className="mt-3 pt-2 border-t flex justify-between text-xs text-gray-500">
                        <span>Attendance Rate: <span className={`font-bold ${percentage >= 90 ? 'text-green-600' : percentage >= 75 ? 'text-yellow-600' : 'text-red-600'}`}>
                          {percentage}%
                        </span></span>
                        <span className="flex items-center gap-2">
                          <span className="text-green-600">✅ {present}</span>
                          <span className="text-red-600">❌ {absent}</span>
                          <span className="text-yellow-600">⏰ {late}</span>
                          <span className="text-purple-600">📝 {excused}</span>
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}