import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { db, doc, getDoc, updateDoc, addDoc, deleteDoc, collection, query, where, getDocs } from "../../supabase/supabase";

export default function EditParent() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
  });

  const [searchStudentId, setSearchStudentId] = useState("");
  const [foundStudent, setFoundStudent] = useState(null);
  const [linkedStudents, setLinkedStudents] = useState([]);
  // Snapshot of the students linked when the page loaded, so we only
  // touch the parent_children rows that actually changed on save.
  const [originalLinkedIds, setOriginalLinkedIds] = useState(new Set());
  // parent_children.parentId links to the parent's own `parents` row
  // id, not directly to their users.id/auth uid -- resolve it once and
  // reuse it for every read/write in this page.
  const [parentRowId, setParentRowId] = useState(null);

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phoneRegex = /^(09\d{8}|07\d{8}|\+2519\d{8}|\+2517\d{8})$/;

  const fetchParent = async () => {
    setLoading(true);
    setErrorMessage("");

    try {
      const docRef = doc(db, "users", id);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const data = docSnap.data();
        setFormData({
          name: data.name || "",
          email: data.email || "",
          phone: data.phone || "",
        });

        const parentRowSnapshot = await getDocs(
          query(collection(db, "parents"), where("userId", "==", id))
        );
        if (parentRowSnapshot.empty) {
          setErrorMessage("This parent's account isn't fully set up (no parent record found).");
          setLinkedStudents([]);
          setLoading(false);
          return;
        }
        const resolvedParentRowId = parentRowSnapshot.docs[0].id;
        setParentRowId(resolvedParentRowId);

        const linksSnapshot = await getDocs(
          query(collection(db, "parentChildren"), where("parentId", "==", resolvedParentRowId))
        );
        const linkedIds = linksSnapshot.docs.map((d) => d.data().studentId).filter(Boolean);
        setOriginalLinkedIds(new Set(linkedIds));

        if (linkedIds.length > 0) {
          const studentsSnapshot = await getDocs(
            query(collection(db, "students"), where("id", "in", linkedIds))
          );
          setLinkedStudents(studentsSnapshot.docs.map((d) => ({ id: d.id, ...d.data() })));
        } else {
          setLinkedStudents([]);
        }
      } else {
        setErrorMessage("Parent not found");
        setTimeout(() => navigate("/parent-management"), 2000);
      }
    } catch (error) {
      setErrorMessage("Error loading parent: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchParent();
    // eslint-disable-next-line react-hooks/exhaustive-deps -- fetchParent is a stable local function; only id should retrigger
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const searchStudent = async () => {
    if (!searchStudentId) {
      setErrorMessage("Please enter a Student ID");
      return;
    }

    try {
      const q = query(
        collection(db, "students"),
        where("studentId", "==", searchStudentId.toUpperCase())
      );
      const snapshot = await getDocs(q);

      if (snapshot.empty) {
        setErrorMessage("Student not found!");
        setFoundStudent(null);
        return;
      }

      let student = {};
      snapshot.forEach((doc) => {
        student = { id: doc.id, ...doc.data() };
      });

      if (linkedStudents.find((s) => s.id === student.id)) {
        setErrorMessage("Student already linked!");
        setFoundStudent(null);
        return;
      }

      setFoundStudent(student);
      setErrorMessage("");
    } catch (error) {
      setErrorMessage("Error searching student: " + error.message);
    }
  };

  const linkStudent = () => {
    if (foundStudent) {
      setLinkedStudents([...linkedStudents, foundStudent]);
      setFoundStudent(null);
      setSearchStudentId("");
    }
  };

  const removeStudent = (studentRowId) => {
    setLinkedStudents(linkedStudents.filter((s) => s.id !== studentRowId));
  };

  const validateForm = () => {
    const { name, phone, email } = formData;

    if (!name) {
      setErrorMessage("Parent Name is required");
      return false;
    }
    if (!phone) {
      setErrorMessage("Phone number is required");
      return false;
    }
    if (!phoneRegex.test(phone)) {
      setErrorMessage("Please enter a valid Ethiopian phone number");
      return false;
    }
    if (email && !emailRegex.test(email)) {
      setErrorMessage("Please enter a valid email address");
      return false;
    }
    if (linkedStudents.length === 0) {
      setErrorMessage("Please link at least one student");
      return false;
    }
    return true;
  };

  const updateParent = async () => {
    setSubmitting(true);
    setErrorMessage("");
    setSuccessMessage("");

    if (!validateForm()) {
      setSubmitting(false);
      return;
    }

    try {
      const { name, email, phone } = formData;

      // Check if phone is already used by another parent
      const phoneQuery = query(
        collection(db, "users"),
        where("phone", "==", phone),
        where("role", "==", "parent")
      );
      const phoneSnapshot = await getDocs(phoneQuery);
      let phoneExists = false;
      phoneSnapshot.forEach((doc) => {
        if (doc.id !== id) {
          phoneExists = true;
        }
      });
      if (phoneExists) {
        setErrorMessage("This phone number is already registered to another parent!");
        setSubmitting(false);
        return;
      }

      // Check if email is already used by another parent (if provided)
      if (email) {
        const emailQuery = query(
          collection(db, "users"),
          where("email", "==", email),
          where("role", "==", "parent")
        );
        const emailSnapshot = await getDocs(emailQuery);
        let emailExists = false;
        emailSnapshot.forEach((doc) => {
          if (doc.id !== id) {
            emailExists = true;
          }
        });
        if (emailExists) {
          setErrorMessage("This email is already registered to another parent!");
          setSubmitting(false);
          return;
        }
      }

      const parentRef = doc(db, "users", id);

      await updateDoc(parentRef, {
        name: name,
        email: email || "",
        phone: phone,
      });

      // Sync parent_children links: add newly-linked students, remove
      // ones that were unlinked, leave unchanged ones alone.
      const newLinkedIds = new Set(linkedStudents.map((s) => s.id));
      const toAdd = linkedStudents.filter((s) => !originalLinkedIds.has(s.id));
      const toRemoveIds = [...originalLinkedIds].filter((studentRowId) => !newLinkedIds.has(studentRowId));

      await Promise.all([
        ...toAdd.map((student) =>
          addDoc(collection(db, "parentChildren"), { parentId: parentRowId, studentId: student.id })
        ),
        ...(toRemoveIds.length > 0
          ? [
              getDocs(
                query(collection(db, "parentChildren"), where("parentId", "==", parentRowId), where("studentId", "in", toRemoveIds))
              ).then((snapshot) => Promise.all(snapshot.docs.map((d) => deleteDoc(d.ref)))),
            ]
          : []),
      ]);

      // Keep each currently-linked student's parent contact info up to date
      if (linkedStudents.length > 0) {
        const studentIds = linkedStudents.map((s) => s.id);
        const studentsSnapshot = await getDocs(query(collection(db, "students"), where("id", "in", studentIds)));
        await Promise.all(
          studentsSnapshot.docs.map((studentDoc) =>
            updateDoc(studentDoc.ref, { parentEmail: email || "", parentPhone: phone })
          )
        );
      }

      setSuccessMessage(`✅ Parent ${name} updated successfully!`);
      
      setTimeout(() => {
        navigate("/parent-management");
      }, 1500);

    } catch (error) {
      setErrorMessage("Error updating parent: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setSubmitting(false);
    }
  };

  const isFormValid = 
    formData.name &&
    formData.phone &&
    linkedStudents.length > 0;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading parent data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate(-1)}
              className="text-gray-600 hover:text-gray-800 transition"
            >
              ← Back
            </button>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
                ✏️ Edit Parent
              </h1>
              <p className="text-gray-600 mt-1">
                Update parent information and linked students
              </p>
            </div>
          </div>
        </div>

        {/* Messages */}
        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Form Card */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-6 sm:p-8">
            <div className="grid gap-4">
              {/* Parent Information */}
              <div className="border-b border-gray-200 pb-4 mb-2">
                <h2 className="text-lg font-semibold text-gray-700 mb-3">
                  👤 Parent Information
                </h2>
                <div className="grid sm:grid-cols-2 gap-3">
                  <input
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Full Name *"
                    className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition"
                  />
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="Email Address (Optional)"
                    className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition"
                  />
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="Phone Number (Login) *"
                    className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition"
                  />
                </div>
                <p className="text-xs text-gray-400 mt-1">User can login with either Phone Number or Email</p>
              </div>

              {/* Link Students */}
              <div className="border-b border-gray-200 pb-4 mb-2">
                <h2 className="text-lg font-semibold text-gray-700 mb-3">
                  👨‍🎓 Linked Students
                </h2>
                
                {/* Search Student */}
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    value={searchStudentId}
                    onChange={(e) => setSearchStudentId(e.target.value.toUpperCase())}
                    placeholder="Enter Student ID (e.g., STU001)"
                    className="flex-1 border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition"
                  />
                  <button
                    onClick={searchStudent}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition"
                  >
                    Search
                  </button>
                </div>

                {foundStudent && (
                  <div className="mt-3 bg-green-50 border border-green-200 rounded-lg p-3 flex justify-between items-center">
                    <div>
                      <p className="font-semibold">
                        {foundStudent.firstName} {foundStudent.fatherName}
                      </p>
                      <p className="text-sm text-gray-600">
                        ID: {foundStudent.studentId} | {foundStudent.grade} - Section {foundStudent.section}
                      </p>
                    </div>
                    <button
                      onClick={linkStudent}
                      className="bg-green-600 text-white px-4 py-1 rounded hover:bg-green-700 transition"
                    >
                      Link
                    </button>
                  </div>
                )}

                {/* Linked Students List */}
                {linkedStudents.length > 0 ? (
                  <div className="mt-3">
                    <p className="text-sm font-medium text-gray-700 mb-2">
                      Linked Students ({linkedStudents.length}):
                    </p>
                    <div className="space-y-2">
                      {linkedStudents.map((student) => (
                        <div
                          key={student.id}
                          className="bg-gray-50 border rounded-lg p-3 flex justify-between items-center"
                        >
                          <div>
                            <p className="font-semibold">{student.firstName} {student.fatherName}</p>
                            <p className="text-sm text-gray-600">
                              {student.studentId} | {student.grade} - Section {student.section}
                            </p>
                          </div>
                          <button
                            onClick={() => removeStudent(student.id)}
                            className="text-red-600 hover:text-red-800"
                          >
                            ✕ Remove
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <p className="text-sm text-gray-500 mt-3">No students linked yet.</p>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 mt-4">
                <button
                  onClick={updateParent}
                  disabled={!isFormValid || submitting}
                  className={`flex-1 py-3 rounded-lg font-semibold text-white transition ${
                    isFormValid && !submitting
                      ? "bg-blue-700 hover:bg-blue-800 hover:shadow-lg"
                      : "bg-gray-400 cursor-not-allowed"
                  }`}
                >
                  {submitting ? (
                    <span className="flex items-center justify-center gap-2">
                      <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Updating...
                    </span>
                  ) : (
                    "💾 Update Parent"
                  )}
                </button>
                <button
                  onClick={() => navigate(-1)}
                  className="px-6 py-3 rounded-lg font-semibold text-gray-700 bg-gray-200 hover:bg-gray-300 transition"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}