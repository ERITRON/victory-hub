// src/pages/ParentProfile.jsx
import { useAuth } from "../../context/AuthContext";
import { useEffect, useState } from "react";
import { db, doc, getDoc } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";
import { useParentChildren } from "../../hooks/useParentChildren";
import { studentName } from "../dashboardUtils";

export default function ParentProfile() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [parentData, setParentData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { children, loading: childrenLoading } = useParentChildren(user?.uid);

  useEffect(() => {
    if (user) {
      getDoc(doc(db, "users", user.uid))
        .then((doc) => {
          if (doc.exists()) {
            setParentData(doc.data());
          }
        })
        .catch(console.error)
        .finally(() => setLoading(false));
    }
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading profile...</p>
        </div>
      </div>
    );
  }

  if (!parentData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <p className="text-gray-600">No parent data found.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <button onClick={() => navigate(-1)} className="text-gray-600 hover:text-gray-800 transition">
            ← Back
          </button>
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">👨‍👩‍👦 Parent Profile</h1>
        </div>

        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-green-600 to-green-800 px-6 py-8">
            <div className="flex items-center gap-6">
              <div className="w-24 h-24 rounded-full bg-white/20 flex items-center justify-center text-4xl text-white font-bold border-4 border-white">
                {parentData.name?.charAt(0) || "P"}
              </div>
              <div className="text-white">
                <h2 className="text-2xl font-bold">{parentData.name || "Parent"}</h2>
                <p className="text-green-200">{parentData.email}</p>
                <span className="inline-block bg-green-700 px-3 py-1 rounded-full text-sm font-medium mt-2">
                  👨‍👩‍👦 Parent
                </span>
              </div>
            </div>
          </div>

          <div className="p-6 space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Full Name</p>
                <p className="font-semibold text-gray-800">{parentData.name || "N/A"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Email</p>
                <p className="font-semibold text-gray-800">{parentData.email || "N/A"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Phone</p>
                <p className="font-semibold text-gray-800">{parentData.phone || "Not set"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">Children Linked</p>
                <p className="font-semibold text-gray-800">{childrenLoading ? "…" : children.length}</p>
              </div>
            </div>

            {!childrenLoading && children.length > 0 && (
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-500 mb-2">Children</p>
                <div className="flex flex-wrap gap-2">
                  {children.map((child) => (
                    <span key={child.id} className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm">
                      {studentName(child)} ({child.grade} - {child.section})
                    </span>
                  ))}
                </div>
              </div>
            )}

            <button
              onClick={() => navigate("/profile")}
              className="w-full bg-blue-700 text-white py-3 rounded-lg hover:bg-blue-800 transition font-medium"
            >
              ⚙️ Edit Profile & Security
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}