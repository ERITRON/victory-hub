import { useEffect, useMemo, useState } from "react";
import { collection, doc, getDoc, getDocs } from "../../supabase/supabase";
import { useAuth } from "../../context/AuthContext";
import { db } from "../../supabase/supabase";
import DashboardShell from "../../components/dashboard/DashboardShell";
import { SkeletonDashboard } from "../../components/LoadingSkeleton";
import SEO from "../../components/SEO";
import { useParentChildren } from "../../hooks/useParentChildren";
import {
  assignmentMatchesStudent,
  attendanceSummary,
  firstValue,
  formatPercent,
  isSubmitted,
  resultPercentage,
  sortStudents,
  studentId,
  studentName,
  toDate,
} from "../dashboardUtils";

const snapshotData = (snapshot) => snapshot.docs.map((item) => ({ id: item.id, ...item.data() }));
const matchesStudentId = (record, child) => {
  const identifiers = new Set([String(child.id || ""), studentId(child)]);
  return identifiers.has(String(firstValue(record, ["studentId", "studentID"], "")));
};
const isTodayOrFuture = (value) => {
  const date = toDate(value);
  if (!date) return false;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  date.setHours(0, 0, 0, 0);
  return date >= today;
};
const eventMatchesChildren = (event, children) => {
  const grades = firstValue(event, ["grades", "targetGrades"], null);
  const sections = firstValue(event, ["sections", "targetSections"], null);
  const grade = firstValue(event, ["grade", "targetGrade"], "");
  const section = firstValue(event, ["section", "targetSection"], "");
  const targetedGrades = Array.isArray(grades) ? grades.map(String) : grade ? [String(grade)] : [];
  const targetedSections = Array.isArray(sections) ? sections.map(String) : section ? [String(section)] : [];
  if (!targetedGrades.length && !targetedSections.length) return true;
  return children.some((child) => (!targetedGrades.length || targetedGrades.includes(String(child.grade))) && (!targetedSections.length || targetedSections.includes(String(child.section))));
};

export default function ParentDashboard() {
  const { user } = useAuth();
  const [parent, setParent] = useState(null);
  const [attendance, setAttendance] = useState([]);
  const [results, setResults] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const { children: linkedChildren, loading: childrenLoading, error: childrenError } = useParentChildren(user?.uid);

  useEffect(() => {
    if (!user) return;
    let active = true;
    async function loadDashboard() {
      setLoading(true);
      setError("");
      try {
        const [parentDoc, attendanceSnapshot, resultSnapshot, assignmentSnapshot, submissionSnapshot, eventSnapshot] = await Promise.all([
          getDoc(doc(db, "users", user.uid)),
          getDocs(collection(db, "attendance")),
          getDocs(collection(db, "results")),
          getDocs(collection(db, "teacherAssignmentsUploads")),
          getDocs(collection(db, "assignmentSubmissions")).catch(() => null),
          getDocs(collection(db, "events")).catch(() => null),
        ]);
        if (!active) return;
        setParent(parentDoc.exists() ? { id: parentDoc.id, ...parentDoc.data() } : null);
        setAttendance(snapshotData(attendanceSnapshot));
        setResults(snapshotData(resultSnapshot));
        setAssignments(snapshotData(assignmentSnapshot));
        setSubmissions(submissionSnapshot ? snapshotData(submissionSnapshot) : []);
        setEvents(eventSnapshot ? snapshotData(eventSnapshot) : []);
      } catch (loadError) {
        console.error("Unable to load parent dashboard", loadError);
        if (active) setError("The parent dashboard data could not be loaded. Please try again.");
      } finally {
        if (active) setLoading(false);
      }
    }
    loadDashboard();
    return () => { active = false; };
  }, [user]);

  const children = useMemo(() => sortStudents(linkedChildren), [linkedChildren]);

  const allChildAttendance = useMemo(() => attendance.filter((record) => children.some((child) => matchesStudentId(record, child))), [attendance, children]);
  const allChildResults = useMemo(() => results.filter((record) => children.some((child) => matchesStudentId(record, child))), [children, results]);
  const attendanceTotals = useMemo(() => attendanceSummary(allChildAttendance), [allChildAttendance]);
  const validPercentages = useMemo(() => allChildResults.map(resultPercentage).filter((value) => value !== null), [allChildResults]);
  const averageScore = validPercentages.length ? validPercentages.reduce((sum, value) => sum + value, 0) / validPercentages.length : null;
  const dueAssignments = useMemo(() => assignments.filter((assignment) => isTodayOrFuture(firstValue(assignment, ["dueDate", "deadline"])) && children.some((child) => assignmentMatchesStudent(assignment, child))), [assignments, children]);
  const pendingAssignments = useMemo(() => {
    if (!submissions.length) return null;
    return dueAssignments.reduce((count, assignment) => count + children.filter((child) => assignmentMatchesStudent(assignment, child) && !submissions.some((submission) => isSubmitted(submission, assignment, child))).length, 0);
  }, [children, dueAssignments, submissions]);
  const upcomingEvents = useMemo(() => events.filter((event) => isTodayOrFuture(firstValue(event, ["date", "eventDate", "startDate"])) && eventMatchesChildren(event, children)).length, [children, events]);

  const statCards = [
    { label: "Children", value: children.length, icon: "student", color: "text-blue-700", bgColor: "bg-blue-50", borderColor: "border-blue-200" },
    { label: "Attendance Rate", value: formatPercent(attendanceTotals.rate), icon: "attendance", color: "text-emerald-700", bgColor: "bg-emerald-50", borderColor: "border-emerald-200" },
    { label: "Average Score", value: formatPercent(averageScore), icon: "chart", color: "text-violet-700", bgColor: "bg-violet-50", borderColor: "border-violet-200" },
    { label: "Homework Due", value: dueAssignments.length, icon: "assignment", color: "text-amber-700", bgColor: "bg-amber-50", borderColor: "border-amber-200" },
    { label: "Total Results", value: allChildResults.length, icon: "result", color: "text-indigo-700", bgColor: "bg-indigo-50", borderColor: "border-indigo-200" },
    { label: "Pending Assignments", value: pendingAssignments === null ? "Not tracked" : pendingAssignments, icon: "pending", color: "text-orange-700", bgColor: "bg-orange-50", borderColor: "border-orange-200" },
    { label: "Upcoming Events", value: upcomingEvents, icon: "calendar", color: "text-rose-700", bgColor: "bg-rose-50", borderColor: "border-rose-200" },
  ];

  const dashboardItems = [
    { icon: "parent", title: "My Profile", description: "View parent account information", route: "/parent-profile", color: "bg-emerald-50 hover:bg-emerald-100 border-emerald-200", iconColor: "text-emerald-700" },
    { icon: "student", title: "My Children", description: `${children.length} linked student${children.length === 1 ? "" : "s"}`, route: "/parent-children", color: "bg-blue-50 hover:bg-blue-100 border-blue-200", iconColor: "text-blue-700" },
    { icon: "result", title: "Results", description: `${allChildResults.length} recorded result${allChildResults.length === 1 ? "" : "s"}`, route: "/parent-results", color: "bg-violet-50 hover:bg-violet-100 border-violet-200", iconColor: "text-violet-700" },
    { icon: "attendance", title: "Attendance", description: `${attendanceTotals.total} attendance record${attendanceTotals.total === 1 ? "" : "s"}`, route: "/parent-attendance", color: "bg-amber-50 hover:bg-amber-100 border-amber-200", iconColor: "text-amber-700" },
    { icon: "calendar", title: "Schedule", description: "View class schedules", route: "/parent-schedule", color: "bg-rose-50 hover:bg-rose-100 border-rose-200", iconColor: "text-rose-700" },
    { icon: "download", title: "Documents", description: "Report cards, certificates, and files", route: "/my-documents", color: "bg-indigo-50 hover:bg-indigo-100 border-indigo-200", iconColor: "text-indigo-700" },
    { icon: "message", title: "Messages", description: "Message your child's homeroom teacher", route: "/chat", color: "bg-teal-50 hover:bg-teal-100 border-teal-200", iconColor: "text-teal-700" },
    { icon: "settings", title: "Security Settings", description: "Update password and security", route: "/profile", color: "bg-slate-50 hover:bg-slate-100 border-slate-200", iconColor: "text-slate-700" },
  ];

  if (loading || childrenLoading) return <div className="min-h-screen bg-slate-50 px-4 py-8"><div className="mx-auto max-w-7xl"><SkeletonDashboard /></div></div>;
  if (!parent) return <main className="flex min-h-screen items-center justify-center bg-slate-50 px-4"><div className="rounded-xl border border-slate-200 bg-white p-10 text-center text-slate-600">No parent profile was found for this account.</div></main>;

  return <>
    <SEO title="Parent Dashboard" noindex />
    <DashboardShell icon="dashboard" title="Parent Dashboard" welcomeName={parent.name || parent.email || "Parent"} subtitle={parent.email || ""} badgeLabel="Parent" badgeColor="bg-emerald-100 text-emerald-700" stats={statCards} statsColumns="grid-cols-2 md:grid-cols-4" menuItems={dashboardItems} footerText="Tech Zone Academy - Parent Dashboard">
      {(error || childrenError) && <div className="mb-6 rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">{error || childrenError}</div>}
    </DashboardShell>
  </>;
}
