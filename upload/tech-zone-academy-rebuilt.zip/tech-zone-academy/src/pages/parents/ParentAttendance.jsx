// src/pages/ParentAttendance.jsx
import { useAuth } from "../../context/AuthContext";
import { useEffect, useState } from "react";
import { useAttendance } from "../../context/AttendanceContext";
import { db, doc, getDoc, collection, getDocs } from "../../supabase/supabase";
import { useNavigate } from "react-router-dom";

export default function ParentAttendance() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const {
    attendanceData,
    setAttendanceData,
    loading,
    setLoading,
    getAttendanceStatus,
  } = useAttendance();

  const [parentData, setParentData] = useState(null);
  const [selectedChild, setSelectedChild] = useState(null);
  const [childAttendance, setChildAttendance] = useState([]);
  const [summary, setSummary] = useState(null);
  const [viewType, setViewType] = useState("weekly");
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0]);
  const [errorMessage, setErrorMessage] = useState("");
  const [childStudents, setChildStudents] = useState([]);

  const fetchParentData = async () => {
    setLoading(true);
    try {
      // Fetch parent user data
      const parentDoc = await getDoc(doc(db, "users", user.uid));
      if (parentDoc.exists()) {
        const data = parentDoc.data();
        setParentData(data);

        // Fetch all students to find children
        const studentsSnap = await getDocs(collection(db, "students"));
        const allStudents = studentsSnap.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));

        // Find children based on parentId or parentEmail
        const children = allStudents.filter(
          (s) => s.parentId === user.uid || s.parentEmail === user.email
        );

        setChildStudents(children);

        // Fetch attendance data if not already loaded
        if (attendanceData.length === 0) {
          const attSnap = await getDocs(collection(db, "attendance"));
          const attData = attSnap.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          }));
          setAttendanceData(attData);
        }

        // Auto-select first child if available
        if (children.length > 0) {
          setSelectedChild(children[0]);
        }
      } else {
        setErrorMessage("Parent data not found.");
      }
    } catch (error) {
      setErrorMessage("Error loading data: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const updateChildData = () => {
    if (!selectedChild) return;

    let records = attendanceData.filter(
      (a) => a.studentId === (selectedChild.studentId || selectedChild.id)
    );

    // Apply view type filters
    if (viewType === "daily") {
      records = records.filter((a) => a.date === selectedDate);
    } else if (viewType === "weekly") {
      const date = new Date(selectedDate);
      const start = new Date(date);
      start.setDate(date.getDate() - date.getDay());
      const end = new Date(start);
      end.setDate(start.getDate() + 6);
      records = records.filter((a) => {
        const d = new Date(a.date);
        return d >= start && d <= end;
      });
    } else if (viewType === "monthly") {
      const date = new Date(selectedDate);
      records = records.filter((a) => {
        const d = new Date(a.date);
        return d.getMonth() === date.getMonth() && d.getFullYear() === date.getFullYear();
      });
    } else if (viewType === "yearly") {
      const year = new Date(selectedDate).getFullYear();
      records = records.filter((a) => new Date(a.date).getFullYear() === year);
    }

    // Sort by date (newest first)
    records = records.sort((a, b) => new Date(b.date) - new Date(a.date));

    setChildAttendance(records);

    // Calculate summary
    const total = records.length;
    const present = records.filter((a) => a.status === "Present").length;
    const absent = records.filter((a) => a.status === "Absent").length;
    const late = records.filter((a) => a.status === "Late").length;
    const excused = records.filter((a) => a.status === "Excused").length;
    const percentage = total > 0 ? Math.round((present / total) * 100) : 0;
    const status = getAttendanceStatus(percentage);

    setSummary({ total, present, absent, late, excused, percentage, status });
  };

  useEffect(() => {
    if (user) {
      fetchParentData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- fetchParentData is a stable local function; only user should retrigger
  }, [user]);

  useEffect(() => {
    if (selectedChild) {
      updateChildData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- updateChildData is a stable local function; retrigger only on the listed data
  }, [attendanceData, selectedChild, viewType, selectedDate]);

  const getStatusBadge = (status) => {
    const styles = {
      Present: "bg-green-100 text-green-700 border-green-200",
      Absent: "bg-red-100 text-red-700 border-red-200",
      Late: "bg-yellow-100 text-yellow-700 border-yellow-200",
      Excused: "bg-blue-100 text-blue-700 border-blue-200",
    };
    return styles[status] || "bg-gray-100 text-gray-700 border-gray-200";
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case "Present": return "✅";
      case "Absent": return "❌";
      case "Late": return "⏰";
      case "Excused": return "📝";
      default: return "—";
    }
  };

  const getDayName = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", { weekday: "long" });
  };

  const getDateRangeLabel = () => {
    const date = new Date(selectedDate);
    if (viewType === "daily") {
      return date.toLocaleDateString("en-US", { 
        weekday: "long", 
        year: "numeric", 
        month: "long", 
        day: "numeric" 
      });
    } else if (viewType === "weekly") {
      const start = new Date(date);
      start.setDate(date.getDate() - date.getDay());
      const end = new Date(start);
      end.setDate(start.getDate() + 6);
      return `${start.toLocaleDateString()} - ${end.toLocaleDateString()}`;
    } else if (viewType === "monthly") {
      return date.toLocaleDateString("en-US", { month: "long", year: "numeric" });
    } else {
      return date.getFullYear().toString();
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading your child's attendance...</p>
        </div>
      </div>
    );
  }

  if (!parentData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">📭</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">No Parent Data</h2>
          <p className="text-gray-600">Please contact the school administrator.</p>
          <button
            onClick={() => navigate("/parent-dashboard")}
            className="mt-4 bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  if (childStudents.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">👶</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">No Children Linked</h2>
          <p className="text-gray-600">No children are linked to your account. Please contact the school administrator.</p>
          <button
            onClick={() => navigate("/parent-dashboard")}
            className="mt-4 bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-6 sm:py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <button 
            onClick={() => navigate("/parent-dashboard")} 
            className="text-gray-600 hover:text-gray-800 transition"
          >
            ← Back
          </button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              👨‍👩‍👧 Child Attendance
            </h1>
            <p className="text-gray-600 text-sm mt-1">
              {selectedChild ? (
                `${selectedChild.firstName} ${selectedChild.fatherName}`
              ) : (
                "Select a child"
              )}
            </p>
          </div>
          <div className="ml-auto">
            <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
              👪 Parent
            </span>
          </div>
        </div>

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Child Selector */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <label className="block text-sm font-semibold text-gray-700 mb-3">
            👤 Select Child
          </label>
          <div className="flex flex-wrap gap-2">
            {childStudents.map((child) => (
              <button
                key={child.id}
                onClick={() => setSelectedChild(child)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                  selectedChild?.id === child.id
                    ? "bg-blue-700 text-white shadow-md"
                    : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                }`}
              >
                {child.firstName} {child.fatherName}
                <span className="text-xs ml-1 opacity-70">
                  ({child.grade || "N/A"} - {child.section || "N/A"})
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Controls */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">View Type</label>
              <select
                value={viewType}
                onChange={(e) => setViewType(e.target.value)}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none bg-white"
              >
                <option value="daily">📅 Daily</option>
                <option value="weekly">📆 Weekly</option>
                <option value="monthly">📊 Monthly</option>
                <option value="yearly">📈 Yearly</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Date</label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full border rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Child Info */}
        {selectedChild && (
          <div className="bg-white rounded-xl shadow-md p-4 mb-6">
            <div className="flex flex-wrap gap-2">
              <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
                📚 {selectedChild.grade || "No Grade"}
              </span>
              <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                📋 Section {selectedChild.section || "N/A"}
              </span>
              <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-medium">
                🆔 {selectedChild.studentId || selectedChild.id}
              </span>
              <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium">
                📅 {getDateRangeLabel()}
              </span>
            </div>
          </div>
        )}

        {/* Summary Cards */}
        {summary && selectedChild && summary.total > 0 && (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 mb-6">
              <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-blue-500">
                <div className="text-xl sm:text-2xl font-bold text-blue-700">{summary.total}</div>
                <div className="text-[10px] sm:text-xs text-gray-600">Total Days</div>
              </div>
              <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-green-500">
                <div className="text-xl sm:text-2xl font-bold text-green-700">{summary.present}</div>
                <div className="text-[10px] sm:text-xs text-gray-600">✅ Present</div>
              </div>
              <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-red-500">
                <div className="text-xl sm:text-2xl font-bold text-red-700">{summary.absent}</div>
                <div className="text-[10px] sm:text-xs text-gray-600">❌ Absent</div>
              </div>
              <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-yellow-500">
                <div className="text-xl sm:text-2xl font-bold text-yellow-700">{summary.late}</div>
                <div className="text-[10px] sm:text-xs text-gray-600">⏰ Late</div>
              </div>
              <div className="bg-white rounded-xl shadow p-4 text-center border-l-4 border-purple-500">
                <div className="text-xl sm:text-2xl font-bold text-purple-700">{summary.excused}</div>
                <div className="text-[10px] sm:text-xs text-gray-600">📝 Excused</div>
              </div>
              <div className={`bg-white rounded-xl shadow p-4 text-center border-l-4 ${summary.percentage >= 90 ? 'border-green-500' : summary.percentage >= 75 ? 'border-yellow-500' : 'border-red-500'}`}>
                <div className={`text-xl sm:text-2xl font-bold ${summary.percentage >= 90 ? 'text-green-700' : summary.percentage >= 75 ? 'text-yellow-700' : 'text-red-700'}`}>
                  {summary.percentage}%
                </div>
                <div className="text-[10px] sm:text-xs text-gray-600">Attendance Rate</div>
              </div>
            </div>

            {/* Status Card */}
            <div className="bg-white rounded-xl shadow-md p-4 mb-6 flex items-center gap-3 border-l-4 border-purple-500">
              <div className="text-2xl">{summary.status.icon}</div>
              <div>
                <div className="font-semibold text-gray-800">Attendance Status</div>
                <div className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${summary.status.color}`}>
                  {summary.status.label}
                </div>
                <span className="text-xs text-gray-500 ml-2">
                  ({summary.present} out of {summary.total} days present)
                </span>
              </div>
            </div>
          </>
        )}

        {/* Records Table */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="px-4 sm:px-6 py-3 border-b bg-gray-50 flex justify-between items-center">
            <h3 className="text-sm font-semibold text-gray-800">
              📋 Attendance Records ({childAttendance.length})
            </h3>
            <span className="text-xs text-gray-500">
              {viewType.charAt(0).toUpperCase() + viewType.slice(1)} View
            </span>
          </div>
          {childAttendance.length === 0 ? (
            <div className="p-12 text-center">
              <div className="text-6xl mb-4">📭</div>
              <h3 className="text-xl font-semibold text-gray-700 mb-2">No Records Found</h3>
              <p className="text-gray-500">
                No attendance records found for this period.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-3 sm:px-4 py-2 text-left text-xs font-semibold text-gray-600">#</th>
                    <th className="px-3 sm:px-4 py-2 text-left text-xs font-semibold text-gray-600">Date</th>
                    <th className="px-3 sm:px-4 py-2 text-left text-xs font-semibold text-gray-600">Day</th>
                    <th className="px-3 sm:px-4 py-2 text-center text-xs font-semibold text-gray-600">Status</th>
                    <th className="px-3 sm:px-4 py-2 text-left text-xs font-semibold text-gray-600">Remark</th>
                  </tr>
                </thead>
                <tbody>
                  {childAttendance.map((record, index) => (
                    <tr key={record.id || index} className="border-b hover:bg-gray-50 transition">
                      <td className="px-3 sm:px-4 py-2 text-sm text-gray-500">{index + 1}</td>
                      <td className="px-3 sm:px-4 py-2 text-sm text-gray-600">{record.date}</td>
                      <td className="px-3 sm:px-4 py-2 text-sm text-gray-600">
                        {record.day || getDayName(record.date)}
                      </td>
                      <td className="px-3 sm:px-4 py-2 text-center">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusBadge(record.status)}`}>
                          {getStatusIcon(record.status)} {record.status}
                        </span>
                      </td>
                      <td className="px-3 sm:px-4 py-2 text-sm text-gray-500">{record.remark || "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}