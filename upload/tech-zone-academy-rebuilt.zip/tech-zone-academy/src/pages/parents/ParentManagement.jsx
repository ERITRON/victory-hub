// src/pages/ParentManagement.jsx
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { db, collection, getDocs } from "../../supabase/supabase";
import { deleteAccount } from "../../services/adminService";

export default function ParentManagement() {
  const [parents, setParents] = useState([]);
  const [childCounts, setChildCounts] = useState({});
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const navigate = useNavigate();

  const fetchParents = async () => {
    setLoading(true);
    setErrorMessage("");
    try {
      const [usersSnapshot, linksSnapshot] = await Promise.all([
        getDocs(collection(db, "users")),
        getDocs(collection(db, "parentChildren")),
      ]);
      const data = usersSnapshot.docs
        .map((doc) => ({ id: doc.id, ...doc.data() }))
        .filter((user) => user.role === "parent");
      setParents(data);

      const counts = {};
      linksSnapshot.docs.forEach((linkDoc) => {
        const { parentId } = linkDoc.data();
        if (!parentId) return;
        counts[parentId] = (counts[parentId] || 0) + 1;
      });
      setChildCounts(counts);
    } catch (error) {
      setErrorMessage("Error loading parents: " + error.message);
      setTimeout(() => setErrorMessage(""), 3000);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchParents();
     
  }, []);

  const deleteParent = async (id, name) => {
    if (!window.confirm(`Delete parent ${name}? This action cannot be undone.`)) return;
    try {
      await deleteAccount(id, "parent");
      setParents(parents.filter((p) => p.id !== id));
      setSuccessMessage(`✅ Parent ${name} deleted successfully!`);
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setErrorMessage(`❌ ${error.message}`);
      setTimeout(() => setErrorMessage(""), 4000);
    }
  };

  const filteredParents = parents.filter((parent) => {
    const search = searchTerm.toLowerCase();
    return (
      parent.name?.toLowerCase().includes(search) ||
      parent.email?.toLowerCase().includes(search) ||
      parent.phone?.includes(search)
    );
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading parents...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              👨‍👩‍👦 Parent Management
            </h1>
            <p className="text-gray-600 mt-1">Manage parent accounts and their children</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={fetchParents}
              className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition text-sm flex items-center gap-2"
            >
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
                <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h3.992v3.992m0-3.992-6.3 6.3a2.25 2.25 0 01-3.182 0l-3.7-3.7a2.25 2.25 0 010-3.182l6.3-6.3a2.25 2.25 0 013.182 0l3.7 3.7z" />
              </svg>
              Refresh
            </button>
            <button
              onClick={() => navigate("/add-parent")}
              className="bg-blue-700 text-white px-4 py-2 rounded-lg hover:bg-blue-800 transition text-sm flex items-center gap-2"
            >
              <span className="text-lg">+</span> Add Parent
            </button>
          </div>
        </div>

        {/* Messages */}
        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4">
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        {/* Search */}
        <div className="bg-white rounded-xl shadow-md p-4 sm:p-6 mb-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Search Parents
              </label>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by name, email, or phone..."
                className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition"
              />
            </div>
            {searchTerm && (
              <div className="flex items-end">
                <button
                  onClick={() => setSearchTerm("")}
                  className="bg-gray-200 text-gray-700 px-4 py-2.5 rounded-lg hover:bg-gray-300 transition font-medium"
                >
                  Clear
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Stats */}
        <div className="flex flex-wrap gap-4 mb-6">
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Total Parents:</span>
            <span className="ml-2 font-bold text-blue-700">{parents.length}</span>
          </div>
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Filtered:</span>
            <span className="ml-2 font-bold text-green-700">{filteredParents.length}</span>
          </div>
          <div className="bg-white rounded-lg shadow px-4 py-2">
            <span className="text-sm text-gray-600">Total Children:</span>
            <span className="ml-2 font-bold text-purple-700">
              {Object.values(childCounts).reduce((sum, count) => sum + count, 0)}
            </span>
          </div>
        </div>

        {/* Parents Table */}
        {filteredParents.length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-6xl mb-4">📭</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              {parents.length === 0 ? "No Parents Found" : "No Parents Match"}
            </h3>
            <p className="text-gray-500">
              {parents.length === 0 
                ? "No parent accounts have been created yet." 
                : "No parents match your search criteria."}
            </p>
            {parents.length === 0 && (
              <button
                onClick={() => navigate("/add-parent")}
                className="mt-4 bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition"
              >
                + Create First Parent
              </button>
            )}
          </div>
        ) : (
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">#</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Name</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Email</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Phone</th>
                    <th className="px-4 py-3 text-center text-sm font-semibold text-gray-600">Children</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Status</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredParents.map((parent, index) => (
                    <tr key={parent.id} className="border-b hover:bg-gray-50 transition">
                      <td className="px-4 py-3 text-sm text-gray-500">{index + 1}</td>
                      <td className="px-4 py-3 font-medium text-gray-800">{parent.name}</td>
                      <td className="px-4 py-3 text-sm text-gray-600">{parent.email || "—"}</td>
                      <td className="px-4 py-3 text-sm text-gray-600">{parent.phone || "—"}</td>
                      <td className="px-4 py-3 text-center text-sm text-gray-600">
                        {childCounts[parent.id] || 0}
                      </td>
                      <td className="px-4 py-3">
                        <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs font-medium">
                          Active
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-1">
                          <button
                            onClick={() => navigate(`/edit-parent/${parent.id}`)}
                            className="bg-yellow-500 text-white px-3 py-1 rounded text-xs hover:bg-yellow-600 transition"
                          >
                            ✏️ Edit
                          </button>
                          <button
                            onClick={() => deleteParent(parent.id, parent.name)}
                            className="bg-red-600 text-white px-3 py-1 rounded text-xs hover:bg-red-700 transition"
                          >
                            🗑️ Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}