import { useEffect, useMemo, useState } from "react";
import { collection, getDocs } from "../../supabase/supabase";
import { Link } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { db } from "../../supabase/supabase";
import Icon from "../../components/Icon";
import SEO from "../../components/SEO";
import { useParentChildren } from "../../hooks/useParentChildren";
import { firstValue, formatPercent, resultPercentage, sortStudents, studentId, studentName } from "../dashboardUtils";

const snapshotData = (snapshot) => snapshot.docs.map((item) => ({ id: item.id, ...item.data() }));

const matchesStudent = (result, child) => {
  const identifiers = new Set([String(child.id || ""), studentId(child)]);
  return identifiers.has(String(firstValue(result, ["studentId", "studentID"], "")));
};

export default function ParentResults() {
  const { user } = useAuth();
  const { children: linkedChildren, loading: childrenLoading, error: childrenError } = useParentChildren(user?.uid);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!user) return;
    let active = true;

    getDocs(collection(db, "results")).then((resultSnapshot) => {
      if (!active) return;
      setResults(snapshotData(resultSnapshot));
    }).catch((loadError) => {
      console.error("Unable to load parent results", loadError);
      if (active) setError("Results could not be loaded. Please try again.");
    }).finally(() => {
      if (active) setLoading(false);
    });

    return () => { active = false; };
  }, [user]);

  const children = useMemo(() => sortStudents(linkedChildren), [linkedChildren]);

  const resultCards = useMemo(() => children.map((child) => {
    const childResults = results.filter((result) => matchesStudent(result, child));
    const scores = childResults.map(resultPercentage).filter((value) => value !== null);
    const subjects = new Set(childResults.map((result) => result.subject).filter(Boolean));
    return {
      child,
      resultCount: childResults.length,
      subjectCount: subjects.size,
      average: scores.length ? scores.reduce((sum, value) => sum + value, 0) / scores.length : null,
    };
  }), [children, results]);

  return (
    <main className="min-h-screen bg-gray-50 px-4 py-6 sm:px-6 sm:py-8 lg:px-8">
      <SEO title="Children Results" noindex />
      <div className="mx-auto max-w-7xl">
        <header className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="flex items-center gap-3 text-2xl font-bold text-gray-800 sm:text-3xl"><Icon name="result" className="text-violet-700" />Results</h1>
            <p className="mt-1 text-sm text-gray-500">Select a child to view complete subject and assessment results.</p>
          </div>
          <Link to="/parent-dashboard" className="inline-flex items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-100"><Icon name="dashboard" />Dashboard</Link>
        </header>

        {(error || childrenError) && <div className="mb-6 rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">{error || childrenError}</div>}
        {(loading || childrenLoading) ? <div className="rounded-lg border border-gray-200 bg-white p-12 text-center text-gray-500">Loading results...</div> : !resultCards.length ? <div className="rounded-lg border border-gray-200 bg-white p-12 text-center text-gray-500">No children are linked to this parent account.</div> : (
          <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
            {resultCards.map(({ child, resultCount, subjectCount, average }) => (
              <article key={studentId(child) || child.id} className="rounded-lg border border-violet-200 bg-violet-50 p-5 shadow-sm transition hover:bg-violet-100 hover:shadow-md">
                <p className="text-xs font-semibold uppercase text-violet-700">{studentId(child) || "Student ID not set"}</p>
                <h2 className="mt-1 text-xl font-bold text-gray-800">{studentName(child)}</h2>
                <p className="mt-1 text-sm text-gray-600">{child.grade || "Grade not set"} / Section {child.section || "not set"}</p>
                <div className="mt-5 grid grid-cols-3 gap-2 border-y border-violet-200 py-4 text-center">
                  <div><p className="font-bold text-gray-900">{resultCount}</p><p className="text-xs text-gray-600">Results</p></div>
                  <div><p className="font-bold text-gray-900">{subjectCount}</p><p className="text-xs text-gray-600">Subjects</p></div>
                  <div><p className="font-bold text-gray-900">{formatPercent(average)}</p><p className="text-xs text-gray-600">Average</p></div>
                </div>
                <Link to={`/parent-results/${encodeURIComponent(studentId(child))}`} className="mt-4 block rounded-lg bg-violet-700 px-4 py-2.5 text-center text-sm font-semibold text-white hover:bg-violet-800">View Full Results</Link>
              </article>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
