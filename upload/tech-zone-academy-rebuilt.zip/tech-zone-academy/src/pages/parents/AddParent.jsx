// src/pages/AddParent.jsx
import { useState } from "react";
import { db } from "../../supabase/supabase";
import { collection, query, where, getDocs } from "../../supabase/supabase";
import { createParent } from "../../services/adminService";

export default function AddParent() {
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
  });

  const [searchStudentId, setSearchStudentId] = useState("");
  const [foundStudent, setFoundStudent] = useState(null);
  const [linkedStudents, setLinkedStudents] = useState([]);

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phoneRegex = /^(09\d{8}|07\d{8}|\+2519\d{8}|\+2517\d{8})$/;

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const searchStudent = async () => {
    if (!searchStudentId) {
      setErrorMessage("Please enter a Student ID");
      return;
    }

    try {
      const q = query(
        collection(db, "students"),
        where("studentId", "==", searchStudentId.toUpperCase())
      );
      const snapshot = await getDocs(q);

      if (snapshot.empty) {
        setErrorMessage("Student not found!");
        setFoundStudent(null);
        return;
      }

      let student = {};
      snapshot.forEach((doc) => {
        student = { id: doc.id, ...doc.data() };
      });

      if (linkedStudents.find((s) => s.id === student.id)) {
        setErrorMessage("Student already linked!");
        setFoundStudent(null);
        return;
      }

      setFoundStudent(student);
      setErrorMessage("");
    } catch (error) {
      setErrorMessage("Error searching student: " + error.message);
    }
  };

  const linkStudent = () => {
    if (foundStudent) {
      setLinkedStudents([...linkedStudents, foundStudent]);
      setFoundStudent(null);
      setSearchStudentId("");
    }
  };

  const removeStudent = (studentRowId) => {
    setLinkedStudents(linkedStudents.filter((s) => s.id !== studentRowId));
  };

  const validateForm = () => {
    const { name, email, phone, password, confirmPassword } = formData;

    if (!name) {
      setErrorMessage("Parent Name is required");
      return false;
    }
    if (email && !emailRegex.test(email)) {
      setErrorMessage("Please enter a valid email address");
      return false;
    }
    if (!phone) {
      setErrorMessage("Phone number is required");
      return false;
    }
    if (!phoneRegex.test(phone)) {
      setErrorMessage("Please enter a valid Ethiopian phone number");
      return false;
    }
    if (!password) {
      setErrorMessage("Password is required");
      return false;
    }
    if (password.length < 6) {
      setErrorMessage("Password must be at least 6 characters");
      return false;
    }
    if (password !== confirmPassword) {
      setErrorMessage("Passwords do not match");
      return false;
    }
    if (linkedStudents.length === 0) {
      setErrorMessage("Please link at least one student");
      return false;
    }
    return true;
  };

  const addParent = async () => {
    setLoading(true);
    setErrorMessage("");
    setSuccessMessage("");

    if (!validateForm()) {
      setLoading(false);
      return;
    }

    try {
      const { name, email, phone, password } = formData;

      // Account creation happens server-side (Supabase Edge Function,
      // service role) so the admin's own session is never touched and
      // no admin password needs to live in the browser. It also links
      // the parent to each student through the real parents/
      // parent_children tables, rather than storing an ad-hoc list on
      // the user record.
      const result = await createParent({
        name,
        email,
        phone,
        password,
        studentIds: linkedStudents.map((s) => s.studentId),
      });

      setSuccessMessage(
        `✅ Parent Created Successfully!\n\n` +
        `Name: ${name}\n` +
        `Email: ${result.email}\n` +
        `Phone: ${phone}\n` +
        `Password: ${password}\n` +
        `Linked Students: ${result.linkedStudents.join(", ")}\n\n` +
        `📌 Login with Email: ${result.email}\n` +
        `📌 Login with Phone: ${phone}`
      );

      setFormData({
        name: "",
        email: "",
        phone: "",
        password: "",
        confirmPassword: "",
      });
      setLinkedStudents([]);
      setSearchStudentId("");
      setFoundStudent(null);

      setTimeout(() => setSuccessMessage(""), 8000);

    } catch (error) {
      setErrorMessage(`❌ ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const isFormValid =
    formData.name &&
    formData.phone &&
    formData.password &&
    formData.password === formData.confirmPassword &&
    linkedStudents.length > 0;

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">👨‍👩‍👦 Add Parent</h1>
          <p className="text-gray-600 mt-1">Email is optional - can login with phone number</p>
        </div>

        {successMessage && (
          <div className="bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4 whitespace-pre-line">
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4">
            {errorMessage}
          </div>
        )}

        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-6 sm:p-8">
            <div className="grid gap-4">
              <div className="border-b border-gray-200 pb-4 mb-2">
                <h2 className="text-lg font-semibold text-gray-700 mb-3">👤 Parent Information</h2>
                <div className="grid sm:grid-cols-2 gap-3">
                  <input name="name" value={formData.name} onChange={handleChange} placeholder="Full Name *" className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition" />
                  <input type="email" name="email" value={formData.email} onChange={handleChange} placeholder="Email Address (Optional)" className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition" />
                  <input type="tel" name="phone" value={formData.phone} onChange={handleChange} placeholder="Phone Number (Login) *" className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition" />
                </div>
                <p className="text-xs text-gray-400 mt-1">User can login with either Phone Number or Email</p>
              </div>

              <div className="border-b border-gray-200 pb-4 mb-2">
                <h2 className="text-lg font-semibold text-gray-700 mb-3">👨‍🎓 Link Students</h2>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input type="text" value={searchStudentId} onChange={(e) => setSearchStudentId(e.target.value.toUpperCase())} placeholder="Enter Student ID (e.g., STU001)" className="flex-1 border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition" />
                  <button onClick={searchStudent} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition">Search</button>
                </div>

                {foundStudent && (
                  <div className="mt-3 bg-green-50 border border-green-200 rounded-lg p-3 flex justify-between items-center">
                    <div>
                      <p className="font-semibold">{foundStudent.firstName} {foundStudent.fatherName}</p>
                      <p className="text-sm text-gray-600">ID: {foundStudent.studentId} | {foundStudent.grade} - Section {foundStudent.section}</p>
                    </div>
                    <button onClick={linkStudent} className="bg-green-600 text-white px-4 py-1 rounded hover:bg-green-700 transition">Link</button>
                  </div>
                )}

                {linkedStudents.length > 0 && (
                  <div className="mt-3">
                    <p className="text-sm font-medium text-gray-700 mb-2">Linked Students ({linkedStudents.length}):</p>
                    <div className="space-y-2">
                      {linkedStudents.map((student) => (
                        <div key={student.id} className="bg-gray-50 border rounded-lg p-3 flex justify-between items-center">
                          <div>
                            <p className="font-semibold">{student.firstName} {student.fatherName}</p>
                            <p className="text-sm text-gray-600">{student.studentId} | {student.grade} - Section {student.section}</p>
                          </div>
                          <button onClick={() => removeStudent(student.id)} className="text-red-600 hover:text-red-800">✕ Remove</button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="pb-2">
                <h2 className="text-lg font-semibold text-gray-700 mb-3">🔐 Login Credentials</h2>
                <div className="grid gap-3">
                  <div className="relative">
                    <input type={showPassword ? "text" : "password"} name="password" value={formData.password} onChange={handleChange} placeholder="Password (min 6 chars) *" className="border rounded-lg p-3 w-full focus:ring-2 focus:ring-blue-500 outline-none transition pr-12" minLength="6" />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700">
                      {showPassword ? "🙈" : "👁️"}
                    </button>
                  </div>
                  <input type={showPassword ? "text" : "password"} name="confirmPassword" value={formData.confirmPassword} onChange={handleChange} placeholder="Confirm Password *" className="border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition" />
                </div>
                <p className="text-xs text-gray-400 mt-2">🔑 Login with: <strong>Phone Number</strong> or <strong>Email</strong></p>
              </div>

              <button onClick={addParent} disabled={!isFormValid || loading} className={`w-full py-4 rounded-lg font-semibold text-white transition ${isFormValid && !loading ? "bg-blue-700 hover:bg-blue-800 hover:shadow-lg" : "bg-gray-400 cursor-not-allowed"}`}>
                {loading ? "Creating Parent Account..." : "Create Parent Account"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}