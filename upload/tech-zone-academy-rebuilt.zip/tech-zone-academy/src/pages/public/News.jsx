// src/pages/News.jsx
import { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { useWebsiteSettings } from "../../context/WebsiteSettingsContext";
import { db, collection, getDocs, query, orderBy, getDoc, doc } from "../../supabase/supabase";

export default function News() {
  const { id } = useParams();
  const { settings, loading } = useWebsiteSettings();
  const newsSettings = settings?.newsSettings || {};
  const [news, setNews] = useState([]);
  const [selectedNews, setSelectedNews] = useState(null);
  const [loadingNews, setLoadingNews] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  const fetchAllNews = async () => {
    setLoadingNews(true);
    try {
      const q = query(collection(db, "news"), orderBy("date", "desc"));
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setNews(data);
    } catch (error) {
      console.error("Error fetching news:", error);
    } finally {
      setLoadingNews(false);
    }
  };

  const fetchSingleNews = async () => {
    setLoadingNews(true);
    try {
      const docRef = doc(db, "news", id);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setSelectedNews({ id: docSnap.id, ...docSnap.data() });
      }
    } catch (error) {
      console.error("Error fetching news:", error);
    } finally {
      setLoadingNews(false);
    }
  };

  useEffect(() => {
    if (id) {
       
      fetchSingleNews();
    } else {
       
      fetchAllNews();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const categories = newsSettings.categories || [];

  const filteredNews = news.filter((item) => {
    const matchCategory = selectedCategory === "all" || item.category === selectedCategory;
    const matchSearch = item.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       item.content?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchCategory && matchSearch;
  });

  if (loading || loadingNews) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse">
            <div className="h-12 w-48 bg-gray-200 rounded mx-auto mb-4"></div>
            <div className="h-6 w-64 bg-gray-200 rounded mx-auto mb-8"></div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="bg-white rounded-xl shadow p-4 h-64"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Single News View
  if (selectedNews) {
    const category = categories.find(c => c.name === selectedNews.category);
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link to="/news" className="text-blue-600 hover:text-blue-800 transition mb-4 inline-block">
            ← Back to News
          </Link>
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            {selectedNews.image && (
              <div className="w-full h-80 bg-gray-200">
                <img src={selectedNews.image} alt={selectedNews.title} className="w-full h-full object-cover" />
              </div>
            )}
            <div className="p-6 sm:p-8">
              <div className="flex items-center gap-3 mb-4">
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${category?.color || "bg-gray-100 text-gray-700"}`}>
                  {category?.emoji || "📌"} {selectedNews.category || "General"}
                </span>
                <span className="text-sm text-gray-400">
                  {selectedNews.date ? new Date(selectedNews.date).toLocaleDateString() : ""}
                </span>
              </div>
              <h1 className="text-3xl font-bold text-gray-800 mb-4">{selectedNews.title}</h1>
              <div className="prose max-w-none">
                <p className="text-gray-600 leading-relaxed whitespace-pre-wrap">{selectedNews.content}</p>
              </div>
              <div className="mt-6 pt-6 border-t border-gray-200 flex items-center justify-between">
                <span className="text-sm text-gray-400">By {selectedNews.author || "Admin"}</span>
                {selectedNews.tags && (
                  <div className="flex gap-2">
                    {selectedNews.tags.split(',').map((tag, i) => (
                      <span key={i} className="bg-gray-100 text-gray-600 px-2 py-1 rounded text-xs">#{tag.trim()}</span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Full News List
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="text-5xl mb-4">📰</div>
          <h1 className="text-3xl sm:text-4xl font-bold">
            {newsSettings.title || "News & Announcements"}
          </h1>
          <p className="text-blue-100 mt-2 max-w-2xl mx-auto">
            {newsSettings.subtitle || "Stay updated with the latest news from Tech Zone Academy"}
          </p>
        </div>
      </section>

      {/* Search & Filters */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-wrap items-center gap-4 mb-6">
          <div className="flex-1 min-w-[200px]">
            <input
              type="text"
              placeholder="🔍 Search News..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setSelectedCategory("all")}
              className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                selectedCategory === "all"
                  ? "bg-blue-700 text-white"
                  : "bg-gray-200 text-gray-700 hover:bg-gray-300"
              }`}
            >
              All
            </button>
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.name)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                  selectedCategory === cat.name
                    ? "bg-blue-700 text-white"
                    : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                }`}
              >
                {cat.emoji || "📌"} {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* News Grid */}
        {filteredNews.length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-6xl mb-4">📭</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No News Found</h3>
            <p className="text-gray-500">
              {news.length === 0 
                ? "No news has been posted yet. Check back later!" 
                : "No news found for the selected filters."}
            </p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredNews.map((item) => {
              const category = categories.find(c => c.name === item.category);
              return (
                <Link
                  to={`/news/${item.id}`}
                  key={item.id}
                  className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition duration-300 group"
                >
                  {item.image && (
                    <div className="h-48 bg-gray-200 overflow-hidden">
                      <img
                        src={item.image}
                        alt={item.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                      />
                    </div>
                  )}
                  <div className="p-5">
                    <div className="flex items-center justify-between mb-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${category?.color || "bg-gray-100 text-gray-700"}`}>
                        {category?.emoji || "📌"} {item.category || "General"}
                      </span>
                      <span className="text-xs text-gray-400">
                        {item.date ? new Date(item.date).toLocaleDateString() : ""}
                      </span>
                    </div>
                    <h3 className="text-xl font-bold text-gray-800 mb-2 line-clamp-2">
                      {item.title}
                    </h3>
                    <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                      {item.content}
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-400">
                        By {item.author || "Admin"}
                      </span>
                      <span className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                        Read More →
                      </span>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}