// src/pages/About.jsx
import { useWebsiteSettings } from "../../context/WebsiteSettingsContext";
import { Link } from "react-router-dom";
import { handleImageError } from "../../utils/imageFallback";

export default function About() {
  const { settings } = useWebsiteSettings();

  // Get values from settings with fallbacks
  const title = settings?.aboutTitle || "About Tech Zone Academy";
  const subtitle = settings?.aboutSubtitle || "Building Bright Futures Through Quality Education";
  const description = settings?.aboutDescription || "Tech Zone Academy is a premier educational institution dedicated to providing quality education from KG-3 to Grade 8...";
  const image = settings?.aboutImage || "/images/about-default.jpg";
  
  const missionTitle = settings?.aboutMissionTitle || "Our Mission";
  const mission = settings?.aboutMission || "To provide quality education that nurtures intellectual curiosity, critical thinking, and character development.";
  const visionTitle = settings?.aboutVisionTitle || "Our Vision";
  const vision = settings?.aboutVision || "To become a leading educational institution that empowers students with knowledge, skills, and values to excel.";
  const valuesTitle = settings?.aboutValuesTitle || "Core Values";
  
  const features = settings?.aboutFeatures || [
    { icon: "📚", title: "Modern Curriculum", description: "Up-to-date educational programs designed for academic excellence." },
    { icon: "👨‍🏫", title: "Expert Teachers", description: "Qualified and experienced educators dedicated to student success." },
    { icon: "💻", title: "Technology Integration", description: "Smart classrooms and digital learning resources." },
    { icon: "🎯", title: "Student-Centered", description: "Personalized attention and support for each learner's unique needs." },
  ];
  
  const coreValues = settings?.aboutCoreValues || [
    { icon: "🌟", title: "Excellence", description: "Striving for the highest standards in education" },
    { icon: "🤝", title: "Community", description: "Building strong partnerships with parents and community" },
    { icon: "💡", title: "Innovation", description: "Embracing new ideas and modern teaching methods" },
    { icon: "🧠", title: "Integrity", description: "Instilling honesty, respect, and responsibility" },
  ];

  const teamMembers = settings?.aboutTeamMembers || [
    { name: "Dr. Sarah Johnson", role: "School Director", bio: "PhD in Education with 20+ years of experience." },
    { name: "Mr. David Smith", role: "Head of Academics", bio: "Masters in Curriculum Development." },
    { name: "Ms. Emily Brown", role: "Head of Student Affairs", bio: "Passionate about student welfare and development." },
    { name: "Mr. James Wilson", role: "Head of Technology", bio: "Expert in educational technology integration." },
  ];

  const historyTimeline = settings?.aboutHistoryTimeline || [
    { year: "2015", title: "Foundation", description: "Tech Zone Academy was established with 50 students." },
    { year: "2017", title: "Expansion", description: "Expanded to include high school programs." },
    { year: "2019", title: "Innovation", description: "Introduced digital learning and smart classrooms." },
    { year: "2021", title: "Excellence", description: "Received National Quality Education Award." },
    { year: "2023", title: "Global Reach", description: "Launched international exchange programs." },
  ];

  const ctaTitle = settings?.aboutCtaTitle || "Ready to Join Us?";
  const ctaDescription = settings?.aboutCtaDescription || "Give your child the best education. Enroll today at Tech Zone Academy.";
  const ctaButton1Text = settings?.aboutCtaButton1Text || "Apply Now";
  const ctaButton1Link = settings?.aboutCtaButton1Link || "/admissions";
  const ctaButton2Text = settings?.aboutCtaButton2Text || "Contact Us";
  const ctaButton2Link = settings?.aboutCtaButton2Link || "/contact";

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative bg-blue-700 text-white py-20">
        <div className="absolute inset-0 bg-black opacity-30"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">About</h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            {subtitle}
          </p>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <span className="text-blue-700 font-semibold text-sm uppercase tracking-wider">
                About Us
              </span>
              <h2 className="text-3xl font-bold text-gray-800 mt-2">{title}</h2>
              <div className="w-20 h-1 bg-blue-700 mt-4"></div>
              <p className="text-gray-600 mt-6 leading-relaxed">
                {description}
              </p>
              <div className="grid grid-cols-2 gap-4 mt-6">
                <div className="bg-blue-50 rounded-lg p-4 text-center">
                  <div className="text-3xl font-bold text-blue-700">{settings?.aboutStudentsValue || "500+"}</div>
                  <div className="text-sm text-gray-600">{settings?.aboutStudentsLabel || "Students"}</div>
                </div>
                <div className="bg-blue-50 rounded-lg p-4 text-center">
                  <div className="text-3xl font-bold text-blue-700">{settings?.aboutTeachersValue || "30+"}</div>
                  <div className="text-sm text-gray-600">{settings?.aboutTeachersLabel || "Teachers"}</div>
                </div>
                <div className="bg-blue-50 rounded-lg p-4 text-center">
                  <div className="text-3xl font-bold text-blue-700">{settings?.aboutSuccessValue || "95%"}</div>
                  <div className="text-sm text-gray-600">{settings?.aboutSuccessLabel || "Success Rate"}</div>
                </div>
                <div className="bg-blue-50 rounded-lg p-4 text-center">
                  <div className="text-3xl font-bold text-blue-700">{settings?.aboutYearsValue || "10+"}</div>
                  <div className="text-sm text-gray-600">{settings?.aboutYearsLabel || "Years"}</div>
                </div>
              </div>
            </div>
            <div>
              <img
                src={image}
                alt={title}
                className="rounded-2xl shadow-xl w-full h-auto object-cover"
                onError={(e) => handleImageError(e, "About Us")}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Mission, Vision, Values Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800">Our Mission, Vision & Values</h2>
            <div className="w-20 h-1 bg-blue-700 mx-auto mt-4"></div>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {/* Mission */}
            <div className="bg-white rounded-xl shadow-lg p-8 text-center hover:shadow-xl transition">
              <div className="text-5xl mb-4">🎯</div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">{missionTitle}</h3>
              <p className="text-gray-600 leading-relaxed">
                {mission}
              </p>
            </div>

            {/* Vision */}
            <div className="bg-white rounded-xl shadow-lg p-8 text-center hover:shadow-xl transition">
              <div className="text-5xl mb-4">👁️</div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">{visionTitle}</h3>
              <p className="text-gray-600 leading-relaxed">
                {vision}
              </p>
            </div>

            {/* Values */}
            <div className="bg-white rounded-xl shadow-lg p-8 text-center hover:shadow-xl transition">
              <div className="text-5xl mb-4">💎</div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">{valuesTitle}</h3>
              <ul className="text-gray-600 leading-relaxed space-y-2">
                {coreValues.map((value, index) => (
                  <li key={index}>✓ {value.title}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800">Why Choose Us</h2>
            <div className="w-20 h-1 bg-blue-700 mx-auto mt-4"></div>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="text-center p-6 bg-gray-50 rounded-xl hover:shadow-lg transition">
                <div className="text-5xl mb-4">{feature.icon}</div>
                <h4 className="text-lg font-bold text-gray-800">{feature.title}</h4>
                <p className="text-gray-600 text-sm mt-2">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* History Timeline */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800">Our History</h2>
            <div className="w-20 h-1 bg-blue-700 mx-auto mt-4"></div>
            <p className="text-gray-600 mt-4">A journey of excellence and growth</p>
          </div>
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 bg-blue-200 h-full"></div>
            
            <div className="space-y-12">
              {historyTimeline.map((item, index) => (
                <div key={index} className={`relative flex items-center ${index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'}`}>
                  <div className="w-5/12"></div>
                  {/* Timeline Dot */}
                  <div className="absolute left-1/2 transform -translate-x-1/2 w-6 h-6 bg-blue-700 rounded-full border-4 border-white shadow-lg z-10"></div>
                  {/* Content */}
                  <div className={`w-5/12 ${index % 2 === 0 ? 'pr-8 text-right' : 'pl-8 text-left'}`}>
                    <div className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition">
                      <span className="text-blue-700 font-bold text-lg">{item.year}</span>
                      <h4 className="text-lg font-semibold text-gray-800 mt-1">{item.title}</h4>
                      <p className="text-gray-600 text-sm mt-2">{item.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Our Team Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800">Our Leadership Team</h2>
            <div className="w-20 h-1 bg-blue-700 mx-auto mt-4"></div>
            <p className="text-gray-600 mt-4">Meet the dedicated professionals leading our school</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <div key={index} className="bg-gray-50 rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition">
                <div className="h-48 bg-blue-100 flex items-center justify-center">
                  <span className="text-6xl">👤</span>
                </div>
                <div className="p-6 text-center">
                  <h4 className="text-lg font-bold text-gray-800">{member.name}</h4>
                  <p className="text-blue-700 text-sm font-medium">{member.role}</p>
                  <p className="text-gray-600 text-sm mt-2">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-blue-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">{ctaTitle}</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            {ctaDescription}
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link
              to={ctaButton1Link}
              className="bg-white text-blue-700 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition"
            >
              {ctaButton1Text}
            </Link>
            <Link
              to={ctaButton2Link}
              className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-700 transition"
            >
              {ctaButton2Text}
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}