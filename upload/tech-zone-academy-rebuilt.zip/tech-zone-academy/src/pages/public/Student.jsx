import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "../../supabase/supabaseClient";
import { useWebsiteSettings } from "../../context/WebsiteSettingsContext";

export default function Student() {
  const { settings } = useWebsiteSettings();
  const schoolName = settings?.schoolInfo?.schoolName || "Tech Zone Academy";
  const [studentCount, setStudentCount] = useState(0);
  const [loading, setLoading] = useState(true);

  const fetchStudentCount = async () => {
    try {
      // Public page: anonymous visitors don't have row-level read
      // access to students, so this goes through the aggregate-only
      // security-definer RPC instead of a direct table query.
      const { data, error } = await supabase.rpc("get_public_school_stats").single();
      if (error) throw error;
      setStudentCount(data?.students ?? 0);
    } catch (error) {
      console.error("Error fetching student count:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
     
    fetchStudentCount();
  }, []);

  const features = [
    {
      icon: "📚",
      title: "Academics",
      description: "High-quality education with modern teaching methods and a comprehensive curriculum.",
      color: "bg-blue-50 hover:bg-blue-100 border-blue-200",
    },
    {
      icon: "🔬",
      title: "Science & Technology",
      description: "Hands-on learning in science labs and technology-integrated classrooms.",
      color: "bg-green-50 hover:bg-green-100 border-green-200",
    },
    {
      icon: "🎨",
      title: "Arts & Creativity",
      description: "Visual arts, music, drama, and creative expression programs.",
      color: "bg-purple-50 hover:bg-purple-100 border-purple-200",
    },
    {
      icon: "⚽",
      title: "Sports & Athletics",
      description: "Physical education, sports teams, and athletic competitions.",
      color: "bg-orange-50 hover:bg-orange-100 border-orange-200",
    },
    {
      icon: "🤝",
      title: "Clubs & Activities",
      description: "Science club, math club, debate, robotics, and leadership programs.",
      color: "bg-pink-50 hover:bg-pink-100 border-pink-200",
    },
    {
      icon: "🏆",
      title: "Student Achievements",
      description: "Celebrating academic excellence, sports victories, and creative accomplishments.",
      color: "bg-yellow-50 hover:bg-yellow-100 border-yellow-200",
    },
  ];

  const gradeLevels = [
    { level: "KG-1", age: "3-4 years", color: "bg-green-100 text-green-700" },
    { level: "KG-2", age: "4-5 years", color: "bg-blue-100 text-blue-700" },
    { level: "KG-3", age: "5-6 years", color: "bg-purple-100 text-purple-700" },
    { level: "Grade 1-4", age: "6-10 years", color: "bg-orange-100 text-orange-700" },
    { level: "Grade 5-8", age: "10-14 years", color: "bg-red-100 text-red-700" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="text-6xl mb-4">🎓</div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
              Student Life
            </h1>
            <p className="text-lg sm:text-xl text-blue-100 max-w-3xl mx-auto">
              Welcome to the Student Life page of {schoolName}. We provide a safe,
              engaging, and supportive learning environment for students from KG-3 to Grade 8.
            </p>
            <div className="mt-4 inline-block bg-blue-500/30 backdrop-blur-sm px-4 py-1 rounded-full text-sm">
              {loading ? "Loading..." : `🎯 ${studentCount}+ Students Enrolled`}
            </div>
          </div>
        </div>
      </section>

      {/* Grade Levels */}
      <section className="py-8 sm:py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 sm:mb-10">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-800">
              Grade Levels
            </h2>
            <div className="w-16 sm:w-20 h-1 bg-blue-600 mx-auto mt-3 rounded"></div>
          </div>
          <div className="flex flex-wrap justify-center gap-3 sm:gap-4">
            {gradeLevels.map((grade) => (
              <div
                key={grade.level}
                className={`${grade.color} px-4 py-2 rounded-full text-sm sm:text-base font-medium shadow-sm`}
              >
                {grade.level} <span className="opacity-75">•</span> {grade.age}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12 sm:py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-800">
              Student Experience
            </h2>
            <div className="w-16 sm:w-20 h-1 bg-blue-600 mx-auto mt-3 rounded"></div>
            <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
              We offer a well-rounded education that nurtures academic, social, and personal growth
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {features.map((feature, index) => (
              <div
                key={index}
                className={`${feature.color} border-2 rounded-xl p-6 transition duration-300 hover:shadow-lg hover:-translate-y-1`}
              >
                <div className="text-4xl mb-3">{feature.icon}</div>
                <h3 className="text-lg font-bold text-gray-800 mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-gray-600">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Student Resources */}
      <section className="py-12 sm:py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-800">
              📋 Student Resources
            </h2>
            <div className="w-16 sm:w-20 h-1 bg-blue-600 mx-auto mt-3 rounded"></div>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-gray-50 rounded-lg p-4 text-center hover:bg-gray-100 transition">
              <div className="text-3xl mb-2">📖</div>
              <h4 className="font-semibold text-gray-800">Library</h4>
              <p className="text-xs text-gray-500">Access our school library</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4 text-center hover:bg-gray-100 transition">
              <div className="text-3xl mb-2">💻</div>
              <h4 className="font-semibold text-gray-800">Computer Lab</h4>
              <p className="text-xs text-gray-500">Technology resources</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4 text-center hover:bg-gray-100 transition">
              <div className="text-3xl mb-2">🧪</div>
              <h4 className="font-semibold text-gray-800">Science Lab</h4>
              <p className="text-xs text-gray-500">Hands-on experiments</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4 text-center hover:bg-gray-100 transition">
              <div className="text-3xl mb-2">🏫</div>
              <h4 className="font-semibold text-gray-800">Cafeteria</h4>
              <p className="text-xs text-gray-500">Healthy meals daily</p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-12 sm:py-16 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl sm:text-3xl font-bold mb-4">
            Ready to Join Our School?
          </h2>
          <p className="text-lg text-blue-100 mb-6 max-w-2xl mx-auto">
            Enroll your child today and give them the gift of quality education.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/about"
              className="bg-white text-blue-700 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition duration-200"
            >
              Learn More
            </Link>
            <Link
              to="/login"
              className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-700 transition duration-200"
            >
              Get Started
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
