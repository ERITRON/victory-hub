import { useLanguage } from "../../context/LanguageContext";
import { translations } from "../../translations";
import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "../../supabase/supabaseClient";

export default function Home() {
  const { language } = useLanguage();
  const [stats, setStats] = useState({
    students: 0,
    teachers: 0,
    grades: 0,
    parents: 0,
  });
  const [loading, setLoading] = useState(true);

  const fetchStats = async () => {
    try {
      // Public homepage stats are served through a security-definer
      // RPC (get_public_school_stats) that returns only aggregate
      // counts. Anonymous visitors don't have row-level read access to
      // students/teachers/users, so a direct table query would return
      // nothing here.
      const { data, error } = await supabase.rpc("get_public_school_stats").single();
      if (error) throw error;

      setStats({
        students: data?.students ?? 0,
        teachers: data?.teachers ?? 0,
        grades: data?.grades ?? 0,
        parents: data?.parents ?? 0,
      });
    } catch (error) {
      console.error("Error fetching stats:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
     
    fetchStats();
  }, []);

  const features = [
    {
      icon: "📚",
      title: "Quality Education",
      description: "Modern curriculum designed for academic excellence",
    },
    {
      icon: "👨‍🏫",
      title: "Expert Teachers",
      description: "Qualified educators dedicated to student success",
    },
    {
      icon: "💻",
      title: "Smart Learning",
      description: "Technology-integrated classrooms for better learning",
    },
    {
      icon: "🏅",
      title: "Extracurricular",
      description: "Sports, arts, and clubs for holistic development",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-28">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            {/* Left Content */}
            <div className="text-center md:text-left">
              <div className="inline-block bg-blue-500/30 backdrop-blur-sm px-4 py-1 rounded-full text-sm font-medium mb-4">
                🏫 Welcome to Tech Zone Academy
              </div>
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 leading-tight">
                {translations[language].title || "Building Bright Futures"}
              </h1>
              <p className="text-lg sm:text-xl text-blue-100 mb-6 leading-relaxed">
                {translations[language].subtitle || "KG-3 to Grade 8 | Quality Education for Every Child"}
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                <Link
                  to="/about"
                  className="bg-white text-blue-700 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition duration-200 text-center"
                >
                  Learn More
                </Link>
                <Link
                  to="/login"
                  className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-700 transition duration-200 text-center"
                >
                  Get Started
                </Link>
              </div>
            </div>

            {/* Right Content - Stats */}
            <div className="grid grid-cols-2 gap-4 mt-8 md:mt-0">
              {loading ? (
                <>
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 sm:p-6 text-center animate-pulse">
                    <div className="h-8 w-16 bg-white/20 rounded mx-auto mb-2"></div>
                    <div className="h-4 w-20 bg-white/20 rounded mx-auto"></div>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 sm:p-6 text-center animate-pulse">
                    <div className="h-8 w-16 bg-white/20 rounded mx-auto mb-2"></div>
                    <div className="h-4 w-20 bg-white/20 rounded mx-auto"></div>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 sm:p-6 text-center animate-pulse">
                    <div className="h-8 w-16 bg-white/20 rounded mx-auto mb-2"></div>
                    <div className="h-4 w-20 bg-white/20 rounded mx-auto"></div>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 sm:p-6 text-center animate-pulse">
                    <div className="h-8 w-16 bg-white/20 rounded mx-auto mb-2"></div>
                    <div className="h-4 w-20 bg-white/20 rounded mx-auto"></div>
                  </div>
                </>
              ) : (
                <>
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 sm:p-6 text-center hover:bg-white/20 transition">
                    <div className="text-3xl sm:text-4xl font-bold">{stats.students}+</div>
                    <div className="text-sm sm:text-base text-blue-200">Students</div>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 sm:p-6 text-center hover:bg-white/20 transition">
                    <div className="text-3xl sm:text-4xl font-bold">{stats.teachers}+</div>
                    <div className="text-sm sm:text-base text-blue-200">Teachers</div>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 sm:p-6 text-center hover:bg-white/20 transition">
                    <div className="text-3xl sm:text-4xl font-bold">{stats.grades}</div>
                    <div className="text-sm sm:text-base text-blue-200">Grades</div>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 sm:p-6 text-center hover:bg-white/20 transition">
                    <div className="text-3xl sm:text-4xl font-bold">{stats.parents}+</div>
                    <div className="text-sm sm:text-base text-blue-200">Parents</div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12 sm:py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-800">
              Why Choose Tech Zone Academy?
            </h2>
            <div className="w-16 sm:w-20 h-1 bg-blue-600 mx-auto mt-3 rounded"></div>
            <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
              We provide a nurturing environment that fosters academic excellence and personal growth
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {features.map((feature, index) => (
              <div
                key={index}
                className="bg-white rounded-xl p-6 text-center shadow-sm hover:shadow-xl transition duration-300 hover:-translate-y-1 border border-gray-100"
              >
                <div className="text-4xl mb-3">{feature.icon}</div>
                <h3 className="text-lg font-bold text-gray-800 mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-gray-600">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-12 sm:py-16 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl sm:text-3xl font-bold mb-4">
            Ready to Join Our School?
          </h2>
          <p className="text-lg text-blue-100 mb-6 max-w-2xl mx-auto">
            Enroll your child today and give them the gift of quality education.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/about"
              className="bg-white text-blue-700 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition duration-200"
            >
              Learn More
            </Link>
            <Link
              to="/login"
              className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-700 transition duration-200"
            >
              Get Started
            </Link>
          </div>
        </div>
      </section>

      {/* Footer Note */}
      <div className="bg-gray-50 py-4 text-center text-sm text-gray-500 border-t border-gray-200">
        <p>Tech Zone Academy © {new Date().getFullYear()} - Building Bright Futures</p>
      </div>
    </div>
  );
}