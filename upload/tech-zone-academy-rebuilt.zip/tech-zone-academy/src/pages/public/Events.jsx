// src/pages/Events.jsx
import { useState, useEffect } from "react";
import { useWebsiteSettings } from "../../context/WebsiteSettingsContext";
import { db, collection, getDocs, query, orderBy } from "../../supabase/supabase";

export default function Events() {
  const { settings, loading } = useWebsiteSettings();
  const eventsSettings = settings?.eventsSettings || {};
  const [events, setEvents] = useState([]);
  const [loadingEvents, setLoadingEvents] = useState(true);
  const [selectedMonth, setSelectedMonth] = useState("");
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  const months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const fetchEvents = async () => {
    setLoadingEvents(true);
    try {
      const q = query(collection(db, "events"), orderBy("date", "asc"));
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setEvents(data);
    } catch (error) {
      console.error("Error fetching events:", error);
    } finally {
      setLoadingEvents(false);
    }
  };

  useEffect(() => {
     
    fetchEvents();
  }, []);

  const filteredEvents = events.filter((event) => {
    if (!event.date) return false;
    const eventDate = new Date(event.date);
    const monthMatch = selectedMonth === "" || months[eventDate.getMonth()] === selectedMonth;
    const yearMatch = eventDate.getFullYear() === selectedYear;
    return monthMatch && yearMatch;
  });

  const categories = eventsSettings.categories || [];

  const getCategoryColor = (category) => {
    const found = categories.find(c => c.name === category);
    return found?.color || "bg-gray-100 text-gray-700";
  };

  if (loading || loadingEvents) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse">
            <div className="h-12 w-48 bg-gray-200 rounded mx-auto mb-4"></div>
            <div className="h-6 w-64 bg-gray-200 rounded mx-auto mb-8"></div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-white rounded-xl shadow p-4 h-64"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-purple-600 to-purple-800 text-white py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="text-5xl mb-4">📅</div>
          <h1 className="text-3xl sm:text-4xl font-bold">
            {eventsSettings.title || "School Events"}
          </h1>
          <p className="text-purple-100 mt-2 max-w-2xl mx-auto">
            {eventsSettings.subtitle || "Stay updated with upcoming events and activities"}
          </p>
        </div>
      </section>

      {/* Filters */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-xl shadow-md p-4 sm:p-6 mb-8">
          <div className="flex flex-wrap gap-4 items-center">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Month</label>
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="border rounded-lg p-2 focus:ring-2 focus:ring-purple-500 outline-none"
              >
                <option value="">All Months</option>
                {months.map((month) => (
                  <option key={month} value={month}>{month}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Year</label>
              <select
                value={selectedYear}
                onChange={(e) => setSelectedYear(Number(e.target.value))}
                className="border rounded-lg p-2 focus:ring-2 focus:ring-purple-500 outline-none"
              >
                {[2024, 2025, 2026, 2027, 2028].map((year) => (
                  <option key={year} value={year}>{year}</option>
                ))}
              </select>
            </div>
            {(selectedMonth || selectedYear) && (
              <button
                onClick={() => {
                  setSelectedMonth("");
                  setSelectedYear(new Date().getFullYear());
                }}
                className="mt-6 px-4 py-2 bg-gray-200 rounded-lg hover:bg-gray-300 transition font-medium"
              >
                Clear Filters
              </button>
            )}
          </div>
        </div>

        {/* Events Grid */}
        {filteredEvents.length === 0 ? (
          <div className="bg-white rounded-xl shadow p-12 text-center">
            <div className="text-6xl mb-4">📭</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No Events Found</h3>
            <p className="text-gray-500">
              {events.length === 0 
                ? "No events have been added yet." 
                : "No events found for the selected filters."}
            </p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEvents.map((event) => {
              const categoryColor = getCategoryColor(event.category);
              return (
                <div
                  key={event.id}
                  className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition duration-300"
                >
                  {event.banner && (
                    <div className="h-48 bg-gray-200 overflow-hidden">
                      <img
                        src={event.banner}
                        alt={event.title}
                        className="w-full h-full object-cover"
                        onError={(e) => { e.target.style.display = "none"; }}
                      />
                    </div>
                  )}
                  <div className="p-5">
                    <div className="flex items-center justify-between mb-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${categoryColor}`}>
                        {event.category || "General"}
                      </span>
                      <span className="text-xs text-gray-400">
                        {event.date ? new Date(event.date).toLocaleDateString() : "TBD"}
                      </span>
                    </div>
                    <h3 className="text-xl font-bold text-gray-800 mb-2">
                      {event.title}
                    </h3>
                    <p className="text-gray-600 text-sm mb-3 line-clamp-3">
                      {event.description}
                    </p>
                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <span>📍 {event.location || "School"}</span>
                      <span>🕐 {event.time || "TBD"}</span>
                    </div>
                    {event.registrationLink && (
                      <a
                        href={event.registrationLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="mt-3 inline-block bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition text-sm font-medium"
                      >
                        Register Now →
                      </a>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}