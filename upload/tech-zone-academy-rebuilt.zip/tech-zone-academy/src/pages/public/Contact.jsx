// src/pages/Contact.jsx
import { useState } from "react";
import emailjs from "@emailjs/browser";
import toast from "react-hot-toast";
import { useWebsiteSettings } from "../../context/WebsiteSettingsContext";

const INITIAL_FORM_DATA = {
  name: "",
  email: "",
  subject: "",
  message: "",
};

export default function Contact() {
  const { settings } = useWebsiteSettings();
  const school = settings?.schoolInfo || {};
  const [formData, setFormData] = useState(INITIAL_FORM_DATA);
  const [submission, setSubmission] = useState({
    loading: false,
    success: false,
    error: null,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));

    if (submission.success || submission.error) {
      setSubmission({
        loading: false,
        success: false,
        error: null,
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmission({
      loading: true,
      success: false,
      error: null,
    });

    const serviceId = import.meta.env.VITE_EMAILJS_SERVICE_ID;
    const templateId = import.meta.env.VITE_EMAILJS_TEMPLATE_ID;
    const publicKey = import.meta.env.VITE_EMAILJS_PUBLIC_KEY;

    try {
      if (!serviceId || !templateId || !publicKey) {
        throw new Error(
          "Email service is not configured. Please contact the administrator.",
        );
      }

      await emailjs.send(
        serviceId,
        templateId,
        {
          to_email: school.email,
          from_name: formData.name.trim(),
          from_email: formData.email.trim(),
          reply_to: formData.email.trim(),
          subject: formData.subject.trim(),
          message: formData.message.trim(),
          sent_at: new Date().toLocaleString(),
        },
        { publicKey },
      );

      setSubmission({
        loading: false,
        success: true,
        error: null,
      });
      setFormData(INITIAL_FORM_DATA);
      toast.success("Your message was sent successfully.");
    } catch (sendError) {
      console.error("Contact email failed:", sendError);

      const errorMessage =
        sendError instanceof Error
          ? sendError.message
          : typeof sendError?.text === "string"
            ? sendError.text
          : "We could not send your message. Please try again.";

      setSubmission({
        loading: false,
        success: false,
        error: errorMessage,
      });
      toast.error(errorMessage);
    }
  };

  const contactInfo = [
    {
      icon: "📞",
      title: "Phone",
      details: [school.phone, school.secondaryPhone].filter(Boolean),
    },
    {
      icon: "✉️",
      title: "Email",
      details: [school.email].filter(Boolean),
    },
    {
      icon: "📍",
      title: "Address",
      details: [school.address, school.addressLine2].filter(Boolean),
    },
    {
      icon: "🕐",
      title: "Working Hours",
      details: [school.workingHours, school.saturdayHours].filter(Boolean),
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="text-5xl mb-4">📞</div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
              Contact Us
            </h1>
            <p className="text-lg text-blue-100 max-w-2xl mx-auto">
              Have questions? We'd love to hear from you. Get in touch with us
              and we'll respond as soon as possible.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Info Cards */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-12">
            {contactInfo.map((info, index) => (
              <div
                key={index}
                className="bg-white rounded-xl shadow-md p-6 text-center hover:shadow-xl transition duration-300"
              >
                <div className="text-4xl mb-3">{info.icon}</div>
                <h3 className="text-lg font-bold text-gray-800 mb-2">
                  {info.title}
                </h3>
                {info.details.map((detail, i) => (
                  <p key={i} className="text-sm text-gray-600">
                    {detail}
                  </p>
                ))}
              </div>
            ))}
          </div>

          {/* Contact Form & Map */}
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Contact Form */}
            <div className="bg-white rounded-xl shadow-lg p-6 sm:p-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">
                Send Us a Message
              </h2>

              {submission.success ? (
                <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
                  <div className="text-5xl mb-4">✅</div>
                  <h3 className="text-xl font-bold text-green-700 mb-2">
                    Message Sent!
                  </h3>
                  <p className="text-gray-600">
                    Thank you for contacting us. We'll get back to you soon.
                  </p>
                  <button
                    type="button"
                    onClick={() =>
                      setSubmission({
                        loading: false,
                        success: false,
                        error: null,
                      })
                    }
                    className="mt-4 bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {submission.error && (
                    <div
                      role="alert"
                      className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
                    >
                      {submission.error}
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Your Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition"
                      placeholder="Enter your full name"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition"
                      placeholder="Enter your email address"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Subject *
                    </label>
                    <input
                      type="text"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      required
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition"
                      placeholder="Enter subject"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Message *
                    </label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                      rows="5"
                      className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none transition resize-none"
                      placeholder="Write your message here..."
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={submission.loading}
                    className={`w-full py-3 rounded-lg font-semibold text-white transition ${
                      submission.loading
                        ? "bg-gray-400 cursor-not-allowed"
                        : "bg-blue-700 hover:bg-blue-800 hover:shadow-lg"
                    }`}
                  >
                    {submission.loading ? (
                      <span className="flex items-center justify-center gap-2">
                        <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Sending...
                      </span>
                    ) : (
                      "Send Message"
                    )}
                  </button>
                </form>
              )}
            </div>

            {/* Map & Additional Info */}
            <div className="space-y-6">
              <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                <div className="h-64 bg-gray-200 relative">
                  {school.mapEmbedUrl ? (
                    <iframe
                      title={`${school.schoolName || "School"} location`}
                      src={school.mapEmbedUrl}
                      className="h-full w-full border-0"
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                      allowFullScreen
                    />
                  ) : (
                  <div className="w-full h-full flex items-center justify-center bg-gray-100">
                    <div className="text-center">
                      <div className="text-6xl mb-2">🗺️</div>
                      <p className="text-gray-500">Google Map</p>
                      <p className="text-sm text-gray-400">
                        {[school.address, school.addressLine2].filter(Boolean).join(", ")}
                      </p>
                    </div>
                  </div>
                  )}
                </div>
                <div className="p-4 bg-gray-50">
                  <p className="text-sm text-gray-600">
                    <strong>Location:</strong>{" "}
                    {[school.address, school.addressLine2].filter(Boolean).join(", ")}
                  </p>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-lg font-bold text-gray-800 mb-4">
                  📢 Quick Links
                </h3>
                <div className="space-y-2">
                  <a
                    href="/about"
                    className="block text-blue-600 hover:text-blue-800 transition"
                  >
                    → About Our School
                  </a>
                  <a
                    href="/student"
                    className="block text-blue-600 hover:text-blue-800 transition"
                  >
                    → Student Information
                  </a>
                  <a
                    href="/parent"
                    className="block text-blue-600 hover:text-blue-800 transition"
                  >
                    → Parent Information
                  </a>
                  <a
                    href="/login"
                    className="block text-blue-600 hover:text-blue-800 transition"
                  >
                    → Login to Portal
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
