// src/pages/public/NotFound.jsx
// 404 page shown for any unmatched route. The global <Navbar /> from App.jsx
// still renders above this; here we fill the remaining space with a friendly,
// centered error state.
import { Link } from "react-router-dom";
import SEO from "../../components/SEO";
import Icon from "../../components/Icon";

export default function NotFound() {
  return (
    <>
      <SEO
        title="Page Not Found"
        description="Sorry, the page you're looking for doesn't exist or has been moved."
        noindex
      />

      <section className="min-h-[80vh] flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-blue-50 px-4 py-16">
        <div className="w-full max-w-xl text-center">
          {/* Search icon badge */}
          <div className="mx-auto mb-8 flex h-20 w-20 items-center justify-center rounded-full bg-blue-100 text-blue-600 shadow-sm sm:h-24 sm:w-24">
            <Icon name="search" size="2x" />
          </div>

          {/* Large 404 */}
          <h1 className="bg-gradient-to-r from-blue-600 to-blue-800 bg-clip-text text-7xl font-extrabold tracking-tight text-transparent sm:text-8xl md:text-9xl">
            404
          </h1>

          {/* Heading */}
          <h2 className="mt-4 text-2xl font-bold text-gray-800 sm:text-3xl">
            Page Not Found
          </h2>

          {/* Friendly message */}
          <p className="mx-auto mt-3 max-w-md text-base leading-relaxed text-gray-600 sm:text-lg">
            Oops! The page you&apos;re looking for doesn&apos;t exist, may have
            been moved, or is temporarily unavailable. Let&apos;s get you back on
            track.
          </p>

          {/* Actions */}
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link
              to="/"
              className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-blue-700 px-6 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 sm:w-auto"
            >
              <Icon name="home" />
              Go Home
            </Link>
            <Link
              to="/contact"
              className="inline-flex w-full items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-6 py-3 text-sm font-semibold text-gray-700 shadow-sm transition hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 sm:w-auto"
            >
              <Icon name="phone" />
              Contact Support
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
