// src/pages/Admissions.jsx
import { useState } from "react";
import { useWebsiteSettings } from "../../context/WebsiteSettingsContext";
import { Link } from "react-router-dom";

export default function Admissions() {
  const { settings, loading } = useWebsiteSettings();
  const schoolName = settings?.schoolInfo?.schoolName || "Tech Zone Academy";
  const pageContent = settings?.pages?.admissions || { sections: [] };
  const [activeTab, setActiveTab] = useState("requirements");

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse">
            <div className="h-12 w-48 bg-gray-200 rounded mx-auto mb-4"></div>
            <div className="h-6 w-64 bg-gray-200 rounded mx-auto mb-8"></div>
            <div className="h-64 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  const sections = pageContent.sections || [];
  const requirements = sections.find(s => s.type === "requirements")?.items || [];
  const processSteps = sections.find(s => s.type === "process")?.items || [];
  const grades = sections.find(s => s.type === "grades")?.items || [];
  const feeStructure = sections.find(s => s.type === "fees")?.items || [];
  const currency = sections.find(s => s.type === "fees")?.currency || "$";

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-teal-600 to-teal-800 text-white py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="text-5xl mb-4">🎓</div>
          <h1 className="text-3xl sm:text-4xl font-bold">Admissions</h1>
          <p className="text-teal-100 mt-2 max-w-2xl mx-auto">
            Join {schoolName} and give your child the gift of quality education. We welcome students from KG-1 to Grade 8.
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tabs */}
        <div className="flex flex-wrap gap-2 border-b border-gray-200 pb-4 mb-8">
          {["requirements", "process", "grades", "fees"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-6 py-3 rounded-lg font-medium transition ${
                activeTab === tab
                  ? "bg-teal-600 text-white"
                  : "bg-gray-200 text-gray-700 hover:bg-gray-300"
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {/* Requirements Tab */}
        {activeTab === "requirements" && (
          <div className="bg-white rounded-xl shadow-lg p-6 sm:p-8">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">📋 Admission Requirements</h2>
            <p className="text-gray-600 mb-6">
              To apply for admission at {schoolName}, please ensure you have the following documents ready:
            </p>
            <div className="grid sm:grid-cols-2 gap-3">
              {requirements.map((req, index) => (
                <div key={index} className="flex items-center gap-3 bg-gray-50 rounded-lg p-3">
                  <span className="text-green-600 text-xl">✅</span>
                  <span className="text-gray-700">{req}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Process Tab */}
        {activeTab === "process" && (
          <div className="bg-white rounded-xl shadow-lg p-6 sm:p-8">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">📝 Admission Process</h2>
            <div className="space-y-4">
              {processSteps.map((step, index) => (
                <div key={index} className="flex items-start gap-4 bg-gray-50 rounded-lg p-4">
                  <div className="text-3xl flex-shrink-0">📌</div>
                  <div>
                    <h3 className="font-bold text-gray-800">{step}</h3>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Grades Tab */}
        {activeTab === "grades" && (
          <div className="bg-white rounded-xl shadow-lg p-6 sm:p-8">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">📚 Grades We Offer</h2>
            <p className="text-gray-600 mb-6">
              {schoolName} offers quality education from Kindergarten to Grade 8:
            </p>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {grades.map((grade, index) => (
                <div key={index} className="bg-gradient-to-br from-teal-50 to-blue-50 rounded-lg p-4 text-center border border-teal-100">
                  <div className="text-2xl font-bold text-teal-700">{grade}</div>
                  <div className="text-xs text-gray-500">Available</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Fees Tab */}
        {activeTab === "fees" && (
          <div className="bg-white rounded-xl shadow-lg p-6 sm:p-8">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">💰 Fee Structure</h2>
            <p className="text-gray-600 mb-6">
              Our fee structure is designed to be affordable and competitive:
            </p>
            <div className="bg-gray-50 rounded-lg overflow-hidden">
              <table className="w-full">
                <thead className="bg-teal-600 text-white">
                  <tr>
                    <th className="px-6 py-3 text-left">Item</th>
                    <th className="px-6 py-3 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {feeStructure.map((fee, index) => {
                    const isTotal = fee.item.toLowerCase().includes("total");
                    return (
                      <tr key={index} className={isTotal ? "bg-gray-100 font-bold" : "border-b border-gray-200"}>
                        <td className="px-6 py-3 text-gray-700">{fee.item}</td>
                        <td className="px-6 py-3 text-right font-medium text-gray-800">
                          {fee.isPercentage ? fee.amount : `${currency}${fee.amount}`}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <p className="mt-4 text-sm text-gray-500">
              📌 Fees are subject to change. Contact the school for the most accurate and up-to-date fee structure.
            </p>
            <Link
              to="/contact"
              className="mt-6 inline-block bg-teal-600 text-white px-6 py-3 rounded-lg hover:bg-teal-700 transition font-medium"
            >
              Request Fee Details
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
