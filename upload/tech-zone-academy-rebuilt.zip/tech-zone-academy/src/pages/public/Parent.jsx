import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "../../supabase/supabaseClient";
import { useWebsiteSettings } from "../../context/WebsiteSettingsContext";

export default function Parent() {
  const { settings } = useWebsiteSettings();
  const school = settings?.schoolInfo || {};
  const [parentCount, setParentCount] = useState(0);
  const [loading, setLoading] = useState(true);

  const fetchParentCount = async () => {
    try {
      // Public page: anonymous visitors don't have row-level read
      // access to users, so this goes through the aggregate-only
      // security-definer RPC instead of a direct table query.
      const { data, error } = await supabase.rpc("get_public_school_stats").single();
      if (error) throw error;
      setParentCount(data?.parents ?? 0);
    } catch (error) {
      console.error("Error fetching parent count:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
     
    fetchParentCount();
  }, []);

  const features = [
    {
      icon: "📊",
      title: "Academic Results",
      description: "Monitor your child's academic performance and progress reports.",
      link: "/login",
      color: "bg-blue-50 hover:bg-blue-100 border-blue-200",
    },
    {
      icon: "📋",
      title: "Attendance Tracking",
      description: "Track daily attendance records and view attendance summaries.",
      link: "/login",
      color: "bg-green-50 hover:bg-green-100 border-green-200",
    },
    {
      icon: "💬",
      title: "Teacher Communication",
      description: "Receive announcements, messages, and updates from teachers.",
      link: "/login",
      color: "bg-purple-50 hover:bg-purple-100 border-purple-200",
    },
    {
      icon: "📅",
      title: "School Calendar",
      description: "Stay informed about school events, holidays, and activities.",
      link: "/login",
      color: "bg-orange-50 hover:bg-orange-100 border-orange-200",
    },
    {
      icon: "📝",
      title: "Homework Updates",
      description: "View homework assignments and track submission status.",
      link: "/login",
      color: "bg-pink-50 hover:bg-pink-100 border-pink-200",
    },
    {
      icon: "👨‍👩‍👦",
      title: "Parent-Teacher Meetings",
      description: "Schedule and manage parent-teacher conference meetings.",
      link: "/login",
      color: "bg-indigo-50 hover:bg-indigo-100 border-indigo-200",
    },
  ];

  const guidelines = [
    "Attend parent-teacher conferences regularly",
    "Check your child's academic progress weekly",
    "Communicate with teachers about any concerns",
    "Support your child's learning at home",
    "Ensure timely payment of school fees",
    "Participate in school events and activities",
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-green-600 to-green-800 text-white py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="text-6xl mb-4">👨‍👩‍👦</div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
              Parent Information
            </h1>
            <p className="text-lg sm:text-xl text-green-100 max-w-3xl mx-auto">
              Parents are important partners in the education of our students. 
              We encourage active participation and communication with teachers 
              and school administration.
            </p>
            <div className="mt-4 inline-block bg-green-500/30 backdrop-blur-sm px-4 py-1 rounded-full text-sm">
              {loading ? "Loading..." : `${parentCount}+ Parents Connected`}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12 sm:py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-800">
              Parent Portal Features
            </h2>
            <div className="w-16 sm:w-20 h-1 bg-green-600 mx-auto mt-3 rounded"></div>
            <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
              Access everything you need to support your child's education
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {features.map((feature, index) => (
              <Link
                key={index}
                to={feature.link}
                className={`${feature.color} border-2 rounded-xl p-6 transition duration-300 hover:shadow-lg hover:-translate-y-1`}
              >
                <div className="text-4xl mb-3">{feature.icon}</div>
                <h3 className="text-lg font-bold text-gray-800 mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-gray-600">
                  {feature.description}
                </p>
                <div className="mt-3 text-green-600 font-medium text-sm">
                  View Details →
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Guidelines Section */}
      <section className="py-12 sm:py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8 lg:gap-12 items-start">
            <div>
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-4">
                📋 Parent Guidelines
              </h2>
              <div className="w-16 h-1 bg-green-600 rounded mb-4"></div>
              <p className="text-gray-600 mb-6">
                As a parent at {school.schoolName || "Tech Zone Academy"}, we encourage you to follow these
                guidelines to ensure the best educational experience for your child.
              </p>
              <ul className="space-y-3">
                {guidelines.map((item, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <span className="text-green-600 font-bold text-lg">✓</span>
                    <span className="text-gray-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6 sm:p-8">
              <h3 className="text-xl font-bold text-gray-800 mb-4">
                📞 Need Help?
              </h3>
              <p className="text-gray-600 mb-4">
                If you have any questions or need assistance, please don't hesitate 
                to contact our school administration.
              </p>
              <div className="space-y-3 text-sm">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">📞</span>
                  <div>
                    <p className="font-medium text-gray-700">Phone</p>
                    <p className="text-gray-500">{school.phone}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">✉️</span>
                  <div>
                    <p className="font-medium text-gray-700">Email</p>
                    <p className="text-gray-500">{school.email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">📍</span>
                  <div>
                    <p className="font-medium text-gray-700">Address</p>
                    <p className="text-gray-500">{school.address}</p>
                  </div>
                </div>
              </div>
              <Link
                to="/login"
                className="mt-6 block w-full bg-green-700 text-white text-center px-6 py-3 rounded-lg font-semibold hover:bg-green-800 transition"
              >
                Login to Parent Portal →
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-12 sm:py-16 bg-gradient-to-r from-green-600 to-green-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl sm:text-3xl font-bold mb-4">
            Ready to Connect?
          </h2>
          <p className="text-lg text-green-100 mb-6 max-w-2xl mx-auto">
            Join our parent community and stay connected with your child's education
          </p>
          <Link
            to="/login"
            className="bg-white text-green-700 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition duration-200"
          >
            Login to Parent Portal
          </Link>
        </div>
      </section>
    </div>
  );
}
