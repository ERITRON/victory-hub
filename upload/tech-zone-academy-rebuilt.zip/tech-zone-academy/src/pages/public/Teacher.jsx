import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "../../supabase/supabaseClient";
import { useWebsiteSettings } from "../../context/WebsiteSettingsContext";

export default function Teacher() {
  const { settings } = useWebsiteSettings();
  const schoolName = settings?.schoolInfo?.schoolName || "Tech Zone Academy";
  const [teacherCount, setTeacherCount] = useState(0);
  const [loading, setLoading] = useState(true);

  const fetchTeacherCount = async () => {
    try {
      // Public page: anonymous visitors don't have row-level read
      // access to teachers, so this goes through the aggregate-only
      // security-definer RPC instead of a direct table query.
      const { data, error } = await supabase.rpc("get_public_school_stats").single();
      if (error) throw error;
      setTeacherCount(data?.teachers ?? 0);
    } catch (error) {
      console.error("Error fetching teacher count:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
     
    fetchTeacherCount();
  }, []);

  const features = [
    {
      icon: "👨‍🏫",
      title: "Expert Teachers",
      description: "Qualified and experienced educators dedicated to student success.",
      color: "bg-blue-50 hover:bg-blue-100 border-blue-200",
    },
    {
      icon: "📚",
      title: "Subject Specialists",
      description: "Teachers specialize in their subjects for better learning outcomes.",
      color: "bg-green-50 hover:bg-green-100 border-green-200",
    },
    {
      icon: "💡",
      title: "Innovative Teaching",
      description: "Modern teaching methods with technology integration.",
      color: "bg-purple-50 hover:bg-purple-100 border-purple-200",
    },
    {
      icon: "🤝",
      title: "Supportive Environment",
      description: "Creating a positive and encouraging learning atmosphere.",
      color: "bg-orange-50 hover:bg-orange-100 border-orange-200",
    },
    {
      icon: "📊",
      title: "Student Progress",
      description: "Regular assessment and feedback to track student growth.",
      color: "bg-red-50 hover:bg-red-100 border-red-200",
    },
    {
      icon: "🏅",
      title: "Professional Development",
      description: "Continuous learning and development opportunities for teachers.",
      color: "bg-indigo-50 hover:bg-indigo-100 border-indigo-200",
    },
  ];

  const departments = [
    { name: "Science", icon: "🔬", color: "bg-green-100 text-green-700" },
    { name: "Mathematics", icon: "📐", color: "bg-blue-100 text-blue-700" },
    { name: "Languages", icon: "📖", color: "bg-purple-100 text-purple-700" },
    { name: "Social Studies", icon: "🌍", color: "bg-orange-100 text-orange-700" },
    { name: "Arts & Music", icon: "🎨", color: "bg-pink-100 text-pink-700" },
    { name: "Physical Education", icon: "⚽", color: "bg-green-100 text-green-700" },
    { name: "ICT", icon: "💻", color: "bg-cyan-100 text-cyan-700" },
    { name: "Life Skills", icon: "🌟", color: "bg-yellow-100 text-yellow-700" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="text-6xl mb-4">👨‍🏫</div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
              Teacher Portal
            </h1>
            <p className="text-lg sm:text-xl text-blue-100 max-w-3xl mx-auto">
              Our dedicated teachers are the heart of {schoolName}.
              They inspire, educate, and empower students to reach their full potential.
            </p>
            <div className="mt-4 inline-block bg-blue-500/30 backdrop-blur-sm px-4 py-1 rounded-full text-sm">
              {loading ? "Loading..." : `👨‍🏫 ${teacherCount}+ Dedicated Teachers`}
            </div>
          </div>
        </div>
      </section>

      {/* Departments Section */}
      <section className="py-8 sm:py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 sm:mb-10">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-800">
              Departments
            </h2>
            <div className="w-16 sm:w-20 h-1 bg-blue-600 mx-auto mt-3 rounded"></div>
          </div>
          <div className="flex flex-wrap justify-center gap-3 sm:gap-4">
            {departments.map((dept) => (
              <div
                key={dept.name}
                className={`${dept.color} px-4 py-2 rounded-full text-sm sm:text-base font-medium shadow-sm flex items-center gap-2`}
              >
                <span>{dept.icon}</span>
                {dept.name}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12 sm:py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-800">
              Why Our Teachers Are Special
            </h2>
            <div className="w-16 sm:w-20 h-1 bg-blue-600 mx-auto mt-3 rounded"></div>
            <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
              Our teachers go above and beyond to ensure every student succeeds
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {features.map((feature, index) => (
              <div
                key={index}
                className={`${feature.color} border-2 rounded-xl p-6 transition duration-300 hover:shadow-lg hover:-translate-y-1`}
              >
                <div className="text-4xl mb-3">{feature.icon}</div>
                <h3 className="text-lg font-bold text-gray-800 mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-gray-600">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Teacher Resources */}
      <section className="py-12 sm:py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-800">
              📋 Teacher Resources
            </h2>
            <div className="w-16 sm:w-20 h-1 bg-blue-600 mx-auto mt-3 rounded"></div>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-gray-50 rounded-lg p-4 text-center hover:bg-gray-100 transition">
              <div className="text-3xl mb-2">📄</div>
              <h4 className="font-semibold text-gray-800">Lesson Plans</h4>
              <p className="text-xs text-gray-500">Access teaching materials</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4 text-center hover:bg-gray-100 transition">
              <div className="text-3xl mb-2">📊</div>
              <h4 className="font-semibold text-gray-800">Assessment Tools</h4>
              <p className="text-xs text-gray-500">Grading and evaluation</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4 text-center hover:bg-gray-100 transition">
              <div className="text-3xl mb-2">📚</div>
              <h4 className="font-semibold text-gray-800">Curriculum</h4>
              <p className="text-xs text-gray-500">Subject guides and standards</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4 text-center hover:bg-gray-100 transition">
              <div className="text-3xl mb-2">🤝</div>
              <h4 className="font-semibold text-gray-800">Collaboration</h4>
              <p className="text-xs text-gray-500">Teacher community</p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-12 sm:py-16 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl sm:text-3xl font-bold mb-4">
            Join Our Teaching Team?
          </h2>
          <p className="text-lg text-blue-100 mb-6 max-w-2xl mx-auto">
            We're always looking for passionate educators to join our team.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/about"
              className="bg-white text-blue-700 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition duration-200"
            >
              Learn More
            </Link>
            <Link
              to="/login"
              className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-700 transition duration-200"
            >
              Teacher Login
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
