// src/pages/Gallery.jsx
import { useState, useEffect } from "react";
import { useWebsiteSettings } from "../../context/WebsiteSettingsContext";
import { db, collection, getDocs, query, orderBy } from "../../supabase/supabase";
import ImageLightbox from "../../components/ImageLightbox";
import { handleImageError } from "../../utils/imageFallback";

export default function Gallery() {
  const { settings, loading } = useWebsiteSettings();
  const gallerySettings = settings?.gallerySettings || {};
  const [images, setImages] = useState([]);
  const [albums, setAlbums] = useState([]);
  const [videos, setVideos] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [lightboxImage, setLightboxImage] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [displayCount, setDisplayCount] = useState(gallerySettings.displayCount || 12);
  const [loadingImages, setLoadingImages] = useState(true);
  const [activeTab, setActiveTab] = useState("photos");

  const fetchGalleryData = async () => {
    setLoadingImages(true);
    try {
      // Fetch images
      const imagesSnap = await getDocs(query(collection(db, "galleryImages"), orderBy("date", "desc")));
      const imagesData = imagesSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setImages(imagesData);

      // Fetch albums
      const albumsSnap = await getDocs(query(collection(db, "galleryAlbums"), orderBy("date", "desc")));
      const albumsData = albumsSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setAlbums(albumsData);

      // Fetch videos
      const videosSnap = await getDocs(query(collection(db, "galleryVideos"), orderBy("date", "desc")));
      const videosData = videosSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setVideos(videosData);
    } catch (error) {
      console.error("Error fetching gallery:", error);
    } finally {
      setLoadingImages(false);
    }
  };

  useEffect(() => {
     
    fetchGalleryData();
  }, []);

  const categories = gallerySettings.categories || [];

  const filteredImages = images.filter((img) => {
    const matchCategory = selectedCategory === "all" || img.category === selectedCategory;
    const matchSearch = img.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       img.description?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchCategory && matchSearch;
  });

  const displayedImages = filteredImages.slice(0, displayCount);
  const hasMore = filteredImages.length > displayCount;

  if (loading || loadingImages) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse">
            <div className="h-12 w-48 bg-gray-200 rounded mx-auto mb-4"></div>
            <div className="h-6 w-64 bg-gray-200 rounded mx-auto mb-8"></div>
            <div className="flex flex-wrap gap-2 justify-center mb-8">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="h-10 w-24 bg-gray-200 rounded-full"></div>
              ))}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                <div key={i} className="aspect-square bg-gray-200 rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-pink-600 to-purple-600 text-white py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="text-5xl mb-4">🖼️</div>
          <h1 className="text-3xl sm:text-4xl font-bold">
            {gallerySettings.title || "School Gallery"}
          </h1>
          <p className="text-pink-100 mt-2 max-w-2xl mx-auto">
            {gallerySettings.subtitle || "Explore our vibrant school community through photos and videos of academics, sports, events, and student achievements."}
          </p>
        </div>
      </section>

      {/* Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        <div className="flex flex-wrap gap-2 border-b border-gray-200 pb-4">
          <button
            onClick={() => setActiveTab("photos")}
            className={`px-6 py-3 rounded-lg font-medium transition ${
              activeTab === "photos"
                ? "bg-purple-600 text-white"
                : "bg-gray-200 text-gray-700 hover:bg-gray-300"
            }`}
          >
            📸 Photos
          </button>
          <button
            onClick={() => setActiveTab("albums")}
            className={`px-6 py-3 rounded-lg font-medium transition ${
              activeTab === "albums"
                ? "bg-purple-600 text-white"
                : "bg-gray-200 text-gray-700 hover:bg-gray-300"
            }`}
          >
            📁 Albums
          </button>
          <button
            onClick={() => setActiveTab("videos")}
            className={`px-6 py-3 rounded-lg font-medium transition ${
              activeTab === "videos"
                ? "bg-purple-600 text-white"
                : "bg-gray-200 text-gray-700 hover:bg-gray-300"
            }`}
          >
            🎬 Videos
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Photos Tab */}
        {activeTab === "photos" && (
          <>
            {/* Search & Filters */}
            <div className="flex flex-wrap items-center gap-4 mb-6">
              <div className="flex-1 min-w-[200px]">
                <input
                  type="text"
                  placeholder="🔍 Search Gallery..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-purple-500 outline-none"
                />
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setSelectedCategory("all")}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                    selectedCategory === "all"
                      ? "bg-purple-700 text-white"
                      : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                  }`}
                >
                  All
                </button>
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.name)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                      selectedCategory === cat.name
                        ? "bg-purple-700 text-white"
                        : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                    }`}
                  >
                    {cat.emoji || "📌"} {cat.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Photo Grid */}
            {displayedImages.length === 0 ? (
              <div className="bg-white rounded-xl shadow p-12 text-center">
                <div className="text-6xl mb-4">📭</div>
                <h3 className="text-xl font-semibold text-gray-700 mb-2">No Images Found</h3>
                <p className="text-gray-500">No images match your search criteria.</p>
              </div>
            ) : (
              <>
                <div className={`grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 ${
                  gallerySettings.layout === "masonry" ? "grid-flow-dense" : ""
                }`}>
                  {displayedImages.map((img) => (
                    <div
                      key={img.id}
                      className="group relative bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition cursor-pointer"
                      onClick={() => setLightboxImage(img)}
                    >
                      <div className="aspect-square bg-gray-200 overflow-hidden">
                        <img
                          src={img.imageUrl}
                          alt={img.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                          onError={(e) => handleImageError(e, "No image")}
                        />
                      </div>
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition duration-300 flex items-end">
                        <div className="p-4 text-white w-full">
                          <h3 className="font-bold text-sm truncate">{img.title}</h3>
                          {img.description && (
                            <p className="text-xs text-gray-300 truncate">{img.description}</p>
                          )}
                          <span className="text-xs text-gray-400">
                            {img.category} • {img.date ? new Date(img.date).toLocaleDateString() : ""}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Load More */}
                {hasMore && (
                  <div className="text-center mt-8">
                    <button
                      onClick={() => setDisplayCount(displayCount + 12)}
                      className="bg-purple-700 text-white px-8 py-3 rounded-lg hover:bg-purple-800 transition font-medium"
                    >
                      Load More
                    </button>
                  </div>
                )}
              </>
            )}
          </>
        )}

        {/* Albums Tab */}
        {activeTab === "albums" && (
          <>
            {albums.length === 0 ? (
              <div className="bg-white rounded-xl shadow p-12 text-center">
                <div className="text-6xl mb-4">📁</div>
                <h3 className="text-xl font-semibold text-gray-700 mb-2">No Albums Found</h3>
                <p className="text-gray-500">No albums have been created yet.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                {albums.map((album) => (
                  <div
                    key={album.id}
                    className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition cursor-pointer"
                  >
                    <div className="aspect-video bg-gray-200 relative">
                      {album.coverImage ? (
                        <img src={album.coverImage} alt={album.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-4xl text-gray-400">📁</div>
                      )}
                      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-3">
                        <p className="text-white text-sm font-medium">{album.name}</p>
                        <p className="text-white/70 text-xs">{album.photoCount || 0} photos</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {/* Videos Tab */}
        {activeTab === "videos" && (
          <>
            {videos.length === 0 ? (
              <div className="bg-white rounded-xl shadow p-12 text-center">
                <div className="text-6xl mb-4">🎬</div>
                <h3 className="text-xl font-semibold text-gray-700 mb-2">No Videos Found</h3>
                <p className="text-gray-500">No videos have been uploaded yet.</p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {videos.map((video) => (
                  <div key={video.id} className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition">
                    <div className="aspect-video bg-gray-900 relative">
                      {video.thumbnail ? (
                        <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-6xl text-gray-600">▶️</div>
                      )}
                      {video.link && (
                        <a
                          href={video.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="absolute inset-0 flex items-center justify-center hover:bg-black/20 transition"
                        >
                          <div className="w-16 h-16 bg-white/80 rounded-full flex items-center justify-center hover:bg-white transition">
                            <span className="text-3xl text-purple-700">▶</span>
                          </div>
                        </a>
                      )}
                    </div>
                    <div className="p-4">
                      <h3 className="font-bold text-gray-800">{video.title}</h3>
                      {video.description && (
                        <p className="text-sm text-gray-600 mt-1">{video.description}</p>
                      )}
                      <span className="text-xs text-gray-400 mt-2 block">
                        {video.category} • {video.date ? new Date(video.date).toLocaleDateString() : ""}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {/* Call to Action */}
        <section className="mt-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl p-8 text-center text-white">
          <h2 className="text-2xl font-bold mb-4">Want to become part of our school community?</h2>
          <div className="flex flex-wrap justify-center gap-4">
            <a href="/admissions" className="bg-white text-purple-700 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition">
              Apply Now
            </a>
            <a href="/contact" className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-purple-700 transition">
              Contact Us
            </a>
          </div>
        </section>
      </div>

      {/* Lightbox */}
      {lightboxImage && (
        <ImageLightbox
          image={lightboxImage}
          images={displayedImages}
          onClose={() => setLightboxImage(null)}
          onNext={() => {
            const currentIndex = displayedImages.findIndex(img => img.id === lightboxImage.id);
            const nextIndex = (currentIndex + 1) % displayedImages.length;
            setLightboxImage(displayedImages[nextIndex]);
          }}
          onPrev={() => {
            const currentIndex = displayedImages.findIndex(img => img.id === lightboxImage.id);
            const prevIndex = (currentIndex - 1 + displayedImages.length) % displayedImages.length;
            setLightboxImage(displayedImages[prevIndex]);
          }}
        />
      )}
    </div>
  );
}