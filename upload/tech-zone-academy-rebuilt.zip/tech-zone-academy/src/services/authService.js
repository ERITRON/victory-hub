import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
} from "../supabase/supabase";

import { auth } from "../supabase/supabase";

export const registerUser = (email, password) => {
  return createUserWithEmailAndPassword(
    auth,
    email,
    password
  );
};

export const loginUser = (email, password) => {
  return signInWithEmailAndPassword(
    auth,
    email,
    password
  );
};