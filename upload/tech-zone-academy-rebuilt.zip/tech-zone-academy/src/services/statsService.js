// src/services/statsService.js
import { supabase } from '../supabase/supabaseClient';

const CACHE_TTL_MS = 60_000;
const cache = new Map();

async function cachedCount(cacheKey, queryFn) {
  const cached = cache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
    return cached.value;
  }
  
  try {
    const value = await queryFn();
    cache.set(cacheKey, { value, timestamp: Date.now() });
    return value;
  } catch (error) {
    console.error(`Error fetching count for "${cacheKey}":`, error);
    return cached?.value ?? 0;
  }
}

export function invalidateStatsCache(key) {
  if (key) cache.delete(key);
  else cache.clear();
}

// Direct table counts
export const getCollectionCount = (tableName) =>
  cachedCount(`count:${tableName}`, async () => {
    const { count, error } = await supabase
      .from(tableName)
      .select('*', { count: 'exact', head: true });
    if (error) throw error;
    return count ?? 0;
  });

// User role counts
export const getUserCountByRole = (role) =>
  cachedCount(`count:users:role:${role}`, async () => {
    const { count, error } = await supabase
      .from('users')
      .select('*', { count: 'exact', head: true })
      .eq('role', role);
    if (error) throw error;
    return count ?? 0;
  });

export const getPendingApprovalsCount = () =>
  cachedCount('count:users:status:pending', async () => {
    const { count, error } = await supabase
      .from('users')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'pending');
    if (error) throw error;
    return count ?? 0;
  });

// School-wide stats
export async function getSchoolWideStats() {
  const [students, teachers, parents, pendingApprovals] = await Promise.all([
    getCollectionCount('students'),
    getCollectionCount('teachers'),
    getUserCountByRole('parent'),
    getPendingApprovalsCount(),
  ]);
  return { students, teachers, parents, pendingApprovals };
}

// Super Admin stats
export async function getSuperAdminStats() {
  const roles = ['owner', 'admin', 'teacher', 'parent', 'student'];
  const [counts, totalUsers] = await Promise.all([
    Promise.all(roles.map((r) => getUserCountByRole(r))),
    getCollectionCount('users'),
  ]);
  
  const statsData = { totalUsers };
  roles.forEach((r, i) => {
    statsData[`total${r.charAt(0).toUpperCase() + r.slice(1)}s`] = counts[i];
  });
  return statsData;
}