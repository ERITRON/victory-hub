export const NOTIFICATION_CATEGORIES = [
  "academic",
  "attendance",
  "financial",
  "administrative",
  "discipline",
  "library",
  "account",
];

// Which notification categories are relevant to each role, and how the
// notification center should introduce itself to them. RLS already
// guarantees a user's `notifications` rows only ever contain their own
// data — this just keeps the filter tabs and empty-state copy focused
// on what that role actually receives, instead of a one-size-fits-all
// list with tabs that can never have anything in them (e.g. a student
// would never see a "Library" tab unless they have library activity).
const CATEGORY_LABELS = {
  academic: "Academic",
  attendance: "Attendance",
  financial: "Financial",
  administrative: "Announcements",
  discipline: "Discipline",
  library: "Library",
  account: "Account",
};

const ROLE_NOTIFICATION_CONFIG = {
  student: {
    categories: ["academic", "attendance", "library", "administrative", "account"],
    subtitle: "Results, attendance, assignments, and school announcements.",
    emptyMessage: "New results, attendance updates, and announcements will appear here.",
  },
  parent: {
    categories: ["academic", "attendance", "discipline", "administrative", "account"],
    subtitle: "Updates about your children's attendance, results, and school announcements.",
    emptyMessage: "Updates about your children will appear here.",
  },
  teacher: {
    categories: ["academic", "attendance", "discipline", "administrative", "account"],
    subtitle: "Assignment submissions, schedule changes, and school announcements.",
    emptyMessage: "Assignment submissions and school updates will appear here.",
  },
  librarian: {
    categories: ["library", "administrative", "account"],
    subtitle: "Library activity, overdue books, and school announcements.",
    emptyMessage: "Library activity will appear here.",
  },
  vice_principal: {
    categories: ["attendance", "discipline", "administrative", "account"],
    subtitle: "Attendance flags, discipline cases, and administrative tasks.",
    emptyMessage: "Attendance and discipline updates will appear here.",
  },
  admin: {
    categories: ["administrative", "attendance", "discipline", "account"],
    subtitle: "Registrations awaiting approval, discipline reports, and school updates.",
    emptyMessage: "New registrations and school updates will appear here.",
  },
  owner: {
    categories: ["administrative", "academic", "account"],
    subtitle: "Enrollment, performance, and school-wide updates.",
    emptyMessage: "School-wide reports and updates will appear here.",
  },
};

const DEFAULT_ROLE_CONFIG = {
  categories: NOTIFICATION_CATEGORIES,
  subtitle: "Account, academic, attendance, and school updates in one place.",
  emptyMessage: "New updates will appear here.",
};

export function getRoleNotificationConfig(role) {
  return ROLE_NOTIFICATION_CONFIG[role] || DEFAULT_ROLE_CONFIG;
}

export function getRoleNotificationFilters(role) {
  const { categories } = getRoleNotificationConfig(role);
  return categories.map((value) => ({ value, label: CATEGORY_LABELS[value] || value }));
}

const CATEGORY_STYLES = {
  academic: { icon: "\u{1F4DA}", iconClass: "bg-blue-100 text-blue-700", dotClass: "bg-blue-600" },
  attendance: { icon: "\u{1F4CB}", iconClass: "bg-amber-100 text-amber-800", dotClass: "bg-amber-500" },
  financial: { icon: "\u{1F4B3}", iconClass: "bg-emerald-100 text-emerald-700", dotClass: "bg-emerald-600" },
  administrative: { icon: "\u{1F4E2}", iconClass: "bg-violet-100 text-violet-700", dotClass: "bg-violet-600" },
  discipline: { icon: "\u26A0\uFE0F", iconClass: "bg-red-100 text-red-700", dotClass: "bg-red-600" },
  library: { icon: "\u{1F4D6}", iconClass: "bg-cyan-100 text-cyan-800", dotClass: "bg-cyan-600" },
  account: { icon: "\u{1F464}", iconClass: "bg-gray-100 text-gray-700", dotClass: "bg-gray-500" },
};

const FALLBACK_STYLE = {
  icon: "\u{1F514}",
  iconClass: "bg-gray-100 text-gray-700",
  dotClass: "bg-gray-500",
};

export function getNotificationStyle(notification) {
  const style = CATEGORY_STYLES[notification?.category] ?? FALLBACK_STYLE;
  return { ...style, icon: notification?.icon || style.icon };
}

export function toDate(value) {
  if (!value) return null;
  if (value instanceof Date) return value;
  if (typeof value.toDate === "function") return value.toDate();
  if (typeof value.seconds === "number") return new Date(value.seconds * 1000);
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

export function formatNotificationTime(value, relative = false) {
  const date = toDate(value);
  if (!date) return "Just now";

  if (!relative) {
    return new Intl.DateTimeFormat(undefined, {
      dateStyle: "medium",
      timeStyle: "short",
    }).format(date);
  }

  const seconds = Math.max(0, Math.floor((Date.now() - date.getTime()) / 1000));
  if (seconds < 60) return "Just now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  const weeks = Math.floor(days / 7);
  return weeks < 5 ? `${weeks}w ago` : formatNotificationTime(date);
}

export function normalizeNotification(id, data = {}) {
  return {
    id,
    userId: data.userId ?? "",
    type: data.type ?? "system",
    title: data.title ?? "Notification",
    message: data.message ?? "",
    body: data.body ?? data.message ?? "",
    link: data.link ?? null,
    read: data.read === true,
    readAt: data.readAt ?? null,
    createdAt: data.createdAt ?? null,
    expiresAt: data.expiresAt ?? null,
    priority: ["normal", "high", "urgent"].includes(data.priority)
      ? data.priority
      : "normal",
    category: NOTIFICATION_CATEGORIES.includes(data.category)
      ? data.category
      : "administrative",
    icon: data.icon ?? null,
    color: data.color ?? null,
    relatedId: data.relatedId ?? null,
    relatedType: data.relatedType ?? null,
    action: data.action ?? null,
    actionLabel: data.actionLabel ?? null,
    sender: data.sender ?? "Tech Zone Academy",
    senderId: data.senderId ?? null,
    channels: Array.isArray(data.channels) ? data.channels : ["in_app"],
  };
}

export function isNotificationExpired(notification) {
  const expiry = toDate(notification.expiresAt);
  return expiry ? expiry.getTime() <= Date.now() : false;
}
