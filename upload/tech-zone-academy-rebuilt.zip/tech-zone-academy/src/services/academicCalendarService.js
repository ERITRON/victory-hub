// src/services/academicCalendarService.js
import { db, collection, query, where, orderBy, getDocs, addDoc, updateDoc, doc } from "../supabase/supabase";

const snap = (snapshot) => snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));

export async function getCurrentSemester() {
  const snapshot = await getDocs(query(collection(db, "semesters"), where("status", "==", "active")));
  const rows = snap(snapshot);
  if (rows.length === 0) return null;
  const semester = rows[0];
  const yearSnapshot = await getDocs(query(collection(db, "academicYears"), where("id", "==", semester.academicYearId)));
  const year = snap(yearSnapshot)[0];
  return { ...semester, academicYearLabel: year?.label || "" };
}

export async function getAllSemesters() {
  const snapshot = await getDocs(query(collection(db, "semesters"), orderBy("createdAt", "desc")));
  return snap(snapshot);
}

export async function getGradeOrder() {
  const snapshot = await getDocs(query(collection(db, "grades"), orderBy("displayOrder", "asc")));
  return snap(snapshot).map((g) => g.name);
}

export function getNextGrade(gradeOrder, currentGrade) {
  const index = gradeOrder.indexOf(currentGrade);
  if (index === -1 || index === gradeOrder.length - 1) return null; // unknown or already the highest grade
  return gradeOrder[index + 1];
}

/**
 * Ends Semester 1 and opens Semester 2 within the same academic year.
 * Does NOT touch student grades/sections -- that only happens at
 * year-end via runPromotionAndStartNewYear().
 */
export async function endSemesterOneStartSemesterTwo(currentSemester, actingUserId) {
  await updateDoc(doc(db, "semesters", currentSemester.id), { status: "ended" });
  await addDoc(collection(db, "semesters"), {
    academicYearId: currentSemester.academicYearId,
    name: "Semester 2",
    termNumber: 2,
    status: "active",
    createdBy: actingUserId,
  });
}

function nextAcademicYearLabel(label) {
  // "2025/2026" -> "2026/2027"; falls back to appending if the format
  // doesn't match what's expected.
  const match = /^(\d{4})\/(\d{4})$/.exec(label || "");
  if (!match) return `${label || "Year"} (new)`;
  const start = parseInt(match[1], 10) + 1;
  const end = parseInt(match[2], 10) + 1;
  return `${start}/${end}`;
}

/**
 * Ends the current academic year (locks its final semester, archives
 * the year), applies the admin's reviewed promotion decisions, logs a
 * permanent promotion_records entry per student, and opens Semester 1
 * of a brand new academic year.
 *
 * @param {object} currentSemester - the currently active semester row
 * @param {Array<{studentId, fromGrade, fromSection, decision, toGrade, toSection}>} decisions
 * @param {string} actingUserId
 */
export async function runPromotionAndStartNewYear(currentSemester, decisions, actingUserId) {
  // 1. Lock the outgoing semester + archive the outgoing year.
  await updateDoc(doc(db, "semesters", currentSemester.id), { status: "ended" });
  await updateDoc(doc(db, "academicYears", currentSemester.academicYearId), { status: "archived", endedAt: new Date().toISOString() });

  const yearSnapshot = await getDocs(query(collection(db, "academicYears"), where("id", "==", currentSemester.academicYearId)));
  const outgoingYear = snap(yearSnapshot)[0];

  // 2. Create the new academic year + its first semester.
  const newYearRef = await addDoc(collection(db, "academicYears"), {
    label: nextAcademicYearLabel(outgoingYear?.label),
    status: "active",
    createdBy: actingUserId,
  });
  await addDoc(collection(db, "semesters"), {
    academicYearId: newYearRef.id,
    name: "Semester 1",
    termNumber: 1,
    status: "active",
    createdBy: actingUserId,
  });

  // 3. Apply each promotion decision + log a permanent record.
  const results = { succeeded: 0, failed: [] };
  for (const decision of decisions) {
    try {
      await addDoc(collection(db, "promotionRecords"), {
        studentId: decision.studentId,
        academicYearId: newYearRef.id,
        fromGrade: decision.fromGrade,
        fromSection: decision.fromSection,
        toGrade: decision.decision === "promoted" || decision.decision === "repeated" ? decision.toGrade : null,
        toSection: decision.decision === "promoted" || decision.decision === "repeated" ? decision.toSection : null,
        decision: decision.decision,
        decidedBy: actingUserId,
      });

      if (decision.decision === "promoted" || decision.decision === "repeated") {
        await updateDoc(doc(db, "students", decision.studentId), {
          grade: decision.toGrade,
          section: decision.toSection,
        });
      } else if (decision.decision === "graduated" || decision.decision === "transferred_out") {
        await updateDoc(doc(db, "students", decision.studentId), { status: "inactive" });
      }
      results.succeeded += 1;
    } catch (error) {
      results.failed.push({ studentId: decision.studentId, error: error.message });
    }
  }

  return { newAcademicYearId: newYearRef.id, ...results };
}
