// src/services/adminService.js
//
// Thin wrapper around the createStudent/createTeacher/createParent/
// deleteAccount Supabase Edge Functions (supabase/functions/*/index.ts).
// Each function creates/deletes the Auth login and matching table rows
// server-side with the service-role key, so the browser never needs
// admin credentials and the admin's own session is never disturbed.
// Used by src/pages/{students,teachers,parents}/Add*.jsx and the
// delete buttons on TeacherList/SectionStudents/ParentManagement.
import { supabase } from "../supabase/supabaseClient";

async function invoke(functionName, payload) {
  const { data, error } = await supabase.functions.invoke(functionName, {
    body: payload,
  });
  if (error) {
    // The edge functions always return { success: false, error: "..." }
    // as the response body on failure — read that first so the person
    // sees the actual reason (invalid phone, duplicate email, blocked
    // by dependent records, etc.) instead of a generic status message.
    let message = null;
    try {
      const body = await error.context?.json?.();
      message = body?.error || null;
    } catch {
      // response body wasn't JSON (e.g. network failure) — fall through
    }

    if (!message) {
      const status = error.context?.status;
      if (status === 401) message = "You must be logged in to perform this action.";
      else if (status === 403) message = "You don't have permission to perform this action.";
      else message = error.message || `Failed to call ${functionName}. Please try again.`;
    }

    throw new Error(message, { cause: error });
  }
  return data;
}

/**
 * Create a new student using a Supabase Edge Function
 * @param {Object} studentData - The student data
 * @returns {Promise<Object>} - Response from the edge function
 */
export const createStudent = async (studentData) => {
  try {
    return await invoke("createStudent", studentData);
  } catch (error) {
    console.error("Error creating student:", error);
    throw error;
  }
};

/**
 * Create a new teacher using a Supabase Edge Function
 * @param {Object} teacherData - The teacher data
 * @returns {Promise<Object>} - Response from the edge function
 */
export const createTeacher = async (teacherData) => {
  try {
    return await invoke("createTeacher", teacherData);
  } catch (error) {
    console.error("Error creating teacher:", error);
    throw error;
  }
};

/**
 * Create a new parent using a Supabase Edge Function
 * @param {Object} parentData - The parent data
 * @returns {Promise<Object>} - Response from the edge function
 */
export const createParent = async (parentData) => {
  try {
    return await invoke("createParent", parentData);
  } catch (error) {
    console.error("Error creating parent:", error);
    throw error;
  }
};

/**
 * Delete a teacher/student/parent account (role row, users row, and
 * the Supabase Auth login) using a Supabase Edge Function.
 * @param {string} userId - the account's id (== auth uid)
 * @param {"teacher"|"student"|"parent"} role
 * @returns {Promise<Object>} - Response from the edge function
 */
export const deleteAccount = async (userId, role) => {
  try {
    return await invoke("deleteAccount", { userId, role });
  } catch (error) {
    console.error(`Error deleting ${role}:`, error);
    throw error;
  }
};
