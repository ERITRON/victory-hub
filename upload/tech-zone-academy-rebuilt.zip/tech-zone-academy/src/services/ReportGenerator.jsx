// src/services/ReportGenerator.jsx
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';

export default class ReportGenerator {
  constructor() {
    this.companyName = 'Tech Zone Academy';
    this.companyAddress = 'Addis Ababa, Ethiopia';
  }

  // Generate PDF Report
  generatePDF(title, headers, data) {
    const doc = new jsPDF('p', 'mm', 'a4');
    
    // Add header
    doc.setFontSize(20);
    doc.text(this.companyName, 14, 22);
    
    doc.setFontSize(12);
    doc.text(this.companyAddress, 14, 30);
    
    doc.setFontSize(16);
    doc.text(title, 14, 40);
    
    // Add date
    doc.setFontSize(10);
    doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 48);
    
    // Add table
    doc.autoTable({
      startY: 55,
      head: [headers],
      body: data.map(row => Object.values(row)),
      theme: 'striped',
      styles: { fontSize: 8 },
      headStyles: { fillColor: [41, 128, 185] },
    });
    
    // Add footer
    const pageCount = doc.internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setFontSize(8);
      doc.text(
        `Page ${i} of ${pageCount}`,
        doc.internal.pageSize.width / 2,
        doc.internal.pageSize.height - 10,
        { align: 'center' }
      );
    }
    
    return doc;
  }

  // Generate Excel Report
  generateExcel(headers, data, sheetName = 'Report') {
    const workbook = XLSX.utils.book_new();
    
    // Format data for Excel
    const excelData = data.map(row => {
      const rowData = {};
      headers.forEach((header, index) => {
        const key = Object.keys(row)[index];
        rowData[header] = row[key];
      });
      return rowData;
    });
    
    const worksheet = XLSX.utils.json_to_sheet(excelData);
    XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
    
    return workbook;
  }

  // Generate CSV
  generateCSV(headers, data) {
    const csvRows = [];
    
    // Add headers
    csvRows.push(headers.join(','));
    
    // Add data rows
    data.forEach(row => {
      const values = Object.values(row);
      csvRows.push(values.join(','));
    });
    
    return csvRows.join('\n');
  }

  // Download report
  downloadReport(report, filename, type = 'pdf') {
    let blob;
    
    switch(type) {
      case 'pdf':
        blob = report.output('blob');
        break;
      case 'xlsx':
        blob = XLSX.write(report, { bookType: 'xlsx', type: 'array' });
        blob = new Blob([blob], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        break;
      case 'csv':
        blob = new Blob([report], { type: 'text/csv' });
        break;
      default:
        throw new Error('Unsupported report type');
    }
    
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filename}.${type}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  // Generate Attendance Report
  generateAttendanceReport(data) {
    const summary = {
      totalDays: data.length,
      present: data.filter(row => row.status === 'Present').length,
      absent: data.filter(row => row.status === 'Absent').length,
      late: data.filter(row => row.status === 'Late').length,
      excused: data.filter(row => row.status === 'Excused').length,
      attendanceRate: 0,
    };
    
    summary.attendanceRate = (summary.present / summary.totalDays) * 100;
    
    return {
      summary,
      details: data,
    };
  }
}

export const REPORT_TYPES = {
  REVENUE: 'revenue',
  ATTENDANCE: 'attendance',
  STUDENT: 'student',
  TEACHER: 'teacher',
  FINANCIAL: 'financial',
  ACADEMIC: 'academic',
};