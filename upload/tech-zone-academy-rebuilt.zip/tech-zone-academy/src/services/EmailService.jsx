// src/services/EmailService.jsx
import { db, collection, addDoc, getDocs, query, where } from "../supabase/supabase";

class EmailService {
  constructor() {
    this.isConfigured = false;
    this.senderEmail = null;
    this.senderName = null;
    this.emailProvider = null;
  }

  // Initialize email service
  initialize(provider, senderEmail, senderName) {
    this.emailProvider = provider;
    this.senderEmail = senderEmail || 'no-reply@techzone.com';
    this.senderName = senderName || 'Tech Zone Academy';
    this.isConfigured = true;
  }

  // Send email
  async sendEmail(to, subject, htmlContent, textContent = null) {
    if (!this.isConfigured) {
      console.warn('Email service not configured');
      return false;
    }

    try {
      const result = await this.sendViaProvider(to, subject, htmlContent, textContent);
      
      // Log email in database
      await this.logEmail(to, subject, result);
      
      return result;
    } catch (error) {
      console.error('Email sending failed:', error);
      return false;
    }
  }

  // Send via provider
  async sendViaProvider(to, subject) {
    console.log(`Sending email to ${to}: ${subject}`);
    
    // For demo, simulate sending
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return {
      success: true,
      messageId: `EMAIL-${Date.now()}`,
      to,
      subject,
      timestamp: new Date().toISOString(),
    };
  }

  // Send email with attachment
  async sendEmailWithAttachment(to, subject, htmlContent, attachments, textContent = null) {
    // Implementation for sending emails with attachments
    return this.sendEmail(to, subject, htmlContent, textContent);
  }

  // Log email to database
  async logEmail(to, subject, result) {
    try {
      await addDoc(collection(db, 'emailLogs'), {
        to,
        subject,
        status: result.success ? 'sent' : 'failed',
        messageId: result.messageId || null,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Error logging email:', error);
    }
  }

  // Get email logs
  async getEmailLogs(filters = {}) {
    try {
      let q = collection(db, 'emailLogs');
      const constraints = [];

      if (filters.to) {
        constraints.push(where('to', '==', filters.to));
      }
      if (filters.status) {
        constraints.push(where('status', '==', filters.status));
      }

      const queryRef = query(q, ...constraints);
      const snapshot = await getDocs(queryRef);
      
      return snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
      }));
    } catch (error) {
      console.error('Error fetching email logs:', error);
      return [];
    }
  }
}

// Email Templates
export const EMAIL_TEMPLATES = {
  reportCard: (studentName, grade, semester, results) => `
    <h1>Report Card - ${semester}</h1>
    <p>Dear ${studentName},</p>
    <p>Here is your report card for ${grade} - ${semester}:</p>
    <table style="border-collapse: collapse; width: 100%;">
      <tr>
        <th style="border: 1px solid #ddd; padding: 8px;">Subject</th>
        <th style="border: 1px solid #ddd; padding: 8px;">Score</th>
        <th style="border: 1px solid #ddd; padding: 8px;">Grade</th>
      </tr>
      ${results.map(r => `
        <tr>
          <td style="border: 1px solid #ddd; padding: 8px;">${r.subject}</td>
          <td style="border: 1px solid #ddd; padding: 8px;">${r.score}</td>
          <td style="border: 1px solid #ddd; padding: 8px;">${r.grade}</td>
        </tr>
      `).join('')}
    </table>
    <p>Continue working hard!</p>
    <p>Best regards,<br>Tech Zone Academy</p>
  `,

  admissionStatus: (studentName, status, message) => `
    <h1>Admission Update</h1>
    <p>Dear ${studentName},</p>
    <p>Your admission application has been <strong>${status}</strong>.</p>
    <p>${message}</p>
    <p>Best regards,<br>Tech Zone Academy</p>
  `,

  announcement: (title, content) => `
    <h1>${title}</h1>
    <p>${content}</p>
    <p>Best regards,<br>Tech Zone Academy</p>
  `,
};

export default new EmailService();