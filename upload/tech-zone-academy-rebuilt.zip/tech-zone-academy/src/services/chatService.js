// src/services/chatService.js
import {
  db,
  collection,
  query,
  where,
  getDocs,
  getDoc,
  doc,
  addDoc,
  updateDoc,
} from "../supabase/supabase";

const snap = (snapshot) => snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));

/**
 * Finds the homeroom teacher (as a real users.id) for a given student
 * row, or null if that grade/section has no homeroom teacher assigned.
 */
export async function getHomeroomTeacherForStudent(student) {
  if (!student?.grade || !student?.section) return null;
  const snapshot = await getDocs(
    query(
      collection(db, "homeroomAssignments"),
      where("grade", "==", student.grade),
      where("section", "==", student.section)
    )
  );
  if (snapshot.empty) return null;
  const assignment = snap(snapshot)[0];
  const teacherDoc = await getDoc(doc(db, "teachers", assignment.teacherId));
  if (!teacherDoc.exists()) return null;
  const teacher = teacherDoc.data();
  return { userId: teacher.userId, fullName: teacher.fullName, teacherRowId: assignment.teacherId };
}

/**
 * Finds an existing direct conversation between two users, or creates
 * one. RLS is the real gatekeeper here (parent -> homeroom teacher
 * only) -- this just implements the "don't create duplicate threads"
 * convenience on top.
 */
export async function findOrCreateDirectConversation(userId, otherUserId) {
  const mine = await getDocs(query(collection(db, "chatParticipants"), where("userId", "==", userId)));
  const myConversationIds = snap(mine).map((p) => p.conversationId);

  if (myConversationIds.length > 0) {
    const theirs = await getDocs(
      query(collection(db, "chatParticipants"), where("userId", "==", otherUserId), where("conversationId", "in", myConversationIds))
    );
    for (const participant of snap(theirs)) {
      const convoDoc = await getDoc(doc(db, "chatConversations", participant.conversationId));
      if (convoDoc.exists() && convoDoc.data().type === "direct") {
        return participant.conversationId;
      }
    }
  }

  const conversationRef = await addDoc(collection(db, "chatConversations"), {
    type: "direct",
    createdBy: userId,
  });
  await Promise.all([
    addDoc(collection(db, "chatParticipants"), { conversationId: conversationRef.id, userId, role: "member" }),
    addDoc(collection(db, "chatParticipants"), { conversationId: conversationRef.id, userId: otherUserId, role: "member" }),
  ]);
  return conversationRef.id;
}

/**
 * Creates (or updates) the grade/section group chat for a class,
 * setting the homeroom teacher as head and adding every student +
 * linked parent in that class as a member. Call this after assigning
 * or reassigning a homeroom teacher. Staff-only (relies on is_staff()
 * RLS bypass to add arbitrary participants).
 */
export async function provisionGradeGroupChat(grade, section, teacherUserId, actingUserId) {
  const existingSnapshot = await getDocs(
    query(collection(db, "chatConversations"), where("type", "==", "grade_group"), where("grade", "==", grade), where("section", "==", section))
  );

  let conversationId;
  if (existingSnapshot.empty) {
    const conversationRef = await addDoc(collection(db, "chatConversations"), {
      type: "grade_group",
      grade,
      section,
      title: `${grade} - Section ${section}`,
      createdBy: actingUserId,
    });
    conversationId = conversationRef.id;
  } else {
    conversationId = snap(existingSnapshot)[0].id;
  }

  const participantsSnapshot = await getDocs(query(collection(db, "chatParticipants"), where("conversationId", "==", conversationId)));
  const participants = snap(participantsSnapshot);
  const existingByUserId = new Map(participants.map((p) => [p.userId, p]));

  // Demote any previous head, promote/add the new one.
  await Promise.all(
    participants
      .filter((p) => p.role === "head" && p.userId !== teacherUserId)
      .map((p) => updateDoc(doc(db, "chatParticipants", p.id), { role: "member" }))
  );
  if (existingByUserId.has(teacherUserId)) {
    await updateDoc(doc(db, "chatParticipants", existingByUserId.get(teacherUserId).id), { role: "head" });
  } else {
    await addDoc(collection(db, "chatParticipants"), { conversationId, userId: teacherUserId, role: "head" });
  }

  // Add every student (with a linked account) and their parent(s).
  const studentsSnapshot = await getDocs(
    query(collection(db, "students"), where("grade", "==", grade), where("section", "==", section))
  );
  const students = snap(studentsSnapshot).filter((s) => s.userId);

  const linksSnapshot = await getDocs(
    query(collection(db, "parentChildren"), where("studentId", "in", students.length ? students.map((s) => s.id) : ["__none__"]))
  );
  const parentRowIds = [...new Set(snap(linksSnapshot).map((l) => l.parentId))];
  const parentRows = parentRowIds.length
    ? snap(await getDocs(query(collection(db, "parents"), where("id", "in", parentRowIds))))
    : [];

  const memberUserIds = [
    ...students.map((s) => s.userId),
    ...parentRows.map((p) => p.userId).filter(Boolean),
  ].filter((uid) => uid && !existingByUserId.has(uid));

  await Promise.all(
    [...new Set(memberUserIds)].map((userId) =>
      addDoc(collection(db, "chatParticipants"), { conversationId, userId, role: "member" })
    )
  );

  return conversationId;
}

export async function sendMessage(conversationId, senderId, body, attachment) {
  await addDoc(collection(db, "chatMessages"), {
    conversationId,
    senderId,
    body: body || null,
    attachmentUrl: attachment?.url || null,
    attachmentName: attachment?.name || null,
  });
}

export async function markConversationRead(conversationId, userId) {
  const snapshot = await getDocs(
    query(collection(db, "chatParticipants"), where("conversationId", "==", conversationId), where("userId", "==", userId))
  );
  const rows = snap(snapshot);
  if (rows.length > 0) {
    await updateDoc(doc(db, "chatParticipants", rows[0].id), { lastReadAt: new Date().toISOString() });
  }
}

export async function setParticipantMuted(participantRowId, muted) {
  await updateDoc(doc(db, "chatParticipants", participantRowId), { muted });
}

export async function toggleAnnouncementOnly(conversationId, value) {
  await updateDoc(doc(db, "chatConversations", conversationId), { announcementOnly: value });
}

export async function pinMessage(messageId, pinned) {
  await updateDoc(doc(db, "chatMessages", messageId), { pinned });
}

export async function softDeleteMessage(messageId) {
  await updateDoc(doc(db, "chatMessages", messageId), { deletedAt: new Date().toISOString() });
}
