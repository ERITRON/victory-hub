// src/context/WebsiteSettingsContext.jsx
import { createContext, useContext, useState, useEffect } from "react";
import { db, doc, getDoc, collection, getDocs, setDoc } from "../supabase/supabase";

const WebsiteSettingsContext = createContext();

const defaultSettings = {
  schoolInfo: {
    schoolName: "Tech Zone Academy",
    academicYear: "2026",
    phone: "+251 9XX XXX XXX",
    secondaryPhone: "",
    email: "info@techzone.com",
    address: "Addis Ababa, Ethiopia",
    addressLine2: "",
    workingHours: "Mon-Fri: 8:00 AM - 5:00 PM",
    saturdayHours: "",
    motto: "Building Bright Futures",
    principal: "",
    mapEmbedUrl: "",
  },
  hero: {
    schoolName: "Tech Zone Academy",
    tagline: "Building Bright Futures",
    description: "KG-3 to Grade 8 | Quality Education for Every Child",
    buttonText: "Apply Now",
    buttonLink: "/admissions",
    backgroundImage: "",
    overlayColor: "from-blue-600 to-blue-800",
    height: "py-20",
    alignment: "center",
    animation: "fade-in",
    overlayOpacity: "70",
    cards: [
      { id: "1", icon: "📚", title: "Quality Education", description: "Modern curriculum designed for academic excellence" },
      { id: "2", icon: "👨‍🏫", title: "Expert Teachers", description: "Qualified educators dedicated to student success" },
      { id: "3", icon: "💻", title: "Smart Learning", description: "Technology-integrated classrooms for better learning" },
      { id: "4", icon: "🏅", title: "Extracurricular", description: "Sports, arts, and clubs for holistic development" },
    ]
  },
  
  // ============================================
  // FLAT ABOUT SETTINGS (Not nested under "about")
  // ============================================
  aboutLabel: "ABOUT US",
  aboutTitle: "About Tech Zone Academy",
  aboutSubtitle: "Building Bright Futures Through Quality Education",
  aboutDescription: "Tech Zone Academy is a premier educational institution dedicated to nurturing young minds with innovative teaching methods and a commitment to excellence.",
  aboutDescription2: "Our mission is to provide quality education that prepares students for the challenges of tomorrow.",
  aboutImage: "/images/about-default.jpg",
  aboutStudentsLabel: "Students",
  aboutStudentsValue: "500+",
  aboutTeachersLabel: "Teachers",
  aboutTeachersValue: "30+",
  aboutSuccessLabel: "Success Rate",
  aboutSuccessValue: "95%",
  aboutYearsLabel: "Years of Excellence",
  aboutYearsValue: "10+",
  aboutButtonText: "Learn More →",
  aboutButtonLink: "/about",
  
  // Mission, Vision, Values
  aboutMissionTitle: "Our Mission",
  aboutMission: "To provide quality education that nurtures intellectual curiosity, critical thinking, and character development.",
  aboutVisionTitle: "Our Vision",
  aboutVision: "To become a leading educational institution that empowers students with knowledge, skills, and values to excel.",
  aboutValuesTitle: "Core Values",
  
  // Features
  aboutFeatures: [
    { icon: "📚", title: "Modern Curriculum", description: "Up-to-date educational programs designed for academic excellence." },
    { icon: "👨‍🏫", title: "Expert Teachers", description: "Qualified and experienced educators dedicated to student success." },
    { icon: "💻", title: "Technology Integration", description: "Smart classrooms and digital learning resources." },
    { icon: "🎯", title: "Student-Centered", description: "Personalized attention and support for each learner's unique needs." },
  ],
  
  // Core Values
  aboutCoreValues: [
    { icon: "🌟", title: "Excellence", description: "Striving for the highest standards in education" },
    { icon: "🤝", title: "Community", description: "Building strong partnerships with parents and community" },
    { icon: "💡", title: "Innovation", description: "Embracing new ideas and modern teaching methods" },
    { icon: "🧠", title: "Integrity", description: "Instilling honesty, respect, and responsibility" },
  ],
  
  // Team Members
  aboutTeamMembers: [
    { name: "Dr. Sarah Johnson", role: "School Director", bio: "PhD in Education with 20+ years of experience." },
    { name: "Mr. David Smith", role: "Head of Academics", bio: "Masters in Curriculum Development." },
    { name: "Ms. Emily Brown", role: "Head of Student Affairs", bio: "Passionate about student welfare and development." },
    { name: "Mr. James Wilson", role: "Head of Technology", bio: "Expert in educational technology integration." },
  ],
  
  // History Timeline
  aboutHistoryTimeline: [
    { year: "2015", title: "Foundation", description: "Tech Zone Academy was established with 50 students." },
    { year: "2017", title: "Expansion", description: "Expanded to include high school programs." },
    { year: "2019", title: "Innovation", description: "Introduced digital learning and smart classrooms." },
    { year: "2021", title: "Excellence", description: "Received National Quality Education Award." },
    { year: "2023", title: "Global Reach", description: "Launched international exchange programs." },
  ],
  
  // CTA Section
  aboutCtaTitle: "Ready to Join Us?",
  aboutCtaDescription: "Give your child the best education. Enroll today at Tech Zone Academy.",
  aboutCtaButton1Text: "Apply Now",
  aboutCtaButton1Link: "/admissions",
  aboutCtaButton2Text: "Contact Us",
  aboutCtaButton2Link: "/contact",

  statistics: {
    enabled: true,
    students: { icon: "👨‍🎓", label: "Students", value: "0", manual: false },
    teachers: { icon: "👨‍🏫", label: "Teachers", value: "0", manual: false },
    parents: { icon: "👨‍👩‍👦", label: "Parents", value: "0", manual: false },
    grades: { icon: "📚", label: "Grades", value: "0", manual: false },
    years: { icon: "⭐", label: "Years of Excellence", value: "5+", manual: true },
  },
  newsSettings: {
    enabled: true,
    title: "Latest News",
    subtitle: "Stay updated with our latest announcements",
    cardCount: 6,
    categories: [
      { id: "1", name: "Announcement", emoji: "📢", color: "bg-blue-100 text-blue-700" },
      { id: "2", name: "Event", emoji: "🎉", color: "bg-purple-100 text-purple-700" },
      { id: "3", name: "Academic", emoji: "📚", color: "bg-green-100 text-green-700" },
      { id: "4", name: "Sports", emoji: "🏅", color: "bg-orange-100 text-orange-700" },
      { id: "5", name: "Achievement", emoji: "🏆", color: "bg-yellow-100 text-yellow-700" },
    ]
  },
  gallerySettings: {
    title: "School Gallery",
    subtitle: "A glimpse into our vibrant school life",
    layout: "masonry",
    displayCount: 12,
    categories: [
      { id: "1", name: "Campus", emoji: "🏫" },
      { id: "2", name: "Graduation", emoji: "🎓" },
      { id: "3", name: "Classroom Activities", emoji: "📚" },
      { id: "4", name: "Science Laboratory", emoji: "🧪" },
      { id: "5", name: "Computer Lab", emoji: "💻" },
      { id: "6", name: "Sports", emoji: "⚽" },
      { id: "7", name: "Cultural Events", emoji: "🎭" },
      { id: "8", name: "Music & Arts", emoji: "🎵" },
      { id: "9", name: "Clubs", emoji: "🌱" },
      { id: "10", name: "Educational Trips", emoji: "🚌" },
      { id: "11", name: "Teachers", emoji: "👨‍🏫" },
      { id: "12", name: "Awards & Achievements", emoji: "🏆" },
      { id: "13", name: "Celebrations", emoji: "🎉" },
      { id: "14", name: "Library", emoji: "📖" },
      { id: "15", name: "Community Service", emoji: "🕌" },
    ]
  },
  eventsSettings: {
    title: "School Events",
    subtitle: "Stay updated with upcoming events and activities",
    categories: [
      { id: "1", name: "Academic", color: "bg-blue-100 text-blue-700" },
      { id: "2", name: "Sports", color: "bg-green-100 text-green-700" },
      { id: "3", name: "Cultural", color: "bg-purple-100 text-purple-700" },
      { id: "4", name: "Holiday", color: "bg-red-100 text-red-700" },
    ]
  },
  footer: {
    address: "Addis Ababa, Ethiopia",
    phone: "+251 9XX XXX XXX",
    email: "info@techzone.com",
    workingHours: "Mon-Fri: 8:00 AM - 5:00 PM",
    copyright: "Tech Zone Academy. All rights reserved.",
    social: {
      facebook: "",
      twitter: "",
      instagram: "",
      youtube: "",
      telegram: "",
      tiktok: "",
      linkedin: "",
    }
  },
  navigation: {
    logo: "",
    websiteName: "Tech Zone Academy",
    sticky: true,
    backgroundColor: "from-blue-700 to-blue-800",
    textColor: "text-white",
    hoverColor: "hover:bg-blue-600",
    items: [
      { id: "1", label: "Home", path: "/", enabled: true },
      { id: "2", label: "About", path: "/about", enabled: true },
      { id: "3", label: "Admissions", path: "/admissions", enabled: true },
      { id: "4", label: "Student", path: "/student", enabled: true },
      { id: "5", label: "Teacher", path: "/teacher", enabled: true },
      { id: "6", label: "Parent", path: "/parent", enabled: true },
      { id: "7", label: "News", path: "/news", enabled: true },
      { id: "8", label: "Gallery", path: "/gallery", enabled: true },
      { id: "9", label: "Events", path: "/events", enabled: true },
      { id: "10", label: "Contact", path: "/contact", enabled: true },
    ]
  },
  theme: {
    primaryColor: "#1e40af",
    secondaryColor: "#1e3a5f",
    accentColor: "#f59e0b",
    backgroundColor: "#f3f4f6",
    cardColor: "#ffffff",
    buttonColor: "#1d4ed8",
    fontFamily: "sans-serif",
    fontSize: "medium",
    fontWeight: "normal",
    borderRadius: "0.5rem",
    shadow: "0 4px 6px -1px rgba(0,0,0,0.1)",
    cardBorderRadius: "0.75rem",
    cardShadow: "0 10px 15px -3px rgba(0,0,0,0.1)",
    cardBackground: "#ffffff",
    cardBorder: "1px solid #e5e7eb",
    cardAnimation: "hover:shadow-xl hover:-translate-y-1",
    hoverEffect: "hover:shadow-xl hover:-translate-y-1",
  },
  pages: {}
};

export function WebsiteSettingsProvider({ children }) {
  const [settings, setSettings] = useState(defaultSettings);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchAllSettings = async () => {
    setLoading(true);
    setError(null);
    try {
      const settingNames = [
        "hero", "statistics", "newsSettings",
        "gallerySettings", "eventsSettings", "footer",
        "navigation", "theme"
      ];

      const results = { ...defaultSettings };

      // Fetch section settings
      for (const name of settingNames) {
        const docRef = doc(db, "websiteSettings", name);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          results[name] = { ...results[name], ...docSnap.data() };
        }
      }

      // Keep legacy hero/footer values as migration fallbacks until the new
      // shared school information document is saved.
      const schoolInfoRef = doc(db, "websiteSettings", "schoolInfo");
      const schoolInfoSnap = await getDoc(schoolInfoRef);
      const legacySchoolInfo = {
        ...defaultSettings.schoolInfo,
        schoolName:
          results.hero?.schoolName ||
          results.navigation?.websiteName ||
          defaultSettings.schoolInfo.schoolName,
        motto: results.hero?.tagline || defaultSettings.schoolInfo.motto,
        phone: results.footer?.phone || defaultSettings.schoolInfo.phone,
        email: results.footer?.email || defaultSettings.schoolInfo.email,
        address: results.footer?.address || defaultSettings.schoolInfo.address,
        workingHours:
          results.footer?.workingHours || defaultSettings.schoolInfo.workingHours,
      };
      results.schoolInfo = schoolInfoSnap.exists()
        ? { ...legacySchoolInfo, ...schoolInfoSnap.data() }
        : legacySchoolInfo;

      // Fetch flat about settings
      const aboutDocRef = doc(db, "websiteSettings", "about");
      const aboutDocSnap = await getDoc(aboutDocRef);
      if (aboutDocSnap.exists()) {
        const aboutData = aboutDocSnap.data();
        Object.keys(aboutData).forEach(key => {
          results[key] = aboutData[key];
        });
      }

      // Fetch page contents
      const pagesSnap = await getDocs(collection(db, "websitePages"));
      const pagesData = {};
      pagesSnap.forEach((doc) => {
        pagesData[doc.id] = doc.data();
      });
      results.pages = pagesData;

      setSettings(results);
    } catch (err) {
      console.error("Error fetching website settings:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
     
    fetchAllSettings();
  }, []);

  const updateSetting = async (key, data) => {
    try {
      // If it's an about setting (starts with "about"), save to about document
      if (key.startsWith("about")) {
        const aboutDocRef = doc(db, "websiteSettings", "about");
        const aboutDocSnap = await getDoc(aboutDocRef);
        let aboutData = {};
        if (aboutDocSnap.exists()) {
          aboutData = aboutDocSnap.data();
        }
        aboutData[key] = data;
        await setDoc(aboutDocRef, aboutData);
        setSettings(prev => ({ ...prev, [key]: data }));
        return true;
      }
      
      await setDoc(doc(db, "websiteSettings", key), data);
      setSettings(prev => ({ ...prev, [key]: data }));
      return true;
    } catch (error) {
      console.error("Error updating setting:", error);
      return false;
    }
  };

  const updatePage = async (pageId, data) => {
    try {
      await setDoc(doc(db, "websitePages", pageId), data);
      setSettings(prev => ({
        ...prev,
        pages: { ...prev.pages, [pageId]: data }
      }));
      return true;
    } catch (error) {
      console.error("Error updating page:", error);
      return false;
    }
  };

  const refresh = fetchAllSettings;

  const value = {
    settings,
    loading,
    error,
    updateSetting,
    updatePage,
    refresh,
    setSettings,
  };

  return (
    <WebsiteSettingsContext.Provider value={value}>
      {children}
    </WebsiteSettingsContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useWebsiteSettings() {
  const context = useContext(WebsiteSettingsContext);
  if (!context) {
    throw new Error("useWebsiteSettings must be used within a WebsiteSettingsProvider");
  }
  return context;
}
