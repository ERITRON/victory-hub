// src/context/AttendanceContext.jsx
import { createContext, useContext, useState } from "react";

const AttendanceContext = createContext();

// eslint-disable-next-line react-refresh/only-export-components
export function useAttendance() {
  return useContext(AttendanceContext);
}

export function AttendanceProvider({ children }) {
  const [attendanceData, setAttendanceData] = useState([]);
  const [loading, setLoading] = useState(false);

  const calculatePercentage = (present, total) => {
    if (total === 0) return 0;
    return Math.round((present / total) * 100);
  };

  const getAttendanceStatus = (percentage) => {
    if (percentage >= 90) {
      return {
        label: "Excellent",
        color: "bg-green-100 text-green-700",
        icon: "🌟",
      };
    } else if (percentage >= 75) {
      return {
        label: "Good",
        color: "bg-blue-100 text-blue-700",
        icon: "👍",
      };
    } else if (percentage >= 50) {
      return {
        label: "Concern",
        color: "bg-yellow-100 text-yellow-700",
        icon: "⚠️",
      };
    } else {
      return {
        label: "Critical",
        color: "bg-red-100 text-red-700",
        icon: "🚨",
      };
    }
  };

  const getClassAttendanceSummary = (grade, section) => {
    const classData = attendanceData.filter(
      (a) => a.grade === grade && a.section === section
    );
    
    const total = classData.length;
    const present = classData.filter((a) => a.status === "Present").length;
    const absent = classData.filter((a) => a.status === "Absent").length;
    const late = classData.filter((a) => a.status === "Late").length;
    const excused = classData.filter((a) => a.status === "Excused").length;
    const percentage = calculatePercentage(present, total);

    return { total, present, absent, late, excused, percentage };
  };

  const getStudentAttendance = (studentId) => {
    return attendanceData.filter((a) => a.studentId === studentId);
  };

  const getAttendanceByDate = (date) => {
    return attendanceData.filter((a) => a.date === date);
  };

  const value = {
    attendanceData,
    setAttendanceData,
    loading,
    setLoading,
    calculatePercentage,
    getAttendanceStatus,
    getClassAttendanceSummary,
    getStudentAttendance,
    getAttendanceByDate,
  };

  return (
    <AttendanceContext.Provider value={value}>
      {children}
    </AttendanceContext.Provider>
  );
}