// src/context/NotificationContext.jsx
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { 
  db,  // ✅ ADD THIS IMPORT
  collection, 
  deleteDoc, 
  doc, 
  limit, 
  onSnapshot, 
  orderBy, 
  query, 
  serverTimestamp, 
  updateDoc, 
  where, 
  writeBatch 
} from "../supabase/supabase";
import {
  isNotificationExpired,
  normalizeNotification,
} from "../services/notificationModel";
import { useAuth } from "./AuthContext";

const NotificationContext = createContext(null);
const NOTIFICATIONS_LIMIT = 100;

function getErrorMessage(error) {
  return error instanceof Error ? error.message : "An unexpected error occurred";
}

export function NotificationProvider({ children }) {
  const { user } = useAuth();
  const userId = user?.uid;
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    setNotifications([]);
    setError(null);
    if (!userId) {
      setLoading(false);
      return undefined;
    }

    setLoading(true);

    // ✅ FIXED: Use snake_case column names (user_id, created_at)
    // ✅ FIXED: db is now properly imported
    const notificationsQuery = query(
      collection(db, "notifications"),
      where("user_id", "=", userId),
      orderBy("created_at", "desc"),
      limit(NOTIFICATIONS_LIMIT)
    );

    const unsubscribe = onSnapshot(
      notificationsQuery,
      (snapshot) => {
        const nextNotifications = snapshot.docs
          .map((notificationDoc) =>
            normalizeNotification(notificationDoc.id, notificationDoc.data())
          )
          .filter((notification) => !isNotificationExpired(notification));
        setNotifications(nextNotifications);
        setError(null);
        setLoading(false);
      },
      (snapshotError) => {
        console.error("Notification snapshot error:", snapshotError);
        setNotifications([]);
        setError(getErrorMessage(snapshotError));
        setLoading(false);
      }
    );

    return unsubscribe;
  }, [userId]);

  const runOperation = useCallback(async (operation) => {
    setError(null);
    try {
      return await operation();
    } catch (operationError) {
      setError(getErrorMessage(operationError));
      throw operationError;
    }
  }, []);

  const requireCurrentUser = useCallback(() => {
    if (!userId) {
      throw new Error("You must be signed in to manage notifications");
    }
    return userId;
  }, [userId]);

  const markAsRead = useCallback(
    (notificationId) =>
      runOperation(async () => {
        requireCurrentUser();
        const notification = notifications.find(
          (item) => item.id === notificationId
        );
        if (!notification) {
          throw new Error("Notification not found");
        }
        if (notification.read) {
          return;
        }
        await updateDoc(doc(db, "notifications", notificationId), {
          read: true,
          read_at: serverTimestamp(),
        });
      }),
    [notifications, requireCurrentUser, runOperation]
  );

  const markAllAsRead = useCallback(
    () =>
      runOperation(async () => {
        requireCurrentUser();
        const unreadNotifications = notifications.filter(
          (notification) => !notification.read
        );
        if (unreadNotifications.length === 0) {
          return;
        }
        const batch = writeBatch(db);
        unreadNotifications.forEach((notification) => {
          batch.update(doc(db, "notifications", notification.id), {
            read: true,
            read_at: serverTimestamp(),
          });
        });
        await batch.commit();
      }),
    [notifications, requireCurrentUser, runOperation]
  );

  const deleteNotification = useCallback(
    (notificationId) =>
      runOperation(async () => {
        requireCurrentUser();
        const notificationExists = notifications.some(
          (notification) => notification.id === notificationId
        );
        if (!notificationExists) {
          throw new Error("Notification not found");
        }
        await deleteDoc(doc(db, "notifications", notificationId));
      }),
    [notifications, requireCurrentUser, runOperation]
  );

  const unreadCount = useMemo(
    () => notifications.filter((notification) => !notification.read).length,
    [notifications]
  );

  const value = useMemo(
    () => ({
      notifications,
      unreadCount,
      loading,
      error,
      markAsRead,
      markAllAsRead,
      deleteNotification,
    }),
    [
      notifications,
      unreadCount,
      loading,
      error,
      markAsRead,
      markAllAsRead,
      deleteNotification,
    ]
  );

  return (
    <NotificationContext.Provider value={value}>
      {children}
    </NotificationContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useNotifications() {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error(
      "useNotifications must be used within a NotificationProvider"
    );
  }
  return context;
}