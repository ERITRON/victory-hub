// src/context/AuthContext.jsx
import { createContext, useContext, useState, useEffect } from "react";
import { 
  auth, 
  db,  // ✅ db is imported here
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  sendPasswordResetEmail, 
  onAuthStateChanged, 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  collection, 
  query, 
  where, 
  getDocs 
} from "../supabase/supabase";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [role, setRole] = useState(null);
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchUserRole = async (uid) => {
    try {
      // First check users collection
      const userDoc = await getDoc(doc(db, "users", uid));
      if (userDoc.exists()) {
        const data = userDoc.data();
        setRole(data.role || "user");
        setUserData(data);
        return data;
      } else {
        // If not in users, check students
        const studentDoc = await getDoc(doc(db, "students", uid));
        if (studentDoc.exists()) {
          const data = studentDoc.data();
          setRole("student");
          setUserData(data);
          return data;
        } else {
          setRole("user");
          setUserData(null);
          return null;
        }
      }
    } catch (error) {
      console.error("Error fetching user role:", error);
      setRole("user");
      setUserData(null);
      return null;
    }
  };

  // Re-fetches the current user's profile row (users/students), so
  // pages that just updated something about the user (avatar, name,
  // phone) can refresh what useAuth() exposes without a full reload.
  const refreshUserData = async () => {
    if (!user?.uid) return null;
    return fetchUserRole(user.uid);
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        setUser(firebaseUser);
        await fetchUserRole(firebaseUser.uid);
      } else {
        setUser(null);
        setRole(null);
        setUserData(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // ============================================
  // CREATE USER WITH ROLE (Strict Hierarchy)
  // ============================================
  const createUserWithRole = async (email, password, roleType, additionalData = {}) => {
    setLoading(true);
    setError(null);
    try {
      const isFirstSetup = !auth.currentUser;
      const isSuperAdminCreation = roleType === "super_admin";

      if (!isFirstSetup || !isSuperAdminCreation) {
        const canCreate = canUserCreateRole(role, roleType);
        if (!canCreate) {
          throw new Error(`You don't have permission to create a ${roleType} account`);
        }
      }

      console.log("Creating user:", { email, roleType, isFirstSetup });

      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const uid = userCredential.user.uid;

      const userData = {
        email,
        role: roleType,
        createdAt: new Date().toISOString(),
        status: "active",
        createdBy: auth.currentUser?.uid || "system",
        createdByRole: role || "system",
        ...additionalData,
      };

      await setDoc(doc(db, "users", uid), userData);
      await createRoleProfile(uid, roleType, additionalData);
      await logUserAction(uid, "user_created", {
        role: roleType,
        email,
        createdBy: auth.currentUser?.uid || "system",
        createdByRole: role || "system",
      });

      return { uid, ...userData };
    } catch (error) {
      console.error("Create user error:", error);
      setError(error.message);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // ============================================
  // CREATE ROLE PROFILE
  // ============================================
  const createRoleProfile = async (uid, roleType, additionalData) => {
    const profileData = {
      userId: uid,
      email: additionalData.email,
      ...additionalData,
      createdAt: new Date().toISOString(),
      status: "active",
    };

    const collections = {
      teacher: "teachers",
      parent: "parents",
      student: "students",
      admin: "admins",
      owner: "owners",
      super_admin: "superAdmins",
      librarian: "librarians",
      vice_principal: "vicePrincipals",
    };

    if (collections[roleType]) {
      await setDoc(doc(db, collections[roleType], uid), profileData);
    }
  };

  // ============================================
  // STRICT ROLE HIERARCHY CHECKS
  // ============================================
  const canUserCreateRole = (currentRole, targetRole) => {
    if (!currentRole) {
      return targetRole === "super_admin";
    }
    if (currentRole === "super_admin") {
      return targetRole === "owner";
    }
    if (currentRole === "owner") {
      return targetRole === "admin";
    }
    if (currentRole === "admin") {
      return ["vice_principal", "teacher", "parent", "student", "librarian"].includes(targetRole);
    }
    if (currentRole === "vice_principal") {
      return false;
    }
    return false;
  };

  // ============================================
  // GET ROLES CURRENT USER CAN CREATE
  // ============================================
  const getCreatableRoles = () => {
    switch (role) {
      case "super_admin":
        return ["owner"];
      case "owner":
        return ["admin"];
      case "admin":
        return ["vice_principal", "teacher", "parent", "student", "librarian"];
      default:
        return [];
    }
  };

  // ============================================
  // GET USERS BY ROLE
  // ============================================
  const getUsersByRole = async (roleType) => {
    try {
      const q = query(collection(db, "users"), where("role", "==", roleType));
      const snap = await getDocs(q);
      return snap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
    } catch (error) {
      console.error("Error fetching users:", error);
      return [];
    }
  };

  // ============================================
  // GET VISIBLE USERS
  // ============================================
  const getVisibleUsers = async () => {
    try {
      let rolesToFetch = [];
      switch (role) {
        case "super_admin":
          rolesToFetch = ["owner", "admin", "vice_principal", "teacher", "parent", "student", "librarian"];
          break;
        case "owner":
          rolesToFetch = ["admin", "vice_principal", "teacher", "parent", "student", "librarian"];
          break;
        case "admin":
          rolesToFetch = ["vice_principal", "teacher", "parent", "student", "librarian"];
          break;
        default:
          rolesToFetch = [];
      }

      let allUsers = [];
      for (const r of rolesToFetch) {
        const users = await getUsersByRole(r);
        allUsers = [...allUsers, ...users];
      }
      return allUsers;
    } catch (error) {
      console.error("Error fetching visible users:", error);
      return [];
    }
  };

  // ============================================
  // UPDATE USER STATUS
  // ============================================
  const updateUserStatus = async (uid, status) => {
    try {
      await updateDoc(doc(db, "users", uid), {
        status,
        updatedAt: new Date().toISOString(),
        updatedBy: auth.currentUser?.uid,
      });
      return true;
    } catch (error) {
      console.error("Error updating user status:", error);
      return false;
    }
  };

  // ============================================
  // DELETE USER
  // ============================================
  const deleteUser = async (uid) => {
    try {
      await updateDoc(doc(db, "users", uid), {
        status: "deleted",
        deletedAt: new Date().toISOString(),
        deletedBy: auth.currentUser?.uid,
      });
      return true;
    } catch (error) {
      console.error("Error deleting user:", error);
      return false;
    }
  };

  // ============================================
  // LOG USER ACTION
  // ============================================
  const logUserAction = async (userId, action, details = {}) => {
    try {
      await setDoc(doc(collection(db, "auditLogs")), {
        userId,
        action,
        details,
        timestamp: new Date().toISOString(),
        ipAddress: "0.0.0.0",
        userAgent: navigator.userAgent,
      });
    } catch (error) {
      console.error("Error logging action:", error);
    }
  };

  // ============================================
  // LOGIN
  // ============================================
  const login = async (email, password) => {
    setLoading(true);
    setError(null);
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      await logUserAction(userCredential.user.uid, "login", { email });
      return userCredential.user;
    } catch (error) {
      setError(error.message);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // ============================================
  // LOGOUT
  // ============================================
  const logout = async () => {
    try {
      if (auth.currentUser) {
        await logUserAction(auth.currentUser.uid, "logout");
      }
      await signOut(auth);
    } catch (error) {
      console.error("Error logging out:", error);
      throw error;
    }
  };

  // ============================================
  // RESET PASSWORD
  // ============================================
  const resetPassword = async (email) => {
    setLoading(true);
    setError(null);
    try {
      await sendPasswordResetEmail(auth, email);
    } catch (error) {
      setError(error.message);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // ============================================
  // CHECK USER ROLE
  // ============================================
  const hasRole = (requiredRoles) => {
    if (!role) return false;
    if (Array.isArray(requiredRoles)) {
      return requiredRoles.includes(role);
    }
    return role === requiredRoles;
  };

  const value = {
    user,
    role,
    userData,
    refreshUserData,
    loading,
    error,
    login,
    logout,
    resetPassword,
    createUserWithRole,
    getUsersByRole,
    getVisibleUsers,
    updateUserStatus,
    deleteUser,
    hasRole,
    getCreatableRoles,
    canUserCreateRole,
    setUser,
    setRole,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}