// src/App.jsx
import { Routes, Route, Navigate } from "react-router-dom";
import { Suspense, lazy } from "react";
import { Helmet } from "react-helmet-async";
import { useAuth } from "./context/AuthContext";
import { WebsiteSettingsProvider, useWebsiteSettings } from "./context/WebsiteSettingsContext";

// Layout Components
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";

// Public Components (Homepage)
import Hero from "./components/Hero";
import AboutSection from "./components/AboutSection";
import Statistics from "./components/Statistics";
import NewsSection from "./components/NewsSection";
import GallerySection from "./components/GallerySection";

// Lazy Load Pages
const Login = lazy(() => import("./pages/auth/Login"));
const ForgotPassword = lazy(() => import("./pages/auth/ForgotPassword"));
const ResetPassword = lazy(() => import("./pages/auth/ResetPassword"));

// Super Admin Pages
const SuperAdminDashboard = lazy(() => import("./pages/org/SuperAdminDashboard"));
const SuperAdminSetup = lazy(() => import("./pages/auth/SuperAdminSetup"));
const OwnerManagement = lazy(() => import("./pages/org/OwnerManagement"));

// Owner Pages
const OwnerDashboard = lazy(() => import("./pages/org/OwnerDashboard"));

// Admin Pages (Principal)
const AdminDashboard = lazy(() => import("./pages/org/AdminDashboard"));

// Vice Principal Pages
const VicePrincipalDashboard = lazy(() => import("./pages/vice-principal/VicePrincipalDashboard"));
const VicePrincipalManagement = lazy(() => import("./pages/vice-principal/VicePrincipalManagement"));
const VicePrincipalProfile = lazy(() => import("./pages/vice-principal/VicePrincipalProfile"));
const DailyOperations = lazy(() => import("./pages/vice-principal/DailyOperations"));
const ClassroomMonitoring = lazy(() => import("./pages/vice-principal/ClassroomMonitoring"));
const TodaysSchedule = lazy(() => import("./pages/vice-principal/TodaysSchedule"));
const TeacherAttendanceManagement = lazy(() => import("./pages/teachers/TeacherAttendanceManagement"));

// Librarian Pages
const LibrarianManagement = lazy(() => import("./pages/library/LibrarianManagement"));

// Academic Pages
const AcademicOverview = lazy(() => import("./pages/results/AcademicOverview"));
const TeacherPerformance = lazy(() => import("./pages/teachers/TeacherPerformance"));
const Discipline = lazy(() => import("./pages/attendance/Discipline"));


// User Management
const UserManagement = lazy(() => import("./pages/org/UserManagement"));

// Library System
const LibraryDashboard = lazy(() => import("./pages/library/LibraryDashboard"));
const BookManagement = lazy(() => import("./pages/library/BookManagement"));
const BorrowReturn = lazy(() => import("./pages/library/BorrowReturn"));
const LibraryMembers = lazy(() => import("./pages/library/Members"));
const Categories = lazy(() => import("./pages/library/Categories"));
const History = lazy(() => import("./pages/library/History"));
const Reports = lazy(() => import("./pages/library/Reports"));

// Existing Dashboards
const StudentDashboard = lazy(() => import("./pages/students/StudentDashboard"));
const ParentDashboard = lazy(() => import("./pages/parents/ParentDashboard"));
const TeacherDashboard = lazy(() => import("./pages/teachers/TeacherDashboard"));
const TeacherClasses = lazy(() => import("./pages/teachers/TeacherClasses"));
const TeacherStudents = lazy(() => import("./pages/teachers/TeacherStudents"));

// Existing Pages
const AddStudent = lazy(() => import("./pages/students/AddStudent"));
const StudentsList = lazy(() => import("./pages/students/StudentList"));
const StudentManagement = lazy(() => import("./pages/students/StudentManagement"));
const StudentReports = lazy(() => import("./pages/students/StudentReports"));
const PerformanceAnalysis = lazy(() => import("./pages/students/PerformanceAnalysis"));
const EditStudent = lazy(() => import("./pages/students/EditStudent"));
const AddTeacher = lazy(() => import("./pages/teachers/AddTeacher"));
const TeacherList = lazy(() => import("./pages/teachers/TeacherList"));
const EditTeacher = lazy(() => import("./pages/teachers/EditTeacher"));
const TeacherManagement = lazy(() => import("./pages/teachers/TeacherManagement"));
const ParentManagement = lazy(() => import("./pages/parents/ParentManagement"));
const AddParent = lazy(() => import("./pages/parents/AddParent"));
const EditParent = lazy(() => import("./pages/parents/EditParent"));
const Results = lazy(() => import("./pages/results/Results"));
const TeacherResults = lazy(() => import("./pages/teachers/TeacherResults"));
const StudentResults = lazy(() => import("./pages/students/StudentResults"));
const ParentChildren = lazy(() => import("./pages/parents/ParentChildren"));
const ParentResults = lazy(() => import("./pages/parents/ParentResults"));
const ParentResultsView = lazy(() => import("./pages/parents/ParentResultsView"));
const ReportCards = lazy(() => import("./pages/results/ReportCards"));
const ClassPerformanceReport = lazy(() => import("./pages/results/ClassPerformanceReport"));
const TopPerformers = lazy(() => import("./pages/results/TopPerformers"));
const SubjectAnalysis = lazy(() => import("./pages/results/SubjectAnalysis"));
const ResultsManagement = lazy(() => import("./pages/results/ResultsManagement"));
const Attendance = lazy(() => import("./pages/attendance/Attendance"));
const AttendanceReport = lazy(() => import("./pages/attendance/AttendanceReport"));
const AssignTeacher = lazy(() => import("./pages/teachers/AssignTeacher"));
const TeacherAssignmentsList = lazy(() => import("./pages/teachers/TeacherAssignmentsList"));
const AssignHomeroomTeacher = lazy(() => import("./pages/teachers/AssignHomeroomTeacher"));
const HomeroomAssignmentsList = lazy(() => import("./pages/teachers/HomeroomAssignmentsList"));
const EditHomeroomAssignment = lazy(() => import("./pages/teachers/EditHomeroomAssignment"));
const EditTeacherAssignment = lazy(() => import("./pages/teachers/EditTeacherAssignment"));
const GradeStudents = lazy(() => import("./pages/students/GradeStudents"));
const SectionStudents = lazy(() => import("./pages/students/SectionStudents"));
const Parent = lazy(() => import("./pages/public/Parent"));
const Student = lazy(() => import("./pages/public/Student"));
const Teacher = lazy(() => import("./pages/public/Teacher"));
const AdminApproval = lazy(() => import("./pages/org/AdminApproval"));
const SchoolSettings = lazy(() => import("./pages/settings/SchoolSettings"));
const SetupAdmin = lazy(() => import("./pages/auth/SetupAdmin"));
const About = lazy(() => import("./pages/public/About"));
const ProfileSettings = lazy(() => import("./pages/settings/ProfileSettings"));
const AdminProfile = lazy(() => import("./pages/org/AdminProfile"));
const TeacherProfile = lazy(() => import("./pages/teachers/TeacherProfile"));
const ParentProfile = lazy(() => import("./pages/parents/ParentProfile"));
const StudentProfile = lazy(() => import("./pages/students/StudentProfile"));

// Public Pages
const News = lazy(() => import("./pages/public/News"));
const Gallery = lazy(() => import("./pages/public/Gallery"));
const Events = lazy(() => import("./pages/public/Events"));
const Contact = lazy(() => import("./pages/public/Contact"));
const Admissions = lazy(() => import("./pages/public/Admissions"));
const NotFound = lazy(() => import("./pages/public/NotFound"));
const Notifications = lazy(() => import("./pages/Notifications"));

// Attendance System Imports
const TeacherAttendance = lazy(() => import("./pages/teachers/TeacherAttendance"));
const ParentAttendance = lazy(() => import("./pages/parents/ParentAttendance"));
const StudentAttendance = lazy(() => import("./pages/students/StudentAttendance"));

// Admin Management Pages
const NewsManagement = lazy(() => import("./pages/admin/NewsManagement"));
const DocumentsManagement = lazy(() => import("./pages/admin/DocumentsManagement"));
const AcademicCalendar = lazy(() => import("./pages/admin/AcademicCalendar"));
const GalleryManagement = lazy(() => import("./pages/admin/GalleryManagement"));
const EventsManagement = lazy(() => import("./pages/admin/EventsManagement"));
const AdmissionsManagement = lazy(() => import("./pages/admin/AdmissionsManagement"));
const WebsiteSettings = lazy(() => import("./pages/settings/WebsiteSettings"));

// Other Features
const Promotion = lazy(() => import("./pages/results/Promotion"));
const TeacherAssignmentsUpload = lazy(() => import("./pages/teachers/TeacherAssignmentsUpload"));
const StudentAssignments = lazy(() => import("./pages/students/StudentAssignments"));
const MyDocuments = lazy(() => import("./pages/students/MyDocuments"));
const ChatPage = lazy(() => import("./pages/chat/ChatPage"));
const Schedule = lazy(() => import("./pages/settings/Schedule"));
const AdminScheduleManagement = lazy(() => import("./pages/org/AdminScheduleManagement"));

// Protected Route Components
import ProtectedRoute from "./components/ProtectedRoute";
import RoleProtectedRoute from "./components/RoleProtectedRoute";
import ErrorBoundary from "./components/ErrorBoundary";

// Loading Component
const LoadingSpinner = () => (
  <div className="min-h-screen flex items-center justify-center bg-gray-50">
    <div className="text-center">
      <div className="relative">
        <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-700 mx-auto"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="h-8 w-8 rounded-full bg-blue-100/20 backdrop-blur-sm"></div>
        </div>
      </div>
      <p className="mt-4 text-gray-600 font-medium">Loading...</p>
      <p className="text-sm text-gray-400 mt-1">Please wait while we prepare your page</p>
    </div>
  </div>
);

// Default site-wide SEO (title, description, Open Graph, keywords).
// Pulls school name/description from WebsiteSettingsContext with sensible
// fallbacks; individual pages can override via their own <Helmet>.
function DefaultSEO() {
  const { settings } = useWebsiteSettings();

  const schoolName =
    settings?.schoolInfo?.schoolName ||
    settings?.hero?.schoolName ||
    settings?.navigation?.websiteName ||
    "Tech Zone Academy";

  const description =
    settings?.hero?.description ||
    settings?.aboutDescription ||
    "Tech Zone Academy provides quality education for every child from KG to Grade 8 — building bright futures through a modern curriculum, expert teachers, and holistic development.";

  const rawOgImage =
    settings?.hero?.backgroundImage ||
    settings?.navigation?.logo ||
    "/images/og-default.jpg";

  // Base site URL (set VITE_APP_URL to your production domain when deploying).
  // Crawlers require absolute URLs, so resolve relative paths against it.
  const siteUrl = (import.meta.env.VITE_APP_URL || "").replace(/\/$/, "");
  const ogImage = /^https?:\/\//.test(rawOgImage)
    ? rawOgImage
    : `${siteUrl}${rawOgImage}`;

  const keywords = [
    schoolName,
    "Tech Zone Academy",
    "school",
    "education",
    "academy",
    "students",
    "teachers",
    "admissions",
    "KG to Grade 8",
    "quality education",
  ].join(", ");

  return (
    <Helmet
      defaultTitle={`${schoolName} - ${settings?.schoolInfo?.motto || "Building Bright Futures"}`}
      titleTemplate={`%s | ${schoolName}`}
    >
      <html lang="en" />
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords} />

      {/* Open Graph */}
      <meta property="og:type" content="website" />
      <meta property="og:site_name" content={schoolName} />
      <meta property="og:url" content={siteUrl} />
      <meta
        property="og:title"
        content={`${schoolName} - ${settings?.schoolInfo?.motto || "Building Bright Futures"}`}
      />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={ogImage} />

      {/* Twitter Card */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta
        name="twitter:title"
        content={`${schoolName} - ${settings?.schoolInfo?.motto || "Building Bright Futures"}`}
      />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={ogImage} />
    </Helmet>
  );
}

// Home Page Component
function HomePage() {
  return (
    <>
      <Hero />
      <AboutSection />
      <Statistics />
      <NewsSection />
      <GallerySection />
      <Footer />
    </>
  );
}

function App() {
  const { loading } = useAuth();

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <WebsiteSettingsProvider>
      <DefaultSEO />
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Navbar />
        
        <main className="flex-grow">
          <ErrorBoundary errorMessage="We couldn't load this page. Please try refreshing.">
            <Suspense fallback={<LoadingSpinner />}>
              <Routes>
              {/* ============================================
                     PUBLIC ROUTES
                  ============================================ */}
              <Route path="/" element={<HomePage />} />
              <Route path="/login" element={<Login />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/reset-password" element={<ResetPassword />} />
              <Route path="/about" element={<About />} />
              <Route path="/student" element={<Student />} />
              <Route path="/teacher" element={<Teacher />} />
              <Route path="/parent" element={<Parent />} />
              <Route path="/news" element={<News />} />
              <Route path="/news/:id" element={<News />} />
              <Route path="/gallery" element={<Gallery />} />
              <Route path="/events" element={<Events />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/admissions" element={<Admissions />} />
              <Route path="/notifications" element={<Notifications />} />
              
              {/* ============================================
                     SUPER ADMIN SETUP
                  ============================================ */}
              <Route path="/super-admin-setup" element={<SuperAdminSetup />} />

              {/* ============================================
                     SUPER ADMIN DASHBOARD
                  ============================================ */}
              <Route 
                path="/super-admin/dashboard" 
                element={
                  <RoleProtectedRoute allowedRole="super_admin">
                    <SuperAdminDashboard />
                  </RoleProtectedRoute>
                } 
              />

              {/* ============================================
                     OWNER MANAGEMENT
                  ============================================ */}
              <Route 
                path="/owner-management" 
                element={
                  <RoleProtectedRoute allowedRole="super_admin">
                    <OwnerManagement />
                  </RoleProtectedRoute>
                } 
              />

              {/* ============================================
                     OWNER DASHBOARD
                  ============================================ */}
              <Route 
                path="/owner/dashboard" 
                element={
                  <RoleProtectedRoute allowedRole="owner">
                    <OwnerDashboard />
                  </RoleProtectedRoute>
                } 
              />

              {/* ============================================
                     ADMIN DASHBOARD (Principal)
                  ============================================ */}
              <Route 
                path="/admin-dashboard" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <AdminDashboard />
                  </RoleProtectedRoute>
                } 
              />

              {/* ============================================
                     VICE PRINCIPAL DASHBOARD
                  ============================================ */}
              <Route 
                path="/vice-principal/dashboard" 
                element={
                  <RoleProtectedRoute allowedRole="vice_principal">
                    <VicePrincipalDashboard />
                  </RoleProtectedRoute>
                } 
              />

              {/* ============================================
                     VICE PRINCIPAL PROFILE
                  ============================================ */}
              <Route 
                path="/vice-principal/profile" 
                element={
                  <RoleProtectedRoute allowedRole="vice_principal">
                    <VicePrincipalProfile />
                  </RoleProtectedRoute>
                } 
              />

              {/* ============================================
                     VICE PRINCIPAL MANAGEMENT
                  ============================================ */}
              <Route 
                path="/vice-principal-management" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <VicePrincipalManagement />
                  </RoleProtectedRoute>
                } 
              />

              {/* ============================================
                     DAILY OPERATIONS (VP)
                  ============================================ */}
              <Route 
                path="/vice-principal/operations" 
                element={
                  <RoleProtectedRoute allowedRole="vice_principal">
                    <DailyOperations />
                  </RoleProtectedRoute>
                } 
              />

              {/* ============================================
                     CLASSROOM MONITORING (VP)
                  ============================================ */}
              <Route 
                path="/vice-principal/classroom-monitoring" 
                element={
                  <RoleProtectedRoute allowedRole="vice_principal">
                    <ClassroomMonitoring />
                  </RoleProtectedRoute>
                } 
              />

              {/* ============================================
                     TODAY'S SCHEDULE (VP)
                  ============================================ */}
              <Route 
                path="/vice-principal/schedule" 
                element={
                  <RoleProtectedRoute allowedRole="vice_principal">
                    <TodaysSchedule />
                  </RoleProtectedRoute>
                } 
              />

              {/* ============================================
                     STUDENT DISCIPLINE - Both Principal & VP
                  ============================================ */}
              <Route 
                path="/discipline" 
                element={
                  <RoleProtectedRoute 
                    allowedRoles={["admin", "vice_principal"]}
                    unauthorizedRedirect="/vice-principal/dashboard"
                  >
                    <Discipline />
                  </RoleProtectedRoute>
                } 
              />

              {/* ============================================
                     ATTENDANCE REPORTS - Both Principal & VP
                  ============================================ */}
              <Route 
                path="/attendance-report" 
                element={
                  <RoleProtectedRoute 
                    allowedRoles={["admin", "vice_principal"]}
                    unauthorizedRedirect="/vice-principal/dashboard"
                  >
                    <AttendanceReport />
                  </RoleProtectedRoute>
                } 
              />

              {/* ============================================
                     TEACHER ATTENDANCE - Both Principal & VP
                  ============================================ */}
              <Route 
                path="/teacher-attendance" 
                element={
                  <RoleProtectedRoute 
                    allowedRoles={["admin", "vice_principal"]}
                    unauthorizedRedirect="/vice-principal/dashboard"
                  >
                    <TeacherAttendanceManagement />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/vice-principal/teacher-attendance" 
                element={
                  <RoleProtectedRoute 
                    allowedRoles={["admin", "vice_principal"]}
                    unauthorizedRedirect="/vice-principal/dashboard"
                  >
                    <TeacherAttendanceManagement />
                  </RoleProtectedRoute>
                } 
              />

              {/* ============================================
                     ACADEMIC PAGES (Principal Only)
                  ============================================ */}
              <Route 
                path="/academic-overview" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <AcademicOverview />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/teacher-performance" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <TeacherPerformance />
                  </RoleProtectedRoute>
                } 
              />

              {/* ============================================
                     LIBRARIAN DASHBOARD
                  ============================================ */}
              <Route 
                path="/librarian/dashboard" 
                element={<Navigate to="/library" replace />} 
              />

              {/* ============================================
                     LIBRARIAN MANAGEMENT
                  ============================================ */}
              <Route 
                path="/librarian-management" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <LibrarianManagement />
                  </RoleProtectedRoute>
                } 
              />

              {/* ============================================
                     LIBRARY SYSTEM
                  ============================================ */}
              <Route 
                path="/library" 
                element={
                  <RoleProtectedRoute allowedRole="librarian">
                    <LibraryDashboard />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/library/books" 
                element={
                  <RoleProtectedRoute allowedRole="librarian">
                    <BookManagement />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/library/borrow" 
                element={
                  <RoleProtectedRoute allowedRole="librarian">
                    <BorrowReturn />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/library/members" 
                element={
                  <RoleProtectedRoute allowedRole="librarian">
                    <LibraryMembers />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/library/categories" 
                element={
                  <RoleProtectedRoute allowedRole="librarian">
                    <Categories />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/library/history" 
                element={
                  <RoleProtectedRoute allowedRole="librarian">
                    <History />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/library/reports" 
                element={
                  <RoleProtectedRoute allowedRole="librarian">
                    <Reports />
                  </RoleProtectedRoute>
                } 
              />

              {/* ============================================
                     USER MANAGEMENT
                  ============================================ */}
              <Route 
                path="/user-management" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <UserManagement />
                  </RoleProtectedRoute>
                } 
              />

              {/* ============================================
                     ADMIN MANAGEMENT
                  ============================================ */}
              <Route 
                path="/admin" 
                element={<Navigate to="/admin-dashboard" replace />} 
              />
              <Route 
                path="/admin-profile" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <AdminProfile />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/admin-approval" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <AdminApproval />
                  </RoleProtectedRoute>
                } 
              />
              
              {/* Admin Management Pages */}
              <Route 
                path="/admin/news" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <NewsManagement />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/admin/documents" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <DocumentsManagement />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/admin/academic-calendar" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <AcademicCalendar />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/admin/gallery" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <GalleryManagement />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/admin/events" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <EventsManagement />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/admin/admissions" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <AdmissionsManagement />
                  </RoleProtectedRoute>
                } 
              />
              
              {/* Admin Settings */}
              <Route 
                path="/settings" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <SchoolSettings />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/website-settings" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <WebsiteSettings />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/admin-schedule" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <AdminScheduleManagement />
                  </RoleProtectedRoute>
                } 
              />
              <Route
                path="/report-cards"
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <ReportCards />
                  </RoleProtectedRoute>
                }
              />
              <Route
                path="/class-performance"
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <ClassPerformanceReport />
                  </RoleProtectedRoute>
                }
              />
              <Route
                path="/top-performers"
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <TopPerformers />
                  </RoleProtectedRoute>
                }
              />
              <Route
                path="/subject-analysis"
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <SubjectAnalysis />
                  </RoleProtectedRoute>
                }
              />
              <Route
                path="/results-management"
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <ResultsManagement />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/promotion" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <Promotion />
                  </RoleProtectedRoute>
                } 
              />
              
              {/* STUDENT MANAGEMENT */}
              <Route 
                path="/add-student" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <AddStudent />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/students" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <StudentsList />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/student-list" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <StudentsList />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/student-list/:grade" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <GradeStudents />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/student-list/:grade/:section" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <SectionStudents />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/edit-student/:id" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <EditStudent />
                  </RoleProtectedRoute>
                } 
              />
              <Route
                path="/student-management"
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <StudentManagement />
                  </RoleProtectedRoute>
                }
              />
              <Route
                path="/student-reports"
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <StudentReports />
                  </RoleProtectedRoute>
                }
              />
              <Route
                path="/performance-analysis"
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <PerformanceAnalysis />
                  </RoleProtectedRoute>
                }
              />

              {/* TEACHER MANAGEMENT */}
              <Route 
                path="/add-teacher" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <AddTeacher />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/teacher-list" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <TeacherList />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/edit-teacher/:id" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <EditTeacher />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/teacher-management" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <TeacherManagement />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/assign-teacher" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <AssignTeacher />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/teacher-assignments" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <TeacherAssignmentsList />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/edit-teacher-assignment/:id" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <EditTeacherAssignment />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/assign-homeroom-teacher" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <AssignHomeroomTeacher />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/homeroom-assignments" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <HomeroomAssignmentsList />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/edit-homeroom/:id" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <EditHomeroomAssignment />
                  </RoleProtectedRoute>
                } 
              />

              {/* PARENT MANAGEMENT */}
              <Route 
                path="/parent-management" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <ParentManagement />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/add-parent" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <AddParent />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/edit-parent/:id" 
                element={
                  <RoleProtectedRoute allowedRole="admin">
                    <EditParent />
                  </RoleProtectedRoute>
                } 
              />

              {/* STUDENT ROUTES */}
              <Route 
                path="/student-dashboard" 
                element={
                  <RoleProtectedRoute allowedRole="student">
                    <StudentDashboard />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/student-profile" 
                element={
                  <RoleProtectedRoute allowedRole="student">
                    <StudentProfile />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/student-results" 
                element={
                  <RoleProtectedRoute allowedRole="student">
                    <StudentResults />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/student-attendance" 
                element={
                  <RoleProtectedRoute allowedRole="student">
                    <StudentAttendance />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/student-assignments" 
                element={
                  <RoleProtectedRoute allowedRole="student">
                    <StudentAssignments />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/my-documents" 
                element={
                  <RoleProtectedRoute allowedRoles={["student", "parent"]}>
                    <MyDocuments />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/chat" 
                element={
                  <RoleProtectedRoute allowedRoles={["parent", "teacher", "admin", "vice_principal"]}>
                    <ChatPage />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/student-schedule" 
                element={
                  <RoleProtectedRoute allowedRole="student">
                    <Schedule />
                  </RoleProtectedRoute>
                } 
              />

              {/* TEACHER ROUTES */}
              <Route 
                path="/teacher-dashboard" 
                element={
                  <RoleProtectedRoute allowedRole="teacher">
                    <TeacherDashboard />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/teacher-profile" 
                element={
                  <RoleProtectedRoute allowedRole="teacher">
                    <TeacherProfile />
                  </RoleProtectedRoute>
                } 
              />
              <Route
                path="/teacher-classes"
                element={
                  <RoleProtectedRoute allowedRole="teacher">
                    <TeacherClasses />
                  </RoleProtectedRoute>
                }
              />
              <Route
                path="/teacher-students"
                element={
                  <RoleProtectedRoute allowedRole="teacher">
                    <TeacherStudents />
                  </RoleProtectedRoute>
                }
              />
              <Route 
                path="/teacher-results" 
                element={
                  <RoleProtectedRoute allowedRole="teacher">
                    <TeacherResults />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/teacher-attendance" 
                element={
                  <RoleProtectedRoute allowedRole="teacher">
                    <TeacherAttendance />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/teacher-assignments-upload" 
                element={
                  <RoleProtectedRoute allowedRole="teacher">
                    <TeacherAssignmentsUpload />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/teacher-schedule" 
                element={
                  <RoleProtectedRoute allowedRole="teacher">
                    <Schedule />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/attendance" 
                element={
                  <RoleProtectedRoute allowedRole="teacher">
                    <Attendance />
                  </RoleProtectedRoute>
                } 
              />

              {/* PARENT ROUTES */}
              <Route 
                path="/parent-dashboard" 
                element={
                  <RoleProtectedRoute allowedRole="parent">
                    <ParentDashboard />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/parent-profile" 
                element={
                  <RoleProtectedRoute allowedRole="parent">
                    <ParentProfile />
                  </RoleProtectedRoute>
                } 
              />
              <Route
                path="/parent-children"
                element={
                  <RoleProtectedRoute allowedRole="parent">
                    <ParentChildren />
                  </RoleProtectedRoute>
                }
              />
              <Route 
                path="/parent-results/:studentId" 
                element={
                  <RoleProtectedRoute allowedRole="parent">
                    <ParentResultsView />
                  </RoleProtectedRoute>
                } 
              />
              <Route
                path="/parent-results"
                element={
                  <RoleProtectedRoute allowedRole="parent">
                    <ParentResults />
                  </RoleProtectedRoute>
                }
              />
              <Route 
                path="/parent-attendance" 
                element={
                  <RoleProtectedRoute allowedRole="parent">
                    <ParentAttendance />
                  </RoleProtectedRoute>
                } 
              />
              <Route 
                path="/parent-schedule" 
                element={
                  <RoleProtectedRoute allowedRole="parent">
                    <Schedule />
                  </RoleProtectedRoute>
                } 
              />

              {/* RESULTS ROUTES */}
              <Route 
                path="/results" 
                element={
                  <ProtectedRoute>
                    <Results />
                  </ProtectedRoute>
                } 
              />

              {/* PROFILE SETTINGS */}
              <Route 
                path="/profile" 
                element={
                  <ProtectedRoute>
                    <ProfileSettings />
                  </ProtectedRoute>
                } 
              />

              {/* SETUP ROUTES */}
              <Route path="/setup-admin" element={<SetupAdmin />} />

              {/* ============================================
                     404 - CATCH ALL (must be last)
                  ============================================ */}
              <Route path="*" element={<NotFound />} />
            </Routes>
            </Suspense>
          </ErrorBoundary>
        </main>
      </div>
    </WebsiteSettingsProvider>
  );
}

export default App;
