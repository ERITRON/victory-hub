# Tech Zone Academy Notifications

## Delivery model

- **In-app:** Every notification is stored in the `documents` table under the `notifications` collection and appears live in the navbar bell and `/notifications`. Users can filter, open, mark read, mark all read, and delete their own records.
- **Email:** Important catalog entries also create a queued record under the `mail` collection, and — if `RESEND_API_KEY` is set as an Edge Function secret — are sent immediately via [Resend](https://resend.com). Swap in any other provider by editing `sendEmail()` in `supabase/functions/_shared/notify.ts`.
- **Push and SMS:** Reserved in the catalog for future adapters. Neither channel is enabled until credentials and recipient consent are configured.

The complete role/type/channel/timing policy is the executable catalog in `supabase/functions/_shared/notificationCatalog.ts`. It covers all users, students, teachers, parents, admin, vice principal, librarian, and owner. (There's no cashier role or finance category — this app has no finance module.)

## Automatic triggers

A Postgres trigger on the `documents` table calls the `on-document-change` Edge Function on every insert/update, which listens for:

| Source (`collection`) | Recipients |
| --- | --- |
| `users` create/update | New user, admin registration/approval queue, approved user |
| `results` create/update | Student and linked parent |
| `attendance` create | Student; linked parent when absent or late |
| `teacherAssignmentsUploads` create | Students in the class and linked parents |
| `announcements` create | Students, teachers, parents, and vice principals |
| Password reset completion | The user whose password changed |

Other modules can insert a row into the `notificationEvents` collection with a catalog `type`, `title`, `message`, and either `targetUserIds` or `targetRoles`. The backend validates the type, resolves recipients, deduplicates delivery, and queues important email.

## Scheduled notifications

Insert a row into the `notificationSchedules` collection (via the app's `setDoc`/`addDoc` helpers):

```javascript
{
  type: "school_event",
  title: "Parent-teacher day",
  message: "Parent-teacher conferences are next week.",
  targetUserIds: ["parent_uid"],
  dueAt: new Date().toISOString(),
  status: "pending",
  link: "/parent-dashboard",
  priority: "high",
  relatedId: "event_id",
  relatedType: "event"
}
```

`process-scheduled-notifications` runs every 15 minutes via `pg_cron`. It sends due records once and marks them `sent`. This supports before-event, morning, end-of-day, weekly, monthly, end-of-term, and annual jobs. `cleanup-expired-notifications` removes expired inbox records daily at 03:00.

## Deploy

```bash
supabase functions deploy on-document-change
supabase functions deploy process-scheduled-notifications
supabase functions deploy cleanup-expired-notifications
```

Then run `supabase/schema.sql` (once) and `supabase/functions_setup.sql` (after each functions deploy) in the SQL editor to wire up the webhook trigger and cron schedules — see the comments in those files for the two-minute setup. Optionally set `RESEND_API_KEY` and `EMAIL_FROM` as Edge Function secrets (`supabase secrets set RESEND_API_KEY=...`) to send real emails instead of just queuing them.

## Data ownership

- Clients cannot create inbox records directly (see the RLS policies in `supabase/schema.sql` — tighten these to check `data->>userId` against `auth.uid()` for the `notifications` collection).
- A user should only be able to query, acknowledge, or delete notifications whose `userId` matches their Supabase Auth UID.
- Only staff should be able to create generic event requests; password-change events should be limited to the authenticated user's own UID.
- Mail is backend-only (written with the service role key from Edge Functions, not reachable by the anon key). Notification IDs are deterministic (SHA-1 of the event key) to prevent duplicate delivery if a function retries.
